"""
Tileset loader — loads ALttP sprite sheets and cuts 16x16 tiles.

Supports loading tiles from a grid-based sprite sheet PNG.
Falls back to procedural drawing if sprite sheets are missing.
"""
import pygame
import os

TILE_SIZE = 16


class Tileset:
    """Loads a sprite sheet and provides individual tile Surfaces."""

    def __init__(self, path, tile_w=TILE_SIZE, tile_h=TILE_SIZE,
                 bg_color=None, spacing=0, margin=0):
        """
        Args:
            path: Path to the sprite sheet PNG
            tile_w: Width of each tile (default 16)
            tile_h: Height of each tile (default 16)
            bg_color: Background color to make transparent (e.g., (0,128,128) for teal)
            spacing: Pixels between tiles in the sheet
            margin: Pixels of margin around the sheet edge
        """
        self.path = path
        self.tile_w = tile_w
        self.tile_h = tile_h
        self.tiles = {}  # (col, row) -> Surface
        self.loaded = False

        if not os.path.exists(path):
            print(f"Tileset not found: {path}")
            return

        try:
            self.sheet = pygame.image.load(path).convert_alpha()
            self.loaded = True
        except Exception as e:
            print(f"Failed to load tileset {path}: {e}")
            return

        # Remove background color if specified
        if bg_color and self.loaded:
            for y in range(self.sheet.get_height()):
                for x in range(self.sheet.get_width()):
                    c = self.sheet.get_at((x, y))
                    if (c[0], c[1], c[2]) == bg_color:
                        self.sheet.set_at((x, y), (0, 0, 0, 0))

        # Pre-cut all tiles
        if self.loaded:
            sheet_w, sheet_h = self.sheet.get_size()
            cols = (sheet_w - 2 * margin + spacing) // (tile_w + spacing)
            rows = (sheet_h - 2 * margin + spacing) // (tile_h + spacing)

            for row in range(rows):
                for col in range(cols):
                    x = margin + col * (tile_w + spacing)
                    y = margin + row * (tile_h + spacing)
                    if x + tile_w <= sheet_w and y + tile_h <= sheet_h:
                        tile_surf = pygame.Surface((tile_w, tile_h), pygame.SRCALPHA)
                        tile_surf.blit(self.sheet, (0, 0), (x, y, tile_w, tile_h))
                        self.tiles[(col, row)] = tile_surf

            print(f"Loaded tileset: {path} ({cols}x{rows} = {len(self.tiles)} tiles)")

    def get_tile(self, col, row):
        """Get a tile Surface by its grid position in the sheet."""
        return self.tiles.get((col, row))

    def get_tile_by_index(self, index):
        """Get a tile by linear index (left-to-right, top-to-bottom)."""
        if not self.loaded:
            return None
        sheet_w = self.sheet.get_width()
        cols = sheet_w // self.tile_w
        if cols == 0:
            return None
        col = index % cols
        row = index // cols
        return self.get_tile(col, row)


class TilesetManager:
    """Manages multiple tilesets and maps game tile IDs to sprite sheet tiles."""

    def __init__(self, sprites_dir="sprites"):
        self.sprites_dir = sprites_dir
        self.tilesets = {}  # name -> Tileset
        self.tile_map = {}  # game_tile_id -> (tileset_name, col, row)
        self._cache = {}    # game_tile_id -> Surface (pre-looked-up)

    def load_tileset(self, name, filename, **kwargs):
        """Load a tileset from the sprites directory."""
        path = os.path.join(self.sprites_dir, filename)
        ts = Tileset(path, **kwargs)
        self.tilesets[name] = ts
        return ts.loaded

    def map_tile(self, game_tile_id, tileset_name, col, row):
        """Map a game tile ID to a position in a loaded tileset."""
        self.tile_map[game_tile_id] = (tileset_name, col, row)
        # Pre-cache the lookup
        ts = self.tilesets.get(tileset_name)
        if ts and ts.loaded:
            tile = ts.get_tile(col, row)
            if tile:
                self._cache[game_tile_id] = tile

    def map_tiles_batch(self, tileset_name, mappings):
        """Map multiple tile IDs at once.

        Args:
            tileset_name: Name of the tileset
            mappings: list of (game_tile_id, col, row) tuples
        """
        for game_tile_id, col, row in mappings:
            self.map_tile(game_tile_id, tileset_name, col, row)

    def get_tile(self, game_tile_id):
        """Get the sprite Surface for a game tile ID, or None if not mapped/loaded."""
        return self._cache.get(game_tile_id)

    def has_tile(self, game_tile_id):
        """Check if a sprite exists for this tile ID."""
        return game_tile_id in self._cache

    def draw_tile(self, surf, game_tile_id, x, y):
        """Draw a tile at the given position. Returns True if drawn, False if no sprite."""
        tile = self._cache.get(game_tile_id)
        if tile:
            surf.blit(tile, (x, y))
            return True
        return False


# ══════════════════════════════════════════
#  DEFAULT TILESET CONFIGURATION
# ══════════════════════════════════════════

def create_default_manager():
    """Create a TilesetManager with the expected ALttP tileset configuration.

    Call this once at game startup. If sprite sheets are present, tiles
    will render from sprites. If not, the game falls back to procedural drawing.

    Expected sprite sheets in sprites/:
        overworld_tiles.png  — overworld terrain, structures, vegetation
        dungeon_tiles.png    — dungeon walls, floors, doors

    These should be 16x16 tile grids ripped from ALttP.
    """
    mgr = TilesetManager("sprites")

    # Try to load overworld tileset
    if os.path.exists("sprites/overworld_tiles.png"):
        mgr.load_tileset("overworld", "overworld_tiles.png")
        # Tile mappings would go here once we know the sheet layout:
        # mgr.map_tiles_batch("overworld", [
        #     (OW_GRASS, 0, 0),
        #     (OW_DARK_GRASS, 1, 0),
        #     (OW_PATH, 2, 0),
        #     ...
        # ])

    # Try to load dungeon tileset
    if os.path.exists("sprites/dungeon_tiles.png"):
        mgr.load_tileset("dungeon", "dungeon_tiles.png")

    return mgr


# ══════════════════════════════════════════
#  AUTO-TILING ENGINE
# ══════════════════════════════════════════

class AutoTiler:
    """Selects the correct tile variant based on neighboring tiles.

    For smooth terrain transitions (grass->path edges, grass->water shores,
    cliff edges), the auto-tiler checks the 4 or 8 neighboring tiles and
    picks the appropriate edge/corner variant.

    Each terrain type needs:
    - 1 center tile (surrounded by same type)
    - 4 edge tiles (top, bottom, left, right)
    - 4 inner corner tiles (TL, TR, BL, BR — adjacent tiles are different)
    - 4 outer corner tiles (convex corners)
    = 13 tiles per transition type

    This is used ONLY when sprite-based tilesets are loaded.
    """

    def __init__(self):
        # Define which tile types are in the same "group" for transition purposes
        # Tiles in the same group don't need transitions between them
        self.groups = {
            "grass": set(),     # All grass-type tiles
            "path": set(),      # All path/dirt tiles
            "water": set(),     # All water tiles
            "cliff": set(),     # All cliff tiles
        }

        # Transition rules: (from_group, to_group) -> tile variants
        # Each variant is indexed by neighbor bitmask
        self.transitions = {}

    def set_group(self, group_name, tile_ids):
        """Define which tile IDs belong to a terrain group."""
        self.groups[group_name] = set(tile_ids)

    def get_neighbor_mask(self, tiles, col, row, group_name):
        """Get a bitmask of which neighbors are in the same group.

        Bit positions:
            0=N, 1=NE, 2=E, 3=SE, 4=S, 5=SW, 6=W, 7=NW

        Returns:
            Integer bitmask (0-255)
        """
        group = self.groups.get(group_name, set())
        rows = len(tiles)
        cols = len(tiles[0]) if rows > 0 else 0

        mask = 0
        neighbors = [
            (0, -1, 0),   # N
            (1, -1, 1),   # NE
            (1, 0, 2),    # E
            (1, 1, 3),    # SE
            (0, 1, 4),    # S
            (-1, 1, 5),   # SW
            (-1, 0, 6),   # W
            (-1, -1, 7),  # NW
        ]

        for dx, dy, bit in neighbors:
            nc, nr = col + dx, row + dy
            if 0 <= nr < rows and 0 <= nc < cols:
                if tiles[nr][nc] in group:
                    mask |= (1 << bit)
            else:
                # Out of bounds = assume same group (no edge at screen boundary)
                mask |= (1 << bit)

        return mask

    def select_variant(self, tiles, col, row, base_tile_id, group_name):
        """Select the correct tile variant based on neighbors.

        Returns the tile ID to use (may be the base tile or an edge variant).
        For now, returns the base tile — variants are added when sprite sheets
        provide the edge tiles.
        """
        mask = self.get_neighbor_mask(tiles, col, row, group_name)

        # With full sprites, we'd look up:
        # transition_key = (group_name, mask)
        # return self.transitions.get(transition_key, base_tile_id)

        # For now, return the base tile (auto-tiling activates with sprites)
        return base_tile_id
