# Pygame Zelda — ALttP Light World

School project: teachers review docs, so keep planning/design docs clear and educational.

## Quick Start
```bash
cd /Users/jasper/Sites/localhost/pygame-zelda
source venv/bin/activate
python main.py
```

## How to Play (4-player co-op)
```
Player 1: WASD + Space (attack) + E (interact) + 1/2/3 (weapons)
Player 2: IJKL + Enter (attack) + ; (interact) + 7/8/9 (weapons)
Player 3: TFGH + Y (attack) + U (interact) + 4/5/6 (weapons)
Player 4: Numpad 8/4/5/6 + Numpad 0 (attack) + Numpad Enter (interact)

Phone controllers: start relay server (cd server && npm start), then
run bridge (python bridge.py), open controller on phone at server IP.

F11 = fullscreen, TAB = minimap toggle
```

## Tech Stack
- Python 3.x + Pygame 2.x
- python-socketio 5.x (phone controller relay)
- Node.js + socket.io (relay server in `server/`)
- No requirements.txt — install: `pip install pygame python-socketio`

## Architecture
```
main.py               Main game engine (entry point, game loop, all logic)
overworld_engine.py    Screen & tile management
overworld_maps.py      Overworld level data
overworld_tiles.py     Tile definitions & rendering
extract_sprites.py     Sprite extraction utility
bridge.py              Phone controller → keyboard bridge
controller/            Web-based phone controller UI
server/                Node.js relay server (socket.io)
docs/                  Design docs, sprite data JSONs
sprites/               All sprite sheets + extracted Link sprites
  link/                Individual Link sprite PNGs (265+)
tests/                 Unit tests
```

## Sprite System
- **Primary sheet**: `link_sprites.png` (688×365, root directory)
- **Alternative**: `link_sprites_clean.png` (56KB)
- **Background color**: Teal `(0,128,128)` + dark teal `(0,64,64)` — removed per-pixel at load
- **Loading**: `create_player_sprites()` in main.py — all sprites loaded at startup
- **Coordinates**: Hard-coded in source, documented in `docs/sprite-sheet-guide.md`
- **No error handling**: Missing sprite file = immediate crash

### Sprite Sheets (in sprites/)
overworld.png, dungeon.png, items.png, enemies_light.png, knights.png, stalfos.png, npcs.png, ganon.png

### Key Sprite Coordinates (Link)
| Direction | Frame 1 | Frame 2 | Size |
|-----------|---------|---------|------|
| Down | (1,3) | (19,3) | 16×24 |
| Up | (1,32) | (104,32) | 16×24 |
| Right | (1,58) | (55,58) | 17×24 |
| Left | Flipped from Right | — | — |

## Constants (main.py)
```python
NATIVE_W, NATIVE_H = 256, 224   # SNES resolution
TILE = 16                        # Tile size in pixels
HUD_H = 28                      # HUD height
FPS = 60
```

## Gotchas
1. **Run from project root** — sprite paths are relative to `main.py` location
2. **No fallback sprites** — if any PNG is missing/corrupt, game crashes on startup
3. **Per-pixel transparency is slow** — loops over every pixel to remove teal background
4. **Hard-coded sprite coords** — changing the sprite sheet breaks everything silently
5. **Enemy sprites are procedural** — generated at runtime, not loaded from files
6. **Audio has fallback, sprites don't** — mixer gracefully degrades, image loading crashes

## Overworld System
- 64 screens (8×8 grid, 40 playable + 24 boundary)
- 35 tile types with ALttP-accurate procedural rendering
- Screen-by-screen transitions (16 frames, smooth scroll)
- Pre-rendered screen caching for performance
- Overworld tile IDs: 100+ (avoids collision with dungeon IDs 0-10)
- Tile collision via `is_walkable()` in overworld_tiles.py
- Three synthesized music tracks (overworld, kakariko, death mountain)
- NPCs with dialogue in key areas
- 4-player co-op: tinted Link sprites (green/blue/red/purple)
- Dead players auto-respawn after 3 seconds near a teammate

## Docs
- `docs/superpowers/specs/2026-03-21-alttp-light-world-overworld-design.md` — Full design spec
- `docs/superpowers/plans/2026-03-21-alttp-overworld-implementation.md` — Implementation plan
- `docs/sprite-sheet-guide.md` — Precise sprite coordinates and mapping
- `docs/technisch-ontwerp.md` — Technical architecture
- `docs/functioneel-ontwerp.md` — Functional requirements
- `docs/concept.md` — Project concept
- `docs/sprite_data.json` — Sprite metadata
