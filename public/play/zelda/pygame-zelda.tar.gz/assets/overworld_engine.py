"""
Overworld engine — screen management, tile caching, and transitions.

The ScreenManager pre-renders static tiles to cached Surfaces for performance,
handles smooth screen-by-screen transitions, and manages overworld state.
"""
import pygame
from overworld_tiles import (
    TILE_PROPS, draw_overworld_tile, get_overlay_tiles,
    OW_GRASS, OW_BOUNDARY, TILE
)

# Screen dimensions (must match main.py)
NATIVE_W = 256
NATIVE_H = 224
HUD_H = 28
GAME_Y = HUD_H
MAP_COLS = NATIVE_W // TILE   # 16
MAP_ROWS = (NATIVE_H - HUD_H) // TILE  # 12
CACHE_H = MAP_ROWS * TILE     # 192 — tile area only, no HUD

# Transition speed
TRANSITION_FRAMES = 16  # ~0.27s at 60fps

# Directions → offsets
DIR_OFFSET = {
    "left":  (-1, 0),
    "right": (1, 0),
    "up":    (0, -1),
    "down":  (0, 1),
}


class ScreenManager:
    """Manages the overworld screen grid, caching, and transitions.

    Usage:
        mgr = ScreenManager(overworld_data)
        mgr.enter_screen((3, 4))  # Start at Link's House

        # In game loop:
        mgr.draw(game_surf, ticks)
        mgr.check_edge(player)    # Triggers transition if player at edge
        mgr.update()              # Advances transition animation
    """

    def __init__(self, overworld_data):
        """
        Args:
            overworld_data: dict of (col, row) → screen dict with "tiles", "enemies", etc.
        """
        self.data = overworld_data
        self.current = None           # (col, row) tuple
        self.cache = {}               # (col, row) → pygame.Surface (256×192)
        self.transition = None        # Active transition state or None
        self.cut_tiles = {}           # (col, row) → set of (tile_col, tile_row) that were cut
        self._overlay_ids = get_overlay_tiles()

    def enter_screen(self, screen_pos):
        """Set current screen and pre-cache it + neighbors."""
        self.current = screen_pos
        self._cache_screen(screen_pos)
        # Pre-cache adjacent screens
        for dx, dy in DIR_OFFSET.values():
            adj = (screen_pos[0] + dx, screen_pos[1] + dy)
            if adj in self.data:
                self._cache_screen(adj)

    def _cache_screen(self, pos):
        """Render static tiles to a 256×192 Surface."""
        if pos in self.cache:
            return
        screen_data = self.data.get(pos)
        if not screen_data:
            return
        surf = pygame.Surface((NATIVE_W, CACHE_H))
        surf.fill((0, 0, 0))
        tiles = screen_data["tiles"]
        cut = self.cut_tiles.get(pos, set())
        for row in range(MAP_ROWS):
            for col in range(MAP_COLS):
                tile = tiles[row][col]
                if (col, row) in cut:
                    tile = OW_GRASS
                props = TILE_PROPS.get(tile, {})
                if not props.get("animated", False):
                    draw_overworld_tile(surf, tile, col * TILE, row * TILE, 0)
        self.cache[pos] = surf

    def invalidate_cache(self, pos):
        """Force re-render after tile change (e.g., cutting grass)."""
        self.cache.pop(pos, None)

    def cut_tile(self, pos, tile_col, tile_row):
        """Record a tile as cut (tall grass/bush → grass)."""
        if pos not in self.cut_tiles:
            self.cut_tiles[pos] = set()
        self.cut_tiles[pos].add((tile_col, tile_row))
        self.invalidate_cache(pos)

    def get_tile(self, pos, col, row):
        """Get the effective tile at a position (accounting for cuts)."""
        if pos not in self.data:
            return OW_BOUNDARY
        cut = self.cut_tiles.get(pos, set())
        if (col, row) in cut:
            return OW_GRASS
        return self.data[pos]["tiles"][row][col]

    def draw(self, game_surf, ticks):
        """Draw the current screen (and transition if active) to game_surf."""
        if self.transition:
            self._draw_transition(game_surf, ticks)
        else:
            self._draw_screen(game_surf, self.current, 0, 0, ticks)

    def _draw_screen(self, game_surf, pos, offset_x, offset_y, ticks):
        """Draw a screen at the given offset."""
        # Blit cached static background
        if pos not in self.cache:
            self._cache_screen(pos)
        if pos in self.cache:
            game_surf.blit(self.cache[pos], (offset_x, GAME_Y + offset_y))

        # Draw animated tiles on top
        screen_data = self.data.get(pos)
        if not screen_data:
            return
        tiles = screen_data["tiles"]
        cut = self.cut_tiles.get(pos, set())
        for row in range(MAP_ROWS):
            for col in range(MAP_COLS):
                tile = tiles[row][col]
                if (col, row) in cut:
                    continue
                props = TILE_PROPS.get(tile, {})
                if props.get("animated", False):
                    draw_overworld_tile(game_surf, tile,
                                       offset_x + col * TILE,
                                       GAME_Y + offset_y + row * TILE,
                                       ticks)

    def draw_overlays(self, game_surf, pos, offset_x, offset_y, ticks):
        """Draw tree canopy overlays (rendered above sprites)."""
        screen_data = self.data.get(pos)
        if not screen_data:
            return
        tiles = screen_data["tiles"]
        for row in range(MAP_ROWS):
            for col in range(MAP_COLS):
                if tiles[row][col] in self._overlay_ids:
                    # Redraw just the canopy portion (top half of tree)
                    draw_overworld_tile(game_surf, tiles[row][col],
                                       offset_x + col * TILE,
                                       GAME_Y + offset_y + row * TILE,
                                       ticks)

    # ── Screen Transitions ──

    def check_edge(self, player_x, player_y, player_w, player_h):
        """Check if player has reached a screen edge. Returns direction or None.

        Uses tile-local coordinates (player_y is 0-192, NOT screen Y).
        """
        if self.transition:
            return None
        hw = player_w // 2
        if player_x - hw <= 0:
            return "left"
        if player_x + hw >= NATIVE_W:
            return "right"
        if player_y <= 0:
            return "up"
        if player_y + player_h >= MAP_ROWS * TILE:
            return "down"
        return None

    def start_transition(self, direction):
        """Begin scrolling to the adjacent screen.

        Returns:
            True if transition started, False if blocked (boundary/missing screen).
        """
        dx, dy = DIR_OFFSET[direction]
        next_pos = (self.current[0] + dx, self.current[1] + dy)
        if next_pos not in self.data:
            return False
        # Don't transition into boundary screens
        screen_data = self.data.get(next_pos, {})
        if screen_data.get("boundary", False):
            return False
        # Pre-cache the target
        self._cache_screen(next_pos)
        self.transition = {
            "direction": direction,
            "from": self.current,
            "to": next_pos,
            "progress": 0,
            "total": TRANSITION_FRAMES,
        }
        return True

    def update_transition(self):
        """Advance transition animation by one frame.

        Returns:
            True if transition just completed, False otherwise.
        """
        if not self.transition:
            return False
        self.transition["progress"] += 1
        if self.transition["progress"] >= self.transition["total"]:
            # Transition complete
            self.enter_screen(self.transition["to"])
            self.transition = None
            return True
        return False

    @property
    def in_transition(self):
        return self.transition is not None

    def _draw_transition(self, game_surf, ticks):
        """Draw the scrolling transition between two screens."""
        t = self.transition
        progress = t["progress"] / t["total"]  # 0.0 → 1.0
        d = t["direction"]

        if d == "left":
            off_x = int(NATIVE_W * progress)
            self._draw_screen(game_surf, t["from"], off_x, 0, ticks)
            self._draw_screen(game_surf, t["to"], off_x - NATIVE_W, 0, ticks)
        elif d == "right":
            off_x = int(-NATIVE_W * progress)
            self._draw_screen(game_surf, t["from"], off_x, 0, ticks)
            self._draw_screen(game_surf, t["to"], off_x + NATIVE_W, 0, ticks)
        elif d == "up":
            off_y = int(CACHE_H * progress)
            self._draw_screen(game_surf, t["from"], 0, off_y, ticks)
            self._draw_screen(game_surf, t["to"], 0, off_y - CACHE_H, ticks)
        elif d == "down":
            off_y = int(-CACHE_H * progress)
            self._draw_screen(game_surf, t["from"], 0, off_y, ticks)
            self._draw_screen(game_surf, t["to"], 0, off_y + CACHE_H, ticks)

    def get_player_entry_pos(self, direction):
        """Get player position after arriving from a transition.

        Returns (x, y) in tile-local coordinates (no GAME_Y).
        """
        if direction == "left":
            return NATIVE_W - 20, None  # Keep y, set x to right edge
        elif direction == "right":
            return 20, None
        elif direction == "up":
            return None, CACHE_H - 20  # Keep x, set y to bottom (tile-local)
        elif direction == "down":
            return None, 20
        return None, None
