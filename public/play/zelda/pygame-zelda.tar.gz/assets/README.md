# Zelda Remote Controller

SNES-style Zelda game (Pygame) controlled from your phone via WebSockets.

## Links

- **Trello:** https://trello.com/b/A9fA29Sl/zelda-remote-controller
- **Figma:** [Functioneel Ontwerp (wireframes)](https://www.figma.com/design/HYw1xUBaishemA3YHrW7p6)
- **Docs:** See `docs/` folder

## Project

Control Link in a top-down Zelda game using a responsive web controller on your phone. The game runs on your laptop, the controller runs in your phone's browser.

### Architecture
```
Phone (browser)       Node.js server        Pygame game (laptop)
┌──────────────┐     ┌──────────────┐      ┌──────────────┐
│ D-pad         │──ws─▶│  Relay server │──ws─▶│ Reads input  │
│ A = sword     │     │  (socket.io)  │      │ Moves Link   │
│ B = item      │     │              │◀──ws──│ Sends state  │
│ Start = pause │     └──────────────┘      └──────────────┘
└──────────────┘
```

## Tech Stack
- **Python + Pygame** — game engine
- **Node.js + socket.io** — WebSocket relay server
- **HTML/CSS/JS** — phone controller (touch events)
- **Python websockets** — game receives input

## Setup

### Game (laptop)
```bash
python3 -m venv venv
source venv/bin/activate
pip install pygame
python main.py
```

### Server
```bash
cd server
npm install
node server.js
```

### Controller
Open the controller URL on your phone's browser (same WiFi network).

## Roadmap

> Synced from [Trello board](https://trello.com/b/A9fA29Sl/zelda-remote-controller)

### Done
- [x] Plan van Aanpak
- [x] Technisch Ontwerp
- [x] Functioneel Ontwerp
- [x] Concept Document

### Week 1 — Fundament (20 mrt)
- [ ] Planning finaliseren
- [ ] Git repo opzetten + docenten uitnodigen
- [ ] GO/NOGO vrijdag

### Week 2 — Game (25–27 mrt)
- [ ] Pygame game afronden (combat, enemies, dungeons)
- [ ] Game input abstraheren (keyboard → input handler)
- [ ] Node.js relay server opzetten (socket.io)
- [ ] Eerste WebSocket test (browser → server → console)

### Week 3 — Controller (1 apr)
- [ ] Controller UI bouwen (D-pad, A, B, Start)
- [ ] Touch events implementeren

### Integration & Polish
- [ ] Pygame WebSocket client (python-socketio)
- [ ] Controller → Server → Game koppeling werkend
- [ ] Testen op verschillende telefoons
- [ ] Bugs fixen, latency optimaliseren
- [ ] Game state terugsturen naar controller (HP display)
- [ ] Usability verbeteren (haptic feedback, visuele feedback)

### Delivery
- [ ] Code opschonen, README schrijven
- [ ] Final release in Git
- [ ] Video presentatie maken (proces + product)
- [ ] Alle documenten in Git repo (zip)
- [ ] Retrospective schrijven
- [ ] Feedback geven en ontvangen

### Ideas (Nice-to-have)
- Gyroscoop sturen (alternatief bewegen)
- Multiplayer co-op (2 telefoons)
- Shake = special attack

## Team
Module 7.2 — Remote Controller (D1-K1-W1)
