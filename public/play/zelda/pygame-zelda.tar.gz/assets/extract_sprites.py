"""
Scan the Link sprite sheet, find every distinct sprite bounding box,
and save them as individual PNGs in sprites/link/
"""
import pygame, os

pygame.init()
screen = pygame.display.set_mode((1, 1))  # needed for convert_alpha

img = pygame.image.load("link_sprites.png").convert_alpha()
W, H = img.get_width(), img.get_height()
BG = (0, 128, 128, 255)

# Build mask: True = sprite pixel, False = background
mask = [[False] * W for _ in range(H)]
for y in range(H):
    for x in range(W):
        px = img.get_at((x, y))
        # Consider anything not the teal background as sprite
        if (px[0], px[1], px[2]) != (0, 128, 128):
            mask[y][x] = True

# Flood-fill to find connected regions
visited = [[False] * W for _ in range(H)]
sprites = []

def flood_fill(sx, sy):
    stack = [(sx, sy)]
    pixels = []
    while stack:
        x, y = stack.pop()
        if x < 0 or x >= W or y < 0 or y >= H:
            continue
        if visited[y][x] or not mask[y][x]:
            continue
        visited[y][x] = True
        pixels.append((x, y))
        # 8-connected to catch diagonal connections
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                if dx == 0 and dy == 0:
                    continue
                stack.append((x + dx, y + dy))
    return pixels

for y in range(H):
    for x in range(W):
        if mask[y][x] and not visited[y][x]:
            pixels = flood_fill(x, y)
            if len(pixels) < 10:  # skip tiny noise
                continue
            xs = [p[0] for p in pixels]
            ys = [p[1] for p in pixels]
            bbox = (min(xs), min(ys), max(xs), max(ys))
            w = bbox[2] - bbox[0] + 1
            h = bbox[3] - bbox[1] + 1
            sprites.append((bbox, w, h, len(pixels)))

# Sort by position: top-to-bottom, left-to-right
sprites.sort(key=lambda s: (s[0][1] // 24, s[0][0]))

# Save each sprite
out_dir = "sprites/link"
os.makedirs(out_dir, exist_ok=True)

print(f"Found {len(sprites)} sprites\n")
print(f"{'#':>3}  {'X':>4} {'Y':>4}  {'W':>3}x{'H':<3}  {'Pixels':>6}")
print("-" * 40)

for i, (bbox, w, h, npx) in enumerate(sprites):
    x0, y0, x1, y1 = bbox
    print(f"{i:3d}  {x0:4d} {y0:4d}  {w:3d}x{h:<3d}  {npx:6d}")

    # Extract sprite with transparency
    surf = pygame.Surface((w, h), pygame.SRCALPHA)
    surf.fill((0, 0, 0, 0))
    for px_x in range(x0, x1 + 1):
        for px_y in range(y0, y1 + 1):
            if mask[px_y][px_x]:
                surf.set_at((px_x - x0, px_y - y0), img.get_at((px_x, px_y)))

    pygame.image.save(surf, os.path.join(out_dir, f"sprite_{i:03d}.png"))

print(f"\nSaved to {out_dir}/")
pygame.quit()
