import pygame
import random
import math
import array
import asyncio
import sys

IS_WEB = sys.platform in ("emscripten", "wasi")

from dialogue_system import DialogueBox
from save_system import save_game, load_game, list_saves, delete_save, format_time

pygame.init()
SOUND_OK = False
try:
    pygame.mixer.init(22050, -16, 2, 512)
    SOUND_OK = True
except Exception:
    try:
        pygame.mixer.init()
        SOUND_OK = True
    except Exception:
        print("Audio unavailable — running without sound")

# ══════════════════════════════════════════
#  SNES-STYLE RENDERING
# ══════════════════════════════════════════
NATIVE_W, NATIVE_H = 256, 224
TILE = 16
HUD_H = 28
GAME_Y = HUD_H
GAME_H = NATIVE_H - HUD_H
MAP_COLS = NATIVE_W // TILE   # 16
MAP_ROWS = GAME_H // TILE     # 12
FPS = 60

# Auto-detect best integer scale for this monitor
_info = pygame.display.Info()
_max_w = _info.current_w // NATIVE_W
_max_h = _info.current_h // NATIVE_H
SCALE = max(2, min(_max_w, _max_h) - 1)  # -1 for taskbar, min 2
SCREEN_W = NATIVE_W * SCALE
SCREEN_H = NATIVE_H * SCALE

# All drawing goes to this surface, then scaled for crisp pixels
game_surf = pygame.Surface((NATIVE_W, NATIVE_H))
screen = pygame.display.set_mode((SCREEN_W, SCREEN_H))
pygame.display.set_caption("The Legend of Link")
clock = pygame.time.Clock()
fullscreen = False

_monitor_w, _monitor_h = _info.current_w, _info.current_h  # Save at startup

def toggle_fullscreen():
    global fullscreen, SCALE, SCREEN_W, SCREEN_H, screen
    fullscreen = not fullscreen
    if fullscreen:
        SCALE = min(_monitor_w // NATIVE_W, _monitor_h // NATIVE_H)
        screen = pygame.display.set_mode((_monitor_w, _monitor_h), pygame.FULLSCREEN)
    else:
        SCALE = max(2, min(_monitor_w // NATIVE_W, _monitor_h // NATIVE_H) - 1)
        screen = pygame.display.set_mode((NATIVE_W * SCALE, NATIVE_H * SCALE))
    SCREEN_W = NATIVE_W * SCALE
    SCREEN_H = NATIVE_H * SCALE

# Tiny fonts for native resolution
font_sm = pygame.font.SysFont("arial", 8, bold=True)
font_md = pygame.font.SysFont("arial", 10, bold=True)
font_lg = pygame.font.SysFont("arial", 14, bold=True)
font_xl = pygame.font.SysFont("arial", 20, bold=True)
font_title = pygame.font.SysFont("arial", 24, bold=True)

# ══════════════════════════════════════════
#  COLORS
# ══════════════════════════════════════════
BLACK    = (0, 0, 0)
WHITE    = (255, 255, 255)
DKGREEN  = (16, 72, 16)
GREEN    = (32, 136, 32)
LTGREEN  = (64, 192, 64)
GRASS1   = (24, 100, 24)
GRASS2   = (32, 120, 32)
BROWN    = (96, 64, 32)
DKBROWN  = (56, 40, 20)
GRAY     = (112, 112, 112)
DKGRAY   = (64, 64, 64)
RED      = (200, 40, 40)
DKRED    = (128, 24, 24)
YELLOW   = (248, 216, 0)
BLUE     = (32, 80, 200)
LTBLUE   = (96, 160, 248)
DKBLUE   = (16, 16, 48)
SKIN     = (240, 192, 144)
DKSKIN   = (200, 152, 112)
BLONDE   = (216, 176, 64)
DKBLONDE = (168, 128, 40)
ORANGE   = (224, 120, 24)
PURPLE   = (112, 40, 152)
DKPURPLE = (72, 24, 100)
PINK     = (224, 112, 128)
CYAN     = (64, 216, 216)
LAVA1    = (192, 56, 16)
LAVA2    = (224, 96, 32)
SAND     = (200, 184, 128)
METAL    = (160, 160, 176)
DKMETAL  = (100, 100, 116)

# ══════════════════════════════════════════
#  SOUND EFFECTS
# ══════════════════════════════════════════
class DummySound:
    def play(self): pass

def make_sound(freq=440, dur=0.1, vol=0.15, wave="square", freq_end=None):
    if not SOUND_OK:
        return DummySound()
    sr = 22050
    n = int(sr * dur)
    if n == 0:
        n = 1
    buf = array.array('h')
    for i in range(n):
        t = i / sr
        p = i / n
        f = freq + (freq_end - freq) * p if freq_end else freq
        if wave == "square":
            v = vol * 32767 * (1 if math.sin(2 * math.pi * f * t) > 0 else -1)
        elif wave == "sine":
            v = vol * 32767 * math.sin(2 * math.pi * f * t)
        elif wave == "noise":
            v = vol * 32767 * random.uniform(-1, 1)
        else:
            v = 0
        env = min(1.0, min(i / max(1, n * 0.05), (n - i) / max(1, n * 0.15)))
        s = int(v * env)
        buf.append(s)
        buf.append(s)
    return pygame.mixer.Sound(buffer=buf)

SFX = {}
def init_sounds():
    SFX["sword"]    = make_sound(280, 0.12, 0.12, "square", 560)
    SFX["arrow"]    = make_sound(700, 0.08, 0.08, "sine", 350)
    SFX["bomb_tick"]= make_sound(1000, 0.02, 0.05, "square")
    SFX["bomb"]     = make_sound(60, 0.5, 0.2, "noise")
    SFX["hit"]      = make_sound(180, 0.1, 0.12, "square", 90)
    SFX["hurt"]     = make_sound(280, 0.2, 0.12, "square", 90)
    SFX["pickup"]   = make_sound(600, 0.07, 0.08, "sine", 900)
    SFX["chest"]    = make_sound(400, 0.2, 0.1, "sine", 800)
    SFX["door"]     = make_sound(140, 0.3, 0.08, "sine", 280)
    SFX["text"]     = make_sound(660, 0.025, 0.04, "square")
    SFX["select"]   = make_sound(500, 0.05, 0.08, "sine", 700)
    SFX["grass"]    = make_sound(400, 0.06, 0.06, "noise")
    SFX["win"]      = make_sound(500, 0.5, 0.12, "sine", 1000)
    SFX["die"]      = make_sound(350, 0.6, 0.15, "square", 60)
    SFX["boss_hit"] = make_sound(80, 0.3, 0.15, "noise")
    SFX["phase"]    = make_sound(180, 0.8, 0.15, "sine", 40)
    SFX["block"]    = make_sound(800, 0.06, 0.1, "square", 400)
    SFX["step_grass"] = make_sound(200, 0.03, 0.03, "noise")
    SFX["step_stone"] = make_sound(400, 0.02, 0.04, "square", 300)
    SFX["step_sand"]  = make_sound(150, 0.04, 0.03, "noise")
    SFX["step_water"] = make_sound(300, 0.03, 0.03, "noise")
    # Victory fanfare — quick ascending notes: C D E G
    def make_fanfare():
        if not SOUND_OK:
            return DummySound()
        sr = 22050
        notes = [(523, 0.12), (587, 0.12), (659, 0.12), (784, 0.3)]
        buf = array.array('h')
        for freq, dur in notes:
            n = int(sr * dur)
            for i in range(n):
                t = i / sr
                env = min(1.0, min(i / max(1, n * 0.02), (n - i) / max(1, n * 0.1)))
                v = 0.12 * 32767 * math.sin(2 * math.pi * freq * t)
                s = int(v * env)
                buf.append(s); buf.append(s)
        return pygame.mixer.Sound(buffer=buf)
    SFX["fanfare"] = make_fanfare()
init_sounds()

# ══════════════════════════════════════════
#  BACKGROUND MUSIC (synthesized chiptune)
# ══════════════════════════════════════════
def make_music_track(notes, tempo=120, vol=0.06, wave="square"):
    """Generate a music track from a list of (freq, duration_beats) tuples."""
    if not SOUND_OK:
        return None
    sr = 22050
    beat_len = 60.0 / tempo
    samples = array.array('h')
    for freq, beats in notes:
        dur = beat_len * beats
        n = int(sr * dur)
        for i in range(n):
            t = i / sr
            env = min(1.0, min(i / max(1, n * 0.02), (n - i) / max(1, n * 0.05)))
            if freq == 0:
                v = 0
            elif wave == "square":
                v = vol * 32767 * (1 if math.sin(2 * math.pi * freq * t) > 0 else -1)
            elif wave == "sine":
                v = vol * 32767 * math.sin(2 * math.pi * freq * t)
            else:
                v = 0
            s = int(v * env)
            samples.append(s)
            samples.append(s)
    if len(samples) == 0:
        return None
    return pygame.mixer.Sound(buffer=samples)

# ALttP-inspired overworld melody (simplified)
OVERWORLD_MELODY = [
    # Phrase 1 — bright, adventurous
    (392, 0.5), (440, 0.5), (523, 1), (587, 0.5), (523, 0.5),
    (440, 1), (392, 1), (0, 0.5),
    (330, 0.5), (392, 0.5), (440, 1), (523, 0.5), (440, 0.5),
    (392, 1), (330, 1), (0, 0.5),
    # Phrase 2 — variation
    (392, 0.5), (523, 0.5), (659, 1), (587, 0.5), (523, 0.5),
    (440, 0.5), (392, 0.5), (440, 1), (0, 0.5),
    (330, 0.5), (440, 0.5), (523, 1), (440, 0.5), (392, 0.5),
    (330, 1), (262, 1), (0, 1),
]

KAKARIKO_MELODY = [
    # Gentle, peaceful
    (330, 1), (392, 0.5), (440, 1), (392, 0.5),
    (330, 1), (294, 1), (0, 0.5),
    (262, 0.5), (294, 0.5), (330, 1), (392, 0.5), (330, 0.5),
    (294, 1), (262, 1), (0, 1),
    (330, 1), (392, 0.5), (440, 1), (523, 0.5),
    (440, 0.5), (392, 0.5), (330, 1), (294, 1), (0, 1),
]

DEATH_MOUNTAIN_MELODY = [
    # Dark, ominous
    (196, 1), (208, 0.5), (220, 1), (196, 0.5),
    (185, 1), (196, 1), (0, 0.5),
    (165, 0.5), (175, 0.5), (196, 1), (220, 0.5),
    (196, 0.5), (175, 1), (165, 1), (0, 1),
]

# Dungeon music — dark, atmospheric, minor key
DUNGEON_MELODY = [
    (165, 1), (175, 0.5), (196, 1), (175, 0.5),
    (165, 1), (156, 1), (0, 0.5),
    (131, 0.5), (147, 0.5), (165, 1), (147, 0.5),
    (131, 1), (123, 1), (0, 0.5),
    (165, 0.5), (196, 0.5), (220, 1), (196, 0.5),
    (175, 0.5), (165, 0.5), (147, 1), (131, 1), (0, 1),
]

BOSS_MELODY = [
    # Intense, fast, threatening
    (220, 0.25), (233, 0.25), (247, 0.25), (262, 0.25),
    (220, 0.25), (233, 0.25), (247, 0.25), (262, 0.25),
    (294, 0.5), (262, 0.5), (220, 0.5), (0, 0.25),
    (196, 0.25), (220, 0.25), (262, 0.25), (294, 0.25),
    (330, 0.5), (294, 0.5), (262, 0.5), (0, 0.25),
    (220, 0.25), (196, 0.25), (175, 0.25), (165, 0.25),
    (196, 0.5), (220, 1), (0, 0.5),
]

music_tracks = {}
current_music = None
music_channel = None

def init_music():
    global music_tracks, music_channel
    if not SOUND_OK:
        return
    music_tracks["overworld"] = make_music_track(OVERWORLD_MELODY, tempo=140, vol=0.04)
    music_tracks["kakariko"] = make_music_track(KAKARIKO_MELODY, tempo=100, vol=0.04, wave="sine")
    music_tracks["mountain"] = make_music_track(DEATH_MOUNTAIN_MELODY, tempo=90, vol=0.04)
    music_tracks["dungeon"] = make_music_track(DUNGEON_MELODY, tempo=80, vol=0.035, wave="sine")
    music_tracks["boss"] = make_music_track(BOSS_MELODY, tempo=160, vol=0.05)
    music_channel = pygame.mixer.Channel(7)  # Reserve channel 7 for music

def play_music(track_name):
    global current_music
    if not SOUND_OK or not music_channel:
        return
    if track_name == current_music:
        return  # Already playing
    current_music = track_name
    track = music_tracks.get(track_name)
    if track:
        music_channel.play(track, loops=-1)  # Loop forever
    else:
        music_channel.stop()

def stop_music():
    global current_music
    current_music = None
    if music_channel:
        music_channel.stop()

init_music()

# ══════════════════════════════════════════
#  SPRITE CREATION (pre-rendered at native res)
# ══════════════════════════════════════════
def make_sprite(width, height):
    return pygame.Surface((width, height), pygame.SRCALPHA)

def load_sprite_from_sheet(sheet, x, y, w, h):
    """Cut a single sprite from the sheet, removing the teal background."""
    surf = pygame.Surface((w, h), pygame.SRCALPHA)
    surf.fill((0, 0, 0, 0))
    surf.blit(sheet, (0, 0), (x, y, w, h))
    # Replace teal background + dark teal outline with transparency
    for py in range(h):
        for px in range(w):
            c = surf.get_at((px, py))
            if (c[0], c[1], c[2]) == (0, 128, 128) or (c[0], c[1], c[2]) == (0, 64, 64):
                surf.set_at((px, py), (0, 0, 0, 0))
    return surf

def normalize_sprite(sprite, target_w, target_h):
    """Place a sprite onto a fixed-size canvas, bottom-center aligned."""
    canvas = pygame.Surface((target_w, target_h), pygame.SRCALPHA)
    canvas.fill((0, 0, 0, 0))
    sw, sh = sprite.get_size()
    x = (target_w - sw) // 2
    y = target_h - sh  # Align feet to bottom
    canvas.blit(sprite, (x, y))
    return canvas


def create_player_sprites():
    """Load Link sprites from the sprite sheet."""
    import os
    sprites = {}
    sheet_path = os.path.join(os.path.dirname(__file__) or ".", "link_sprites.png")
    sheet = pygame.image.load(sheet_path).convert_alpha()

    # Sprite locations from the sheet (x, y, w, h) — confirmed via extract_sprites.py
    # Pick frame pairs with matching sizes for smooth animation
    SPRITE_W, SPRITE_H = 17, 26  # Normalized canvas size (fits all frames)

    sprite_map = {
        # Walk down: sprites #0 and #1 — both 16x24
        "down":  [(1, 3, 16, 24), (19, 3, 16, 24)],
        # Walk up: sprites #31 and #37 — both 16x24 (skip #32 which is 16x23)
        "up":    [(1, 32, 16, 24), (104, 32, 16, 24)],
        # Walk right: sprites #66 and #69 — both 17x24
        "right": [(1, 58, 17, 24), (55, 58, 17, 24)],
    }

    for d, frame_rects in sprite_map.items():
        frames = []
        for (x, y, w, h) in frame_rects:
            raw = load_sprite_from_sheet(sheet, x, y, w, h)
            frames.append(normalize_sprite(raw, SPRITE_W, SPRITE_H))
        sprites[d] = frames

    # Left = mirror of right
    sprites["left"] = [pygame.transform.flip(f, True, False) for f in sprites["right"]]

    # --- Attack sprites (sword swing per direction) ---
    # Row 1 end: sprites #64 (27x24) and #65 (28x24) — Link facing up with sword
    ATK_W, ATK_H = 30, 28  # Larger canvas for attack frames

    # Use larger sprites from the sheet for attacks where available
    atk_map = {
        # Facing up attack: sprites 64-65 are wider (sword extending)
        "up":    [(575, 28, 27, 24), (603, 28, 28, 24)],
        # Facing down attack: sprites 2-3 are taller (sword extending down)
        "down":  [(36, 2, 16, 25), (53, 1, 16, 26)],
        # Facing right attack: wider sprites from row 3
        "right": [(57, 86, 23, 22), (81, 86, 19, 22)],
    }
    for d, frame_rects in atk_map.items():
        frames = []
        for (x, y, w, h) in frame_rects:
            raw = load_sprite_from_sheet(sheet, x, y, w, h)
            frames.append(normalize_sprite(raw, ATK_W, ATK_H))
        sprites[f"atk_{d}"] = frames
    sprites["atk_left"] = [pygame.transform.flip(f, True, False) for f in sprites["atk_right"]]

    return sprites

PLAYER_SPRITES = create_player_sprites()


def create_enemy_sprites():
    """Create all enemy animation frames."""
    sprites = {}

    # --- Slime ---
    for f in range(2):
        s = make_sprite(16, 16)
        sq = f * 2
        pygame.draw.ellipse(s, GREEN, (2, 4 + sq, 12, 10 - sq))
        pygame.draw.ellipse(s, DKGREEN, (2, 4 + sq, 12, 10 - sq), 1)
        pygame.draw.rect(s, WHITE, (4, 6 + sq, 2, 2))
        pygame.draw.rect(s, WHITE, (9, 6 + sq, 2, 2))
        pygame.draw.rect(s, BLACK, (5, 7 + sq, 1, 1))
        pygame.draw.rect(s, BLACK, (10, 7 + sq, 1, 1))
        sprites.setdefault("slime", []).append(s)

    # --- Bat ---
    for f in range(2):
        s = make_sprite(16, 16)
        wing_y = -3 if f == 0 else 3
        # Wings
        pygame.draw.polygon(s, PURPLE, [(8, 6), (1, 4 + wing_y), (3, 10)])
        pygame.draw.polygon(s, PURPLE, [(8, 6), (15, 4 + wing_y), (13, 10)])
        # Body
        pygame.draw.ellipse(s, DKPURPLE, (5, 4, 6, 8))
        # Eyes
        pygame.draw.rect(s, YELLOW, (6, 6, 1, 1))
        pygame.draw.rect(s, YELLOW, (9, 6, 1, 1))
        sprites.setdefault("bat", []).append(s)

    # --- Skeleton ---
    for f in range(2):
        s = make_sprite(16, 16)
        bob = f
        # Body
        pygame.draw.rect(s, WHITE, (4, 6 + bob, 8, 8))
        # Head
        pygame.draw.rect(s, WHITE, (5, 1 + bob, 6, 6))
        # Eyes
        pygame.draw.rect(s, BLACK, (6, 3 + bob, 2, 2))
        pygame.draw.rect(s, BLACK, (9, 3 + bob, 2, 2))
        # Mouth
        pygame.draw.rect(s, BLACK, (7, 5 + bob, 3, 1))
        # Ribs
        pygame.draw.rect(s, GRAY, (5, 8 + bob, 6, 1))
        pygame.draw.rect(s, GRAY, (5, 10 + bob, 6, 1))
        # Sword
        pygame.draw.rect(s, METAL, (12, 2 + bob, 2, 10))
        pygame.draw.rect(s, YELLOW, (11, 10 + bob, 4, 2))
        sprites.setdefault("skeleton", []).append(s)

    # --- Knight ---
    for f in range(2):
        s = make_sprite(16, 16)
        bob = f
        # Armor body
        pygame.draw.rect(s, METAL, (3, 6 + bob, 10, 8))
        pygame.draw.rect(s, DKMETAL, (3, 6 + bob, 10, 8), 1)
        # Helmet
        pygame.draw.rect(s, METAL, (4, 1 + bob, 8, 6))
        pygame.draw.rect(s, DKMETAL, (4, 1 + bob, 8, 6), 1)
        # Visor
        pygame.draw.rect(s, BLACK, (5, 3 + bob, 6, 2))
        pygame.draw.rect(s, RED, (6, 3 + bob, 1, 1))
        pygame.draw.rect(s, RED, (9, 3 + bob, 1, 1))
        # Shield
        pygame.draw.rect(s, DKBLUE, (1, 7 + bob, 4, 6))
        pygame.draw.rect(s, BLUE, (2, 8 + bob, 2, 4))
        # Sword
        pygame.draw.rect(s, METAL, (13, 1 + bob, 2, 11))
        pygame.draw.rect(s, YELLOW, (12, 10 + bob, 4, 2))
        sprites.setdefault("knight", []).append(s)

    # --- Mage ---
    for f in range(2):
        s = make_sprite(16, 16)
        # Robe
        pygame.draw.polygon(s, PURPLE, [(4, 6), (12, 6), (14, 15), (2, 15)])
        pygame.draw.polygon(s, DKPURPLE, [(4, 6), (12, 6), (14, 15), (2, 15)], 1)
        # Hood
        pygame.draw.polygon(s, PURPLE, [(5, 7), (11, 7), (8, 1)])
        # Eyes
        pygame.draw.rect(s, CYAN, (6, 7, 1, 2))
        pygame.draw.rect(s, CYAN, (9, 7, 1, 2))
        # Staff
        pygame.draw.rect(s, BROWN, (13, 2, 1, 12))
        glow = CYAN if f == 0 else WHITE
        pygame.draw.rect(s, glow, (12, 1, 3, 3))
        sprites.setdefault("mage", []).append(s)

    # --- Boss ---
    for f in range(2):
        s = make_sprite(32, 32)
        sq = f * 2
        # Body
        pygame.draw.ellipse(s, PURPLE, (4, 8 + sq, 24, 20 - sq))
        pygame.draw.ellipse(s, DKPURPLE, (4, 8 + sq, 24, 20 - sq), 1)
        # Horns
        pygame.draw.polygon(s, ORANGE, [(8, 10), (5, 1), (11, 8)])
        pygame.draw.polygon(s, ORANGE, [(24, 10), (27, 1), (21, 8)])
        # Eyes
        pygame.draw.circle(s, YELLOW, (11, 14 + sq), 3)
        pygame.draw.circle(s, YELLOW, (21, 14 + sq), 3)
        pygame.draw.circle(s, RED, (11, 14 + sq), 1)
        pygame.draw.circle(s, RED, (21, 14 + sq), 1)
        # Mouth
        pygame.draw.rect(s, BLACK, (11, 20 + sq, 10, 3))
        # Teeth
        for tx in range(12, 21, 2):
            pygame.draw.rect(s, WHITE, (tx, 20 + sq, 1, 2))
        sprites.setdefault("boss", []).append(s)

    # Boss phase 2
    for f in range(2):
        s = sprites["boss"][f].copy()
        sq = f * 2
        # Extra horns
        pygame.draw.polygon(s, RED, [(10, 8), (8, 2), (12, 7)])
        pygame.draw.polygon(s, RED, [(22, 8), (24, 2), (20, 7)])
        # Redder eyes
        pygame.draw.circle(s, RED, (11, 14 + sq), 3)
        pygame.draw.circle(s, RED, (21, 14 + sq), 3)
        pygame.draw.circle(s, YELLOW, (11, 14 + sq), 1)
        pygame.draw.circle(s, YELLOW, (21, 14 + sq), 1)
        sprites.setdefault("boss2", []).append(s)

    # Boss phase 3
    for f in range(2):
        s = sprites["boss2"][f].copy()
        sq = f * 2
        # White eyes
        pygame.draw.circle(s, WHITE, (11, 14 + sq), 3)
        pygame.draw.circle(s, WHITE, (21, 14 + sq), 3)
        sprites.setdefault("boss3", []).append(s)

    return sprites

ENEMY_SPRITES = create_enemy_sprites()


# ══════════════════════════════════════════
#  MAP DATA (16x12 per level)
# ══════════════════════════════════════════
# 0=grass 1=wall 2=path 3=water 4=tree 5=tall_grass
# 6=stairs 7=lava 8=dark_floor 9=torch_wall 10=locked_door
W, G, P, Q, T, H, S, L, D, F = 1, 0, 2, 3, 4, 5, 6, 7, 8, 9
K = 10  # Locked door tile
MAPS = [
  # Level 0: Forest
  [[W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W],
   [W,G,G,H,T,G,G,P,P,G,G,T,H,G,G,W],
   [W,G,G,G,G,G,P,P,P,P,G,G,G,G,G,W],
   [W,H,G,T,G,P,P,G,G,P,P,G,T,G,H,W],
   [W,G,G,G,P,P,G,H,H,G,P,P,G,G,G,W],
   [W,T,G,G,P,G,G,G,G,G,G,P,G,G,T,W],
   [W,G,G,G,P,G,H,G,G,H,G,P,G,G,G,W],
   [W,T,G,G,P,P,G,G,G,G,P,P,G,G,T,W],
   [W,H,G,T,G,P,P,P,P,P,P,G,T,G,H,W],
   [W,G,G,G,G,G,G,P,P,G,G,G,G,G,G,W],
   [W,G,G,H,T,G,G,P,S,G,G,T,H,G,G,W],
   [W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W]],
  # Level 1: Cave
  [[W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W],
   [W,D,D,D,W,D,D,D,D,D,D,W,D,D,D,W],
   [W,D,D,D,F,D,D,D,D,D,D,F,D,D,D,W],
   [W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W],
   [W,D,D,D,D,D,W,W,K,W,D,D,D,D,D,W],
   [W,D,D,D,D,D,W,D,D,W,D,D,D,D,D,W],
   [W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W],
   [W,D,D,D,D,D,W,D,D,W,D,D,D,D,D,W],
   [W,D,D,D,D,D,W,W,W,W,D,D,D,D,D,W],
   [W,D,D,D,F,D,D,D,D,D,D,F,D,D,D,W],
   [W,D,D,D,W,D,D,D,S,D,D,W,D,D,D,W],
   [W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W]],
  # Level 2: Castle
  [[W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W],
   [W,P,P,W,P,P,P,P,P,P,P,P,W,P,P,W],
   [W,P,P,P,P,P,P,P,P,P,P,P,P,P,P,W],
   [W,P,P,P,P,P,P,P,P,P,P,P,P,P,P,W],
   [W,W,P,W,W,P,P,P,P,P,P,W,W,P,W,W],
   [W,P,P,P,P,P,P,P,P,P,P,P,P,P,P,W],
   [W,P,P,P,P,P,P,P,P,P,P,P,P,P,P,W],
   [W,W,P,W,W,P,P,P,P,P,P,W,W,P,W,W],
   [W,P,P,P,P,P,P,P,P,P,P,P,P,P,P,W],
   [W,P,P,P,P,P,P,P,P,P,P,P,P,P,P,W],
   [W,P,P,W,P,P,P,P,S,P,P,P,W,P,P,W],
   [W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W]],
  # Level 3: Lava Dungeon
  [[W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W],
   [W,D,D,L,L,D,D,F,D,D,D,L,L,D,D,W],
   [W,D,D,D,L,D,D,D,D,D,D,L,D,D,D,W],
   [W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W],
   [W,L,L,D,D,D,D,K,K,D,D,D,D,L,L,W],
   [W,L,D,D,D,D,D,D,D,D,D,D,D,D,L,W],
   [W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W],
   [W,L,D,D,D,D,D,D,D,D,D,D,D,D,L,W],
   [W,L,L,D,D,D,D,D,D,D,D,D,D,L,L,W],
   [W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W],
   [W,D,D,L,L,D,D,F,S,F,D,D,L,L,D,W],
   [W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W]],
  # Level 4: Boss Arena (Shadow Lord - mid-game boss)
  [[W,W,W,W,W,W,W,F,F,W,W,W,W,W,W,W],
   [W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W],
   [W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W],
   [W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W],
   [W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W],
   [F,D,D,D,D,D,D,D,D,D,D,D,D,D,D,F],
   [F,D,D,D,D,D,D,D,D,D,D,D,D,D,D,F],
   [W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W],
   [W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W],
   [W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W],
   [W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W],
   [W,W,W,W,W,W,W,F,F,W,W,W,W,W,W,W]],
  # Level 5: Ice Cavern
  [[W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W],
   [W,D,D,D,Q,D,D,F,D,D,D,Q,D,D,D,W],
   [W,D,D,Q,Q,Q,D,D,D,D,Q,Q,Q,D,D,W],
   [W,D,D,D,Q,D,D,D,D,D,D,Q,D,D,D,W],
   [W,D,D,D,D,D,W,W,K,W,D,D,D,D,D,W],
   [W,Q,Q,D,D,D,W,D,D,W,D,D,D,Q,Q,W],
   [W,Q,Q,D,D,D,D,D,D,D,D,D,D,Q,Q,W],
   [W,D,D,D,D,D,W,D,D,W,D,D,D,D,D,W],
   [W,D,D,D,D,D,W,W,W,W,D,D,D,D,D,W],
   [W,D,D,Q,Q,D,D,D,D,D,D,Q,Q,D,D,W],
   [W,D,D,D,Q,D,D,F,S,F,D,Q,D,D,D,W],
   [W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W]],
  # Level 6: Skull Woods
  [[W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W],
   [W,D,D,T,D,D,D,D,D,D,D,D,T,D,D,W],
   [W,D,T,T,D,D,F,D,D,F,D,D,T,T,D,W],
   [W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W],
   [W,T,D,D,D,W,D,K,K,D,W,D,D,D,T,W],
   [W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W],
   [W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W],
   [W,T,D,D,D,W,D,D,D,D,W,D,D,D,T,W],
   [W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W],
   [W,D,T,T,D,D,F,D,D,F,D,D,T,T,D,W],
   [W,D,D,T,D,D,D,D,S,D,D,D,T,D,D,W],
   [W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W]],
  # Level 7: Thieves' Hideout
  [[W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W],
   [W,D,D,W,D,D,D,D,D,D,D,D,W,D,D,W],
   [W,D,D,K,D,D,D,D,D,D,D,D,K,D,D,W],
   [W,D,D,W,W,W,D,D,D,D,W,W,W,D,D,W],
   [W,D,D,D,D,W,D,F,F,D,W,D,D,D,D,W],
   [W,W,K,W,D,D,D,D,D,D,D,D,W,K,W,W],
   [W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W],
   [W,W,K,W,D,D,D,D,D,D,D,D,W,K,W,W],
   [W,D,D,D,D,W,D,D,D,D,W,D,D,D,D,W],
   [W,D,D,W,W,W,D,D,D,D,W,W,W,D,D,W],
   [W,D,D,D,D,D,D,D,S,D,D,D,D,D,D,W],
   [W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W]],
  # Level 8: Swamp Palace
  [[W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W],
   [W,Q,Q,D,D,D,D,F,D,D,D,D,Q,Q,D,W],
   [W,Q,D,D,D,D,D,D,D,D,D,D,D,Q,D,W],
   [W,D,D,D,Q,Q,D,D,D,D,Q,Q,D,D,D,W],
   [W,D,D,Q,Q,Q,D,K,K,D,Q,Q,Q,D,D,W],
   [W,D,D,Q,Q,D,D,D,D,D,D,Q,Q,D,D,W],
   [W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W],
   [W,D,D,Q,Q,D,D,D,D,D,D,Q,Q,D,D,W],
   [W,D,D,Q,Q,Q,D,D,D,D,Q,Q,Q,D,D,W],
   [W,D,D,D,Q,Q,D,D,D,D,Q,Q,D,D,D,W],
   [W,Q,D,D,D,D,D,F,S,F,D,D,D,D,Q,W],
   [W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W]],
  # Level 9: Misery Mire
  [[W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W],
   [W,D,D,L,D,D,D,F,D,D,D,L,D,D,D,W],
   [W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W],
   [W,L,D,D,D,D,D,D,D,D,D,D,D,D,L,W],
   [W,L,D,D,D,W,W,K,W,W,D,D,D,D,L,W],
   [W,D,D,D,D,W,D,D,D,W,D,D,D,D,D,W],
   [W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W],
   [W,D,D,D,D,W,D,D,D,W,D,D,D,D,D,W],
   [W,L,D,D,D,W,W,W,W,W,D,D,D,D,L,W],
   [W,L,D,D,D,D,D,D,D,D,D,D,D,D,L,W],
   [W,D,D,D,D,D,D,F,S,F,D,D,D,D,D,W],
   [W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W]],
  # Level 10: Turtle Rock
  [[W,W,W,W,W,W,W,F,F,W,W,W,W,W,W,W],
   [W,D,D,D,L,D,D,D,D,D,D,L,D,D,D,W],
   [W,D,D,L,L,D,D,D,D,D,D,L,L,D,D,W],
   [W,D,D,D,D,D,K,D,D,K,D,D,D,D,D,W],
   [W,L,D,D,D,D,D,D,D,D,D,D,D,D,L,W],
   [F,D,D,D,D,D,D,D,D,D,D,D,D,D,D,F],
   [F,D,D,D,D,D,D,D,D,D,D,D,D,D,D,F],
   [W,L,D,D,D,D,D,D,D,D,D,D,D,D,L,W],
   [W,D,D,D,D,D,K,D,D,K,D,D,D,D,D,W],
   [W,D,D,L,L,D,D,D,D,D,D,L,L,D,D,W],
   [W,D,D,D,L,D,D,D,S,D,D,L,D,D,D,W],
   [W,W,W,W,W,W,W,F,F,W,W,W,W,W,W,W]],
  # Level 11: Ganon's Tower (Final Boss)
  [[W,W,W,W,W,W,F,F,F,F,W,W,W,W,W,W],
   [W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W],
   [W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W],
   [W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W],
   [W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W],
   [F,D,D,D,D,D,D,D,D,D,D,D,D,D,D,F],
   [F,D,D,D,D,D,D,D,D,D,D,D,D,D,D,F],
   [W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W],
   [W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W],
   [W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W],
   [W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W],
   [W,W,W,W,W,W,F,F,F,F,W,W,W,W,W,W]],
]

LEVEL_NAMES = ["The Forest", "Dark Cave", "Castle Halls", "Lava Depths", "Shadow Lord"]
LEVEL_SUBTITLES = ["Find the boomerang!", "Beware the shadows...", "The Pegasus Boots await!", "Heat and fire...", "Final battle!"]

# ══════════════════════════════════════════
#  TILE RENDERER
# ══════════════════════════════════════════
def draw_tile(surf, tile, col, row, ticks):
    x = col * TILE
    y = row * TILE + GAME_Y
    r = pygame.Rect(x, y, TILE, TILE)
    rng = random.Random(col * 137 + row * 97)

    if tile == G:  # Grass
        surf.fill(GRASS1, r)
        # Grass detail
        for _ in range(3):
            gx = x + rng.randint(2, 13)
            gy = y + rng.randint(3, 13)
            pygame.draw.rect(surf, GRASS2, (gx, gy, 1, 2))

    elif tile == W:  # Wall
        surf.fill(GRAY, r)
        pygame.draw.rect(surf, DKGRAY, r, 1)
        pygame.draw.line(surf, DKGRAY, (x, y + 5), (x + 15, y + 5))
        pygame.draw.line(surf, DKGRAY, (x, y + 10), (x + 15, y + 10))
        pygame.draw.line(surf, DKGRAY, (x + 8, y), (x + 8, y + 5))
        pygame.draw.line(surf, DKGRAY, (x + 4, y + 5), (x + 4, y + 10))
        pygame.draw.line(surf, DKGRAY, (x + 12, y + 10), (x + 12, y + 15))

    elif tile == P:  # Path
        surf.fill(BROWN, r)
        # Dirt texture
        for _ in range(2):
            dx = x + rng.randint(2, 12)
            dy = y + rng.randint(2, 12)
            pygame.draw.rect(surf, DKBROWN, (dx, dy, 2, 1))

    elif tile == Q:  # Water
        c = BLUE if ((ticks // 20) % 2 == 0) else (24, 72, 180)
        surf.fill(c, r)
        for i in range(2):
            wy = y + 4 + i * 8
            for wx in range(x + 2, x + 14, 5):
                off = int(math.sin((wx + ticks * 0.05) * 0.3) * 2)
                pygame.draw.rect(surf, LTBLUE, (wx, wy + off, 3, 1))

    elif tile == T:  # Tree
        surf.fill(GRASS1, r)
        pygame.draw.rect(surf, BROWN, (x + 6, y + 9, 4, 6))
        pygame.draw.circle(surf, GREEN, (x + 8, y + 6), 6)
        pygame.draw.circle(surf, LTGREEN, (x + 6, y + 4), 3)

    elif tile == H:  # Tall grass (cuttable!)
        surf.fill(GRASS1, r)
        for i in range(3):
            gx = x + 2 + i * 5
            sway = int(math.sin(ticks * 0.04 + gx * 0.2) * 1)
            pygame.draw.rect(surf, GREEN, (gx + sway, y + 2, 2, 10))
            pygame.draw.rect(surf, LTGREEN, (gx + sway, y + 2, 2, 3))

    elif tile == S:  # Stairs
        surf.fill(DKBROWN, r)
        for i in range(4):
            sy = y + i * 4
            c = min(255, 60 + i * 20)
            pygame.draw.rect(surf, (c, c - 10, c - 20), (x + 2, sy, 12, 4))
            pygame.draw.rect(surf, DKGRAY, (x + 2, sy, 12, 4), 1)
        # Arrow
        pygame.draw.polygon(surf, YELLOW, [(x + 8, y + 1), (x + 6, y + 4), (x + 10, y + 4)])

    elif tile == L:  # Lava
        c = LAVA1 if ((ticks // 15 + col + row) % 2 == 0) else LAVA2
        surf.fill(c, r)
        for _ in range(2):
            lx = x + rng.randint(2, 12)
            ly = y + rng.randint(2, 12)
            off = int(math.sin(ticks * 0.06 + lx) * 2)
            pygame.draw.circle(surf, ORANGE, (lx + off, ly), 2)
        # Glow
        if rng.random() < 0.3:
            glow = pygame.Surface((TILE, TILE), pygame.SRCALPHA)
            a = int(abs(math.sin(ticks * 0.04 + col)) * 30)
            glow.fill((255, 100, 0, a))
            surf.blit(glow, (x, y))

    elif tile == D:  # Dark floor
        surf.fill((28, 26, 34), r)
        pygame.draw.rect(surf, (22, 20, 28), r, 1)

    elif tile == F:  # Torch wall
        surf.fill(GRAY, r)
        pygame.draw.rect(surf, DKGRAY, r, 1)
        pygame.draw.rect(surf, BROWN, (x + 6, y + 6, 4, 6))
        # Flame
        flk = random.randint(-1, 1)
        pygame.draw.rect(surf, YELLOW, (x + 6 + flk, y + 3, 4, 4))
        pygame.draw.rect(surf, ORANGE, (x + 7 + flk, y + 2, 2, 3))
        pygame.draw.rect(surf, RED, (x + 7 + flk, y + 1, 2, 2))
        # Glow
        glow = pygame.Surface((TILE, TILE), pygame.SRCALPHA)
        pygame.draw.circle(glow, (255, 200, 50, 20), (8, 8), 10)
        surf.blit(glow, (x, y))

    elif tile == K:  # Locked door
        surf.fill(DKBROWN, r)
        pygame.draw.rect(surf, BROWN, (x + 2, y + 2, 12, 12))
        pygame.draw.rect(surf, DKBROWN, (x + 2, y + 2, 12, 12), 1)
        # Iron bands
        pygame.draw.rect(surf, DKMETAL, (x + 1, y + 4, 14, 2))
        pygame.draw.rect(surf, DKMETAL, (x + 1, y + 10, 14, 2))
        # Lock
        pygame.draw.circle(surf, YELLOW, (x + 8, y + 8), 3)
        pygame.draw.circle(surf, DKBROWN, (x + 8, y + 8), 1)
        pygame.draw.rect(surf, YELLOW, (x + 7, y + 9, 2, 3))
        # Shimmer
        if (ticks // 30) % 3 == 0:
            pygame.draw.rect(surf, WHITE, (x + 6, y + 6, 1, 1))


# ══════════════════════════════════════════
#  PARTICLE / DAMAGE NUMBER
# ══════════════════════════════════════════
class Particle:
    def __init__(self, x, y, color, vx=None, vy=None, life=20, size=2):
        self.x, self.y = x, y
        self.vx = vx if vx is not None else random.uniform(-1.5, 1.5)
        self.vy = vy if vy is not None else random.uniform(-2.5, -0.3)
        self.color, self.life, self.max_life, self.size = color, life, life, size

    def update(self):
        self.x += self.vx; self.y += self.vy; self.vy += 0.08; self.life -= 1

    def draw(self, surf):
        a = self.life / self.max_life
        s = max(1, int(self.size * a))
        pygame.draw.rect(surf, self.color, (int(self.x), int(self.y) + GAME_Y, s, s))


class DmgNum:
    def __init__(self, x, y, text, color=WHITE):
        self.x, self.y, self.text, self.color = x, y, text, color
        self.life, self.vy = 35, -0.8

    def update(self):
        self.y += self.vy; self.vy += 0.02; self.life -= 1

    def draw(self, surf):
        if self.life > 0:
            t = font_sm.render(self.text, True, self.color)
            surf.blit(t, (int(self.x) - t.get_width() // 2, int(self.y) + GAME_Y))


# ══════════════════════════════════════════
#  PROJECTILE
# ══════════════════════════════════════════
class Projectile:
    def __init__(self, x, y, dx, dy, kind="arrow", owner="player"):
        self.x, self.y, self.dx, self.dy = x, y, dx, dy
        self.kind, self.owner = kind, owner
        self.alive, self.timer = True, 0
        self.speed = 3.5 if kind == "arrow" else (1.8 if kind == "bomb" else (4.0 if kind == "boomerang" else (1.0 if kind == "trident" else 2.5)))
        self.exploded, self.exp_timer, self.exp_r = False, 0, 24
        # Boomerang-specific
        self.returning = False
        self.lifetime = 0
        self.spin_angle = 0

    @property
    def rect(self):
        if self.kind == "bomb" and self.exploded:
            return pygame.Rect(self.x - self.exp_r, self.y - self.exp_r, self.exp_r * 2, self.exp_r * 2)
        return pygame.Rect(self.x - 2, self.y - 2, 4, 4)

    def update(self, cmap, particles):
        if self.kind == "bomb":
            if not self.exploded:
                self.x += self.dx * self.speed
                self.y += self.dy * self.speed
                self.speed *= 0.96
                self.timer += 1
                if self.timer % 10 == 0:
                    SFX["bomb_tick"].play()
                if self.timer > 35 or self.speed < 0.3:
                    self.exploded = True
                    self.exp_timer = 15
                    SFX["bomb"].play()
                    for _ in range(15):
                        particles.append(Particle(self.x, self.y,
                            random.choice([RED, ORANGE, YELLOW, WHITE]),
                            life=random.randint(10, 25), size=random.randint(1, 3)))
            else:
                self.exp_timer -= 1
                if self.exp_timer <= 0:
                    self.alive = False
        elif self.kind == "boomerang":
            self.lifetime += 1
            self.spin_angle = (self.spin_angle + 15) % 360
            if self.lifetime > 40 and not self.returning:
                self.returning = True
                self.dx = -self.dx
                self.dy = -self.dy
            self.x += self.dx * self.speed
            self.y += self.dy * self.speed
            # Boomerang dies if it goes way off screen (safety)
            if self.lifetime > 160:
                self.alive = False
        elif self.kind == "trident":
            # Spinning trident that returns like a boomerang
            self.lifetime += 1
            self.spin_angle = (self.spin_angle + 10) % 360
            self.x += self.dx * self.speed
            self.y += self.dy * self.speed
            if self.lifetime > 50 and not self.returning:
                self.returning = True
                self.dx = -self.dx
                self.dy = -self.dy
            if self.lifetime > 120:
                self.alive = False
        else:
            self.x += self.dx * self.speed
            self.y += self.dy * self.speed
            self.timer += 1
            c, r = int(self.x) // TILE, int(self.y) // TILE
            if 0 <= r < MAP_ROWS and 0 <= c < MAP_COLS:
                if cmap[r][c] in (W, Q, T, L, K):
                    self.alive = False
                    for _ in range(3):
                        particles.append(Particle(self.x, self.y, YELLOW, life=8))
            else:
                self.alive = False
            if self.timer > 80:
                self.alive = False

    def draw(self, surf):
        sx, sy = int(self.x), int(self.y) + GAME_Y
        if self.kind == "arrow":
            ex = sx + int(self.dx * 5)
            ey = sy + int(self.dy * 5)
            pygame.draw.line(surf, BROWN, (sx, sy), (ex, ey), 1)
            pygame.draw.rect(surf, METAL, (ex - 1, ey - 1, 2, 2))
        elif self.kind == "bomb":
            if not self.exploded:
                pygame.draw.circle(surf, DKGRAY, (sx, sy), 3)
                spark = YELLOW if (self.timer // 3) % 2 == 0 else ORANGE
                pygame.draw.rect(surf, spark, (sx, sy - 4, 2, 2))
            else:
                p = self.exp_timer / 15
                r = int(self.exp_r * (1 - p * 0.3))
                es = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
                a = int(200 * p)
                pygame.draw.circle(es, (255, 200, 50, a), (r, r), r)
                pygame.draw.circle(es, (255, 100, 0, a // 2), (r, r), r // 2)
                surf.blit(es, (sx - r, sy - r))
        elif self.kind == "boomerang":
            # Draw spinning boomerang (L-shaped)
            cx, cy = sx, sy
            angle = math.radians(self.spin_angle)
            for arm_angle in [0, math.pi / 2]:
                a = angle + arm_angle
                ex = cx + int(math.cos(a) * 5)
                ey = cy + int(math.sin(a) * 5)
                pygame.draw.line(surf, (200, 168, 112), (cx, cy), (ex, ey), 2)
        elif self.kind == "fireball":
            pygame.draw.circle(surf, ORANGE, (sx, sy), 3)
            pygame.draw.circle(surf, YELLOW, (sx, sy), 1)
        elif self.kind == "magic":
            # Purple energy ball
            pygame.draw.circle(surf, (160, 60, 200), (sx, sy), 4)
            pygame.draw.circle(surf, (200, 120, 240), (sx, sy), 2)
        elif self.kind == "rock":
            pygame.draw.circle(surf, (120, 110, 100), (int(self.x), int(self.y) + GAME_Y), 3)
            pygame.draw.circle(surf, (80, 70, 60), (int(self.x), int(self.y) + GAME_Y), 3, 1)
        elif self.kind == "trident":
            # Spinning trident projectile
            cx, cy = sx, sy
            angle = math.radians(self.spin_angle)
            ex = int(math.cos(angle) * 8)
            ey = int(math.sin(angle) * 8)
            pygame.draw.line(surf, (200, 180, 60), (cx - ex, cy - ey), (cx + ex, cy + ey), 2)
            # Prongs at tip
            pygame.draw.circle(surf, (220, 200, 80), (cx + ex, cy + ey), 3)
            pygame.draw.circle(surf, (255, 220, 100), (cx + ex, cy + ey), 1)


# ══════════════════════════════════════════
#  PLAYER KEY MAPS & TINTS (4-player co-op)
# ══════════════════════════════════════════
PLAYER_KEYS = {
    1: {"up": [pygame.K_w, pygame.K_UP], "down": [pygame.K_s, pygame.K_DOWN],
        "left": [pygame.K_a, pygame.K_LEFT], "right": [pygame.K_d, pygame.K_RIGHT],
        "attack": pygame.K_SPACE, "interact": pygame.K_e, "dash": pygame.K_LSHIFT,
        "weapon1": pygame.K_1, "weapon2": pygame.K_2, "weapon3": pygame.K_3, "weapon4": pygame.K_4,
        "weapon5": pygame.K_5},
    2: {"up": [pygame.K_i], "down": [pygame.K_k], "left": [pygame.K_j], "right": [pygame.K_l],
        "attack": pygame.K_RETURN, "interact": pygame.K_SEMICOLON, "dash": pygame.K_RSHIFT,
        "weapon1": pygame.K_7, "weapon2": pygame.K_8, "weapon3": pygame.K_9, "weapon4": pygame.K_0,
        "weapon5": pygame.K_MINUS},
    3: {"up": [pygame.K_t], "down": [pygame.K_g], "left": [pygame.K_f], "right": [pygame.K_h],
        "attack": pygame.K_y, "interact": pygame.K_u, "dash": pygame.K_CAPSLOCK,
        "weapon1": pygame.K_4, "weapon2": pygame.K_5, "weapon3": pygame.K_6, "weapon4": pygame.K_MINUS,
        "weapon5": pygame.K_EQUALS},
    4: {"up": [pygame.K_KP8], "down": [pygame.K_KP5], "left": [pygame.K_KP4], "right": [pygame.K_KP6],
        "attack": pygame.K_KP0, "interact": pygame.K_KP_ENTER, "dash": pygame.K_KP_PLUS,
        "weapon1": pygame.K_KP1, "weapon2": pygame.K_KP2, "weapon3": pygame.K_KP3, "weapon4": pygame.K_KP_PERIOD,
        "weapon5": pygame.K_KP7},
}

PLAYER_TINTS = {
    1: None,              # Original green Link
    2: (0, 0, 180),       # Blue Link
    3: (180, 0, 0),       # Red Link
    4: (120, 0, 160),     # Purple Link
}

def _create_tinted_sprites(tint):
    """Create a color-shifted copy of all player sprites for a co-op player."""
    tinted = {}
    for key, frames in PLAYER_SPRITES.items():
        new_frames = []
        for frame in frames:
            f = frame.copy()
            # Color shift: blend the tint onto non-transparent pixels
            overlay = pygame.Surface(f.get_size(), pygame.SRCALPHA)
            overlay.fill((*tint, 100))
            f.blit(overlay, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
            # Re-brighten with additive tint so the character is clearly colored
            bright = pygame.Surface(f.get_size(), pygame.SRCALPHA)
            bright.fill((*tint, 60))
            f.blit(bright, (0, 0), special_flags=pygame.BLEND_RGBA_ADD)
            new_frames.append(f)
        tinted[key] = new_frames
    return tinted

# Pre-create tinted sprite sets for each player color
TINTED_SPRITES = {}
for _pn, _tint in PLAYER_TINTS.items():
    if _tint is not None:
        TINTED_SPRITES[_pn] = _create_tinted_sprites(_tint)

# ══════════════════════════════════════════
#  PLAYER
# ══════════════════════════════════════════
class Player:
    def __init__(self, x, y, keys=None, tint=None, player_num=1):
        self.x, self.y = float(x), float(y)
        self.w, self.h = 10, 12  # Hitbox smaller than sprite
        self.speed = 1.8
        self.hp, self.max_hp = 6, 6
        self.dir = "down"
        self.attacking, self.atk_t, self.atk_dur = False, 0, 12
        self.invincible = 0
        self.rupees, self.arrows, self.bombs, self.keys = 0, 15, 5, 0
        self.weapon = "sword"
        self.weapons_unlocked = ["sword"]
        self.walk_frame, self.walk_t = 0, 0
        self.kills, self.dmg_dealt, self.game_time = 0, 0, 0
        self.kb_vx, self.kb_vy, self.kb_t = 0.0, 0.0, 0  # Knockback
        self.player_num = player_num
        self.tint = tint
        self.dead = False
        self.respawn_timer = 0
        self.sprites = TINTED_SPRITES.get(player_num, PLAYER_SPRITES) if tint else PLAYER_SPRITES
        self.input_keys = keys or PLAYER_KEYS[1]
        self.ledge_hop = 0       # >0 means currently hopping off a cliff ledge
        self.ledge_hop_vy = 0.0
        self.heart_pieces = 0
        # Spin attack
        self.charge_time = 0
        self.spin_attacking = False
        self.spin_t = 0
        self._carried_pot = None
        self.step_timer = 0
        self._wants_step = False
        # Pegasus Boots dash
        self.has_boots = False
        self.dashing = False
        self.dash_timer = 0
        self.dash_dir = None
        # Zora's Flippers — swimming
        self.has_flippers = False
        self.swimming = False
        self.swim_frame = 0
        self.swim_timer = 0
        # Item hold animation (ALttP-style hold-above-head)
        self.holding_item = None
        self.holding_timer = 0
        # Hookshot
        self.has_hookshot = False
        self.hookshot_active = False
        self.hookshot_x = 0
        self.hookshot_y = 0
        self.hookshot_dx = 0
        self.hookshot_dy = 0
        self.hookshot_length = 0
        self.hookshot_max = 80
        self.hookshot_speed = 5
        self.hookshot_retracting = False
        self.hookshot_hit_wall = False
        # Lantern
        self.has_lantern = False
        self.lantern_fuel = 100
        self.lantern_on = False
        # Magic meter
        self.magic = 0
        self.max_magic = 0
        self.has_magic = False

    @property
    def rect(self):
        return pygame.Rect(self.x - self.w // 2, self.y - self.h // 2, self.w, self.h)

    def sword_rect(self):
        """Hitbox that follows the sword arc from hand position."""
        progress = self.atk_t / self.atk_dur
        sword_len = 14

        # Hand offsets and arc angles (must match draw code)
        if self.dir == "down":
            hx, hy = self.x, self.y + 4
            base_angle = math.pi * 0.8
            sweep = -math.pi * 0.6
        elif self.dir == "up":
            hx, hy = self.x, self.y - 8
            base_angle = -math.pi * 0.8
            sweep = math.pi * 0.6
        elif self.dir == "left":
            hx, hy = self.x - 6, self.y - 2
            base_angle = math.pi * 0.3
            sweep = math.pi * 0.6
        else:  # right
            hx, hy = self.x + 6, self.y - 2
            base_angle = -math.pi * 0.3
            sweep = -math.pi * 0.6

        angle = base_angle + sweep * progress
        tip_x = hx + math.cos(angle) * sword_len
        tip_y = hy + math.sin(angle) * sword_len

        # Hitbox centered on the sword tip area
        hit_size = 10
        return pygame.Rect(tip_x - hit_size // 2, tip_y - hit_size // 2, hit_size, hit_size)

    def update(self, keys_pressed, cmap):
        self.game_time += 1

        # Magic regen
        if self.has_magic and self.magic < self.max_magic:
            if self.game_time % 120 == 0:
                self.magic = min(self.max_magic, self.magic + 1)

        # Hookshot movement (freezes player while active)
        if self.hookshot_active:
            if not self.hookshot_retracting:
                # Extend
                self.hookshot_x += self.hookshot_dx
                self.hookshot_y += self.hookshot_dy
                self.hookshot_length += self.hookshot_speed
                if self.hookshot_length >= self.hookshot_max:
                    self.hookshot_retracting = True
            else:
                if self.hookshot_hit_wall:
                    # Pull player toward hook point
                    dx = self.hookshot_x - self.x
                    dy = self.hookshot_y - self.y
                    dist = max(1, math.sqrt(dx * dx + dy * dy))
                    if dist < 4:
                        self.hookshot_active = False
                    else:
                        self.x += (dx / dist) * 4
                        self.y += (dy / dist) * 4
                else:
                    # Retract hook to player
                    dx = self.x - self.hookshot_x
                    dy = self.y - self.hookshot_y
                    dist = max(1, math.sqrt(dx * dx + dy * dy))
                    if dist < 4:
                        self.hookshot_active = False
                    else:
                        self.hookshot_x += (dx / dist) * self.hookshot_speed
                        self.hookshot_y += (dy / dist) * self.hookshot_speed
            return  # Skip normal movement during hookshot

        # Item hold animation freeze (ALttP-style hold-above-head)
        if self.holding_timer > 0:
            self.holding_timer -= 1
            return  # Freeze player during item hold

        # Apply knockback (overrides movement while active)
        if self.kb_t > 0:
            self.kb_t -= 1
            friction = 0.8
            self.kb_vx *= friction
            self.kb_vy *= friction
            hw, hh = self.w // 2, self.h // 2
            nx = self.x + self.kb_vx
            tr = pygame.Rect(nx - hw, self.y - hh, self.w, self.h)
            if not self._wall(tr, cmap):
                self.x = nx
            else:
                self.kb_vx = 0
            ny = self.y + self.kb_vy
            tr = pygame.Rect(self.x - hw, ny - hh, self.w, self.h)
            if not self._wall(tr, cmap):
                self.y = ny
            else:
                self.kb_vy = 0
            self.x = max(hw + 1, min(MAP_COLS * TILE - hw - 1, self.x))
            self.y = max(hh + 1, min(MAP_ROWS * TILE - hh - 1, self.y))
        else:
            dx = dy = 0
            if any(keys_pressed[k] for k in self.input_keys["up"]):    dy = -self.speed; self.dir = "up"
            if any(keys_pressed[k] for k in self.input_keys["down"]):  dy = self.speed;  self.dir = "down"
            if any(keys_pressed[k] for k in self.input_keys["left"]):  dx = -self.speed; self.dir = "left"
            if any(keys_pressed[k] for k in self.input_keys["right"]): dx = self.speed;  self.dir = "right"

            # Pegasus Boots dash: hold SHIFT + direction to trigger
            dash_key = self.input_keys.get("dash")
            if (dash_key and keys_pressed[dash_key] and self.has_boots
                    and not self.dashing and not self._carried_pot
                    and not self.swimming and (dx != 0 or dy != 0)):
                self.dashing = True
                self.dash_timer = 20
                self.dash_dir = self.dir
                SFX["arrow"].play()

            # Pegasus Boots dash: override movement when dashing
            if self.dashing:
                self.dash_timer -= 1
                dash_speed = 4
                ddx, ddy = {"up": (0, -1), "down": (0, 1), "left": (-1, 0), "right": (1, 0)}[self.dash_dir]
                dx = ddx * dash_speed
                dy = ddy * dash_speed
                if self.dash_timer <= 0:
                    self.dashing = False
            elif dx != 0 and dy != 0:
                dx *= 0.707; dy *= 0.707

            if dx != 0 or dy != 0:
                self.walk_t += 1
                if self.walk_t >= 8:
                    self.walk_frame = (self.walk_frame + 1) % 2
                    self.walk_t = 0
                self.step_timer += 1
                if self.step_timer >= 12:
                    self.step_timer = 0
                    self._wants_step = True
            else:
                self.walk_frame = 0

            hw, hh = self.w // 2, self.h // 2
            # Move X
            nx = self.x + dx
            tr = pygame.Rect(nx - hw, self.y - hh, self.w, self.h)
            if not self._wall(tr, cmap):
                self.x = nx
            elif self.dashing:
                self.dashing = False  # Stop dash on wall collision
            # Move Y
            ny = self.y + dy
            tr = pygame.Rect(self.x - hw, ny - hh, self.w, self.h)
            if not self._wall(tr, cmap):
                self.y = ny
            elif self.dashing:
                self.dashing = False  # Stop dash on wall collision

            self.x = max(hw + 1, min(MAP_COLS * TILE - hw - 1, self.x))
            self.y = max(hh + 1, min(MAP_ROWS * TILE - hh - 1, self.y))

        if self.attacking:
            self.atk_t += 1
            if self.atk_t >= self.atk_dur:
                self.attacking = False
                self.atk_t = 0
        if self.invincible > 0:
            self.invincible -= 1

        # Spin attack charge: hold attack key to charge, release for spin
        attack_key = self.input_keys.get("attack", pygame.K_SPACE)
        if isinstance(attack_key, list):
            attack_held = any(keys_pressed[k] for k in attack_key)
        else:
            attack_held = keys_pressed[attack_key]

        if attack_held and not self.attacking and self.weapon == "sword" and not self.swimming:
            self.charge_time += 1
        elif not attack_held and self.charge_time > 45 and not self.swimming:
            # Release spin attack!
            self.spin_attacking = True
            self.spin_t = 0
            self.charge_time = 0
            SFX["sword"].play()
            if self.has_magic:
                self.magic = max(0, self.magic - 3)
        elif not attack_held:
            self.charge_time = 0

        # Update spin attack timer
        if self.spin_attacking:
            self.spin_t += 1
            if self.spin_t >= 12:
                self.spin_attacking = False

    def _wall(self, rect, cmap):
        for cx, cy in [(rect.left, rect.top), (rect.right - 1, rect.top),
                       (rect.left, rect.bottom - 1), (rect.right - 1, rect.bottom - 1)]:
            c, r = int(cx) // TILE, int(cy) // TILE
            if 0 <= r < MAP_ROWS and 0 <= c < MAP_COLS:
                tile = cmap[r][c]
                # Dungeon water (Q=3) is passable with Zora's Flippers
                if tile == Q and self.has_flippers:
                    continue
                if tile in (W, Q, T, L, K):
                    return True
            else:
                return True
        return False

    def attack(self, projectiles, cmap, particles):
        if self.attacking:
            return
        self.attacking = True
        self.atk_t = 0
        dirs = {"up": (0, -1), "down": (0, 1), "left": (-1, 0), "right": (1, 0)}
        ddx, ddy = dirs[self.dir]

        if self.weapon == "sword":
            SFX["sword"].play()
            # Cut tall grass
            sr = self.sword_rect()
            for check_t in range(self.atk_dur):
                self.atk_t = check_t
                sr = self.sword_rect()
                gc, gr_tile = (sr.centerx) // TILE, (sr.centery) // TILE
                if 0 <= gr_tile < MAP_ROWS and 0 <= gc < MAP_COLS:
                    if cmap[gr_tile][gc] == H:
                        cmap[gr_tile][gc] = G
                        SFX["grass"].play()
                        for _ in range(5):
                            particles.append(Particle(gc * TILE + 8, gr_tile * TILE + 8,
                                random.choice([GREEN, LTGREEN]), life=15, size=2))
                        # Sometimes drop stuff from grass
                        if random.random() < 0.25:
                            from_grass_pickups.append(("rupee" if random.random() < 0.7 else "heart",
                                                       gc * TILE + 8, gr_tile * TILE + 8))
            self.atk_t = 0
        elif self.weapon == "bow" and self.arrows > 0:
            self.arrows -= 1
            SFX["arrow"].play()
            projectiles.append(Projectile(self.x + ddx * 8, self.y + ddy * 8, ddx, ddy, "arrow"))
        elif self.weapon == "bomb" and self.bombs > 0:
            self.bombs -= 1
            projectiles.append(Projectile(self.x + ddx * 8, self.y + ddy * 8, ddx, ddy, "bomb"))
        elif self.weapon == "boomerang":
            SFX["arrow"].play()
            projectiles.append(Projectile(self.x + ddx * 8, self.y + ddy * 8, ddx, ddy, "boomerang", "player"))
        elif self.weapon == "hookshot":
            SFX["arrow"].play()
            self.hookshot_active = True
            self.hookshot_x = self.x
            self.hookshot_y = self.y
            self.hookshot_dx = ddx * self.hookshot_speed
            self.hookshot_dy = ddy * self.hookshot_speed
            self.hookshot_length = 0
            self.hookshot_retracting = False
            self.hookshot_hit_wall = False
            if self.has_magic:
                self.magic = max(0, self.magic - 5)

    def take_damage(self, amt=1, from_x=None, from_y=None):
        if self.invincible <= 0:
            self.hp -= amt
            self.invincible = 50
            SFX["hurt"].play()
            # Knockback away from damage source (ALttP-style: strong initial push)
            if from_x is not None and from_y is not None:
                dx = self.x - from_x
                dy = self.y - from_y
                dist = max(1, math.sqrt(dx * dx + dy * dy))
                self.kb_vx = (dx / dist) * 5.0
                self.kb_vy = (dy / dist) * 5.0
                self.kb_t = 12

    def draw(self, surf):
        if self.invincible > 0 and (self.invincible // 3) % 2 == 0:
            return

        px, py = int(self.x), int(self.y)

        # Shadow
        shadow = pygame.Surface((12, 6), pygame.SRCALPHA)
        pygame.draw.ellipse(shadow, (0, 0, 0, 50), (0, 0, 12, 6))
        surf.blit(shadow, (px - 6, py + 2 + GAME_Y))

        # Choose sprite: attack sprite or walk sprite
        sp = self.sprites
        if self.attacking and self.weapon == "sword":
            atk_key = f"atk_{self.dir}"
            if atk_key in sp:
                frame = min(self.atk_t * 2 // self.atk_dur, 1)
                sprite = sp[atk_key][frame]
            else:
                sprite = sp[self.dir][self.walk_frame]
        else:
            sprite = sp[self.dir][self.walk_frame]

        sw, sh = sprite.get_size()
        sx = px - sw // 2
        sy = py - sh + 10 + GAME_Y
        surf.blit(sprite, (sx, sy))

        # Draw sword swing from hands (not center)
        if self.attacking and self.weapon == "sword":
            progress = self.atk_t / self.atk_dur
            sword_len = 14

            # Hand position offset from player center (where sword originates)
            if self.dir == "down":
                hx, hy = px, py + 4 + GAME_Y
                base_angle = math.pi * 0.8
                sweep = -math.pi * 0.6
            elif self.dir == "up":
                hx, hy = px, py - 8 + GAME_Y
                base_angle = -math.pi * 0.8
                sweep = math.pi * 0.6
            elif self.dir == "left":
                hx, hy = px - 6, py - 2 + GAME_Y
                base_angle = math.pi * 0.3
                sweep = math.pi * 0.6
            else:  # right
                hx, hy = px + 6, py - 2 + GAME_Y
                base_angle = -math.pi * 0.3
                sweep = -math.pi * 0.6

            angle = base_angle + sweep * progress
            ex = hx + int(math.cos(angle) * sword_len)
            ey = hy + int(math.sin(angle) * sword_len)

            # Sword blade (thicker, from hands)
            pygame.draw.line(surf, DKMETAL, (hx, hy), (ex, ey), 3)
            pygame.draw.line(surf, METAL, (hx, hy), (ex, ey), 2)
            # Bright edge
            mid_x = (hx + ex) // 2
            mid_y = (hy + ey) // 2
            pygame.draw.line(surf, WHITE, (mid_x, mid_y), (ex, ey), 1)
            # Tip
            pygame.draw.rect(surf, WHITE, (ex - 1, ey - 1, 3, 3))

            # Swing trail arc
            for t in range(4):
                tp = max(0, progress - (t + 1) * 0.06)
                ta = base_angle + sweep * tp
                tx = hx + int(math.cos(ta) * (sword_len - t))
                ty = hy + int(math.sin(ta) * (sword_len - t))
                alpha = 150 - t * 40
                trail_surf = pygame.Surface((3, 3), pygame.SRCALPHA)
                trail_surf.fill((220, 220, 255, max(0, alpha)))
                surf.blit(trail_surf, (tx - 1, ty - 1))

        # Shield (when not attacking, draw small shield on facing side)
        if not self.attacking:
            if self.dir == "down":
                pygame.draw.rect(surf, DKBLUE, (px + 3, py - 1 + GAME_Y, 4, 6))
                pygame.draw.rect(surf, BLUE, (px + 4, py + GAME_Y, 2, 4))
            elif self.dir == "up":
                pygame.draw.rect(surf, DKBLUE, (px - 7, py - 3 + GAME_Y, 4, 6))
                pygame.draw.rect(surf, BLUE, (px - 6, py - 2 + GAME_Y, 2, 4))
            elif self.dir == "left":
                pygame.draw.rect(surf, DKBLUE, (px - 5, py - 2 + GAME_Y, 4, 6))
                pygame.draw.rect(surf, BLUE, (px - 4, py - 1 + GAME_Y, 2, 4))
            else:  # right
                pygame.draw.rect(surf, DKBLUE, (px + 2, py - 2 + GAME_Y, 4, 6))
                pygame.draw.rect(surf, BLUE, (px + 3, py - 1 + GAME_Y, 2, 4))

        # Swimming water overlay — covers lower body, ripple effect
        if self.swimming:
            # Water overlay on bottom half (submerged look)
            wx = px - 10
            wy = py + GAME_Y + 2  # Cover lower body
            water_overlay = pygame.Surface((20, 12), pygame.SRCALPHA)
            wave_phase = self.swim_frame * 4 + pygame.time.get_ticks() // 80
            water_overlay.fill((40, 88, 192, 160))
            # Wavy top edge — clear pixels above the wave line
            for wpx in range(20):
                wave_y = int(math.sin((wpx + wave_phase) * 0.5) * 2)
                for py_clear in range(wave_y + 2):
                    if 0 <= py_clear < 12:
                        water_overlay.set_at((wpx, py_clear), (0, 0, 0, 0))
            surf.blit(water_overlay, (wx, wy))
            # Ripple ellipse around player
            ripple_r = 8 + self.swim_frame * 2
            pygame.draw.ellipse(surf, (100, 180, 255),
                (px - ripple_r, py + GAME_Y + 4, ripple_r * 2, 6), 1)

        # Spin attack charge sparkles (ALttP-style orbiting particles)
        if self.charge_time > 15 and self.weapon == "sword":
            charge_pct = min(1.0, self.charge_time / 45)
            ticks_now = pygame.time.get_ticks()
            num_sparkles = int(charge_pct * 6)
            for i in range(num_sparkles):
                angle = (ticks_now * 0.005 + i * (math.pi * 2 / max(1, num_sparkles)))
                radius = 12 + charge_pct * 4
                sx_sp = px + math.cos(angle) * radius
                sy_sp = py + GAME_Y + math.sin(angle) * radius
                size = 2 if charge_pct > 0.8 else 1
                color = (255, 255, 100) if charge_pct > 0.8 else (200, 200, 150)
                pygame.draw.rect(surf, color, (int(sx_sp), int(sy_sp), size, size))
            # Subtle glow underneath
            glow_r = int(6 + charge_pct * 8)
            glow_alpha = int(30 + charge_pct * 60)
            gs = pygame.Surface((glow_r * 2, glow_r * 2), pygame.SRCALPHA)
            glow_col = (255, 255, 100, glow_alpha) if charge_pct > 0.8 else (255, 255, 200, glow_alpha)
            pygame.draw.circle(gs, glow_col, (glow_r, glow_r), glow_r)
            surf.blit(gs, (px - glow_r, py + GAME_Y - glow_r))

        # Spin attack visual (circular sword sweep)
        if self.spin_attacking:
            sweep_angle = (self.spin_t / 12) * 360
            for a in range(0, int(sweep_angle), 30):
                rad = math.radians(a)
                sx_spin = px + math.cos(rad) * 16
                sy_spin = py + GAME_Y + math.sin(rad) * 16
                pygame.draw.circle(surf, (255, 255, 200), (int(sx_spin), int(sy_spin)), 2)

        # Pegasus Boots dash trail (speed lines behind player)
        if self.dashing and self.dash_dir:
            dir_offsets = {"right": (-1, 0), "left": (1, 0), "down": (0, -1), "up": (0, 1)}
            ox, oy = dir_offsets.get(self.dash_dir, (0, 0))
            for i in range(3):
                trail_x = px + ox * (i + 1) * 5
                trail_y = py + oy * (i + 1) * 5
                alpha = 150 - i * 50
                trail = pygame.Surface((4, 4), pygame.SRCALPHA)
                trail.fill((255, 255, 255, max(0, alpha)))
                surf.blit(trail, (int(trail_x) - 2, int(trail_y) + GAME_Y - 2))

        # ALttP-style item hold animation (Link holds item above head)
        if self.holding_timer > 0:
            item_y = py + GAME_Y - self.h - 8
            item_x = px - 4
            if "Sword" in (self.holding_item or ""):
                pygame.draw.rect(surf, (180, 180, 200), (item_x + 2, item_y, 3, 10))
                pygame.draw.rect(surf, (140, 100, 40), (item_x, item_y + 8, 7, 2))
            elif "Bow" in (self.holding_item or ""):
                pygame.draw.arc(surf, (140, 100, 40), (item_x, item_y, 8, 10), -1, 1, 2)
            elif "Bomb" in (self.holding_item or ""):
                pygame.draw.circle(surf, (60, 60, 60), (item_x + 4, item_y + 5), 4)
                pygame.draw.line(surf, (200, 160, 0), (item_x + 4, item_y + 1), (item_x + 6, item_y - 1))
            elif "Boomerang" in (self.holding_item or ""):
                pygame.draw.line(surf, (200, 168, 112), (item_x, item_y + 4), (item_x + 4, item_y), 2)
                pygame.draw.line(surf, (200, 168, 112), (item_x + 4, item_y), (item_x + 8, item_y + 4), 2)
            elif "Heart" in (self.holding_item or ""):
                pygame.draw.rect(surf, (255, 0, 0), (item_x + 1, item_y + 2, 6, 5))
                pygame.draw.rect(surf, (255, 0, 0), (item_x + 2, item_y + 1, 4, 1))
            elif "Boot" in (self.holding_item or ""):
                pygame.draw.rect(surf, (140, 100, 40), (item_x + 1, item_y + 2, 6, 6))
                pygame.draw.rect(surf, (180, 140, 60), (item_x + 1, item_y + 2, 6, 3))
            elif "Flipper" in (self.holding_item or ""):
                # Blue flipper icon
                pygame.draw.ellipse(surf, (40, 120, 220), (item_x, item_y + 1, 8, 6))
                pygame.draw.ellipse(surf, (80, 180, 255), (item_x + 1, item_y + 2, 6, 4))
            elif "Hookshot" in (self.holding_item or ""):
                pygame.draw.rect(surf, (140, 120, 80), (item_x + 1, item_y + 2, 6, 6))
                pygame.draw.rect(surf, (200, 180, 100), (item_x + 2, item_y, 4, 3))
            elif "Lantern" in (self.holding_item or ""):
                pygame.draw.rect(surf, (180, 140, 40), (item_x + 2, item_y + 2, 4, 6))
                pygame.draw.rect(surf, (255, 200, 50), (item_x + 2, item_y, 4, 3))
            elif "Magic" in (self.holding_item or ""):
                pygame.draw.rect(surf, (0, 160, 0), (item_x + 1, item_y + 1, 6, 6))
                pygame.draw.rect(surf, (0, 220, 0), (item_x + 2, item_y + 2, 4, 4))
            else:
                pygame.draw.rect(surf, (248, 216, 0), (item_x + 2, item_y + 2, 4, 4))
            # Sparkle particles around the item
            if self.holding_timer % 4 == 0:
                sparkle_x = item_x + 4 + random.randint(-8, 8)
                sparkle_y = item_y + 4 + random.randint(-6, 6)
                pygame.draw.rect(surf, (255, 255, 200), (sparkle_x, sparkle_y, 2, 2))

        # Hookshot chain drawing
        if self.hookshot_active:
            hx, hy = int(self.hookshot_x), int(self.hookshot_y) + GAME_Y
            ppx, ppy = int(self.x), int(self.y) + GAME_Y
            chain_color = (140, 120, 80)
            cdx = hx - ppx
            cdy = hy - ppy
            cdist = max(1, math.sqrt(cdx * cdx + cdy * cdy))
            for ci in range(0, int(cdist), 4):
                cx_c = ppx + int(cdx * ci / cdist)
                cy_c = ppy + int(cdy * ci / cdist)
                pygame.draw.rect(surf, chain_color, (cx_c, cy_c, 2, 2))
            # Hook tip
            pygame.draw.rect(surf, (200, 180, 100), (hx - 3, hy - 3, 6, 6))
            pygame.draw.rect(surf, (160, 140, 60), (hx - 3, hy - 3, 6, 6), 1)


# ══════════════════════════════════════════
#  ENEMY
# ══════════════════════════════════════════
class Enemy:
    def __init__(self, x, y, kind="slime"):
        self.x, self.y = float(x), float(y)
        self.kind = kind
        stats = {"slime": (6, 0.6, 2, 1), "bat": (5, 1.2, 1, 1), "skeleton": (7, 0.5, 3, 1),
                 "knight": (8, 0.4, 5, 2), "mage": (7, 0.3, 3, 1), "boss": (16, 0.6, 30, 2),
                 "miniboss": (10, 0.8, 8, 2), "octorok": (7, 0.5, 2, 1), "moblin": (8, 0.6, 4, 2)}
        self.sz, self.speed, self.hp, self.dmg = stats.get(kind, stats["slime"])
        self.max_hp = self.hp
        self.move_t, self.move_dir = 0, [0, 0]
        self.flash, self.anim, self.anim_t = 0, 0, 0
        self.shoot_cd, self.phase = 0, 1
        self.phase_timer, self.attack_pattern = 0, 0
        self.kb_vx, self.kb_vy, self.kb_t = 0.0, 0.0, 0  # Knockback
        self.stun = 0  # Hit stun frames
        # Octorok-specific
        if kind == "octorok":
            self.shoot_timer = 0
            self.shoot_interval = 90
            self.dir = "down"
        # Moblin-specific
        if kind == "moblin":
            self.charging = False
            self.charge_timer = 0
        # Shadow Lord boss state
        if kind == "boss":
            self.boss_state = "idle"  # idle, teleporting, dashing, jumping, charging
            self.state_timer = 0
            self.teleport_cooldown = 0
            self.attack_cooldown = 0
            self.clones = []  # Shadow clone positions [(x, y), ...]
            self.fire_trail = []  # [(x, y, timer), ...]
            self.visible = True
            self.slam_target = None
            self.slam_landed = False
            self.dash_dir = None
            self.dash_bounces = 0
            self.base_speed = 0.6

    @property
    def rect(self):
        return pygame.Rect(self.x - self.sz//2, self.y - self.sz//2, self.sz, self.sz)

    def update(self, player, cmap, projectiles):
        self.anim_t += 1
        if self.anim_t >= 14:
            self.anim = (self.anim + 1) % 2; self.anim_t = 0
        if self.flash > 0:
            self.flash -= 1
        if self.shoot_cd > 0:
            self.shoot_cd -= 1
        if self.stun > 0:
            self.stun -= 1

        # Apply knockback (ALttP-style with friction)
        if self.kb_t > 0:
            self.kb_t -= 1
            friction = 0.8
            self.kb_vx *= friction
            self.kb_vy *= friction
            nx = self.x + self.kb_vx
            ny = self.y + self.kb_vy
            c_nx, r_ny = int(nx) // TILE, int(ny) // TILE
            if 0 <= r_ny < MAP_ROWS and 0 <= c_nx < MAP_COLS and cmap[r_ny][c_nx] not in (W, Q, T, L, K):
                self.x, self.y = nx, ny
            else:
                self.kb_vx, self.kb_vy = 0, 0
            return  # Skip AI while in knockback

        # Skip AI while stunned
        if self.stun > 0:
            return

        dx = player.x - self.x
        dy = player.y - self.y
        dist = math.sqrt(dx * dx + dy * dy) or 1

        if self.kind == "boss":
            self.phase_timer += 1
            hp_pct = self.hp / max(1, self.max_hp)

            # Phase transitions
            if hp_pct <= 0.6 and self.phase == 1:
                self.phase = 2
                self.flash = 30
                self.boss_state = "idle"
                self.attack_cooldown = 60
                SFX["phase"].play()
                # Spawn 2 shadow clones
                self.clones = [(self.x + 30, self.y), (self.x - 30, self.y)]
            elif hp_pct <= 0.25 and self.phase == 2:
                self.phase = 3
                self.flash = 30
                self.speed = 1.2
                self.boss_state = "idle"
                self.attack_cooldown = 60
                self.visible = True
                SFX["phase"].play()
                self.clones.clear()

            # Phase-specific AI
            if self.phase == 1:
                self._boss_phase1(player, projectiles)
            elif self.phase == 2:
                self._boss_phase2(player, projectiles)
            elif self.phase == 3:
                self._boss_phase3(player, projectiles)

            # Update fire trail
            self.fire_trail = [(fx, fy, ft - 1) for fx, fy, ft in self.fire_trail if ft > 1]

            # Update shadow clones (mirror boss movement)
            if self.clones and self.phase == 2:
                new_clones = []
                for i, (cx, cy) in enumerate(self.clones):
                    # Clones mirror boss offset, moving in loose formation
                    off_angle = (i + 1) * math.pi * 2 / 3
                    target_cx = self.x + math.cos(off_angle + self.phase_timer * 0.02) * 40
                    target_cy = self.y + math.sin(off_angle + self.phase_timer * 0.02) * 40
                    ncx = cx + (target_cx - cx) * 0.05
                    ncy = cy + (target_cy - cy) * 0.05
                    ncx = max(2 * TILE, min(13 * TILE, ncx))
                    ncy = max(2 * TILE, min(9 * TILE, ncy))
                    new_clones.append((ncx, ncy))
                self.clones = new_clones

            return  # Skip normal enemy movement

        elif self.kind == "bat":
            a = math.atan2(dy, dx) + math.sin(self.anim_t * 0.18) * 1.5
            self.x += math.cos(a) * self.speed
            self.y += math.sin(a) * self.speed

        elif self.kind == "mage":
            if dist < 40:
                # Run away from player when too close
                self.x -= (dx / dist) * self.speed
                self.y -= (dy / dist) * self.speed
            elif dist < 60:
                self.x -= (dx / dist) * self.speed * 0.5
                self.y -= (dy / dist) * self.speed * 0.5
            elif dist > 100:
                self.x += (dx / dist) * self.speed * 0.5
                self.y += (dy / dist) * self.speed * 0.5
            if self.shoot_cd <= 0 and dist < 120:
                self.shoot_cd = 90
                pdx = player.x - self.x
                pdy = player.y - self.y
                d = max(1, math.sqrt(pdx*pdx + pdy*pdy))
                projectiles.append(Projectile(self.x, self.y, pdx/d*2, pdy/d*2, "magic", "enemy"))

        elif self.kind == "knight":
            # Knights are smarter: they try to flank the player
            self.move_t += 1
            if self.move_t > 30:
                self.move_t = 0
                if dist < 80:
                    # Approach at an angle to flank
                    base_dir = [dx / dist, dy / dist]
                    if random.random() < 0.3:
                        # Move perpendicular sometimes
                        perp = random.choice([-1, 1])
                        base_dir[0] += -base_dir[1] * perp * 0.5
                        base_dir[1] += base_dir[0] * perp * 0.5
                    self.move_dir = base_dir
                else:
                    self.move_dir = [dx / dist, dy / dist]
            nx = self.x + self.move_dir[0] * self.speed
            ny = self.y + self.move_dir[1] * self.speed
            # Knights occasionally strafe
            if abs(dx) > abs(dy) and random.random() < 0.3:
                ny += random.choice([-1, 1]) * self.speed
            c, r = int(nx) // TILE, int(ny) // TILE
            if 0 <= r < MAP_ROWS and 0 <= c < MAP_COLS and cmap[r][c] not in (W, Q, T, L, K):
                self.x, self.y = nx, ny
            else:
                self.move_dir = [-self.move_dir[0], -self.move_dir[1]]

        elif self.kind == "miniboss":
            # Charge at player periodically
            self.phase_timer += 1
            if self.phase_timer % 120 < 30:
                # Charge! Move faster toward player
                ddx = 1 if player.x > self.x else -1
                ddy = 1 if player.y > self.y else -1
                nx = self.x + ddx * 2.0
                ny = self.y + ddy * 2.0
            else:
                self.move_t += 1
                if self.move_t > 30:
                    self.move_t = 0
                    self.move_dir = [dx / dist, dy / dist]
                nx = self.x + self.move_dir[0] * self.speed
                ny = self.y + self.move_dir[1] * self.speed
            c, r = int(nx) // TILE, int(ny) // TILE
            if 0 <= r < MAP_ROWS and 0 <= c < MAP_COLS and cmap[r][c] not in (W, Q, T, L, K):
                self.x, self.y = nx, ny
            else:
                self.move_dir = [-self.move_dir[0], -self.move_dir[1]]

        elif self.kind == "octorok":
            self.shoot_timer += 1
            # Wander randomly
            if random.random() < 0.02:
                self.dir = random.choice(["up", "down", "left", "right"])
            ddx, ddy = {"up": (0, -1), "down": (0, 1), "left": (-1, 0), "right": (1, 0)}[self.dir]
            nx = self.x + ddx * self.speed
            ny = self.y + ddy * self.speed
            c, r = int(nx) // TILE, int(ny) // TILE
            if 0 <= r < MAP_ROWS and 0 <= c < MAP_COLS and cmap[r][c] not in (W, Q, T, L, K):
                self.x, self.y = nx, ny
            else:
                self.dir = random.choice(["up", "down", "left", "right"])
            # Shoot rock at player
            if self.shoot_timer >= self.shoot_interval:
                self.shoot_timer = 0
                pdx = player.x - self.x
                pdy = player.y - self.y
                pdist = max(1, math.sqrt(pdx * pdx + pdy * pdy))
                if pdist < 80:
                    proj = Projectile(self.x, self.y, pdx / pdist * 2, pdy / pdist * 2, "rock", "enemy")
                    projectiles.append(proj)

        elif self.kind == "moblin":
            self.charge_timer += 1
            if self.charge_timer % 150 < 40:
                # Charge! Rush straight at player
                self.charging = True
                nx = self.x + (dx / dist) * 2.0
                ny = self.y + (dy / dist) * 2.0
            else:
                self.charging = False
                self.move_t += 1
                if self.move_t > 40:
                    self.move_t = 0
                    if dist < 100:
                        self.move_dir = [dx / dist, dy / dist]
                    else:
                        a = random.uniform(0, math.pi * 2)
                        self.move_dir = [math.cos(a), math.sin(a)]
                nx = self.x + self.move_dir[0] * self.speed
                ny = self.y + self.move_dir[1] * self.speed
            c, r = int(nx) // TILE, int(ny) // TILE
            if 0 <= r < MAP_ROWS and 0 <= c < MAP_COLS and cmap[r][c] not in (W, Q, T, L, K):
                self.x, self.y = nx, ny
            else:
                self.move_dir = [-self.move_dir[0], -self.move_dir[1]]
                self.charging = False

        else:
            self.move_t += 1
            if self.move_t > 45:
                self.move_t = 0
                if dist < 80 or random.random() < 0.5:
                    self.move_dir = [dx / dist, dy / dist]
                else:
                    a = random.uniform(0, math.pi * 2)
                    self.move_dir = [math.cos(a), math.sin(a)]
            nx = self.x + self.move_dir[0] * self.speed
            ny = self.y + self.move_dir[1] * self.speed
            c, r = int(nx) // TILE, int(ny) // TILE
            if 0 <= r < MAP_ROWS and 0 <= c < MAP_COLS and cmap[r][c] not in (W, Q, T, L, K):
                self.x, self.y = nx, ny
            else:
                self.move_dir = [-self.move_dir[0], -self.move_dir[1]]

    # ── Shadow Lord Boss Phase AI ──

    def _boss_phase1(self, player, projectiles):
        """Phase 1: Teleport + dark orb barrage. Slow menacing movement."""
        self.teleport_cooldown = max(0, self.teleport_cooldown - 1)
        self.attack_cooldown = max(0, self.attack_cooldown - 1)

        dx = player.x - self.x
        dy = player.y - self.y
        dist = max(1, math.sqrt(dx * dx + dy * dy))

        # Slow menacing movement toward player
        self.x += (dx / dist) * self.speed * 0.5
        self.y += (dy / dist) * self.speed * 0.5
        self.x = max(2 * TILE, min(13 * TILE, self.x))
        self.y = max(2 * TILE, min(9 * TILE, self.y))

        # Teleport every ~180 frames (3 sec)
        if self.teleport_cooldown <= 0 and self.phase_timer % 180 < 3:
            self.x = random.randint(3 * TILE, 12 * TILE)
            self.y = random.randint(3 * TILE, 9 * TILE)
            self.teleport_cooldown = 90
            self.flash = 5
            SFX["door"].play()

        # Dark orb spread every ~240 frames (4 sec)
        if self.attack_cooldown <= 0 and self.phase_timer % 240 < 3:
            dx = player.x - self.x
            dy = player.y - self.y
            dist = max(1, math.sqrt(dx * dx + dy * dy))
            base_a = math.atan2(dy, dx)
            for spread in [-0.3, 0, 0.3]:
                a = base_a + spread
                projectiles.append(Projectile(self.x, self.y,
                    math.cos(a) * 2.5, math.sin(a) * 2.5, "magic", "enemy"))
            self.attack_cooldown = 60
            SFX["arrow"].play()

    def _boss_phase2(self, player, projectiles):
        """Phase 2: Darkness + spin dash + ground slam + shadow clones."""
        self.attack_cooldown = max(0, self.attack_cooldown - 1)
        self.state_timer = max(0, self.state_timer - 1)

        if self.boss_state == "idle":
            # Move toward player
            dx = player.x - self.x
            dy = player.y - self.y
            dist = max(1, math.sqrt(dx * dx + dy * dy))
            self.x += (dx / dist) * self.speed * 0.8
            self.y += (dy / dist) * self.speed * 0.8
            self.x = max(2 * TILE, min(13 * TILE, self.x))
            self.y = max(2 * TILE, min(9 * TILE, self.y))

            # Choose attack when cooldown ready
            if self.attack_cooldown <= 0:
                attack = random.choice(["dash", "slam", "orbs"])
                if attack == "dash":
                    self.boss_state = "dashing"
                    self.state_timer = 45
                    dx = player.x - self.x
                    dy = player.y - self.y
                    dist = max(1, math.sqrt(dx * dx + dy * dy))
                    self.dash_dir = (dx / dist * 3.5, dy / dist * 3.5)
                    self.dash_bounces = 2
                    SFX["arrow"].play()
                elif attack == "slam":
                    self.boss_state = "jumping"
                    self.state_timer = 35
                    self.slam_target = (player.x, player.y)
                    self.slam_landed = False
                    self.visible = False
                    SFX["door"].play()
                else:
                    # Shoot orbs in 6 directions
                    for i in range(6):
                        angle = i * math.pi / 3
                        projectiles.append(Projectile(self.x, self.y,
                            math.cos(angle) * 2, math.sin(angle) * 2, "magic", "enemy"))
                    SFX["arrow"].play()
                self.attack_cooldown = 120

        elif self.boss_state == "dashing":
            self.x += self.dash_dir[0]
            self.y += self.dash_dir[1]
            # Bounce off walls
            if self.x < 2 * TILE or self.x > 13 * TILE:
                self.dash_dir = (-self.dash_dir[0], self.dash_dir[1])
                self.dash_bounces -= 1
                SFX["block"].play()
            if self.y < 2 * TILE or self.y > 9 * TILE:
                self.dash_dir = (self.dash_dir[0], -self.dash_dir[1])
                self.dash_bounces -= 1
                SFX["block"].play()
            self.x = max(2 * TILE, min(13 * TILE, self.x))
            self.y = max(2 * TILE, min(9 * TILE, self.y))
            if self.state_timer <= 0 or self.dash_bounces < 0:
                self.boss_state = "idle"

        elif self.boss_state == "jumping":
            if self.state_timer <= 0 and not self.slam_landed:
                # SLAM down at target
                self.visible = True
                self.x = self.slam_target[0]
                self.y = self.slam_target[1]
                self.x = max(2 * TILE, min(13 * TILE, self.x))
                self.y = max(2 * TILE, min(9 * TILE, self.y))
                self.slam_landed = True
                # Damage check + screen shake handled in game loop
                SFX["boss_hit"].play()
                self.boss_state = "idle"

    def _boss_phase3(self, player, projectiles):
        """Phase 3: Desperate — fire trail + trident throw + burst."""
        self.attack_cooldown = max(0, self.attack_cooldown - 1)

        # Aggressive chase
        dx = player.x - self.x
        dy = player.y - self.y
        dist = max(1, math.sqrt(dx * dx + dy * dy))
        self.x += (dx / dist) * self.speed
        self.y += (dy / dist) * self.speed
        self.x = max(2 * TILE, min(13 * TILE, self.x))
        self.y = max(2 * TILE, min(9 * TILE, self.y))

        # Fire trail — drop fire every 5 frames
        if self.phase_timer % 5 == 0:
            self.fire_trail.append((self.x, self.y, 180))  # 3 seconds at 60fps

        # Attacks
        if self.attack_cooldown <= 0:
            if self.hp <= self.max_hp * 0.1:
                # Desperation burst — 8 directions
                for i in range(8):
                    angle = i * math.pi / 4
                    projectiles.append(Projectile(self.x, self.y,
                        math.cos(angle) * 3, math.sin(angle) * 3, "magic", "enemy"))
                SFX["boss_hit"].play()
                self.attack_cooldown = 90
            else:
                # Alternate between trident throw and orb burst
                if random.random() < 0.5:
                    # Trident throw (boomerang-like)
                    dx = player.x - self.x
                    dy = player.y - self.y
                    dist = max(1, math.sqrt(dx * dx + dy * dy))
                    proj = Projectile(self.x, self.y,
                        dx / dist * 3, dy / dist * 3, "trident", "enemy")
                    proj.returning = False
                    proj.lifetime = 0
                    projectiles.append(proj)
                    SFX["arrow"].play()
                else:
                    # Orb spread toward player
                    base_a = math.atan2(dy, dx)
                    for spread in [-0.4, -0.2, 0, 0.2, 0.4]:
                        a = base_a + spread
                        projectiles.append(Projectile(self.x, self.y,
                            math.cos(a) * 2.5, math.sin(a) * 2.5, "magic", "enemy"))
                    SFX["arrow"].play()
                self.attack_cooldown = 100

    def take_damage(self, amt=1, from_x=None, from_y=None):
        if self.flash > 0:
            return
        self.hp -= amt; self.flash = 15; self.stun = 6; SFX["hit"].play()
        # Boss teleports away when hit (punish reckless attacking)
        if self.kind == "boss" and self.phase == 1 and self.hp > 0:
            self.x = random.randint(3 * TILE, 12 * TILE)
            self.y = random.randint(3 * TILE, 9 * TILE)
            self.teleport_cooldown = 60
        # Knockback away from damage source (ALttP-style)
        if from_x is not None and from_y is not None:
            dx = self.x - from_x
            dy = self.y - from_y
            dist = max(1, math.sqrt(dx * dx + dy * dy))
            # Heavy enemies resist knockback
            kb_force = 4.0
            if self.kind in ("knight", "miniboss", "boss"):
                kb_force = 2.0
            self.kb_vx = (dx / dist) * kb_force
            self.kb_vy = (dy / dist) * kb_force
            self.kb_t = 10

    def _draw_boss(self, surf):
        """Draw the Shadow Lord boss with phase-dependent visuals."""
        # Draw shadow clones first (phase 2)
        if self.phase == 2 and self.clones:
            for cx, cy in self.clones:
                csx, csy = int(cx), int(cy) + GAME_Y
                # Semi-transparent clone
                clone_s = pygame.Surface((32, 32), pygame.SRCALPHA)
                # Dark ghostly body
                pygame.draw.ellipse(clone_s, (40, 20, 60, 80), (4, 8, 24, 20))
                pygame.draw.polygon(clone_s, (30, 15, 45, 80), [(8, 10), (5, 1), (11, 8)])
                pygame.draw.polygon(clone_s, (30, 15, 45, 80), [(24, 10), (27, 1), (21, 8)])
                pygame.draw.rect(clone_s, (200, 0, 0, 80), (10, 14, 3, 2))
                pygame.draw.rect(clone_s, (200, 0, 0, 80), (19, 14, 3, 2))
                surf.blit(clone_s, (csx - 16, csy - 16))

        if not self.visible:
            # Draw growing shadow on ground during jump
            if self.slam_target:
                stx, sty = int(self.slam_target[0]), int(self.slam_target[1]) + GAME_Y
                size = max(4, (35 - self.state_timer) * 2)
                shadow_s = pygame.Surface((size * 2, size), pygame.SRCALPHA)
                pygame.draw.ellipse(shadow_s, (0, 0, 0, 120), (0, 0, size * 2, size))
                surf.blit(shadow_s, (stx - size, sty - size // 2))
                # Warning indicator
                if self.state_timer < 15:
                    pygame.draw.circle(surf, (255, 50, 50, 150), (stx, sty), size // 2, 1)
            return

        sx = int(self.x); sy = int(self.y) + GAME_Y
        bx = sx - 14
        by = sy - 16

        # Dark aura (phase-dependent, pulsing)
        aura_size = 22 + int(math.sin(self.phase_timer * 0.05) * 4)
        aura = pygame.Surface((aura_size * 2, aura_size * 2), pygame.SRCALPHA)
        if self.phase == 1:
            aura_color = (80, 0, 120, 30)
        elif self.phase == 2:
            aura_color = (40, 0, 80, 50)
        else:
            aura_color = (160, 0, 0, 40)
        pygame.draw.circle(aura, aura_color, (aura_size, aura_size), aura_size)
        surf.blit(aura, (sx - aura_size, sy - aura_size))

        # Flash override
        if self.flash > 0:
            flash_col = (255, 255, 255) if self.flash % 3 == 0 else (255, 80, 80)
            pygame.draw.rect(surf, flash_col, (bx + 4, by + 2, 20, 26))
            # Still draw HP bar during flash
            bar_w = 28
            bar_x = sx - bar_w // 2
            bar_y = by - 6
            hp_pct = self.hp / max(1, self.max_hp)
            pygame.draw.rect(surf, (40, 0, 0), (bar_x, bar_y, bar_w, 3))
            bar_color = (0, 200, 0) if hp_pct > 0.6 else ((200, 200, 0) if hp_pct > 0.25 else (200, 0, 0))
            pygame.draw.rect(surf, bar_color, (bar_x, bar_y, int(bar_w * hp_pct), 3))
            pygame.draw.rect(surf, (200, 200, 200), (bar_x, bar_y, bar_w, 3), 1)
            return

        # Phase 2: flicker between visible and semi-transparent
        if self.phase == 2 and self.phase_timer % 8 < 2:
            return  # Brief flicker

        # Body: dark robe
        pygame.draw.rect(surf, (40, 20, 60), (bx + 4, by + 10, 20, 18))
        pygame.draw.rect(surf, (60, 30, 80), (bx + 6, by + 12, 16, 14))
        # Shoulders
        pygame.draw.rect(surf, (50, 25, 70), (bx + 2, by + 10, 6, 8))
        pygame.draw.rect(surf, (50, 25, 70), (bx + 20, by + 10, 6, 8))
        # Head/helmet
        pygame.draw.rect(surf, (30, 15, 45), (bx + 6, by + 2, 16, 12))
        pygame.draw.rect(surf, (40, 20, 55), (bx + 8, by + 4, 12, 8))
        # Crown/horns
        pygame.draw.rect(surf, (200, 160, 0), (bx + 6, by, 4, 4))
        pygame.draw.rect(surf, (200, 160, 0), (bx + 18, by, 4, 4))
        pygame.draw.rect(surf, (200, 160, 0), (bx + 10, by - 2, 8, 3))
        # Glowing eyes
        eye_glow = int(abs(math.sin(self.phase_timer * 0.1)) * 55) + 200
        if self.phase < 3:
            eye_col = (eye_glow, 0, 0)
        else:
            eye_col = (eye_glow, max(0, eye_glow - 55), 0)
        pygame.draw.rect(surf, eye_col, (bx + 9, by + 6, 3, 2))
        pygame.draw.rect(surf, eye_col, (bx + 16, by + 6, 3, 2))
        # Trident in hand
        pygame.draw.rect(surf, (160, 140, 40), (bx + 26, by + 2, 2, 24))
        pygame.draw.rect(surf, (200, 180, 60), (bx + 24, by, 6, 4))
        pygame.draw.rect(surf, (200, 180, 60), (bx + 24, by - 2, 2, 3))
        pygame.draw.rect(surf, (200, 180, 60), (bx + 28, by - 2, 2, 3))

        # Phase 3: red glow overlay
        if self.phase == 3:
            glow = pygame.Surface((32, 32), pygame.SRCALPHA)
            a = int(30 + 20 * math.sin(self.phase_timer * 0.08))
            glow.fill((255, 0, 0, a))
            surf.blit(glow, (bx + 2, by))

        # Dashing spin effect
        if self.boss_state == "dashing":
            spin_s = pygame.Surface((28, 28), pygame.SRCALPHA)
            spin_a = (self.phase_timer * 20) % 360
            for i in range(4):
                angle = math.radians(spin_a + i * 90)
                ex = 14 + int(math.cos(angle) * 10)
                ey = 14 + int(math.sin(angle) * 10)
                pygame.draw.line(spin_s, (160, 80, 200, 150), (14, 14), (ex, ey), 2)
            surf.blit(spin_s, (sx - 14, sy - 14))

        # HP bar (large, prominent)
        bar_w = 28
        bar_x = sx - bar_w // 2
        bar_y = by - 6
        hp_pct = self.hp / max(1, self.max_hp)
        pygame.draw.rect(surf, (40, 0, 0), (bar_x, bar_y, bar_w, 3))
        bar_color = (0, 200, 0) if hp_pct > 0.6 else ((200, 200, 0) if hp_pct > 0.25 else (200, 0, 0))
        pygame.draw.rect(surf, bar_color, (bar_x, bar_y, int(bar_w * hp_pct), 3))
        pygame.draw.rect(surf, (200, 200, 200), (bar_x, bar_y, bar_w, 3), 1)

        # Phase indicator dots
        for i in range(3):
            dot_col = (200, 200, 0) if i < self.phase else (60, 60, 60)
            pygame.draw.rect(surf, dot_col, (bar_x + i * 4, bar_y - 3, 3, 2))

    def draw(self, surf):
        # Shadow Lord boss has its own full draw method
        if self.kind == "boss":
            # Draw fire trail first (under everything)
            if hasattr(self, 'fire_trail'):
                for fx, fy, ft in self.fire_trail:
                    fsx, fsy = int(fx), int(fy) + GAME_Y
                    alpha = min(180, ft)
                    fire_s = pygame.Surface((8, 8), pygame.SRCALPHA)
                    # Animated fire colors
                    fc = random.choice([(200, 60, 0, alpha), (220, 100, 0, alpha), (180, 40, 0, alpha)])
                    fire_s.fill(fc)
                    surf.blit(fire_s, (fsx - 4, fsy - 4))
            self._draw_boss(surf)
            return

        sx = int(self.x); sy = int(self.y) + GAME_Y
        # Shadow
        shw = 10 if self.kind != "boss" else 20
        shh = shw // 2
        shadow = pygame.Surface((shw, shh), pygame.SRCALPHA)
        pygame.draw.ellipse(shadow, (0, 0, 0, 40), (0, 0, shw, shh))
        surf.blit(shadow, (sx - shw // 2, sy + (self.sz // 2) - 1))

        key = self.kind

        if self.kind == "miniboss":
            dx = int(self.x) - 10
            dy = int(self.y) - 12 + GAME_Y
            if self.flash > 0:
                flash_col = (255, 255, 255) if self.flash % 3 == 0 else (255, 80, 80)
                pygame.draw.rect(surf, flash_col, (dx+2, dy+6, 16, 14))
            else:
                # Large armored body
                pygame.draw.rect(surf, (80, 40, 40), (dx+2, dy+6, 16, 14))  # Dark red armor
                pygame.draw.rect(surf, (120, 60, 60), (dx+4, dy+8, 12, 10))  # Armor highlight
            # Helmet
            pygame.draw.rect(surf, (60, 60, 70), (dx+4, dy+2, 12, 8))
            pygame.draw.rect(surf, (80, 80, 90), (dx+6, dy+4, 8, 4))
            # Red eyes
            pygame.draw.rect(surf, (255, 40, 40), (dx+6, dy+5, 2, 2))
            pygame.draw.rect(surf, (255, 40, 40), (dx+12, dy+5, 2, 2))
            # Shield
            pygame.draw.rect(surf, (100, 100, 120), (dx, dy+8, 4, 10))
            pygame.draw.rect(surf, (140, 140, 160), (dx+1, dy+9, 2, 8))
            # Sword
            pygame.draw.rect(surf, (180, 180, 200), (dx+16, dy+6, 3, 12))
            pygame.draw.rect(surf, (220, 220, 240), (dx+17, dy+7, 1, 10))
            # HP bar above
            bar_w = 20
            bar_x = dx + 10 - bar_w // 2
            bar_y = dy - 4
            hp_pct = self.hp / max(1, self.max_hp)
            pygame.draw.rect(surf, (60, 0, 0), (bar_x, bar_y, bar_w, 3))
            pygame.draw.rect(surf, (220, 40, 40), (bar_x, bar_y, int(bar_w * hp_pct), 3))
            return

        if self.kind == "octorok":
            dx = int(self.x) - 7
            dy = int(self.y) - 7 + GAME_Y
            if self.flash > 0:
                flash_col = (255, 255, 255) if self.flash % 3 == 0 else (255, 80, 80)
                pygame.draw.ellipse(surf, flash_col, (dx, dy + 2, 14, 10))
            else:
                # Red octopus-like body
                pygame.draw.ellipse(surf, (200, 60, 60), (dx, dy + 2, 14, 10))
                pygame.draw.ellipse(surf, (160, 40, 40), (dx, dy + 2, 14, 10), 1)
            # Eyes
            pygame.draw.circle(surf, WHITE, (dx + 4, dy + 5), 2)
            pygame.draw.circle(surf, WHITE, (dx + 10, dy + 5), 2)
            pygame.draw.circle(surf, BLACK, (dx + 4, dy + 5), 1)
            pygame.draw.circle(surf, BLACK, (dx + 10, dy + 5), 1)
            # Mouth/tube
            pygame.draw.rect(surf, (180, 50, 50), (dx + 5, dy + 8, 4, 3))
            return

        if self.kind == "moblin":
            dx = int(self.x) - 8
            dy = int(self.y) - 10 + GAME_Y
            if self.flash > 0:
                flash_col = (255, 255, 255) if self.flash % 3 == 0 else (255, 80, 80)
                pygame.draw.rect(surf, flash_col, (dx + 2, dy + 4, 12, 14))
            else:
                # Large brown/green pig-like body
                pygame.draw.rect(surf, (120, 100, 60), (dx + 2, dy + 4, 12, 14))
                pygame.draw.rect(surf, (100, 80, 40), (dx + 2, dy + 4, 12, 14), 1)
            # Head
            pygame.draw.rect(surf, (140, 120, 70), (dx + 3, dy, 10, 8))
            # Snout
            pygame.draw.rect(surf, (160, 130, 80), (dx + 5, dy + 4, 6, 4))
            pygame.draw.rect(surf, (80, 60, 30), (dx + 6, dy + 5, 1, 1))
            pygame.draw.rect(surf, (80, 60, 30), (dx + 9, dy + 5, 1, 1))
            # Eyes
            pygame.draw.rect(surf, RED, (dx + 5, dy + 2, 2, 2))
            pygame.draw.rect(surf, RED, (dx + 9, dy + 2, 2, 2))
            # Spear
            pygame.draw.rect(surf, (140, 100, 40), (dx + 14, dy + 2, 2, 16))
            pygame.draw.rect(surf, METAL, (dx + 13, dy, 4, 3))
            return

        if key in ENEMY_SPRITES:
            sp = ENEMY_SPRITES[key][self.anim]
            if self.flash > 0:
                flash_sp = sp.copy()
                # Alternate white/red flash for juicy hit feedback
                if self.flash % 3 == 0:
                    flash_sp.fill((255, 255, 255), special_flags=pygame.BLEND_ADD)
                else:
                    flash_sp.fill(RED, special_flags=pygame.BLEND_MULT)
                sp = flash_sp
            w, h = sp.get_size()
            # Squish effect during knockback
            if self.kb_t > 0:
                squish = 1 + self.kb_t * 0.03
                sw = int(w * (2 - squish))
                sh = int(h * squish)
                sp = pygame.transform.scale(sp, (max(1, sw), max(1, sh)))
                w, h = sp.get_size()
            surf.blit(sp, (sx - w // 2, sy - h // 2))

            # Boss HP bar
            if "boss" in self.kind:
                bw = 28
                hr = self.hp / max(1, self.max_hp)
                by = sy - h // 2 - 5
                pygame.draw.rect(surf, DKGRAY, (sx - bw//2, by, bw, 3))
                bc = GREEN if hr > 0.5 else (YELLOW if hr > 0.2 else RED)
                pygame.draw.rect(surf, bc, (sx - bw//2, by, int(bw * hr), 3))
                pygame.draw.rect(surf, WHITE, (sx - bw//2, by, bw, 3), 1)


# ══════════════════════════════════════════
#  NPC / CHEST / PICKUP
# ══════════════════════════════════════════
class NPC:
    def __init__(self, x, y, name, lines, color=BLUE):
        self.x, self.y, self.name, self.lines, self.color = x, y, name, lines, color
        self.talked = False

    @property
    def rect(self):
        return pygame.Rect(self.x - 6, self.y - 6, 12, 12)

    def draw(self, surf):
        sx, sy = int(self.x), int(self.y) + GAME_Y
        pygame.draw.rect(surf, self.color, (sx - 5, sy - 2, 10, 10))
        pygame.draw.rect(surf, SKIN, (sx - 4, sy - 8, 8, 7))
        pygame.draw.rect(surf, BROWN, (sx - 4, sy - 10, 8, 4))
        pygame.draw.rect(surf, BLACK, (sx - 2, sy - 5, 1, 2))
        pygame.draw.rect(surf, BLACK, (sx + 2, sy - 5, 1, 2))
        if not self.talked:
            pygame.draw.rect(surf, YELLOW, (sx - 1, sy - 16, 2, 4))
            pygame.draw.rect(surf, YELLOW, (sx - 1, sy - 11, 2, 2))


class Chest:
    def __init__(self, x, y, item, item_name):
        self.x, self.y, self.item, self.item_name = x, y, item, item_name
        self.opened = False

    @property
    def rect(self):
        return pygame.Rect(self.x - 7, self.y - 5, 14, 10)

    def draw(self, surf):
        sx, sy = int(self.x), int(self.y) + GAME_Y
        if not self.opened:
            pygame.draw.rect(surf, BROWN, (sx - 7, sy - 5, 14, 10))
            pygame.draw.rect(surf, DKBROWN, (sx - 7, sy - 5, 14, 10), 1)
            pygame.draw.rect(surf, YELLOW, (sx - 1, sy - 1, 3, 3))
            pygame.draw.rect(surf, BROWN, (sx - 7, sy - 8, 14, 4))
            pygame.draw.rect(surf, DKBROWN, (sx - 7, sy - 8, 14, 4), 1)
            t = pygame.time.get_ticks()
            if (t // 400) % 2 == 0:
                pygame.draw.rect(surf, YELLOW, (sx + 4, sy - 10, 2, 2))
        else:
            pygame.draw.rect(surf, BROWN, (sx - 7, sy - 2, 14, 7))
            pygame.draw.rect(surf, DKBROWN, (sx - 7, sy - 2, 14, 7), 1)
            pygame.draw.rect(surf, (20, 15, 10), (sx - 5, sy, 10, 3))


class Pickup:
    def __init__(self, x, y, kind="rupee"):
        self.x, self.y, self.kind = x, y, kind
        self.collected = False
        self.bob_t = random.randint(0, 100)

    @property
    def rect(self):
        return pygame.Rect(self.x - 4, self.y - 4, 8, 8)

    def draw(self, surf):
        if self.collected:
            return
        self.bob_t += 1
        sx, sy = int(self.x), int(self.y) + GAME_Y
        b = int(math.sin(self.bob_t * 0.1) * 1.5)
        if self.kind == "rupee":
            pts = [(sx, sy - 4 + b), (sx + 3, sy + b), (sx, sy + 4 + b), (sx - 3, sy + b)]
            pygame.draw.polygon(surf, YELLOW, pts)
            pygame.draw.polygon(surf, (180, 160, 0), pts, 1)
        elif self.kind == "heart":
            pygame.draw.circle(surf, RED, (sx - 2, sy - 1 + b), 3)
            pygame.draw.circle(surf, RED, (sx + 2, sy - 1 + b), 3)
            pygame.draw.polygon(surf, RED, [(sx - 4, sy + b), (sx + 4, sy + b), (sx, sy + 4 + b)])
        elif self.kind == "arrows":
            pygame.draw.line(surf, BROWN, (sx, sy - 4 + b), (sx, sy + 3 + b), 1)
            pygame.draw.polygon(surf, METAL, [(sx, sy - 5 + b), (sx - 2, sy - 2 + b), (sx + 2, sy - 2 + b)])
        elif self.kind == "bombs":
            pygame.draw.circle(surf, DKGRAY, (sx, sy + b), 3)
            pygame.draw.rect(surf, ORANGE, (sx, sy - 4 + b, 1, 2))
        elif self.kind == "key":
            # Key shape
            pygame.draw.circle(surf, YELLOW, (sx, sy - 2 + b), 3)
            pygame.draw.circle(surf, DKBROWN, (sx, sy - 2 + b), 1)
            pygame.draw.rect(surf, YELLOW, (sx - 1, sy + 1 + b, 2, 5))
            pygame.draw.rect(surf, YELLOW, (sx, sy + 4 + b, 2, 1))
            pygame.draw.rect(surf, YELLOW, (sx, sy + 2 + b, 2, 1))
        elif self.kind == "heart_piece":
            # Draw a glowing heart piece (quarter heart)
            pygame.draw.rect(surf, (255, 80, 80), (sx - 3, sy - 3 + b, 6, 6))
            pygame.draw.rect(surf, (255, 160, 160), (sx - 2, sy - 2 + b, 4, 4))


# ══════════════════════════════════════════
#  HUD
# ══════════════════════════════════════════
def draw_hud(surf, player, lvl, enemies):
    pygame.draw.rect(surf, DKBLUE, (0, 0, NATIVE_W, HUD_H))
    pygame.draw.line(surf, (40, 40, 80), (0, HUD_H - 1), (NATIVE_W, HUD_H - 1))

    # Hearts
    for i in range(player.max_hp // 2):
        hx, hy = 4 + i * 11, 5
        if player.hp >= (i + 1) * 2:
            pygame.draw.circle(surf, RED, (hx + 1, hy + 2), 3)
            pygame.draw.circle(surf, RED, (hx + 5, hy + 2), 3)
            pygame.draw.polygon(surf, RED, [(hx - 1, hy + 3), (hx + 7, hy + 3), (hx + 3, hy + 8)])
        elif player.hp >= i * 2 + 1:
            pygame.draw.circle(surf, RED, (hx + 1, hy + 2), 3)
            pygame.draw.polygon(surf, RED, [(hx - 1, hy + 3), (hx + 3, hy + 3), (hx + 3, hy + 8)])
            pygame.draw.circle(surf, DKGRAY, (hx + 5, hy + 2), 3)
            pygame.draw.polygon(surf, DKGRAY, [(hx + 3, hy + 3), (hx + 7, hy + 3), (hx + 3, hy + 8)])
        else:
            pygame.draw.circle(surf, DKGRAY, (hx + 1, hy + 2), 3)
            pygame.draw.circle(surf, DKGRAY, (hx + 5, hy + 2), 3)
            pygame.draw.polygon(surf, DKGRAY, [(hx - 1, hy + 3), (hx + 7, hy + 3), (hx + 3, hy + 8)])

    # Weapon
    wpn = {"sword": "SWD", "bow": f"BOW:{player.arrows}", "bomb": f"BMB:{player.bombs}", "boomerang": "BOOM", "hookshot": "HOOK"}
    wt = font_sm.render(wpn.get(player.weapon, "SWD"), True, WHITE)
    surf.blit(wt, (NATIVE_W // 2 - wt.get_width() // 2, 3))
    if "hookshot" in player.weapons_unlocked:
        slot_hint = "[1/2/3/4/5]"
    elif "boomerang" in player.weapons_unlocked:
        slot_hint = "[1/2/3/4]"
    else:
        slot_hint = "[1/2/3]"
    wh = font_sm.render(slot_hint, True, GRAY)
    surf.blit(wh, (NATIVE_W // 2 - wh.get_width() // 2, 14))

    # Rupees
    pygame.draw.polygon(surf, YELLOW, [(NATIVE_W - 48, 5), (NATIVE_W - 45, 9),
                                        (NATIVE_W - 48, 13), (NATIVE_W - 51, 9)])
    rt = font_sm.render(f"x{player.rupees}", True, YELLOW)
    surf.blit(rt, (NATIVE_W - 42, 5))

    # Keys
    if player.keys > 0:
        pygame.draw.circle(surf, YELLOW, (NATIVE_W - 20, 7), 3)
        pygame.draw.rect(surf, YELLOW, (NATIVE_W - 21, 9, 2, 5))
        kt = font_sm.render(str(player.keys), True, YELLOW)
        surf.blit(kt, (NATIVE_W - 13, 5))

    # Level
    lt = font_sm.render(LEVEL_NAMES[lvl], True, (100, 100, 140))
    surf.blit(lt, (NATIVE_W - lt.get_width() - 4, 18))

    # Enemy count
    et = font_sm.render(f"x{len(enemies)}", True, (140, 80, 80))
    surf.blit(et, (4, 18))


def draw_multiplayer_hud(surf, players, enemies):
    """ALttP-inspired HUD for multiplayer."""
    # HUD background
    pygame.draw.rect(surf, (0, 0, 0), (0, 0, NATIVE_W, HUD_H))
    pygame.draw.line(surf, (80, 80, 100), (0, HUD_H - 1), (NATIVE_W, HUD_H - 1))

    p = players[0]  # Primary player stats for shared items

    # -- ITEM BOX (top-left) --
    box_x, box_y = 4, 2
    box_size = 22
    # Gold border
    pygame.draw.rect(surf, (184, 152, 48), (box_x, box_y, box_size, box_size))
    pygame.draw.rect(surf, (248, 216, 0), (box_x + 1, box_y + 1, box_size - 2, box_size - 2))
    pygame.draw.rect(surf, (0, 0, 0), (box_x + 2, box_y + 2, box_size - 4, box_size - 4))

    # Current weapon icon inside box
    wcx = box_x + box_size // 2
    wcy = box_y + box_size // 2
    if p.weapon == "sword":
        pygame.draw.rect(surf, (180, 180, 200), (wcx - 1, wcy - 7, 3, 11))
        pygame.draw.rect(surf, (140, 100, 40), (wcx - 3, wcy + 4, 7, 2))
    elif p.weapon == "bow":
        pygame.draw.arc(surf, (140, 100, 40), (wcx - 4, wcy - 6, 8, 12), -1, 1, 2)
        pygame.draw.line(surf, (200, 200, 200), (wcx + 2, wcy - 5), (wcx + 2, wcy + 5))
    elif p.weapon == "bomb":
        pygame.draw.circle(surf, (60, 60, 60), (wcx, wcy + 2), 5)
        pygame.draw.line(surf, (200, 160, 0), (wcx, wcy - 3), (wcx + 2, wcy - 6))
    elif p.weapon == "boomerang":
        pygame.draw.line(surf, (200, 168, 112), (wcx - 4, wcy), (wcx, wcy - 4), 2)
        pygame.draw.line(surf, (200, 168, 112), (wcx, wcy - 4), (wcx + 4, wcy), 2)
    elif p.weapon == "hookshot":
        pygame.draw.rect(surf, (140, 120, 80), (wcx - 3, wcy - 5, 6, 10))
        pygame.draw.rect(surf, (200, 180, 100), (wcx - 2, wcy - 7, 4, 3))

    # Weapon label below box
    wname = {"sword": "SWORD", "bow": "BOW", "bomb": "BOMB", "boomerang": "BOOM", "hookshot": "HOOK"}.get(p.weapon, "")
    wl = font_sm.render(wname, True, (160, 160, 180))
    surf.blit(wl, (box_x + box_size // 2 - wl.get_width() // 2, box_y + box_size + 1))

    # Magic meter (if player has magic)
    if getattr(p, 'has_magic', False) and p.max_magic > 0:
        mx_m = box_x + box_size + 3
        my_m = box_y + 2
        mh_m = box_size - 4
        magic_pct = p.magic / max(1, p.max_magic)
        pygame.draw.rect(surf, (0, 40, 0), (mx_m, my_m, 4, mh_m))
        fill_h = int(mh_m * magic_pct)
        pygame.draw.rect(surf, (0, 200, 0), (mx_m, my_m + mh_m - fill_h, 4, fill_h))
        pygame.draw.rect(surf, (0, 120, 0), (mx_m, my_m, 4, mh_m), 1)

    # -- COUNTERS (center) --
    cx = 35
    cy = 3

    # Rupee icon (small green diamond) + count
    pygame.draw.polygon(surf, (0, 200, 0), [(cx, cy + 4), (cx + 3, cy), (cx + 6, cy + 4), (cx + 3, cy + 8)])
    rupee_text = font_sm.render(f"{p.rupees:03d}", True, (0, 220, 0))
    surf.blit(rupee_text, (cx + 9, cy + 1))

    # Bomb icon + count
    bx = cx + 38
    pygame.draw.circle(surf, (60, 60, 60), (bx + 3, cy + 5), 4)
    pygame.draw.line(surf, (200, 160, 0), (bx + 3, cy + 1), (bx + 5, cy - 1))
    bomb_text = font_sm.render(f"{p.bombs:02d}", True, (200, 200, 200))
    surf.blit(bomb_text, (bx + 9, cy + 1))

    # Arrow icon + count
    ax = cx + 68
    pygame.draw.line(surf, (200, 200, 200), (ax, cy + 7), (ax + 6, cy + 1), 1)
    pygame.draw.polygon(surf, (200, 200, 200), [(ax + 5, cy), (ax + 7, cy + 2), (ax + 5, cy + 3)])
    arrow_text = font_sm.render(f"{p.arrows:02d}", True, (200, 200, 200))
    surf.blit(arrow_text, (ax + 9, cy + 1))

    # Key icon + count
    kx = cx + 98
    pygame.draw.circle(surf, (248, 216, 0), (kx + 2, cy + 3), 2)
    pygame.draw.rect(surf, (248, 216, 0), (kx + 1, cy + 5, 3, 4))
    key_text = font_sm.render(f"{p.keys}", True, (248, 216, 0))
    surf.blit(key_text, (kx + 7, cy + 1))

    # -- HEARTS (right side) --
    # "- LIFE -" label
    life_label = font_sm.render("- LIFE -", True, (200, 60, 60))
    surf.blit(life_label, (NATIVE_W - life_label.get_width() - 4, 1))

    # Heart row
    hearts_x = NATIVE_W - 4
    hearts_y = 11
    max_hearts = p.max_hp // 2
    current = p.hp

    for i in range(max_hearts):
        hx = hearts_x - (max_hearts - i) * 9
        if current >= 2:
            # Full heart
            color = (200, 0, 0)
            current -= 2
        elif current == 1:
            # Half heart
            color = (200, 0, 0)
            current -= 1
            # Draw half: left red, right dark
            pygame.draw.rect(surf, color, (hx, hearts_y, 4, 7))
            pygame.draw.rect(surf, (60, 0, 0), (hx + 4, hearts_y, 4, 7))
            pygame.draw.rect(surf, color, (hx + 1, hearts_y - 1, 6, 1))
            pygame.draw.rect(surf, (60, 0, 0), (hx + 5, hearts_y - 1, 2, 1))
            continue
        else:
            color = (60, 0, 0)  # Empty heart

        # Full/empty heart shape
        pygame.draw.rect(surf, color, (hx, hearts_y, 8, 7))
        pygame.draw.rect(surf, color, (hx + 1, hearts_y - 1, 6, 1))
        # Highlight
        if color == (200, 0, 0):
            pygame.draw.rect(surf, (255, 60, 60), (hx + 1, hearts_y, 2, 2))

    # -- MULTIPLAYER: Player indicators below hearts --
    if len(players) > 1:
        py_ind = HUD_H - 8
        for i, pl in enumerate(players):
            px_ind = NATIVE_W - 8 - (len(players) - i) * 12
            color = {1: (72, 184, 72), 2: (80, 120, 240), 3: (220, 80, 80), 4: (160, 80, 220)}.get(pl.player_num, (200, 200, 200))
            if pl.dead:
                color = (60, 60, 60)
            pygame.draw.circle(surf, color, (px_ind + 4, py_ind + 3), 3)
            # Tiny HP bar
            hp_pct = pl.hp / max(1, pl.max_hp) if not pl.dead else 0
            pygame.draw.rect(surf, (40, 0, 0), (px_ind, py_ind + 7, 8, 2))
            pygame.draw.rect(surf, (200, 0, 0), (px_ind, py_ind + 7, int(8 * hp_pct), 2))


# ══════════════════════════════════════════
#  MINIMAP
# ══════════════════════════════════════════
def draw_minimap(surf, cmap, player, enemies):
    ms = 2  # Scale
    mw, mh = MAP_COLS * ms, MAP_ROWS * ms
    mx, my = NATIVE_W - mw - 3, GAME_Y + 3
    bg = pygame.Surface((mw + 2, mh + 2), pygame.SRCALPHA)
    bg.fill((0, 0, 0, 140))
    surf.blit(bg, (mx - 1, my - 1))

    tc = {G: GRASS1, W: GRAY, P: BROWN, Q: BLUE, T: GREEN, H: LTGREEN,
          S: YELLOW, L: LAVA1, D: (28, 26, 34), F: GRAY, K: DKBROWN}
    for r in range(MAP_ROWS):
        for c in range(MAP_COLS):
            pygame.draw.rect(surf, tc.get(cmap[r][c], BLACK), (mx + c * ms, my + r * ms, ms, ms))
    # Enemies
    for e in enemies:
        pygame.draw.rect(surf, RED, (mx + int(e.x / TILE * ms), my + int(e.y / TILE * ms), 1, 1))
    # Player
    px = mx + int(player.x / TILE * ms)
    py = my + int(player.y / TILE * ms)
    pygame.draw.rect(surf, LTGREEN, (px, py, 2, 2))
    pygame.draw.rect(surf, WHITE, (mx - 1, my - 1, mw + 2, mh + 2), 1)


def draw_overworld_minimap(surf, mgr):
    """Draw an ALttP-style overworld minimap in the HUD."""
    # Position and size
    mm_x, mm_y = NATIVE_W - 50, 2
    mm_w, mm_h = 48, 36

    # Create minimap surface
    mm = pygame.Surface((mm_w, mm_h))
    mm.fill((0, 0, 0))

    # Draw each screen as a colored area (6x6 pixels per screen for inner 6x6 grid)
    cell_w = mm_w // 8  # 6px per screen
    cell_h = mm_h // 8  # ~4px per screen

    for col in range(8):
        for row in range(8):
            px = col * cell_w
            py = row * cell_h
            pos = (col, row)
            if pos in mgr.data:
                sd = mgr.data[pos]
                if sd.get("boundary"):
                    # Boundary: dark brown cliff edge (not black)
                    c = (80, 56, 40)
                else:
                    # Color by most common tile type in the screen
                    name = sd.get("name", "").lower()
                    if "lake" in name or "river" in name:
                        c = (40, 88, 192)  # Blue water
                    elif "water" in name:
                        c = (40, 88, 192)
                    elif "death" in name or "mountain" in name:
                        c = (152, 104, 88)  # Mauve-brown cliff
                    elif "castle" in name:
                        c = (180, 180, 190)  # Pale gray stone
                    elif "kakariko" in name:
                        c = (72, 160, 72)  # Green with a hint of buildings
                    elif "house" in name or "link" in name:
                        c = (72, 168, 72)  # Bright green (home area)
                    elif "desert" in name or "sand" in name:
                        c = (216, 200, 144)  # Sandy tan
                    elif "swamp" in name:
                        c = (56, 104, 56)  # Dark murky green
                    elif "lost" in name or "dark" in name:
                        c = (32, 96, 32)  # Very dark green
                    elif "grave" in name:
                        c = (72, 64, 56)  # Dark brown-gray
                    elif "east" in name:
                        c = (88, 152, 88)  # Medium green
                    elif "forest" in name or "woods" in name:
                        c = (40, 120, 40)
                    else:
                        c = (72, 168, 72)  # Default: bright green field

                pygame.draw.rect(mm, c, (px, py, cell_w, cell_h))
            else:
                pygame.draw.rect(mm, (40, 32, 24), (px, py, cell_w, cell_h))

    # Draw current screen marker (blinking white outline)
    if mgr.current:
        cx = mgr.current[0] * cell_w
        cy = mgr.current[1] * cell_h
        if (pygame.time.get_ticks() // 250) % 2 == 0:
            pygame.draw.rect(mm, (255, 255, 255), (cx, cy, cell_w, cell_h), 1)
        else:
            pygame.draw.rect(mm, (255, 200, 50), (cx, cy, cell_w, cell_h), 1)

    # Draw player dot
    if mgr.current:
        # Small bright dot for player position within the screen cell
        px = mgr.current[0] * cell_w + cell_w // 2
        py = mgr.current[1] * cell_h + cell_h // 2
        mm.set_at((px, py), (255, 255, 255))
        if cell_w > 2:
            mm.set_at((px-1, py), (255, 200, 50))
            mm.set_at((px+1, py), (255, 200, 50))

    # Draw border
    pygame.draw.rect(mm, (160, 140, 100), (0, 0, mm_w, mm_h), 1)

    # Blit to game surface
    surf.blit(mm, (mm_x, mm_y))


# ══════════════════════════════════════════
#  INVENTORY / PAUSE SCREEN
# ══════════════════════════════════════════
def draw_inventory_screen(surf, player):
    """Draw an ALttP-style inventory/pause screen."""
    # Dark overlay
    overlay = pygame.Surface((NATIVE_W, NATIVE_H), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 200))
    surf.blit(overlay, (0, 0))

    # Title
    title = font_lg.render("INVENTORY", True, (248, 216, 0))
    surf.blit(title, (NATIVE_W//2 - title.get_width()//2, 10))

    # Weapons section
    wx = 20
    wy = 35
    weapons_label = font_sm.render("WEAPONS", True, (200, 200, 200))
    surf.blit(weapons_label, (wx, wy))

    weapon_list = [
        ("Sword", "sword", (180, 180, 200)),
        ("Bow", "bow", (140, 100, 60)),
        ("Bombs", "bomb", (80, 80, 80)),
        ("Boomerang", "boomerang", (200, 168, 112)),
        ("Hookshot", "hookshot", (200, 180, 100)),
    ]

    for i, (name, key, color) in enumerate(weapon_list):
        y = wy + 14 + i * 14
        unlocked = key in player.weapons_unlocked
        if unlocked:
            # Equipped indicator
            if player.weapon == key:
                pygame.draw.rect(surf, (248, 216, 0), (wx, y, 2, 10))
            # Weapon icon (small colored square)
            pygame.draw.rect(surf, color, (wx + 6, y + 1, 8, 8))
            pygame.draw.rect(surf, (255, 255, 255), (wx + 6, y + 1, 8, 8), 1)
            text = font_sm.render(name, True, (255, 255, 255))
        else:
            pygame.draw.rect(surf, (40, 40, 50), (wx + 6, y + 1, 8, 8))
            text = font_sm.render("???", True, (80, 80, 80))
        surf.blit(text, (wx + 18, y))

    # Items section
    ix = 120
    iy = 35
    items_label = font_sm.render("ITEMS", True, (200, 200, 200))
    surf.blit(items_label, (ix, iy))

    items = [
        ("Hearts", f"{player.hp}/{player.max_hp}", (255, 60, 60)),
        ("Rupees", str(player.rupees), (0, 200, 0)),
        ("Arrows", str(player.arrows), (200, 200, 200)),
        ("Bombs", str(player.bombs), (100, 100, 100)),
        ("Keys", str(player.keys), (248, 216, 0)),
    ]

    heart_pieces = getattr(player, 'heart_pieces', 0)
    if heart_pieces > 0:
        items.append(("Heart Pcs", f"{heart_pieces}/4", (255, 120, 120)))

    if getattr(player, 'has_boots', False):
        items.append(("P.Boots", "YES", (200, 240, 255)))

    if getattr(player, 'has_flippers', False):
        items.append(("Flippers", "YES", (80, 180, 255)))

    if getattr(player, 'has_lantern', False):
        items.append(("Lantern", "YES", (255, 200, 50)))

    if getattr(player, 'has_magic', False):
        items.append(("Magic", f"{player.magic}/{player.max_magic}", (0, 200, 0)))

    for i, (name, val, color) in enumerate(items):
        y = iy + 14 + i * 12
        label = font_sm.render(f"{name}:", True, (160, 160, 180))
        value = font_sm.render(val, True, color)
        surf.blit(label, (ix, y))
        surf.blit(value, (ix + 55, y))

    # Stats section
    sx = 20
    sy = 120
    stats_label = font_sm.render("STATS", True, (200, 200, 200))
    surf.blit(stats_label, (sx, sy))

    stats = [
        ("Kills", str(player.kills)),
        ("Damage", str(player.dmg_dealt)),
        ("Time", f"{player.game_time // 3600}:{(player.game_time // 60) % 60:02d}"),
    ]

    for i, (name, val) in enumerate(stats):
        y = sy + 14 + i * 12
        label = font_sm.render(f"{name}:", True, (160, 160, 180))
        value = font_sm.render(val, True, (200, 200, 200))
        surf.blit(label, (sx, y))
        surf.blit(value, (sx + 50, y))

    # Controls hint
    hint = font_sm.render("ESC: Resume  1/2/3/4/5: Switch Weapon", True, (80, 80, 100))
    surf.blit(hint, (NATIVE_W//2 - hint.get_width()//2, NATIVE_H - 12))

    # Player number indicator (for multiplayer)
    if player.player_num > 1:
        pn = font_sm.render(f"Player {player.player_num}", True,
            {1: (72, 184, 72), 2: (80, 120, 240), 3: (220, 80, 80), 4: (160, 80, 220)}.get(player.player_num, (200, 200, 200)))
        surf.blit(pn, (NATIVE_W - pn.get_width() - 10, 12))


# ══════════════════════════════════════════
#  TRANSITIONS
# ══════════════════════════════════════════
def draw_boss_phase2_darkness(surf, boss, player_positions, cmap):
    """Draw phase 2 darkness overlay with light circles around players and torches."""
    dark = pygame.Surface((NATIVE_W, NATIVE_H), pygame.SRCALPHA)
    dark.fill((0, 0, 20, 100))
    # Cut out light around players
    for px, py in player_positions:
        pygame.draw.circle(dark, (0, 0, 0, 0), (int(px), int(py) + GAME_Y), 32)
    # Cut out light around torches (tile F=9)
    for r in range(MAP_ROWS):
        for c in range(MAP_COLS):
            if cmap[r][c] == F:  # torch_wall
                pygame.draw.circle(dark, (0, 0, 0, 0), (c * TILE + 8, r * TILE + 8 + GAME_Y), 24)
    surf.blit(dark, (0, 0))


def draw_boss_arena_edges(surf, phase_timer):
    """Draw pulsing dark energy at arena edges during phase 3."""
    pulse = int(20 + 10 * math.sin(phase_timer * 0.06))
    edge = pygame.Surface((NATIVE_W, NATIVE_H), pygame.SRCALPHA)
    # Top and bottom edge glow
    for y in range(8):
        a = int(pulse * (1 - y / 8))
        pygame.draw.line(edge, (100, 0, 0, a), (0, GAME_Y + y), (NATIVE_W, GAME_Y + y))
        pygame.draw.line(edge, (100, 0, 0, a), (0, NATIVE_H - y), (NATIVE_W, NATIVE_H - y))
    # Left and right edge glow
    for x in range(8):
        a = int(pulse * (1 - x / 8))
        pygame.draw.line(edge, (100, 0, 0, a), (x, GAME_Y), (x, NATIVE_H))
        pygame.draw.line(edge, (100, 0, 0, a), (NATIVE_W - x, GAME_Y), (NATIVE_W - x, NATIVE_H))
    surf.blit(edge, (0, 0))


def check_boss_slam_damage(boss, player_list, particles, dmg_nums):
    """Check and apply ground slam AoE damage. Returns shake amount."""
    if not hasattr(boss, 'slam_landed') or not boss.slam_landed:
        return 0
    sx, sy = boss.x, boss.y
    boss.slam_landed = False
    shake_amt = 15
    for pl in player_list:
        if hasattr(pl, 'dead') and pl.dead:
            continue
        if math.sqrt((pl.x - sx) ** 2 + (pl.y - sy) ** 2) < 36:
            pl.take_damage(2, sx, sy)
            dmg_nums.append(DmgNum(pl.x, pl.y - 10, "-2", RED))
    # Slam particles
    for _ in range(12):
        particles.append(Particle(sx, sy,
            random.choice([GRAY, DKGRAY, BROWN, WHITE]),
            life=random.randint(15, 30), size=random.randint(2, 3)))
    return shake_amt


def check_boss_fire_trail_damage(boss, player_list):
    """Check fire trail damage on players (phase 3)."""
    if not hasattr(boss, 'fire_trail'):
        return
    for fx, fy, ft in boss.fire_trail:
        for pl in player_list:
            if hasattr(pl, 'dead') and pl.dead:
                continue
            if abs(pl.x - fx) < 8 and abs(pl.y - fy) < 8:
                pl.take_damage(1, fx, fy)


def check_boss_clone_damage(boss, player_list):
    """Check shadow clone collision damage (phase 2)."""
    if not hasattr(boss, 'clones') or boss.phase != 2:
        return
    for cx, cy in boss.clones:
        for pl in player_list:
            if hasattr(pl, 'dead') and pl.dead:
                continue
            if abs(pl.x - cx) < 10 and abs(pl.y - cy) < 10:
                pl.take_damage(1, cx, cy)


def boss_death_sequence(boss, particles, hitstop_val, shake_val):
    """Create epic boss death with massive particles. Returns (hitstop, shake)."""
    stop_music()
    SFX["fanfare"].play()
    # 5 waves of 20 particles = 100 particles
    for wave in range(5):
        for _ in range(20):
            particles.append(Particle(
                boss.x + random.randint(-30, 30),
                boss.y + random.randint(-30, 30),
                random.choice([RED, ORANGE, YELLOW, WHITE, PURPLE, (255, 200, 255)]),
                life=random.randint(40, 80),
                size=random.randint(2, 5)))
    return 180, 25  # 3 seconds hitstop, heavy shake


async def fade(direction="out", speed=12, color=BLACK):
    overlay = pygame.Surface((NATIVE_W, NATIVE_H))
    overlay.fill(color)
    for i in range(255 // speed + 1):
        a = i * speed if direction == "out" else 255 - i * speed
        a = max(0, min(255, a))
        overlay.set_alpha(a)
        game_surf.blit(overlay, (0, 0))
        scaled = pygame.transform.scale(game_surf, (SCREEN_W, SCREEN_H))
        screen.blit(scaled, (0, 0))
        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)


async def iris_wipe(direction="out", cx=None, cy=None, frames=20):
    """Circle/iris wipe transition centered on a point (Zelda-style)."""
    if cx is None: cx = NATIVE_W // 2
    if cy is None: cy = NATIVE_H // 2
    max_r = int(math.sqrt(NATIVE_W**2 + NATIVE_H**2)) // 2 + 10
    # Take snapshot of current frame
    snapshot = game_surf.copy()
    for i in range(frames + 1):
        t = i / frames
        if direction == "out":
            r = max(0, int(max_r * (1 - t)))
        else:
            r = int(max_r * t)
        # Redraw the snapshot
        game_surf.blit(snapshot, (0, 0))
        # Create black mask with white circle hole
        mask = pygame.Surface((NATIVE_W, NATIVE_H))
        mask.fill(BLACK)
        mask.set_colorkey((255, 255, 255))
        if r > 0:
            pygame.draw.circle(mask, (255, 255, 255), (cx, cy), r)
        game_surf.blit(mask, (0, 0))
        scaled = pygame.transform.scale(game_surf, (SCREEN_W, SCREEN_H))
        screen.blit(scaled, (0, 0))
        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)


# ══════════════════════════════════════════
#  TITLE SCREEN
# ══════════════════════════════════════════
async def title_screen():
    t = 0
    while True:
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                return False
            if ev.type == pygame.KEYDOWN:
                if ev.key in (pygame.K_RETURN, pygame.K_SPACE):
                    SFX["select"].play(); await fade("out", 10); return True
                if ev.key == pygame.K_ESCAPE:
                    return False

        game_surf.fill((0, 0, 0))

        # ── ANIMATED RAIN ──
        rain_surf = pygame.Surface((NATIVE_W, NATIVE_H), pygame.SRCALPHA)
        for i in range(30):
            rx = (i * 37 + t * 2) % NATIVE_W
            ry = (i * 53 + t * 4) % NATIVE_H
            pygame.draw.line(rain_surf, (100, 120, 180, 40), (rx, ry), (rx - 1, ry + 5))
        game_surf.blit(rain_surf, (0, 0))

        # ── TRIFORCE (golden triangles behind text) ──
        tri_cx = NATIVE_W // 2
        tri_cy = 95
        tri_size = 40
        gold = (248, 216, 0)
        dark_gold = (200, 168, 0)

        # Top triangle
        pts_top = [(tri_cx, tri_cy - tri_size + 5),
                   (tri_cx - tri_size//2, tri_cy),
                   (tri_cx + tri_size//2, tri_cy)]
        pygame.draw.polygon(game_surf, dark_gold, pts_top)
        # Bottom-left triangle
        pts_bl = [(tri_cx - tri_size//2, tri_cy),
                  (tri_cx - tri_size, tri_cy + tri_size - 5),
                  (tri_cx, tri_cy + tri_size - 5)]
        pygame.draw.polygon(game_surf, gold, pts_bl)
        # Bottom-right triangle
        pts_br = [(tri_cx + tri_size//2, tri_cy),
                  (tri_cx, tri_cy + tri_size - 5),
                  (tri_cx + tri_size, tri_cy + tri_size - 5)]
        pygame.draw.polygon(game_surf, gold, pts_br)

        # ── MASTER SWORD (left side) ──
        sx = tri_cx - 55
        # Blade
        pygame.draw.rect(game_surf, (180, 180, 200), (sx, 50, 3, 80))
        pygame.draw.rect(game_surf, (220, 220, 240), (sx + 1, 50, 1, 75))
        # Guard (crosspiece)
        pygame.draw.rect(game_surf, (100, 80, 160), (sx - 6, 128, 15, 4))
        pygame.draw.rect(game_surf, (140, 100, 180), (sx - 5, 129, 13, 2))
        # Gem in guard
        pygame.draw.rect(game_surf, (80, 200, 80), (sx, 129, 3, 2))
        # Handle
        pygame.draw.rect(game_surf, (120, 80, 40), (sx, 132, 3, 16))
        pygame.draw.rect(game_surf, (160, 120, 60), (sx + 1, 133, 1, 14))
        # Pommel
        pygame.draw.rect(game_surf, (200, 168, 0), (sx - 1, 148, 5, 3))

        # Sword glow
        glow = pygame.Surface((30, 100), pygame.SRCALPHA)
        a = int(40 + 20 * math.sin(t * 0.05))
        pygame.draw.ellipse(glow, (200, 200, 255, a), (0, 0, 30, 100))
        game_surf.blit(glow, (sx - 13, 45))

        # ── TITLE TEXT ──
        # "THE LEGEND OF" - small white text
        legend_text = font_sm.render("THE LEGEND OF", True, (220, 220, 220))
        game_surf.blit(legend_text, (NATIVE_W // 2 - legend_text.get_width() // 2, 58))

        # "LINK" - large text in dark red/maroon with gold edge
        title = font_title.render("LINK", True, (160, 40, 40))
        tx = NATIVE_W // 2 - title.get_width() // 2
        # Shadow
        shadow = font_title.render("LINK", True, (80, 16, 16))
        game_surf.blit(shadow, (tx + 2, 72))
        # Gold outline effect (render slightly offset in gold)
        gold_title = font_title.render("LINK", True, (248, 216, 0))
        for ox, oy in [(-1,0),(1,0),(0,-1),(0,1)]:
            game_surf.blit(gold_title, (tx + ox, 70 + oy))
        # Main title on top
        game_surf.blit(title, (tx, 70))

        # "LIGHT WORLD" subtitle
        sub = font_sm.render("LIGHT WORLD", True, (180, 160, 100))
        game_surf.blit(sub, (NATIVE_W // 2 - sub.get_width() // 2, 148))

        # ── "UP TO 4 PLAYERS" badge ──
        badge = font_sm.render("UP TO 4 PLAYERS", True, (120, 120, 140))
        game_surf.blit(badge, (NATIVE_W // 2 - badge.get_width() // 2, 165))

        # ── PRESS START (pulsing) ──
        alpha = int(128 + 127 * math.sin(t * 0.06))
        start_surf = pygame.Surface((120, 12), pygame.SRCALPHA)
        start_text = font_sm.render("PRESS ENTER", True, (255, 255, 255))
        start_surf.blit(start_text, (60 - start_text.get_width() // 2, 0))
        start_surf.set_alpha(alpha)
        game_surf.blit(start_surf, (NATIVE_W // 2 - 60, 190))

        # ── Controls hint ──
        ctrl = font_sm.render("WASD:Move SPACE:Attack E:Interact", True, (60, 60, 80))
        game_surf.blit(ctrl, (NATIVE_W // 2 - ctrl.get_width() // 2, NATIVE_H - 12))

        # Scale and display
        scaled = pygame.transform.scale(game_surf, (SCREEN_W, SCREEN_H))
        screen.blit(scaled, (0, 0))
        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)
        t += 1


async def intro_scroll():
    lines = ["", "In the kingdom of Hyrule...", "",
             "The Dark Lord has risen,",
             "spreading shadow across the land.", "",
             "From Death Mountain to Lake Hylia,",
             "his monsters terrorize the people.", "",
             "Four heroes must journey through",
             "forests, deserts, and swamps",
             "to find the five crystals",
             "and restore peace.", "",
             "Your quest begins now.", ""]
    scroll_y = float(NATIVE_H)
    while scroll_y > -len(lines) * 14 - 20:
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                return False
            if ev.type == pygame.KEYDOWN:
                if ev.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_ESCAPE):
                    return True

        # Star-field background
        game_surf.fill((4, 6, 18))

        for i, line in enumerate(lines):
            ly = int(scroll_y) + i * 14
            if -12 < ly < NATIVE_H + 12:
                # Highlight key proper nouns / dramatic lines in gold
                is_gold = any(w in line for w in [
                    "Hyrule", "Death Mountain", "Lake Hylia", "Four heroes",
                    "five crystals", "Your quest begins now."
                ])
                c = YELLOW if is_gold else WHITE
                ts = font_md.render(line, True, c)
                game_surf.blit(ts, (NATIVE_W // 2 - ts.get_width() // 2, ly))

        scroll_y -= 0.5
        scaled = pygame.transform.scale(game_surf, (SCREEN_W, SCREEN_H))
        screen.blit(scaled, (0, 0))
        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)
    return True


# ══════════════════════════════════════════
#  PUSH BLOCKS & FLOOR SWITCHES
# ══════════════════════════════════════════
class PushBlock:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.w, self.h = TILE, TILE
        self.moving = False
        self.move_dx, self.move_dy = 0, 0
        self.move_progress = 0
        self.pushed = False  # Only pushable once

    @property
    def rect(self):
        return pygame.Rect(self.x - self.w//2, self.y - self.h//2, self.w, self.h)

    def try_push(self, direction, cmap):
        if self.pushed or self.moving:
            return False
        dx, dy = {"up":(0,-1), "down":(0,1), "left":(-1,0), "right":(1,0)}[direction]
        # Check destination
        dest_c = int(self.x) // TILE + dx
        dest_r = int(self.y) // TILE + dy
        if 0 <= dest_r < MAP_ROWS and 0 <= dest_c < MAP_COLS:
            if cmap[dest_r][dest_c] in (0, 2, 8):  # grass, path, dark_floor
                self.moving = True
                self.move_dx = dx * TILE
                self.move_dy = dy * TILE
                self.move_progress = 0
                self.pushed = True
                return True
        return False

    def update(self):
        if self.moving:
            self.move_progress += 2
            if self.move_progress >= TILE:
                self.x += self.move_dx
                self.y += self.move_dy
                self.moving = False
                self.move_dx = self.move_dy = 0

    def draw(self, surf):
        dx = self.move_dx * self.move_progress // TILE if self.moving else 0
        dy = self.move_dy * self.move_progress // TILE if self.moving else 0
        bx = int(self.x) - self.w//2 + dx
        by = int(self.y) - self.h//2 + dy + GAME_Y
        # Dark stone block
        pygame.draw.rect(surf, (90, 90, 100), (bx, by, TILE, TILE))
        pygame.draw.rect(surf, (70, 70, 80), (bx, by, TILE, TILE), 1)
        # Cross pattern
        pygame.draw.line(surf, (110, 110, 120), (bx+3, by+3), (bx+12, by+12))
        pygame.draw.line(surf, (110, 110, 120), (bx+12, by+3), (bx+3, by+12))


class FloorSwitch:
    def __init__(self, x, y, target_r, target_c):
        self.x = x
        self.y = y
        self.target_r = target_r  # Row of the barrier to open
        self.target_c = target_c  # Col of the barrier to open
        self.activated = False

    @property
    def rect(self):
        return pygame.Rect(self.x - 6, self.y - 6, 12, 12)

    def check(self, players, cmap):
        if self.activated:
            return
        for pl in players:
            if self.rect.colliderect(pl.rect):
                self.activated = True
                # Open the barrier
                if 0 <= self.target_r < MAP_ROWS and 0 <= self.target_c < MAP_COLS:
                    cmap[self.target_r][self.target_c] = D  # Change to dark_floor
                SFX["door"].play()
                return

    def draw(self, surf):
        bx, by = int(self.x), int(self.y) + GAME_Y
        if self.activated:
            pygame.draw.rect(surf, (60, 80, 60), (bx-5, by-5, 10, 10))
            pygame.draw.rect(surf, (40, 60, 40), (bx-5, by-5, 10, 10), 1)
        else:
            pygame.draw.rect(surf, (200, 180, 60), (bx-5, by-5, 10, 10))
            pygame.draw.rect(surf, (160, 140, 40), (bx-5, by-5, 10, 10), 1)
            # Diamond shape
            pygame.draw.polygon(surf, (240, 220, 80),
                [(bx, by-3), (bx+3, by), (bx, by+3), (bx-3, by)])


class Pot:
    """A liftable pot that can be thrown at enemies."""
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.w, self.h = 12, 12
        self.alive = True
        self.lifted = False
        self.carrier = None  # Player carrying this pot
        self.thrown = False
        self.throw_dx = 0
        self.throw_dy = 0
        self.throw_speed = 4

    @property
    def rect(self):
        return pygame.Rect(self.x - self.w//2, self.y - self.h//2, self.w, self.h)

    def lift(self, player):
        """Player picks up the pot."""
        self.lifted = True
        self.carrier = player
        SFX["pickup"].play()

    def throw_pot(self, direction):
        """Throw the pot in the given direction."""
        self.lifted = False
        self.thrown = True
        self.carrier = None
        dirs = {"up":(0,-1), "down":(0,1), "left":(-1,0), "right":(1,0)}
        dx, dy = dirs.get(direction, (0, 1))
        self.throw_dx = dx * self.throw_speed
        self.throw_dy = dy * self.throw_speed
        SFX["arrow"].play()

    def update(self, cmap, particles):
        if self.lifted and self.carrier:
            # Float above the carrier
            self.x = self.carrier.x
            self.y = self.carrier.y - 16
        elif self.thrown:
            self.x += self.throw_dx
            self.y += self.throw_dy
            # Safety bounds — smash if way off screen
            if self.x < -32 or self.x > NATIVE_W + 32 or self.y < -32 or self.y > MAP_ROWS * TILE + 32:
                self.smash(particles)
                return
            # Check wall collision
            c = int(self.x) // TILE
            r = int(self.y) // TILE
            if c < 0 or c >= MAP_COLS or r < 0 or r >= MAP_ROWS:
                self.smash(particles)
            else:
                try:
                    tile = cmap[r][c]
                    # Check both dungeon tiles (0-10) and overworld tiles (100+)
                    if tile in (W, Q, T, L, K):  # Dungeon wall tiles
                        self.smash(particles)
                    elif tile >= 100:  # Overworld tiles — check walkability
                        from overworld_tiles import TILE_PROPS
                        props = TILE_PROPS.get(tile, {})
                        if not props.get("walkable", False):
                            self.smash(particles)
                except (IndexError, TypeError):
                    self.smash(particles)

    def smash(self, particles):
        """Break the pot into pieces."""
        if not self.alive:
            return  # Already smashed
        self.alive = False
        self.thrown = False
        self.lifted = False
        self.carrier = None
        try:
            SFX["hit"].play()
        except Exception:
            pass
        for _ in range(6):
            particles.append(Particle(
                max(0, min(NATIVE_W, self.x)),
                max(0, min(MAP_ROWS * TILE, self.y)),
                random.choice([(160,140,100), (120,100,70), (180,160,120)]),
                life=15, size=2))

    def draw(self, surf):
        if not self.alive:
            return
        px = int(self.x) - 6
        py = int(self.y) - 6 + GAME_Y
        if self.lifted:
            py -= 4  # Float higher when carried
        # Pot body (rounded shape)
        pygame.draw.rect(surf, (160, 140, 100), (px, py+2, 12, 10))
        pygame.draw.rect(surf, (140, 120, 80), (px, py+2, 12, 10), 1)
        # Pot rim
        pygame.draw.rect(surf, (180, 160, 120), (px-1, py, 14, 3))
        pygame.draw.rect(surf, (140, 120, 80), (px-1, py, 14, 3), 1)
        # Highlight
        pygame.draw.rect(surf, (200, 180, 140), (px+2, py+4, 3, 2))


# ══════════════════════════════════════════
#  LEVEL SETUP
# ══════════════════════════════════════════
from_grass_pickups = []  # Global temp list for grass drops

def setup_level(lvl):
    cmap = [row[:] for row in MAPS[lvl]]
    enemies, pickups, npcs, chests = [], [], [], []

    TC = TILE  # Shorthand
    if lvl == 0:
        enemies = [Enemy(3*TC, 4*TC, "slime"), Enemy(12*TC, 3*TC, "slime"),
                   Enemy(3*TC, 8*TC, "slime"), Enemy(12*TC, 8*TC, "slime"),
                   Enemy(8*TC, 6*TC, "bat")]
        pickups = [Pickup(7*TC, 5*TC, "rupee"), Pickup(9*TC, 5*TC, "rupee"),
                   Pickup(8*TC, 3*TC, "heart")]
        chests = [Chest(12*TC, 3*TC, "boomerang", "Boomerang"),
                  Chest(4*TC, 3*TC, "lantern", "Lantern")]
        npcs = [NPC(3*TC, 2*TC, "Elder",
                    ["Hero! The Dark Lord awaits below.", "Clear all monsters to open stairs.",
                     "Cut tall grass for hidden items!"], BLUE),
                NPC(12*TC, 2*TC, "Scout",
                    ["Switch weapons with 1-4.", "Press E near locked doors with a key!",
                     "Hold attack to charge a spin attack!"], ORANGE)]
    elif lvl == 1:
        enemies = [Enemy(3*TC, 2*TC, "bat"), Enemy(12*TC, 2*TC, "bat"),
                   Enemy(8*TC, 5*TC, "skeleton"), Enemy(3*TC, 9*TC, "skeleton"),
                   Enemy(12*TC, 9*TC, "bat"), Enemy(8*TC, 8*TC, "slime"),
                   Enemy(8*TC, 5*TC, "miniboss")]
        pickups = [Pickup(2*TC, 5*TC, "rupee"), Pickup(13*TC, 5*TC, "rupee"),
                   Pickup(8*TC, 6*TC, "key")]  # Key for the locked door in this level
        chests = [Chest(8*TC, 2*TC, "bow", "Bow & Arrows"),
                  Chest(2*TC, 5*TC, "flippers", "Zora's Flippers")]
        npcs = [NPC(2*TC, 2*TC, "Explorer",
                    ["Watch out for bats here!", "Find the key to open the locked door!"], LTGREEN)]
    elif lvl == 2:
        enemies = [Enemy(2*TC, 2*TC, "knight"), Enemy(13*TC, 2*TC, "knight"),
                   Enemy(2*TC, 9*TC, "skeleton"), Enemy(13*TC, 9*TC, "skeleton"),
                   Enemy(8*TC, 5*TC, "mage"), Enemy(6*TC, 5*TC, "skeleton"),
                   Enemy(10*TC, 5*TC, "skeleton"),
                   Enemy(8*TC, 5*TC, "miniboss")]
        pickups = [Pickup(8*TC, 2*TC, "rupee"), Pickup(8*TC, 8*TC, "heart"),
                   Pickup(4*TC, 5*TC, "arrows"), Pickup(12*TC, 5*TC, "arrows")]
        chests = [Chest(8*TC, 5*TC, "bomb", "Bombs"), Chest(8*TC, 2*TC, "boots", "Pegasus Boots"),
                  Chest(4*TC, 8*TC, "magic", "Magic Jar")]
    elif lvl == 3:
        enemies = [Enemy(4*TC, 3*TC, "mage"), Enemy(11*TC, 3*TC, "mage"),
                   Enemy(4*TC, 8*TC, "knight"), Enemy(11*TC, 8*TC, "knight"),
                   Enemy(8*TC, 5*TC, "knight"), Enemy(6*TC, 5*TC, "bat"),
                   Enemy(10*TC, 5*TC, "bat"),
                   Enemy(8*TC, 5*TC, "miniboss")]
        pickups = [Pickup(8*TC, 3*TC, "heart"), Pickup(8*TC, 8*TC, "heart"),
                   Pickup(3*TC, 5*TC, "bombs"), Pickup(12*TC, 5*TC, "arrows"),
                   Pickup(8*TC, 9*TC, "key")]  # Key for the locked gates
        chests = [Chest(8*TC, 7*TC, "heart_container", "Heart Container"),
                  Chest(12*TC, 7*TC, "hookshot", "Hookshot")]
        npcs = [NPC(2*TC, 5*TC, "Ghost",
                    ["The Shadow Lord has 3 phases...", "Find the key to breach the gates!"], (150, 150, 200))]
    elif lvl == 4:
        enemies = [Enemy(8*TC, 4*TC, "boss")]
        pickups = [Pickup(3*TC, 9*TC, "heart"), Pickup(12*TC, 9*TC, "heart"),
                   Pickup(3*TC, 2*TC, "arrows"), Pickup(12*TC, 2*TC, "bombs")]

    # Push blocks
    push_blocks = []
    if lvl == 1:  # Cave
        push_blocks = [PushBlock(6*TC+8, 6*TC+8)]
    elif lvl == 2:  # Castle
        push_blocks = [PushBlock(4*TC+8, 5*TC+8), PushBlock(11*TC+8, 5*TC+8)]
    elif lvl == 3:  # Lava
        push_blocks = [PushBlock(8*TC+8, 5*TC+8)]

    # Floor switches
    switches = []
    if lvl == 2:  # Castle - switch opens a wall
        switches = [FloorSwitch(8*TC+8, 5*TC+8, 4, 8)]
    if lvl == 3:  # Lava - switch opens locked gate
        switches = [FloorSwitch(8*TC+8, 8*TC+8, 4, 7)]

    # Pots
    pots = []
    if lvl == 0:  # Forest
        pots = [Pot(5*TC+8, 5*TC+8), Pot(10*TC+8, 5*TC+8)]
    elif lvl == 1:  # Cave
        pots = [Pot(3*TC+8, 3*TC+8), Pot(12*TC+8, 3*TC+8), Pot(3*TC+8, 9*TC+8), Pot(12*TC+8, 9*TC+8)]
    elif lvl == 2:  # Castle
        pots = [Pot(2*TC+8, 3*TC+8), Pot(13*TC+8, 3*TC+8), Pot(2*TC+8, 8*TC+8), Pot(13*TC+8, 8*TC+8)]
    elif lvl == 3:  # Lava
        pots = [Pot(3*TC+8, 3*TC+8), Pot(12*TC+8, 3*TC+8)]
    elif lvl == 4:  # Boss
        pots = [Pot(3*TC+8, 3*TC+8), Pot(12*TC+8, 3*TC+8), Pot(3*TC+8, 9*TC+8), Pot(12*TC+8, 9*TC+8)]

    return cmap, enemies, pickups, npcs, chests, push_blocks, switches, pots


# ══════════════════════════════════════════
#  GAME LOOP
# ══════════════════════════════════════════
async def game_loop():
    global from_grass_pickups
    lvl = 0
    cmap, enemies, pickups, npcs, chests, push_blocks, switches, pots = setup_level(lvl)
    player = Player(8 * TILE, 2 * TILE, keys=PLAYER_KEYS[1], tint=None, player_num=1)
    particles, dmg_nums, projectiles = [], [], []
    dialogue = DialogueBox(font_sm)
    dialogue.text_sound = SFX.get("text")
    shake = 0
    hitstop = 0  # Freeze frames for impact
    state = "playing"
    msg, msg_t = "", 0
    show_mm = True
    popup, popup_t = "", 0
    from_grass_pickups = []

    await fade("in", 10)
    play_music("dungeon")

    while True:
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                return False
            if ev.type == pygame.KEYDOWN:
                if dialogue.is_active:
                    if ev.key in (pygame.K_e, pygame.K_RETURN, pygame.K_SPACE):
                        dialogue.advance()
                elif state == "playing":
                    if ev.key == pygame.K_SPACE:
                        # If player is carrying a pot, throw it
                        if player._carried_pot:
                            pot = player._carried_pot
                            pot.throw_pot(player.dir)
                            player._carried_pot = None
                        # Swimming restricts weapons — only boomerang allowed
                        elif player.swimming and player.weapon != "boomerang":
                            pass  # Can't use sword/bow/bomb in water
                        else:
                            player.attack(projectiles, cmap, particles)
                    elif ev.key == pygame.K_e:
                        # If carrying a pot, throw it; otherwise interact normally
                        if player._carried_pot:
                            pot = player._carried_pot
                            pot.throw_pot(player.dir)
                            player._carried_pot = None
                        else:
                            ir = player.rect.inflate(12, 12)
                            # Try to pick up a nearby pot
                            picked_up = False
                            for pot in pots:
                                if pot.alive and not pot.lifted and ir.colliderect(pot.rect):
                                    pot.lift(player)
                                    player._carried_pot = pot
                                    picked_up = True
                                    break
                            if not picked_up:
                                # Check for locked doors nearby
                                door_opened = False
                                for dr in range(MAP_ROWS):
                                    for dc in range(MAP_COLS):
                                        if cmap[dr][dc] == K:
                                            door_r = pygame.Rect(dc * TILE, dr * TILE, TILE, TILE)
                                            if ir.colliderect(door_r):
                                                if player.keys > 0:
                                                    player.keys -= 1
                                                    cmap[dr][dc] = D  # Unlock to dark floor
                                                    SFX["door"].play()
                                                    door_opened = True
                                                    popup = "Door unlocked!"; popup_t = 60
                                                    for _ in range(8):
                                                        particles.append(Particle(dc * TILE + 8, dr * TILE + 8,
                                                            random.choice([YELLOW, WHITE]), life=20, size=2))
                                                else:
                                                    popup = "Need a key!"; popup_t = 40
                                                break
                                    if door_opened:
                                        break
                                if not door_opened:
                                    for npc in npcs:
                                        if ir.colliderect(npc.rect):
                                            dialogue.start(npc.name, npc.lines); npc.talked = True; break
                                for ch in chests:
                                    if not ch.opened and ir.colliderect(ch.rect):
                                        ch.opened = True; SFX["chest"].play()
                                        if ch.item == "bow":
                                            if "bow" not in player.weapons_unlocked:
                                                player.weapons_unlocked.append("bow")
                                            player.arrows += 15
                                        elif ch.item == "bomb":
                                            if "bomb" not in player.weapons_unlocked:
                                                player.weapons_unlocked.append("bomb")
                                            player.bombs += 5
                                        elif ch.item == "heart_container":
                                            player.max_hp += 2; player.hp = player.max_hp
                                        elif ch.item == "arrows":
                                            player.arrows += 10
                                        elif ch.item == "bombs":
                                            player.bombs += 5
                                        elif ch.item == "boomerang":
                                            if "boomerang" not in player.weapons_unlocked:
                                                player.weapons_unlocked.append("boomerang")
                                        elif ch.item == "boots":
                                            player.has_boots = True
                                        elif ch.item == "flippers":
                                            player.has_flippers = True
                                        elif ch.item == "hookshot":
                                            if "hookshot" not in player.weapons_unlocked:
                                                player.weapons_unlocked.append("hookshot")
                                            player.has_hookshot = True
                                        elif ch.item == "lantern":
                                            player.has_lantern = True
                                        elif ch.item == "magic":
                                            player.has_magic = True
                                            player.max_magic = 32
                                            player.magic = 32
                                        popup = f"Got {ch.item_name}!"; popup_t = 90
                                        # ALttP-style item hold for key items
                                        if ch.item in ("bow", "bomb", "heart_container", "boomerang", "boots", "flippers", "hookshot", "lantern", "magic"):
                                            player.holding_item = ch.item_name
                                            player.holding_timer = 60
                                        for _ in range(8):
                                            particles.append(Particle(ch.x, ch.y,
                                                random.choice([YELLOW, WHITE, CYAN]), life=20, size=2))
                                        break
                    elif ev.key == pygame.K_1 and "sword" in player.weapons_unlocked:
                        player.weapon = "sword"; SFX["select"].play()
                    elif ev.key == pygame.K_2 and "bow" in player.weapons_unlocked:
                        player.weapon = "bow"; SFX["select"].play()
                    elif ev.key == pygame.K_3 and "bomb" in player.weapons_unlocked:
                        player.weapon = "bomb"; SFX["select"].play()
                    elif ev.key == pygame.K_4 and "boomerang" in player.weapons_unlocked:
                        player.weapon = "boomerang"; SFX["select"].play()
                    elif ev.key == pygame.K_5 and "hookshot" in player.weapons_unlocked:
                        player.weapon = "hookshot"; SFX["select"].play()
                    elif ev.key == pygame.K_TAB:
                        show_mm = not show_mm
                elif state in ("dead", "win"):
                    if ev.key == pygame.K_r:
                        return True
                    if ev.key == pygame.K_q:
                        return False

        keys = pygame.key.get_pressed()
        ticks = pygame.time.get_ticks()

        # --- UPDATE ---
        if hitstop > 0:
            hitstop -= 1
        elif state == "playing" and not dialogue.is_active:
            player.update(keys, cmap)

            # Hookshot wall/enemy detection
            if player.hookshot_active and not player.hookshot_retracting:
                hc = int(player.hookshot_x) // TILE
                hr = int(player.hookshot_y) // TILE
                if 0 <= hr < MAP_ROWS and 0 <= hc < MAP_COLS:
                    htile = cmap[hr][hc]
                    if htile in (W, Q, T, L, K):
                        player.hookshot_retracting = True
                        player.hookshot_hit_wall = True
                        SFX["hit"].play()
                else:
                    player.hookshot_retracting = True
                hook_rect = pygame.Rect(player.hookshot_x - 4, player.hookshot_y - 4, 8, 8)
                if not player.hookshot_retracting:
                    for enemy in enemies:
                        if hook_rect.colliderect(enemy.rect):
                            enemy.flash = 30
                            enemy.stun = 30
                            player.hookshot_retracting = True
                            SFX["hit"].play()
                            dmg_nums.append(DmgNum(enemy.x, enemy.y - 10, "STUN", CYAN))
                            break

            # Dungeon swimming detection (water tile Q=3 with flippers)
            tc_d = int(player.x) // TILE
            tr_d = int(player.y) // TILE
            if 0 <= tr_d < MAP_ROWS and 0 <= tc_d < MAP_COLS:
                was_swimming = player.swimming
                player.swimming = cmap[tr_d][tc_d] == Q and player.has_flippers
                if player.swimming and not was_swimming:
                    SFX["step_water"].play()
                    for _ in range(5):
                        particles.append(Particle(player.x, player.y,
                            random.choice([(100, 160, 255), (140, 200, 255), (255, 255, 255)]),
                            life=15, size=2))
                if player.swimming:
                    player.speed = 1.1
                    player.swim_timer += 1
                    if player.swim_timer >= 10:
                        player.swim_frame = (player.swim_frame + 1) % 2
                        player.swim_timer = 0
                    if random.random() < 0.1:
                        particles.append(Particle(
                            player.x + random.randint(-6, 6),
                            player.y + random.randint(2, 6),
                            random.choice([(100, 160, 255), (140, 200, 255)]),
                            life=10, size=1))
                elif was_swimming:
                    player.speed = 1.8
                    player.swimming = False
                    player.swim_frame = 0
                    player.swim_timer = 0

            # Push blocks
            for block in push_blocks:
                block.update()
                if not block.moving and player.rect.colliderect(block.rect):
                    block.try_push(player.dir, cmap)
                    SFX["door"].play()

            # Floor switches
            for sw in switches:
                sw.check([player], cmap)

            # Grass drops
            for gp in from_grass_pickups:
                kind, gx, gy = gp
                pickups.append(Pickup(gx, gy, kind))
            from_grass_pickups.clear()

            # Sword hits on enemies
            if player.attacking and player.weapon == "sword":
                sr = player.sword_rect()
                for enemy in enemies:
                    if sr.colliderect(enemy.rect) and enemy.flash == 0:
                        enemy.take_damage(1, player.x, player.y); player.dmg_dealt += 1; shake = 4
                        for _ in range(4):
                            particles.append(Particle(enemy.x, enemy.y, YELLOW))
                        dmg_nums.append(DmgNum(enemy.x, enemy.y - 10, "1", YELLOW))

            # Spin attack hits all enemies in radius
            if player.spin_attacking:
                radius = 24
                for enemy in enemies:
                    dx_e = enemy.x - player.x
                    dy_e = enemy.y - player.y
                    if dx_e * dx_e + dy_e * dy_e < radius * radius and enemy.flash == 0:
                        enemy.take_damage(2, player.x, player.y); player.dmg_dealt += 2; shake = 6
                        for _ in range(5):
                            particles.append(Particle(enemy.x, enemy.y, random.choice([YELLOW, WHITE])))
                        dmg_nums.append(DmgNum(enemy.x, enemy.y - 10, "2", YELLOW))

            # Projectiles
            for proj in projectiles[:]:
                proj.update(cmap, particles)
                if not proj.alive:
                    projectiles.remove(proj); continue
                # Boomerang return: catch by player
                if proj.kind == "boomerang" and proj.returning:
                    if proj.rect.colliderect(player.rect):
                        proj.alive = False
                        continue
                if proj.owner == "player":
                    for enemy in enemies:
                        if proj.rect.colliderect(enemy.rect) and enemy.flash == 0:
                            if proj.kind == "boomerang":
                                # Stun, don't damage
                                enemy.flash = 30
                                enemy.stun = 30
                                dmg_nums.append(DmgNum(enemy.x, enemy.y - 10, "STUN", CYAN))
                                SFX["hit"].play()
                                # Don't destroy the boomerang on hit
                            else:
                                d = 2 if proj.kind == "bomb" and proj.exploded else 1
                                enemy.take_damage(d, proj.x, proj.y); player.dmg_dealt += d; shake = 3
                                for _ in range(3):
                                    particles.append(Particle(enemy.x, enemy.y, YELLOW))
                                dmg_nums.append(DmgNum(enemy.x, enemy.y - 10, str(d), YELLOW))
                                if proj.kind == "arrow":
                                    proj.alive = False
                elif proj.owner == "enemy":
                    if proj.rect.colliderect(player.rect):
                        # Shield block check: not attacking and projectile comes from faced direction
                        blocked = False
                        if not player.attacking:
                            pdx = proj.x - player.x
                            pdy = proj.y - player.y
                            if player.dir == "up" and pdy < 0:
                                blocked = True
                            elif player.dir == "down" and pdy > 0:
                                blocked = True
                            elif player.dir == "left" and pdx < 0:
                                blocked = True
                            elif player.dir == "right" and pdx > 0:
                                blocked = True
                        if blocked:
                            # Deflect projectile back at enemy!
                            proj.dx = -proj.dx
                            proj.dy = -proj.dy
                            proj.owner = "player"  # Reflected back!
                            shake = 2
                            SFX["block"].play()
                            for _ in range(4):
                                particles.append(Particle(player.x, player.y,
                                    random.choice([LTBLUE, WHITE, CYAN]), life=10, size=2))
                            dmg_nums.append(DmgNum(player.x, player.y - 10, "BLOCK!", CYAN))
                        else:
                            player.take_damage(1, proj.x, proj.y)
                            if player.invincible == 50:
                                shake = 5
                                for _ in range(3):
                                    particles.append(Particle(player.x, player.y, RED))
                                dmg_nums.append(DmgNum(player.x, player.y - 10, "-1", RED))
                            proj.alive = False

            # Enemies
            for enemy in enemies[:]:
                enemy.update(player, cmap, projectiles)
                # Boss phase effects
                if enemy.kind == "boss":
                    slam_shake = check_boss_slam_damage(enemy, [player], particles, dmg_nums)
                    if slam_shake > 0: shake = max(shake, slam_shake)
                    if enemy.phase == 3:
                        check_boss_fire_trail_damage(enemy, [player])
                    check_boss_clone_damage(enemy, [player])
                if enemy.hp <= 0:
                    if enemy.kind == "boss":
                        hitstop, shake = boss_death_sequence(enemy, particles, hitstop, shake)
                        popup = "THE SHADOW LORD IS DEFEATED!"
                        popup_t = 180
                    elif enemy.kind == "miniboss":
                        shake = 10; hitstop = 8
                        SFX["boss_hit"].play()
                        for _ in range(15):
                            particles.append(Particle(enemy.x, enemy.y,
                                random.choice([RED, ORANGE, YELLOW, WHITE]),
                                life=random.randint(20, 35), size=random.randint(2, 3)))
                        popup = "Mini-Boss defeated!"
                        popup_t = 90
                    else:
                        hitstop = 4  # Brief freeze on kill
                        for _ in range(8):
                            particles.append(Particle(enemy.x, enemy.y,
                                random.choice([RED, ORANGE, YELLOW]), life=20))
                    player.kills += 1
                    r = random.random()
                    if r < 0.3:   pickups.append(Pickup(enemy.x, enemy.y, "rupee"))
                    elif r < 0.4: pickups.append(Pickup(enemy.x, enemy.y, "heart"))
                    elif r < 0.48: pickups.append(Pickup(enemy.x, enemy.y, "arrows"))
                    elif r < 0.52: pickups.append(Pickup(enemy.x, enemy.y, "bombs"))
                    enemies.remove(enemy); continue

                if enemy.kind == "boss" and not enemy.visible:
                    pass  # Boss invisible during jump — no contact damage
                elif enemy.rect.colliderect(player.rect):
                    player.take_damage(enemy.dmg, enemy.x, enemy.y)
                    if player.invincible == 50:
                        shake = 6
                        for _ in range(3):
                            particles.append(Particle(player.x, player.y, RED))
                        dmg_nums.append(DmgNum(player.x, player.y - 10, f"-{enemy.dmg}", RED))

            # Pickups
            for p in pickups:
                if not p.collected and p.rect.colliderect(player.rect):
                    p.collected = True; SFX["pickup"].play()
                    if p.kind == "rupee":
                        player.rupees += 1; dmg_nums.append(DmgNum(p.x, p.y - 6, "+1", YELLOW))
                    elif p.kind == "heart":
                        h = min(2, player.max_hp - player.hp)
                        player.hp = min(player.max_hp, player.hp + 2)
                        if h > 0: dmg_nums.append(DmgNum(p.x, p.y - 6, f"+{h}", PINK))
                    elif p.kind == "arrows":
                        player.arrows += 5; dmg_nums.append(DmgNum(p.x, p.y - 6, "+5", WHITE))
                    elif p.kind == "bombs":
                        player.bombs += 3; dmg_nums.append(DmgNum(p.x, p.y - 6, "+3", WHITE))
                    elif p.kind == "key":
                        player.keys += 1; dmg_nums.append(DmgNum(p.x, p.y - 6, "+KEY", YELLOW))
                        SFX["chest"].play()
                    elif p.kind == "heart_piece":
                        player.heart_pieces = getattr(player, 'heart_pieces', 0) + 1
                        SFX["chest"].play()
                        if player.heart_pieces >= 4:
                            player.heart_pieces -= 4
                            player.max_hp += 2
                            player.hp = player.max_hp
                            popup = "Heart Container complete!"
                            popup_t = 120
                        else:
                            popup = f"Heart Piece! ({player.heart_pieces}/4)"
                            popup_t = 90
                        dmg_nums.append(DmgNum(p.x, p.y - 6, "+HP", PINK))
                    for _ in range(3):
                        particles.append(Particle(p.x, p.y, YELLOW, life=10))

            # Stairs
            c, r = int(player.x) // TILE, int(player.y) // TILE
            if 0 <= r < MAP_ROWS and 0 <= c < MAP_COLS and cmap[r][c] == S:
                if len(enemies) == 0:
                    if lvl < len(MAPS) - 1:
                        SFX["door"].play()
                        await iris_wipe("out", int(player.x), int(player.y) + GAME_Y, 18)
                        lvl += 1
                        cmap, enemies, pickups, npcs, chests, push_blocks, switches, pots = setup_level(lvl)
                        player.x, player.y = 8 * TILE, 2 * TILE
                        player._carried_pot = None
                        projectiles.clear(); from_grass_pickups.clear()
                        msg, msg_t = LEVEL_NAMES[lvl], 90
                        # Redraw new level before opening iris
                        game_surf.fill(BLACK)
                        for ri in range(MAP_ROWS):
                            for ci in range(MAP_COLS):
                                draw_tile(game_surf, cmap[ri][ci], ci, ri, 0)
                        draw_hud(game_surf, player, lvl, enemies)
                        await iris_wipe("in", int(player.x), int(player.y) + GAME_Y, 18)
                    else:
                        SFX["win"].play(); state = "win"
                elif msg_t <= 0:
                    msg, msg_t = f"Defeat {len(enemies)} enemies!", 50

            if lvl == 4 and len(enemies) == 0 and state == "playing":
                SFX["win"].play(); state = "win"

            if player.hp <= 0:
                SFX["die"].play(); state = "dead"; shake = 12

        dialogue.update()
        for p in particles[:]:
            p.update()
            if p.life <= 0: particles.remove(p)
        for d in dmg_nums[:]:
            d.update()
            if d.life <= 0: dmg_nums.remove(d)
        if msg_t > 0: msg_t -= 1
        if popup_t > 0: popup_t -= 1
        if shake > 0: shake -= 1

        # --- DRAW (all to game_surf at native res) ---
        game_surf.fill(BLACK)
        sx = random.randint(-shake, shake) if shake > 0 else 0
        sy = random.randint(-shake, shake) if shake > 0 else 0

        for r in range(MAP_ROWS):
            for c in range(MAP_COLS):
                draw_tile(game_surf, cmap[r][c], c, r, ticks)

        for sw in switches: sw.draw(game_surf)
        for block in push_blocks: block.draw(game_surf)
        for ch in chests: ch.draw(game_surf)
        for p in pickups: p.draw(game_surf)
        for pot in pots: pot.draw(game_surf)
        for npc in npcs: npc.draw(game_surf)

        # Lantern darkness overlay (dungeons only, level 1+)
        if lvl >= 1:
            dark = pygame.Surface((NATIVE_W, NATIVE_H), pygame.SRCALPHA)
            dark.fill((0, 0, 0, 180))
            lantern_r = 48 if getattr(player, 'has_lantern', False) else 24
            pygame.draw.circle(dark, (0, 0, 0, 0), (int(player.x), int(player.y) + GAME_Y), lantern_r)
            for r_t in range(MAP_ROWS):
                for c_t in range(MAP_COLS):
                    if cmap[r_t][c_t] == F:
                        pygame.draw.circle(dark, (0, 0, 0, 0), (c_t * TILE + 8, r_t * TILE + 8 + GAME_Y), 28)
            game_surf.blit(dark, (0, 0))

        # Boss phase 2 darkness overlay (after tiles, before sprites)
        boss_enemy = next((e for e in enemies if e.kind == "boss"), None)
        if boss_enemy and boss_enemy.phase == 2:
            draw_boss_phase2_darkness(game_surf, boss_enemy, [(player.x, player.y)], cmap)

        for e in enemies: e.draw(game_surf)
        for proj in projectiles: proj.draw(game_surf)
        player.draw(game_surf)
        for p in particles: p.draw(game_surf)
        for d in dmg_nums: d.draw(game_surf)

        # Boss phase 3 arena edge glow
        if boss_enemy and boss_enemy.phase == 3:
            draw_boss_arena_edges(game_surf, boss_enemy.phase_timer)

        draw_hud(game_surf, player, lvl, enemies)
        if show_mm: draw_minimap(game_surf, cmap, player, enemies)
        dialogue.draw(game_surf)

        # Popup
        if popup_t > 0:
            ps = font_md.render(popup, True, CYAN)
            pw = ps.get_width() + 8
            pbx = NATIVE_W // 2 - pw // 2
            pygame.draw.rect(game_surf, (8, 8, 24), (pbx, NATIVE_H // 2 - 22, pw, 16))
            pygame.draw.rect(game_surf, CYAN, (pbx, NATIVE_H // 2 - 22, pw, 16), 1)
            game_surf.blit(ps, (pbx + 4, NATIVE_H // 2 - 20))

        # Level message
        if msg_t > 0 and not dialogue.is_active:
            ms = font_md.render(msg, True, (248, 216, 0))
            mw = ms.get_width() + 12
            mbx = NATIVE_W // 2 - mw // 2
            pygame.draw.rect(game_surf, (0, 0, 0), (mbx, NATIVE_H // 2 - 14, mw, 24))
            pygame.draw.rect(game_surf, (184, 152, 48), (mbx, NATIVE_H // 2 - 14, mw, 24), 1)
            game_surf.blit(ms, (mbx + 6, NATIVE_H // 2 - 12))
            if lvl < len(LEVEL_SUBTITLES):
                sub = font_sm.render(LEVEL_SUBTITLES[lvl], True, (180, 180, 200))
                game_surf.blit(sub, (NATIVE_W // 2 - sub.get_width() // 2, NATIVE_H // 2 + 12))

        # Death
        if state == "dead":
            ov = pygame.Surface((NATIVE_W, NATIVE_H), pygame.SRCALPHA)
            ov.fill((0, 0, 0, 140))
            game_surf.blit(ov, (0, 0))
            gt = font_xl.render("GAME OVER", True, RED)
            game_surf.blit(gt, (NATIVE_W//2 - gt.get_width()//2, NATIVE_H//2 - 40))
            stats = [f"Kills: {player.kills}", f"Rupees: {player.rupees}",
                     f"Level: {LEVEL_NAMES[lvl]}"]
            for i, s in enumerate(stats):
                st = font_sm.render(s, True, WHITE)
                game_surf.blit(st, (NATIVE_W//2 - st.get_width()//2, NATIVE_H//2 - 5 + i * 12))
            sub = font_sm.render("R:Restart  Q:Quit", True, GRAY)
            game_surf.blit(sub, (NATIVE_W//2 - sub.get_width()//2, NATIVE_H//2 + 40))

        # Win
        if state == "win":
            ov = pygame.Surface((NATIVE_W, NATIVE_H), pygame.SRCALPHA)
            ov.fill((0, 0, 0, 140))
            game_surf.blit(ov, (0, 0))
            wt = font_xl.render("VICTORY!", True, YELLOW)
            game_surf.blit(wt, (NATIVE_W//2 - wt.get_width()//2, NATIVE_H//2 - 50))
            ts = player.game_time // 60
            stats = [f"Time: {ts//60}m {ts%60}s", f"Kills: {player.kills}",
                     f"Damage: {player.dmg_dealt}", f"Rupees: {player.rupees}",
                     f"Hearts: {player.hp}/{player.max_hp}"]
            sc = player.kills * 10 + player.rupees * 5 + player.hp * 20 - ts
            gr = "S" if sc > 180 else "A" if sc > 130 else "B" if sc > 80 else "C" if sc > 30 else "D"
            for i, s in enumerate(stats):
                st = font_sm.render(s, True, WHITE)
                game_surf.blit(st, (NATIVE_W//2 - st.get_width()//2, NATIVE_H//2 - 20 + i * 11))
            gc = YELLOW if gr in ("S", "A") else WHITE
            grt = font_lg.render(f"Rank: {gr}", True, gc)
            game_surf.blit(grt, (NATIVE_W//2 - grt.get_width()//2, NATIVE_H//2 + 42))
            sub = font_sm.render("R:Restart  Q:Quit", True, GRAY)
            game_surf.blit(sub, (NATIVE_W//2 - sub.get_width()//2, NATIVE_H//2 + 62))

        # === Scale up to screen ===
        scaled = pygame.transform.scale(game_surf, (SCREEN_W, SCREEN_H))
        screen.blit(scaled, (0, 0))
        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)

    return False


# ══════════════════════════════════════════
#  DUNGEON LOOP (called from overworld)
# ══════════════════════════════════════════
async def game_loop_dungeon(lvl, player_ref):
    """Run a single dungeon level, returning True when complete, False on quit."""
    global from_grass_pickups
    cmap, enemies, pickups, npcs, chests, push_blocks, switches, pots = setup_level(lvl)
    # Use existing player stats but reset position
    player = player_ref
    if not hasattr(player, '_carried_pot'):
        player._carried_pot = None
    if not hasattr(player, 'heart_pieces'):
        player.heart_pieces = 0
    if not hasattr(player, 'has_boots'):
        player.has_boots = False
    if not hasattr(player, 'has_flippers'):
        player.has_flippers = False
    if not hasattr(player, 'has_hookshot'):
        player.has_hookshot = False
    if not hasattr(player, 'has_lantern'):
        player.has_lantern = False
    if not hasattr(player, 'has_magic'):
        player.has_magic = False
        player.magic = 0
        player.max_magic = 0
    old_x, old_y = player.x, player.y
    player.x, player.y = 8 * TILE, 2 * TILE
    particles, dmg_nums, projectiles = [], [], []
    dialogue = DialogueBox(font_sm)
    dialogue.text_sound = SFX.get("text")
    shake, hitstop = 0, 0
    state = "playing"
    msg, msg_t = LEVEL_NAMES[lvl], 90
    popup, popup_t = "", 0
    from_grass_pickups = []

    await fade("in", 10)
    if lvl == 4:
        play_music("boss")
    else:
        play_music("dungeon")

    while True:
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                return False
            if ev.type == pygame.KEYDOWN:
                if ev.key == pygame.K_ESCAPE:
                    # Exit dungeon, return to overworld
                    player.x, player.y = old_x, old_y
                    return True
                elif ev.key == pygame.K_F11:
                    toggle_fullscreen()
                elif dialogue.is_active:
                    if ev.key in (pygame.K_e, pygame.K_RETURN, pygame.K_SPACE):
                        dialogue.advance()
                elif state == "playing":
                    ik = player.input_keys
                    if ev.key == ik["attack"]:
                        # If carrying a pot, throw it
                        if player._carried_pot:
                            pot = player._carried_pot
                            pot.throw_pot(player.dir)
                            player._carried_pot = None
                        # Swimming restricts weapons — only boomerang allowed
                        elif player.swimming and player.weapon != "boomerang":
                            pass  # Can't use sword/bow/bomb in water
                        else:
                            player.attack(projectiles, cmap, particles)
                            # Grass cutting with sword
                            if player.weapon == "sword":
                                sr = player.sword_rect()
                                gc = sr.centerx // TILE
                                gr = sr.centery // TILE
                                if 0 <= gr < MAP_ROWS and 0 <= gc < MAP_COLS:
                                    if cmap[gr][gc] == H:  # Tall grass tile
                                        cmap[gr][gc] = G  # Replace with grass
                                        SFX["grass"].play()
                                        if random.random() < 0.25:
                                            drop = "rupee" if random.random() < 0.7 else "heart"
                                            pickups.append(Pickup(gc * TILE + 8, gr * TILE + 8, drop))
                    elif ev.key == ik.get("interact"):
                        # If carrying a pot, throw it
                        if player._carried_pot:
                            pot = player._carried_pot
                            pot.throw_pot(player.dir)
                            player._carried_pot = None
                        else:
                            ir = player.rect.inflate(12, 12)
                            # Try to pick up a nearby pot
                            picked_up = False
                            for pot in pots:
                                if pot.alive and not pot.lifted and ir.colliderect(pot.rect):
                                    pot.lift(player)
                                    player._carried_pot = pot
                                    picked_up = True
                                    break
                            if not picked_up:
                                # Check for locked doors nearby
                                door_opened = False
                                for dr in range(MAP_ROWS):
                                    for dc in range(MAP_COLS):
                                        if cmap[dr][dc] == K:
                                            door_r = pygame.Rect(dc * TILE, dr * TILE, TILE, TILE)
                                            if ir.colliderect(door_r):
                                                if player.keys > 0:
                                                    player.keys -= 1
                                                    cmap[dr][dc] = D
                                                    SFX["door"].play()
                                                    door_opened = True
                                                    popup = "Door unlocked!"; popup_t = 60
                                                    for _ in range(8):
                                                        particles.append(Particle(dc * TILE + 8, dr * TILE + 8,
                                                            random.choice([YELLOW, WHITE]), life=20, size=2))
                                                else:
                                                    popup = "Need a key!"; popup_t = 40
                                                break
                                    if door_opened:
                                        break
                                if not door_opened:
                                    for npc in npcs:
                                        if ir.colliderect(npc.rect):
                                            dialogue.start(npc.name, npc.lines); npc.talked = True; break
                                    for ch in chests:
                                        if not ch.opened and ir.colliderect(ch.rect):
                                            ch.opened = True; SFX["chest"].play()
                                            if ch.item == "bow":
                                                if "bow" not in player.weapons_unlocked:
                                                    player.weapons_unlocked.append("bow")
                                                player.arrows += 15
                                            elif ch.item == "bomb":
                                                if "bomb" not in player.weapons_unlocked:
                                                    player.weapons_unlocked.append("bomb")
                                                player.bombs += 5
                                            elif ch.item == "heart_container":
                                                player.max_hp += 2; player.hp = player.max_hp
                                            elif ch.item == "arrows":
                                                player.arrows += 10
                                            elif ch.item == "bombs":
                                                player.bombs += 5
                                            elif ch.item == "boomerang":
                                                if "boomerang" not in player.weapons_unlocked:
                                                    player.weapons_unlocked.append("boomerang")
                                            elif ch.item == "boots":
                                                player.has_boots = True
                                            elif ch.item == "flippers":
                                                player.has_flippers = True
                                            elif ch.item == "hookshot":
                                                if "hookshot" not in player.weapons_unlocked:
                                                    player.weapons_unlocked.append("hookshot")
                                                player.has_hookshot = True
                                            elif ch.item == "lantern":
                                                player.has_lantern = True
                                            elif ch.item == "magic":
                                                player.has_magic = True
                                                player.max_magic = 32
                                                player.magic = 32
                                            popup = f"Got {ch.item_name}!"; popup_t = 90
                                            # ALttP-style item hold for key items
                                            if ch.item in ("bow", "bomb", "heart_container", "boomerang", "boots", "flippers", "hookshot", "lantern", "magic"):
                                                player.holding_item = ch.item_name
                                                player.holding_timer = 60
                                            for _ in range(8):
                                                particles.append(Particle(ch.x, ch.y,
                                                    random.choice([YELLOW, WHITE, CYAN]), life=20, size=2))
                                            break
                    elif ev.key == ik.get("weapon1") and "sword" in player.weapons_unlocked:
                        player.weapon = "sword"; SFX["select"].play()
                    elif ev.key == ik.get("weapon2") and "bow" in player.weapons_unlocked:
                        player.weapon = "bow"; SFX["select"].play()
                    elif ev.key == ik.get("weapon3") and "bomb" in player.weapons_unlocked:
                        player.weapon = "bomb"; SFX["select"].play()
                    elif ev.key == ik.get("weapon4") and "boomerang" in player.weapons_unlocked:
                        player.weapon = "boomerang"; SFX["select"].play()
                    elif ev.key == ik.get("weapon5") and "hookshot" in player.weapons_unlocked:
                        player.weapon = "hookshot"; SFX["select"].play()
                elif state == "dead":
                    # Death in dungeon: return to overworld, player respawns
                    if ev.key == pygame.K_r:
                        player.hp = player.max_hp
                        player.x, player.y = old_x, old_y
                        return True
                    if ev.key == pygame.K_q:
                        return False

        keys = pygame.key.get_pressed()
        ticks = pygame.time.get_ticks()

        if hitstop > 0:
            hitstop -= 1
        elif state == "playing" and not dialogue.is_active:
            player.update(keys, cmap)

            # Hookshot wall/enemy detection
            if player.hookshot_active and not player.hookshot_retracting:
                hc = int(player.hookshot_x) // TILE
                hr = int(player.hookshot_y) // TILE
                if 0 <= hr < MAP_ROWS and 0 <= hc < MAP_COLS:
                    htile = cmap[hr][hc]
                    if htile in (W, Q, T, L, K):
                        player.hookshot_retracting = True
                        player.hookshot_hit_wall = True
                        SFX["hit"].play()
                else:
                    player.hookshot_retracting = True
                hook_rect = pygame.Rect(player.hookshot_x - 4, player.hookshot_y - 4, 8, 8)
                if not player.hookshot_retracting:
                    for enemy in enemies:
                        if hook_rect.colliderect(enemy.rect):
                            enemy.flash = 30
                            enemy.stun = 30
                            player.hookshot_retracting = True
                            SFX["hit"].play()
                            dmg_nums.append(DmgNum(enemy.x, enemy.y - 10, "STUN", CYAN))
                            break

            # Dungeon swimming detection (water tile Q=3 with flippers)
            tc_d = int(player.x) // TILE
            tr_d = int(player.y) // TILE
            if 0 <= tr_d < MAP_ROWS and 0 <= tc_d < MAP_COLS:
                was_swimming = player.swimming
                player.swimming = cmap[tr_d][tc_d] == Q and player.has_flippers
                if player.swimming and not was_swimming:
                    SFX["step_water"].play()
                    for _ in range(5):
                        particles.append(Particle(player.x, player.y,
                            random.choice([(100, 160, 255), (140, 200, 255), (255, 255, 255)]),
                            life=15, size=2))
                if player.swimming:
                    player.speed = 1.1
                    player.swim_timer += 1
                    if player.swim_timer >= 10:
                        player.swim_frame = (player.swim_frame + 1) % 2
                        player.swim_timer = 0
                    if random.random() < 0.1:
                        particles.append(Particle(
                            player.x + random.randint(-6, 6),
                            player.y + random.randint(2, 6),
                            random.choice([(100, 160, 255), (140, 200, 255)]),
                            life=10, size=1))
                elif was_swimming:
                    player.speed = 1.8
                    player.swimming = False
                    player.swim_frame = 0
                    player.swim_timer = 0

            # Push blocks
            for block in push_blocks:
                block.update()
                if not block.moving and player.rect.colliderect(block.rect):
                    block.try_push(player.dir, cmap)
                    SFX["door"].play()

            # Floor switches
            for sw in switches:
                sw.check([player], cmap)

            # Grass drops
            for gp in from_grass_pickups:
                kind, gx, gy = gp
                pickups.append(Pickup(gx, gy, kind))
            from_grass_pickups.clear()

            # Pots
            for pot in pots:
                pot.update(cmap, particles)
            for pot in pots:
                if pot.thrown and pot.alive:
                    for enemy in enemies:
                        if pot.rect.colliderect(enemy.rect):
                            enemy.take_damage(1, pot.x, pot.y)
                            player.dmg_dealt += 1
                            pot.smash(particles)
                            shake = 3
                            dmg_nums.append(DmgNum(enemy.x, enemy.y - 10, "1", YELLOW))
                            break

            # Sword hits on enemies
            if player.attacking and player.weapon == "sword":
                sr = player.sword_rect()
                for enemy in enemies:
                    if sr.colliderect(enemy.rect) and enemy.flash == 0:
                        enemy.take_damage(1, player.x, player.y); player.dmg_dealt += 1; shake = 4
                        for _ in range(4):
                            particles.append(Particle(enemy.x, enemy.y, YELLOW))
                        dmg_nums.append(DmgNum(enemy.x, enemy.y - 10, "1", YELLOW))

            # Spin attack hits all enemies in radius
            if player.spin_attacking:
                radius = 24
                for enemy in enemies:
                    dx_e = enemy.x - player.x
                    dy_e = enemy.y - player.y
                    if dx_e * dx_e + dy_e * dy_e < radius * radius and enemy.flash == 0:
                        enemy.take_damage(2, player.x, player.y); player.dmg_dealt += 2; shake = 6
                        for _ in range(5):
                            particles.append(Particle(enemy.x, enemy.y, random.choice([YELLOW, WHITE])))
                        dmg_nums.append(DmgNum(enemy.x, enemy.y - 10, "2", YELLOW))

            # Projectiles
            for proj in projectiles[:]:
                proj.update(cmap, particles)
                if not proj.alive:
                    projectiles.remove(proj); continue
                # Boomerang return: catch by player
                if proj.kind == "boomerang" and proj.returning:
                    if proj.rect.colliderect(player.rect):
                        proj.alive = False
                        continue
                if proj.owner == "player":
                    for enemy in enemies:
                        if proj.rect.colliderect(enemy.rect) and enemy.flash == 0:
                            if proj.kind == "boomerang":
                                enemy.flash = 30
                                enemy.stun = 30
                                dmg_nums.append(DmgNum(enemy.x, enemy.y - 10, "STUN", CYAN))
                                SFX["hit"].play()
                            else:
                                d = 2 if proj.kind == "bomb" and proj.exploded else 1
                                enemy.take_damage(d, proj.x, proj.y); player.dmg_dealt += d; shake = 3
                                dmg_nums.append(DmgNum(enemy.x, enemy.y - 10, str(d), YELLOW))
                                if proj.kind == "arrow":
                                    proj.alive = False
                elif proj.owner == "enemy":
                    if proj.rect.colliderect(player.rect):
                        blocked = False
                        if not player.attacking:
                            pdx = proj.x - player.x
                            pdy = proj.y - player.y
                            if player.dir == "up" and pdy < 0: blocked = True
                            elif player.dir == "down" and pdy > 0: blocked = True
                            elif player.dir == "left" and pdx < 0: blocked = True
                            elif player.dir == "right" and pdx > 0: blocked = True
                        if blocked:
                            proj.dx = -proj.dx; proj.dy = -proj.dy
                            proj.owner = "player"; shake = 2; SFX["block"].play()
                            dmg_nums.append(DmgNum(player.x, player.y - 10, "BLOCK!", CYAN))
                        else:
                            player.take_damage(1, proj.x, proj.y)
                            if player.invincible == 50: shake = 5
                            proj.alive = False

            # Enemies
            for enemy in enemies[:]:
                enemy.update(player, cmap, projectiles)
                # Boss phase effects
                if enemy.kind == "boss":
                    slam_shake = check_boss_slam_damage(enemy, [player], particles, dmg_nums)
                    if slam_shake > 0: shake = max(shake, slam_shake)
                    if enemy.phase == 3:
                        check_boss_fire_trail_damage(enemy, [player])
                    check_boss_clone_damage(enemy, [player])
                if enemy.hp <= 0:
                    if enemy.kind == "boss":
                        hitstop, shake = boss_death_sequence(enemy, particles, hitstop, shake)
                        popup = "THE SHADOW LORD IS DEFEATED!"
                        popup_t = 180
                    elif enemy.kind == "miniboss":
                        shake = 10; hitstop = 8
                        SFX["boss_hit"].play()
                        for _ in range(15):
                            particles.append(Particle(enemy.x, enemy.y,
                                random.choice([RED, ORANGE, YELLOW, WHITE]),
                                life=random.randint(20, 35), size=random.randint(2, 3)))
                        popup = "Mini-Boss defeated!"
                        popup_t = 90
                    else:
                        hitstop = 4
                        for _ in range(8):
                            particles.append(Particle(enemy.x, enemy.y,
                                random.choice([RED, ORANGE, YELLOW]), life=20))
                    player.kills += 1
                    r = random.random()
                    if r < 0.3:   pickups.append(Pickup(enemy.x, enemy.y, "rupee"))
                    elif r < 0.4: pickups.append(Pickup(enemy.x, enemy.y, "heart"))
                    elif r < 0.48: pickups.append(Pickup(enemy.x, enemy.y, "arrows"))
                    elif r < 0.52: pickups.append(Pickup(enemy.x, enemy.y, "bombs"))
                    enemies.remove(enemy); continue
                if enemy.kind == "boss" and not enemy.visible:
                    pass  # Boss invisible during jump — no contact damage
                elif enemy.rect.colliderect(player.rect):
                    player.take_damage(enemy.dmg, enemy.x, enemy.y)
                    if player.invincible == 50: shake = 6

            # Pickups
            for p in pickups:
                if not p.collected and p.rect.colliderect(player.rect):
                    p.collected = True; SFX["pickup"].play()
                    if p.kind == "rupee":
                        player.rupees += 1; dmg_nums.append(DmgNum(p.x, p.y - 6, "+1", YELLOW))
                    elif p.kind == "heart":
                        h = min(2, player.max_hp - player.hp)
                        player.hp = min(player.max_hp, player.hp + 2)
                        if h > 0: dmg_nums.append(DmgNum(p.x, p.y - 6, f"+{h}", PINK))
                    elif p.kind == "arrows":
                        player.arrows += 5; dmg_nums.append(DmgNum(p.x, p.y - 6, "+5", WHITE))
                    elif p.kind == "bombs":
                        player.bombs += 3; dmg_nums.append(DmgNum(p.x, p.y - 6, "+3", WHITE))
                    elif p.kind == "key":
                        player.keys += 1; dmg_nums.append(DmgNum(p.x, p.y - 6, "+KEY", YELLOW))
                        SFX["chest"].play()
                    elif p.kind == "heart_piece":
                        player.heart_pieces = getattr(player, 'heart_pieces', 0) + 1
                        SFX["chest"].play()
                        if player.heart_pieces >= 4:
                            player.heart_pieces -= 4
                            player.max_hp += 2
                            player.hp = player.max_hp
                            popup = "Heart Container complete!"
                            popup_t = 120
                        else:
                            popup = f"Heart Piece! ({player.heart_pieces}/4)"
                            popup_t = 90
                        dmg_nums.append(DmgNum(p.x, p.y - 6, "+HP", PINK))

            # Stairs = dungeon complete, return to overworld
            c, r = int(player.x) // TILE, int(player.y) // TILE
            if 0 <= r < MAP_ROWS and 0 <= c < MAP_COLS and cmap[r][c] == S:
                if len(enemies) == 0:
                    SFX["win"].play()
                    player.x, player.y = old_x, old_y
                    return "completed"

            if player.hp <= 0:
                SFX["die"].play(); state = "dead"; shake = 12

        dialogue.update()
        for p in particles[:]:
            p.update()
            if p.life <= 0: particles.remove(p)
        for d in dmg_nums[:]:
            d.update()
            if d.life <= 0: dmg_nums.remove(d)
        if msg_t > 0: msg_t -= 1
        if popup_t > 0: popup_t -= 1
        if shake > 0: shake -= 1

        # --- DRAW ---
        game_surf.fill(BLACK)
        sx = random.randint(-shake, shake) if shake > 0 else 0
        sy = random.randint(-shake, shake) if shake > 0 else 0

        for ri in range(MAP_ROWS):
            for ci in range(MAP_COLS):
                draw_tile(game_surf, cmap[ri][ci], ci, ri, ticks)

        for sw in switches: sw.draw(game_surf)
        for block in push_blocks: block.draw(game_surf)
        for ch in chests: ch.draw(game_surf)
        for p in pickups:
            if not p.collected: p.draw(game_surf)
        for pot in pots: pot.draw(game_surf)
        for npc in npcs: npc.draw(game_surf)

        # Lantern darkness overlay (dungeons, level 1+)
        if lvl >= 1:
            dark = pygame.Surface((NATIVE_W, NATIVE_H), pygame.SRCALPHA)
            dark.fill((0, 0, 0, 180))
            lantern_r = 48 if getattr(player, 'has_lantern', False) else 24
            pygame.draw.circle(dark, (0, 0, 0, 0), (int(player.x), int(player.y) + GAME_Y), lantern_r)
            for r_t in range(MAP_ROWS):
                for c_t in range(MAP_COLS):
                    if cmap[r_t][c_t] == F:
                        pygame.draw.circle(dark, (0, 0, 0, 0), (c_t * TILE + 8, r_t * TILE + 8 + GAME_Y), 28)
            game_surf.blit(dark, (0, 0))

        # Boss phase 2 darkness overlay
        boss_enemy = next((e for e in enemies if e.kind == "boss"), None)
        if boss_enemy and boss_enemy.phase == 2:
            draw_boss_phase2_darkness(game_surf, boss_enemy, [(player.x, player.y)], cmap)

        for e in enemies: e.draw(game_surf)
        for proj in projectiles: proj.draw(game_surf)
        player.draw(game_surf)
        for p in particles: p.draw(game_surf)
        for d in dmg_nums: d.draw(game_surf)

        # Boss phase 3 arena edge glow
        if boss_enemy and boss_enemy.phase == 3:
            draw_boss_arena_edges(game_surf, boss_enemy.phase_timer)

        draw_hud(game_surf, player, lvl, enemies)
        dialogue.draw(game_surf)

        # Popup
        if popup_t > 0:
            ps = font_md.render(popup, True, CYAN)
            pw = ps.get_width() + 8
            pbx = NATIVE_W // 2 - pw // 2
            pygame.draw.rect(game_surf, (8, 8, 24), (pbx, NATIVE_H // 2 - 22, pw, 16))
            pygame.draw.rect(game_surf, CYAN, (pbx, NATIVE_H // 2 - 22, pw, 16), 1)
            game_surf.blit(ps, (pbx + 4, NATIVE_H // 2 - 20))

        # Level message
        if msg_t > 0 and not dialogue.is_active:
            ms = font_md.render(msg, True, (248, 216, 0))
            mw = ms.get_width() + 12
            mbx = NATIVE_W // 2 - mw // 2
            pygame.draw.rect(game_surf, (0, 0, 0), (mbx, NATIVE_H // 2 - 14, mw, 24))
            pygame.draw.rect(game_surf, (184, 152, 48), (mbx, NATIVE_H // 2 - 14, mw, 24), 1)
            game_surf.blit(ms, (mbx + 6, NATIVE_H // 2 - 12))
            if lvl < len(LEVEL_SUBTITLES):
                sub = font_sm.render(LEVEL_SUBTITLES[lvl], True, (180, 180, 200))
                game_surf.blit(sub, (NATIVE_W // 2 - sub.get_width() // 2, NATIVE_H // 2 + 12))

        # Death
        if state == "dead":
            ov = pygame.Surface((NATIVE_W, NATIVE_H), pygame.SRCALPHA)
            ov.fill((0, 0, 0, 140))
            game_surf.blit(ov, (0, 0))
            gt = font_xl.render("GAME OVER", True, RED)
            game_surf.blit(gt, (NATIVE_W // 2 - gt.get_width() // 2, NATIVE_H // 2 - 40))
            sub = font_sm.render("R:Restart  Q:Quit", True, GRAY)
            game_surf.blit(sub, (NATIVE_W // 2 - sub.get_width() // 2, NATIVE_H // 2 + 40))

        # === Scale up to screen ===
        scaled = pygame.transform.scale(game_surf, (SCREEN_W, SCREEN_H))
        screen.blit(scaled, (0, 0))
        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)

    return False


# ══════════════════════════════════════════
#  OVERWORLD LOOP
# ══════════════════════════════════════════
async def overworld_loop(current_save_slot=None):
    """Main game loop for the overworld mode."""
    global from_grass_pickups
    from overworld_engine import ScreenManager
    from overworld_maps import OVERWORLD, START_SCREEN, START_X, START_Y, DUNGEON_ENTRIES
    from overworld_tiles import TILE_PROPS, is_walkable, OW_GRASS, OW_TALL_GRASS, OW_BUSH, OW_CLIFF_TOP, OW_WATER, OW_DEEP_WATER

    RESPAWN_FRAMES = 180  # 3 seconds at 60 FPS

    mgr = ScreenManager(OVERWORLD)
    mgr.enter_screen(START_SCREEN)

    # Start with only P1 active — others join by pressing their attack key
    players = []
    p1 = Player(START_X, START_Y, keys=PLAYER_KEYS[1], tint=PLAYER_TINTS[1], player_num=1)
    players.append(p1)

    # Track which player numbers have joined
    joined_players = {1}  # P1 always joined

    # Join keys — pressing attack key spawns new player
    JOIN_KEYS = {
        PLAYER_KEYS[2]["attack"]: 2,
        PLAYER_KEYS[3]["attack"]: 3,
        PLAYER_KEYS[4]["attack"]: 4,
    }

    completed_dungeons = set()

    # Load saved progress if resuming from a save slot
    if isinstance(current_save_slot, int):
        save_data = load_game(current_save_slot)
        if save_data:
            players[0].hp = save_data.get("player_hp", players[0].hp)
            players[0].max_hp = save_data.get("player_max_hp", players[0].max_hp)
            players[0].rupees = save_data.get("rupees", 0)
            players[0].arrows = save_data.get("arrows", 15)
            players[0].bombs = save_data.get("bombs", 5)
            players[0].keys = save_data.get("keys", 0)
            players[0].weapons_unlocked = save_data.get("weapons_unlocked", ["sword"])
            players[0].has_boots = save_data.get("has_boots", False)
            players[0].has_flippers = save_data.get("has_flippers", False)
            players[0].heart_pieces = save_data.get("heart_pieces", 0)
            players[0].has_hookshot = save_data.get("has_hookshot", False)
            players[0].has_lantern = save_data.get("has_lantern", False)
            players[0].has_magic = save_data.get("has_magic", False)
            players[0].magic = save_data.get("magic", 0)
            players[0].max_magic = save_data.get("max_magic", 0)
            completed_dungeons = set(save_data.get("completed_dungeons", []))
            saved_screen = save_data.get("current_screen")
            if saved_screen:
                mgr.enter_screen(tuple(saved_screen) if isinstance(saved_screen, list) else saved_screen)
                players[0].x = save_data.get("player_x", START_X)
                players[0].y = save_data.get("player_y", START_Y)

    particles, dmg_nums, projectiles = [], [], []
    dialogue = DialogueBox(font_sm)
    dialogue.text_sound = SFX.get("text")
    shake, hitstop = 0, 0
    state = "playing"
    paused_player = None
    msg, msg_t = OVERWORLD[START_SCREEN]["name"], 90
    show_mm = True
    popup, popup_t = "", 0
    from_grass_pickups = []

    # Spawn enemies for current screen
    enemies = []
    pickups, npcs, chests = [], [], []
    signs = []
    fairy_pos = None
    def get_area_music(screen_name):
        name = screen_name.lower()
        if "kakariko" in name or "house" in name:
            return "kakariko"
        elif "death" in name or "mountain" in name:
            return "mountain"
        else:
            return "overworld"

    def spawn_screen_entities():
        nonlocal enemies, pickups, npcs, chests, signs, fairy_pos
        enemies = []
        pickups = []
        npcs = []
        sd = OVERWORLD.get(mgr.current, {})
        for etype, tc, tr in sd.get("enemies", []):
            # Tile-local coords — same space as player (GAME_Y added at draw time)
            enemies.append(Enemy(tc * TILE, tr * TILE, etype))
        for npc_data in sd.get("npcs", []):
            name, tc, tr, lines, color = npc_data
            npcs.append(NPC(tc * TILE, tr * TILE, name, lines, color))
        # Spawn items (e.g. heart_piece) from map data
        for item_data in sd.get("items", []):
            kind = item_data[0]
            ix, iy = item_data[1] * TILE, item_data[2] * TILE
            pickups.append(Pickup(ix, iy, kind))
        signs = sd.get("signs", [])
        fairy_pos = sd.get("fairy")

    spawn_screen_entities()
    play_music(get_area_music(OVERWORLD[START_SCREEN].get("name", "")))
    await fade("in", 10)

    # Overworld collision map helper
    def ow_cmap():
        """Build a collision-compatible map for the current screen."""
        sd = OVERWORLD.get(mgr.current, {})
        return sd.get("tiles", [[OW_GRASS] * MAP_COLS for _ in range(MAP_ROWS)])

    # Override player wall check for overworld tiles
    original_wall = Player._wall
    def overworld_wall(self, rect, cmap_arg):
        for cx, cy in [(rect.left, rect.top), (rect.right - 1, rect.top),
                       (rect.left, rect.bottom - 1), (rect.right - 1, rect.bottom - 1)]:
            c = int(cx) // TILE
            r = int(cy) // TILE  # tile-local Y, no GAME_Y subtraction
            if 0 <= r < MAP_ROWS and 0 <= c < MAP_COLS:
                tile = mgr.get_tile(mgr.current, c, r)
                # Water tiles are passable with Zora's Flippers
                if tile in (OW_WATER, OW_DEEP_WATER) and self.has_flippers:
                    continue
                if not is_walkable(tile, self.dir):
                    return True
            else:
                # Allow walking slightly past edges for transition detection
                # But block going way off screen
                if cx < -8 or cx > NATIVE_W + 8 or cy < -8 or cy > MAP_ROWS * TILE + 8:
                    return True
        return False
    Player._wall = overworld_wall

    # Disable player position clamping in overworld (so edge transitions work)
    # The original Player.update() has tight clamping at the end (lines ~1093-1094).
    # We override update to call original, then UNDO the tight clamp with wider bounds.
    original_update = Player.update
    def overworld_update(self, keys_pressed, cmap):
        # Temporarily store position before original update's clamp
        original_update(self, keys_pressed, cmap)
        # Override the tight clamp with wider bounds for overworld edge transitions
        hw, hh = self.w // 2, self.h // 2
        # Allow going slightly past screen edges so edge detection can trigger
        self.x = max(-8, min(NATIVE_W + 8, self.x))
        self.y = max(-8, min(MAP_ROWS * TILE + 8, self.y))
    Player.update = overworld_update

    def _restore_patches():
        Player._wall = original_wall
        Player.update = original_update

    def _apply_patches():
        Player._wall = overworld_wall
        Player.update = overworld_update

    # Helper: get alive players
    def alive_players():
        return [p for p in players if not p.dead]

    # Helper: find closest alive player to a position
    def closest_player(x, y):
        alive = alive_players()
        if not alive:
            return players[0]  # Fallback
        best = alive[0]
        best_d = (best.x - x) ** 2 + (best.y - y) ** 2
        for p in alive[1:]:
            d = (p.x - x) ** 2 + (p.y - y) ** 2
            if d < best_d:
                best, best_d = p, d
        return best

    while True:
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                _restore_patches()
                stop_music()
                return False
            if ev.type == pygame.KEYDOWN:
                if ev.key == pygame.K_F11:
                    toggle_fullscreen()
                elif dialogue.is_active:
                    if ev.key in (pygame.K_e, pygame.K_RETURN, pygame.K_SPACE):
                        dialogue.advance()
                elif state == "paused":
                    if ev.key == pygame.K_ESCAPE:
                        state = "playing"
                    # Allow weapon switching while paused
                    for pl in players:
                        ik = pl.input_keys
                        if ev.key == ik.get("weapon1") and "sword" in pl.weapons_unlocked:
                            pl.weapon = "sword"; SFX["select"].play()
                        elif ev.key == ik.get("weapon2") and "bow" in pl.weapons_unlocked:
                            pl.weapon = "bow"; SFX["select"].play()
                        elif ev.key == ik.get("weapon3") and "bomb" in pl.weapons_unlocked:
                            pl.weapon = "bomb"; SFX["select"].play()
                        elif ev.key == ik.get("weapon4") and "boomerang" in pl.weapons_unlocked:
                            pl.weapon = "boomerang"; SFX["select"].play()
                        elif ev.key == ik.get("weapon5") and "hookshot" in pl.weapons_unlocked:
                            pl.weapon = "hookshot"; SFX["select"].play()
                elif state == "playing" and not mgr.in_transition:
                    if ev.key == pygame.K_ESCAPE:
                        state = "paused"
                        paused_player = players[0]
                    # Check for new player joining
                    elif ev.key in JOIN_KEYS and JOIN_KEYS[ev.key] not in joined_players:
                        pn = JOIN_KEYS[ev.key]
                        joined_players.add(pn)
                        ref = alive_players()[0] if alive_players() else players[0]
                        new_x = max(16, min(NATIVE_W - 16, ref.x + random.randint(-20, 20)))
                        new_y = max(16, min(MAP_ROWS * TILE - 16, ref.y + random.randint(-10, 10)))
                        new_p = Player(new_x, new_y,
                                       keys=PLAYER_KEYS[pn], tint=PLAYER_TINTS[pn], player_num=pn)
                        players.append(new_p)
                        SFX["pickup"].play()
                        popup = f"P{pn} Joined!"
                        popup_t = 90

                    # Check each player's attack/interact/weapon keys
                    for pl in alive_players():
                        ik = pl.input_keys
                        if ev.key == ik["attack"]:
                            # Swimming restricts weapons — only boomerang allowed
                            if pl.swimming and pl.weapon != "boomerang":
                                pass  # Can't use sword/bow/bomb in water
                            else:
                                pl.attack(projectiles, ow_cmap(), particles)
                                if pl.weapon == "sword":
                                    sr = pl.sword_rect()
                                    gc = sr.centerx // TILE
                                    gr = sr.centery // TILE
                                    if 0 <= gr < MAP_ROWS and 0 <= gc < MAP_COLS:
                                        tile = mgr.get_tile(mgr.current, gc, gr)
                                        if TILE_PROPS.get(tile, {}).get("cuttable"):
                                            mgr.cut_tile(mgr.current, gc, gr)
                                            SFX["grass"].play()
                                            if random.random() < 0.25:
                                                drop = "rupee" if random.random() < 0.7 else "heart"
                                                pickups.append(Pickup(gc * TILE + 8, gr * TILE + 8, drop))
                        elif ev.key == ik.get("interact"):
                            # Check signs first
                            ir = pygame.Rect(pl.x - 10, pl.y - 10, 20, 20)
                            sign_read = False
                            for sx, sy, text in signs:
                                sign_rect = pygame.Rect(sx * TILE, sy * TILE, TILE, TILE)
                                if ir.colliderect(sign_rect):
                                    dialogue.start("Sign", [text])
                                    sign_read = True
                                    break
                            # Check NPC interaction
                            npc_talked = False
                            if not sign_read:
                                for npc in npcs:
                                    if ir.colliderect(npc.rect):
                                        dialogue.start(npc.name, npc.lines)
                                        npc.talked = True
                                        npc_talked = True
                                        break
                            if not sign_read and not npc_talked:
                                pc = int(pl.x) // TILE
                                pr = int(pl.y) // TILE
                                if 0 <= pr < MAP_ROWS and 0 <= pc < MAP_COLS:
                                    tile = mgr.get_tile(mgr.current, pc, pr)
                                    if TILE_PROPS.get(tile, {}).get("entrance"):
                                        dungeon_lvl = DUNGEON_ENTRIES.get(mgr.current)
                                        if dungeon_lvl is not None and dungeon_lvl not in completed_dungeons:
                                            _restore_patches()
                                            stop_music()
                                            SFX["door"].play()
                                            await iris_wipe("out", int(pl.x), int(pl.y) + GAME_Y, 18)
                                            result = await game_loop_dungeon(dungeon_lvl, pl)
                                            _apply_patches()
                                            if result == False:
                                                _restore_patches()
                                                stop_music()
                                                return False
                                            if result == "completed":
                                                completed_dungeons.add(dungeon_lvl)
                                                # Auto-save progress
                                                if current_save_slot:
                                                    save_game(current_save_slot, {
                                                        "player_hp": players[0].hp,
                                                        "player_max_hp": players[0].max_hp,
                                                        "rupees": players[0].rupees,
                                                        "arrows": players[0].arrows,
                                                        "bombs": players[0].bombs,
                                                        "keys": players[0].keys,
                                                        "weapons_unlocked": players[0].weapons_unlocked[:],
                                                        "completed_dungeons": list(completed_dungeons),
                                                        "current_screen": list(mgr.current),
                                                        "player_x": int(players[0].x),
                                                        "player_y": int(players[0].y),
                                                        "play_time_seconds": players[0].game_time // 60,
                                                        "player_kills": sum(p.kills for p in players),
                                                        "game_mode": "overworld",
                                                        "has_boots": players[0].has_boots,
                                                        "has_flippers": players[0].has_flippers,
                                                        "heart_pieces": players[0].heart_pieces,
                                                        "has_hookshot": players[0].has_hookshot,
                                                        "has_lantern": players[0].has_lantern,
                                                        "has_magic": players[0].has_magic,
                                                        "magic": players[0].magic,
                                                        "max_magic": players[0].max_magic,
                                                    })
                                                popup = f"Crystal {len(completed_dungeons)}/5 obtained!"
                                                popup_t = 120
                                                if len(completed_dungeons) >= 5:
                                                    SFX["win"].play()
                                                    state = "win"
                                            await iris_wipe("in", int(pl.x), int(pl.y) + GAME_Y, 18)
                                            play_music(get_area_music(OVERWORLD[mgr.current].get("name", "")))
                        elif ev.key == ik.get("weapon1") and "sword" in pl.weapons_unlocked:
                            pl.weapon = "sword"; SFX["select"].play()
                        elif ev.key == ik.get("weapon2") and "bow" in pl.weapons_unlocked:
                            pl.weapon = "bow"; SFX["select"].play()
                        elif ev.key == ik.get("weapon3") and "bomb" in pl.weapons_unlocked:
                            pl.weapon = "bomb"; SFX["select"].play()
                        elif ev.key == ik.get("weapon4") and "boomerang" in pl.weapons_unlocked:
                            pl.weapon = "boomerang"; SFX["select"].play()
                        elif ev.key == ik.get("weapon5") and "hookshot" in pl.weapons_unlocked:
                            pl.weapon = "hookshot"; SFX["select"].play()
                    if ev.key == pygame.K_TAB:
                        show_mm = not show_mm
                elif state == "dead":
                    if ev.key == pygame.K_r:
                        _restore_patches()
                        stop_music()
                        return True
                    if ev.key == pygame.K_q:
                        _restore_patches()
                        stop_music()
                        return False
                elif state == "win":
                    if ev.key == pygame.K_r:
                        _restore_patches()
                        stop_music()
                        return True
                    if ev.key == pygame.K_q:
                        _restore_patches()
                        stop_music()
                        return False

        keys = pygame.key.get_pressed()
        ticks = pygame.time.get_ticks()

        # ── UPDATE ──
        if hitstop > 0:
            hitstop -= 1
        elif state == "playing" and not dialogue.is_active:
            if mgr.in_transition:
                last_dir = mgr.transition["direction"]
                completed = mgr.update_transition()
                if completed:
                    new_x, new_y = mgr.get_player_entry_pos(last_dir)
                    for pl in players:
                        if new_x is not None:
                            pl.x = new_x
                        if new_y is not None:
                            pl.y = new_y
                    spawn_screen_entities()
                    msg = OVERWORLD[mgr.current].get("name", "")
                    msg_t = 60
                    play_music(get_area_music(msg))
            else:
                # Update all players (alive ones move, dead ones count respawn)
                for pl in players:
                    if pl.dead:
                        pl.respawn_timer -= 1
                        if pl.respawn_timer <= 0:
                            alive = alive_players()
                            if alive:
                                pl.x = max(16, min(NATIVE_W - 16, alive[0].x + random.randint(-20, 20)))
                                pl.y = max(16, min(MAP_ROWS * TILE - 16, alive[0].y + random.randint(-10, 10)))
                            else:
                                pl.x, pl.y = NATIVE_W // 2, MAP_ROWS * TILE // 2
                            pl.hp = pl.max_hp
                            pl.dead = False
                            pl.invincible = 90
                        continue
                    pl.update(keys, ow_cmap())

                    # Hookshot wall/enemy detection (overworld)
                    if pl.hookshot_active and not pl.hookshot_retracting:
                        hc = int(pl.hookshot_x) // TILE
                        hr = int(pl.hookshot_y) // TILE
                        if 0 <= hr < MAP_ROWS and 0 <= hc < MAP_COLS:
                            htile = mgr.get_tile(mgr.current, hc, hr)
                            if not is_walkable(htile):
                                pl.hookshot_retracting = True
                                pl.hookshot_hit_wall = True
                                SFX["hit"].play()
                        else:
                            pl.hookshot_retracting = True
                        hook_rect = pygame.Rect(pl.hookshot_x - 4, pl.hookshot_y - 4, 8, 8)
                        if not pl.hookshot_retracting:
                            for enemy in enemies:
                                if hook_rect.colliderect(enemy.rect):
                                    enemy.flash = 30
                                    enemy.stun = 30
                                    pl.hookshot_retracting = True
                                    SFX["hit"].play()
                                    dmg_nums.append(DmgNum(enemy.x, enemy.y - 10, "STUN", CYAN))
                                    break

                    # Footstep sounds based on current tile
                    if getattr(pl, '_wants_step', False) and not mgr.in_transition:
                        pl._wants_step = False
                        from overworld_tiles import OW_WATER, OW_PATH, OW_SAND, OW_SWAMP
                        tc = int(pl.x) // TILE
                        tr_s = int(pl.y) // TILE
                        if 0 <= tr_s < MAP_ROWS and 0 <= tc < MAP_COLS:
                            step_tile = mgr.get_tile(mgr.current, tc, tr_s)
                            if step_tile == OW_PATH:
                                SFX["step_stone"].play()
                            elif step_tile == OW_SAND:
                                SFX["step_sand"].play()
                            elif step_tile in (OW_WATER, OW_SWAMP):
                                SFX["step_water"].play()
                            else:
                                SFX["step_grass"].play()

                    # Ledge hop: detect walking off a cliff-top tile downward
                    if pl.ledge_hop <= 0:
                        tc = int(pl.x) // TILE
                        tr = int(pl.y) // TILE
                        if 0 <= tr < MAP_ROWS and 0 <= tc < MAP_COLS:
                            tile = mgr.get_tile(mgr.current, tc, tr)
                            if tile == OW_CLIFF_TOP and pl.dir == "down":
                                pl.ledge_hop = 16
                                pl.ledge_hop_vy = -3.0
                                SFX["door"].play()
                    else:
                        # Apply hop physics (overrides normal movement this frame)
                        pl.ledge_hop -= 1
                        pl.ledge_hop_vy += 0.5  # Gravity
                        pl.y += pl.ledge_hop_vy
                        pl.y += 1.5  # Forward downward movement

                # Grass rustle particles when walking through tall grass
                for pl in alive_players():
                    if pl.walk_frame != 0:
                        tc = int(pl.x) // TILE
                        tr = int(pl.y) // TILE
                        if 0 <= tr < MAP_ROWS and 0 <= tc < MAP_COLS:
                            from overworld_tiles import OW_TALL_GRASS as _OW_TG
                            if mgr.get_tile(mgr.current, tc, tr) == _OW_TG and random.random() < 0.15:
                                particles.append(Particle(
                                    pl.x + random.randint(-4, 4),
                                    pl.y + random.randint(0, 4),
                                    random.choice([(72, 184, 72), (88, 200, 88), (56, 152, 56)]),
                                    life=12, size=1))

                # Swimming state detection
                for pl in alive_players():
                    tc = int(pl.x) // TILE
                    tr = int(pl.y) // TILE
                    if 0 <= tr < MAP_ROWS and 0 <= tc < MAP_COLS:
                        tile = mgr.get_tile(mgr.current, tc, tr)
                        was_swimming = pl.swimming
                        pl.swimming = tile in (OW_WATER, OW_DEEP_WATER) and pl.has_flippers
                        if pl.swimming and not was_swimming:
                            # Just entered water — splash!
                            SFX["step_water"].play()
                            for _ in range(5):
                                particles.append(Particle(pl.x, pl.y,
                                    random.choice([(100, 160, 255), (140, 200, 255), (255, 255, 255)]),
                                    life=15, size=2))
                        if pl.swimming:
                            pl.speed = 1.1  # Slower in water (~60% of normal 1.8)
                            pl.swim_timer += 1
                            if pl.swim_timer >= 10:
                                pl.swim_frame = (pl.swim_frame + 1) % 2
                                pl.swim_timer = 0
                            # Occasional water splash particles
                            if random.random() < 0.1:
                                particles.append(Particle(
                                    pl.x + random.randint(-6, 6),
                                    pl.y + random.randint(2, 6),
                                    random.choice([(100, 160, 255), (140, 200, 255)]),
                                    life=10, size=1))
                        elif was_swimming:
                            # Left the water — restore normal speed
                            pl.speed = 1.8
                            pl.swimming = False
                            pl.swim_frame = 0
                            pl.swim_timer = 0
                    else:
                        if pl.swimming:
                            pl.speed = 1.8
                            pl.swimming = False

                # Check screen edge transitions — ANY alive player at edge triggers
                edge = None
                for pl in alive_players():
                    edge = mgr.check_edge(pl.x, pl.y, pl.w, pl.h)
                    if edge:
                        break
                if edge:
                    started = mgr.start_transition(edge)
                    if started:
                        SFX["door"].play()  # Whoosh sound for screen change
                    if not started:
                        for pl in alive_players():
                            hw = pl.w // 2
                            pl.x = max(hw + 1, min(NATIVE_W - hw - 1, pl.x))
                            pl.y = max(1, min(MAP_ROWS * TILE - pl.h - 1, pl.y))

                # Sword hits on enemies — check ALL alive players
                for pl in alive_players():
                    if pl.attacking and pl.weapon == "sword":
                        sr = pl.sword_rect()
                        for enemy in enemies:
                            if sr.colliderect(enemy.rect) and enemy.flash == 0:
                                enemy.take_damage(1, pl.x, pl.y)
                                pl.dmg_dealt += 1; shake = 4
                                for _ in range(4):
                                    particles.append(Particle(enemy.x, enemy.y, YELLOW))
                                dmg_nums.append(DmgNum(enemy.x, enemy.y - 10, "1", YELLOW))

                # Spin attack hits — check ALL alive players
                for pl in alive_players():
                    if pl.spin_attacking:
                        radius = 24
                        for enemy in enemies:
                            dx_e = enemy.x - pl.x
                            dy_e = enemy.y - pl.y
                            if dx_e * dx_e + dy_e * dy_e < radius * radius and enemy.flash == 0:
                                enemy.take_damage(2, pl.x, pl.y)
                                pl.dmg_dealt += 2; shake = 6
                                for _ in range(5):
                                    particles.append(Particle(enemy.x, enemy.y, random.choice([YELLOW, WHITE])))
                                dmg_nums.append(DmgNum(enemy.x, enemy.y - 10, "2", YELLOW))

                # Projectile updates
                for proj in projectiles[:]:
                    proj.update(ow_cmap(), particles)
                    if not proj.alive:
                        projectiles.remove(proj); continue
                    # Boomerang: don't collide with walls, but do collide with non-walkable tiles if not boomerang
                    pc = int(proj.x) // TILE
                    pr = int(proj.y) // TILE
                    if proj.kind != "boomerang":
                        if 0 <= pr < MAP_ROWS and 0 <= pc < MAP_COLS:
                            tile = mgr.get_tile(mgr.current, pc, pr)
                            if not is_walkable(tile):
                                proj.alive = False
                                continue
                    # Boomerang return: catch by any alive player
                    if proj.kind == "boomerang" and proj.returning:
                        for pl in alive_players():
                            if proj.rect.colliderect(pl.rect):
                                proj.alive = False
                                break
                        if not proj.alive:
                            continue
                    if proj.owner == "player":
                        for enemy in enemies:
                            if proj.rect.colliderect(enemy.rect) and enemy.flash == 0:
                                if proj.kind == "boomerang":
                                    enemy.flash = 30
                                    enemy.stun = 30
                                    dmg_nums.append(DmgNum(enemy.x, enemy.y - 10, "STUN", CYAN))
                                    SFX["hit"].play()
                                else:
                                    d = 2 if proj.kind == "bomb" and proj.exploded else 1
                                    enemy.take_damage(d, proj.x, proj.y)
                                    cp = closest_player(proj.x, proj.y)
                                    cp.dmg_dealt += d; shake = 3
                                    dmg_nums.append(DmgNum(enemy.x, enemy.y - 10, str(d), YELLOW))
                                    if proj.kind == "arrow":
                                        proj.alive = False

                # Enemy updates — chase closest alive player
                for enemy in enemies[:]:
                    target = closest_player(enemy.x, enemy.y)
                    enemy.update(target, ow_cmap(), projectiles)
                    if enemy.hp <= 0:
                        hitstop = 4
                        for _ in range(8):
                            particles.append(Particle(enemy.x, enemy.y,
                                random.choice([RED, ORANGE, YELLOW]), life=20))
                        closest_player(enemy.x, enemy.y).kills += 1
                        r = random.random()
                        if r < 0.3:   pickups.append(Pickup(enemy.x, enemy.y, "rupee"))
                        elif r < 0.4: pickups.append(Pickup(enemy.x, enemy.y, "heart"))
                        elif r < 0.48: pickups.append(Pickup(enemy.x, enemy.y, "arrows"))
                        elif r < 0.52: pickups.append(Pickup(enemy.x, enemy.y, "bombs"))
                        enemies.remove(enemy)
                        continue
                    # Collision with ALL alive players
                    for pl in alive_players():
                        if enemy.rect.colliderect(pl.rect):
                            pl.take_damage(enemy.dmg, enemy.x, enemy.y)
                            if pl.invincible == 50:
                                shake = 6

                # Pickup collection — any alive player can collect
                for p in pickups:
                    if p.collected:
                        continue
                    for pl in alive_players():
                        if p.rect.colliderect(pl.rect):
                            p.collected = True; SFX["pickup"].play()
                            if p.kind == "rupee":
                                pl.rupees += 1
                            elif p.kind == "heart":
                                pl.hp = min(pl.max_hp, pl.hp + 2)
                            elif p.kind == "arrows":
                                pl.arrows += 5
                            elif p.kind == "bombs":
                                pl.bombs += 3
                            elif p.kind == "heart_piece":
                                pl.heart_pieces = getattr(pl, 'heart_pieces', 0) + 1
                                SFX["chest"].play()
                                if pl.heart_pieces >= 4:
                                    pl.heart_pieces -= 4
                                    pl.max_hp += 2
                                    pl.hp = pl.max_hp
                                    popup = "Heart Container complete!"
                                    popup_t = 120
                                else:
                                    popup = f"Heart Piece! ({pl.heart_pieces}/4)"
                                    popup_t = 90
                                dmg_nums.append(DmgNum(p.x, p.y - 6, "+HP", PINK))
                            break

                # Fairy fountain — heal all players on contact
                if fairy_pos:
                    fx, fy = fairy_pos[0] * TILE + 8, fairy_pos[1] * TILE + 8
                    for pl in alive_players():
                        if abs(pl.x - fx) < 12 and abs(pl.y - fy) < 12:
                            healed = False
                            for p2 in players:
                                if p2.hp < p2.max_hp:
                                    p2.hp = p2.max_hp
                                    healed = True
                                if p2.dead:
                                    p2.dead = False
                                    p2.hp = p2.max_hp
                                    p2.x = fx + random.randint(-16, 16)
                                    p2.y = fy
                                    healed = True
                            if healed:
                                SFX["chest"].play()
                                popup = "Fairy Fountain — All heroes healed!"
                                popup_t = 120
                                fairy_pos = None  # One-time per visit
                                for _ in range(20):
                                    particles.append(Particle(fx, fy,
                                        random.choice([(255, 200, 255), (200, 255, 200), (255, 255, 200)]),
                                        life=30, size=2))
                            break

                # Check deaths — mark dead players, game over only if ALL dead
                for pl in alive_players():
                    if pl.hp <= 0:
                        pl.dead = True
                        pl.respawn_timer = RESPAWN_FRAMES
                        SFX["hurt"].play()

                if not alive_players():
                    SFX["die"].play(); state = "dead"; shake = 12

        dialogue.update()
        for p in particles[:]:
            p.update()
            if p.life <= 0: particles.remove(p)
        for d in dmg_nums[:]:
            d.update()
            if d.life <= 0: dmg_nums.remove(d)
        if msg_t > 0: msg_t -= 1
        if popup_t > 0: popup_t -= 1
        if shake > 0: shake -= 1

        # ── DRAW ──
        game_surf.fill(BLACK)
        sx = random.randint(-shake, shake) if shake > 0 else 0
        sy = random.randint(-shake, shake) if shake > 0 else 0

        mgr.draw(game_surf, ticks)

        # Draw fairy fountain
        if fairy_pos:
            fx = fairy_pos[0] * TILE
            fy = fairy_pos[1] * TILE + GAME_Y
            shimmer = int(abs(math.sin(ticks * 0.05)) * 30)
            pygame.draw.ellipse(game_surf, (60 + shimmer, 120 + shimmer, 220), (fx - 2, fy, 20, 12))
            pygame.draw.ellipse(game_surf, (100 + shimmer, 180 + shimmer, 255), (fx + 2, fy + 2, 12, 8))
            if ticks % 10 == 0:
                particles.append(Particle(fx + 8 + random.randint(-6, 6), fy - GAME_Y + random.randint(-2, 6),
                    random.choice([(255, 255, 200), (200, 255, 255)]), life=20, size=1))

        for p in pickups:
            if not p.collected: p.draw(game_surf)
        for npc in npcs: npc.draw(game_surf)
        for e in enemies: e.draw(game_surf)
        for proj in projectiles: proj.draw(game_surf)

        # Draw players sorted by Y position (painter's algorithm)
        draw_order = sorted([pl for pl in players if not pl.dead], key=lambda p: p.y)
        for pl in draw_order:
            if pl.ledge_hop > 0:
                # Visual bounce: draw shadow at ground position, then draw player offset upward
                bounce = int(abs(math.sin(pl.ledge_hop / 16 * math.pi)) * 8)
                shadow_surf = pygame.Surface((12, 4), pygame.SRCALPHA)
                shadow_surf.fill((0, 0, 0, 0))
                pygame.draw.ellipse(shadow_surf, (0, 0, 0, 60), (0, 0, 12, 4))
                game_surf.blit(shadow_surf, (int(pl.x) - 6, int(pl.y) + GAME_Y + pl.h // 2 - 2))
                old_y = pl.y
                pl.y -= bounce
                pl.draw(game_surf)
                pl.y = old_y
            else:
                pl.draw(game_surf)

        # Tree canopy overlay (drawn above Link for depth)
        if not mgr.in_transition:
            mgr.draw_overlays(game_surf, mgr.current, 0, 0, ticks)
        for p in particles: p.draw(game_surf)
        for d in dmg_nums: d.draw(game_surf)

        # Multiplayer HUD: shows health for all 4 players across the top
        draw_multiplayer_hud(game_surf, players, enemies)
        if show_mm:
            draw_overworld_minimap(game_surf, mgr)
        dialogue.draw(game_surf)

        # Draw small player indicators above each player
        for pl in players:
            if pl.dead:
                secs = max(1, pl.respawn_timer // 60 + 1)
                rt = font_sm.render(f"P{pl.player_num}:{secs}s", True, GRAY)
                game_surf.blit(rt, (4 + (pl.player_num - 1) * 50, NATIVE_H - 12))
            elif pl.player_num > 1:
                lbl = font_sm.render(f"P{pl.player_num}", True, WHITE)
                game_surf.blit(lbl, (int(pl.x) - lbl.get_width() // 2, int(pl.y) - 18 + GAME_Y))

        # Pause / inventory overlay
        if state == "paused":
            draw_inventory_screen(game_surf, paused_player or players[0])

        # Popup (crystal obtained, player joined, etc.)
        if popup_t > 0:
            ps = font_md.render(popup, True, CYAN)
            pw = ps.get_width() + 8
            pbx = NATIVE_W // 2 - pw // 2
            pygame.draw.rect(game_surf, (8, 8, 24), (pbx, NATIVE_H // 2 - 22, pw, 16))
            pygame.draw.rect(game_surf, CYAN, (pbx, NATIVE_H // 2 - 22, pw, 16), 1)
            game_surf.blit(ps, (pbx + 4, NATIVE_H // 2 - 20))

        # Dungeon entrance prompt
        if state == "playing" and not mgr.in_transition:
            for pl in alive_players():
                pc = int(pl.x) // TILE
                pr = int(pl.y) // TILE
                if 0 <= pr < MAP_ROWS and 0 <= pc < MAP_COLS:
                    tile = mgr.get_tile(mgr.current, pc, pr)
                    if TILE_PROPS.get(tile, {}).get("entrance") and DUNGEON_ENTRIES.get(mgr.current) is not None:
                        lvl = DUNGEON_ENTRIES[mgr.current]
                        if lvl not in completed_dungeons:
                            prompt = font_sm.render("Press E to Enter", True, WHITE)
                            game_surf.blit(prompt, (int(pl.x) - prompt.get_width() // 2, int(pl.y) + GAME_Y - 20))
                        else:
                            prompt = font_sm.render("Completed!", True, (100, 255, 100))
                            game_surf.blit(prompt, (int(pl.x) - prompt.get_width() // 2, int(pl.y) + GAME_Y - 20))
                        break

        # Crystal tracker (top-right)
        if len(completed_dungeons) > 0:
            ct = font_sm.render(f"Crystals: {len(completed_dungeons)}/5", True, CYAN)
            game_surf.blit(ct, (NATIVE_W - ct.get_width() - 4, NATIVE_H - 12))

        # Area name banner — cinematic fade-in/out strip
        if msg_t > 0 and not dialogue.is_active:
            alpha = min(255, msg_t * 8) if msg_t > 60 else min(255, msg_t * 4)
            banner = pygame.Surface((NATIVE_W, 20), pygame.SRCALPHA)
            banner.fill((0, 0, 0, min(140, alpha)))
            ms = font_md.render(msg, True, (248, 216, 0))
            ms.set_alpha(alpha)
            banner.blit(ms, (NATIVE_W // 2 - ms.get_width() // 2, 4))
            game_surf.blit(banner, (0, NATIVE_H // 2 - 10))

        # Death screen (all players dead)
        if state == "dead":
            ov = pygame.Surface((NATIVE_W, NATIVE_H), pygame.SRCALPHA)
            ov.fill((0, 0, 0, 140))
            game_surf.blit(ov, (0, 0))
            gt = font_xl.render("GAME OVER", True, RED)
            game_surf.blit(gt, (NATIVE_W // 2 - gt.get_width() // 2, NATIVE_H // 2 - 40))
            sub = font_sm.render("R:Restart  Q:Quit", True, GRAY)
            game_surf.blit(sub, (NATIVE_W // 2 - sub.get_width() // 2, NATIVE_H // 2 + 40))

        # Victory screen
        if state == "win":
            ov = pygame.Surface((NATIVE_W, NATIVE_H), pygame.SRCALPHA)
            ov.fill((0, 0, 0, 160))
            game_surf.blit(ov, (0, 0))
            wt = font_xl.render("ALL CRYSTALS COLLECTED!", True, YELLOW)
            game_surf.blit(wt, (NATIVE_W // 2 - wt.get_width() // 2, NATIVE_H // 2 - 50))
            st = font_md.render("The Dark Lord is defeated!", True, WHITE)
            game_surf.blit(st, (NATIVE_W // 2 - st.get_width() // 2, NATIVE_H // 2 - 25))
            hero_names = ", ".join([f"P{pl.player_num}" for pl in players])
            ht = font_sm.render(f"Heroes: {hero_names}", True, CYAN)
            game_surf.blit(ht, (NATIVE_W // 2 - ht.get_width() // 2, NATIVE_H // 2 - 5))
            # Stats
            total_kills = sum(pl.kills for pl in players)
            total_rupees = sum(pl.rupees for pl in players)
            stats_lines = [f"Kills: {total_kills}", f"Rupees: {total_rupees}",
                           f"Players: {len(players)}"]
            for i, s in enumerate(stats_lines):
                stt = font_sm.render(s, True, WHITE)
                game_surf.blit(stt, (NATIVE_W // 2 - stt.get_width() // 2, NATIVE_H // 2 + 12 + i * 11))
            sub = font_sm.render("R:Play Again  Q:Quit", True, GRAY)
            game_surf.blit(sub, (NATIVE_W // 2 - sub.get_width() // 2, NATIVE_H // 2 + 52))

        # Scale and display
        scaled = pygame.transform.scale(game_surf, (SCREEN_W, SCREEN_H))
        screen.blit(scaled, (0, 0))
        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)

    _restore_patches()
    stop_music()
    return False


# ══════════════════════════════════════════
#  DUNGEON CO-OP LOOP (4-player)
# ══════════════════════════════════════════
async def dungeon_coop_loop(pre_connected=None):
    """4-player co-op dungeon mode -- fight through 5 levels together."""
    global from_grass_pickups

    lvl = 0
    cmap, enemies, pickups, npcs, chests, push_blocks, switches, pots = setup_level(lvl)

    # Start with P1 only, others join dynamically
    players = [Player(8 * TILE, 2 * TILE, keys=PLAYER_KEYS[1], tint=PLAYER_TINTS[1], player_num=1)]
    joined_players = {1}

    # Pre-spawn players who connected in lobby
    if pre_connected:
        for pn in sorted(pre_connected.keys()):
            if pn > 1 and pn not in joined_players:
                joined_players.add(pn)
                offset = (pn - 1) * 20
                players.append(Player(8 * TILE + offset - 30, 2 * TILE,
                    keys=PLAYER_KEYS[pn], tint=PLAYER_TINTS[pn], player_num=pn))

    JOIN_KEYS = {
        PLAYER_KEYS[2]["attack"]: 2,
        PLAYER_KEYS[3]["attack"]: 3,
        PLAYER_KEYS[4]["attack"]: 4,
    }
    RESPAWN_FRAMES = 180

    particles, dmg_nums, projectiles = [], [], []
    dialogue = DialogueBox(font_sm)
    dialogue.text_sound = SFX.get("text")
    shake, hitstop = 0, 0
    state = "playing"
    paused_player = None
    msg, msg_t = LEVEL_NAMES[lvl], 90
    show_mm = True
    popup, popup_t = "", 0
    from_grass_pickups = []

    def alive_players():
        return [p for p in players if not p.dead]

    def closest_player(x, y):
        alive = alive_players()
        if not alive:
            return players[0]
        return min(alive, key=lambda p: (p.x - x)**2 + (p.y - y)**2)

    await fade("in", 10)
    play_music("dungeon")

    while True:
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                return False
            if ev.type == pygame.KEYDOWN:
                if ev.key == pygame.K_F11:
                    toggle_fullscreen()

                # Dynamic player joining
                if ev.key in JOIN_KEYS and JOIN_KEYS[ev.key] not in joined_players:
                    pn = JOIN_KEYS[ev.key]
                    joined_players.add(pn)
                    ref = alive_players()[0] if alive_players() else players[0]
                    new_x = max(16, min(NATIVE_W - 16, ref.x + random.randint(-20, 20)))
                    new_y = max(16, min(MAP_ROWS * TILE - 16, ref.y + random.randint(-10, 10)))
                    new_p = Player(new_x, new_y,
                                   keys=PLAYER_KEYS[pn], tint=PLAYER_TINTS[pn], player_num=pn)
                    players.append(new_p)
                    SFX["pickup"].play()
                    popup = f"P{pn} Joined!"
                    popup_t = 90

                elif dialogue.is_active:
                    for pl in players:
                        if ev.key in (pl.input_keys.get("attack"), pl.input_keys.get("interact")):
                            dialogue.advance()
                            break

                elif state == "paused":
                    if ev.key == pygame.K_ESCAPE:
                        state = "playing"
                    # Allow weapon switching while paused
                    for pl in players:
                        ik = pl.input_keys
                        if ev.key == ik.get("weapon1") and "sword" in pl.weapons_unlocked:
                            pl.weapon = "sword"; SFX["select"].play()
                        elif ev.key == ik.get("weapon2") and "bow" in pl.weapons_unlocked:
                            pl.weapon = "bow"; SFX["select"].play()
                        elif ev.key == ik.get("weapon3") and "bomb" in pl.weapons_unlocked:
                            pl.weapon = "bomb"; SFX["select"].play()
                        elif ev.key == ik.get("weapon4") and "boomerang" in pl.weapons_unlocked:
                            pl.weapon = "boomerang"; SFX["select"].play()
                        elif ev.key == ik.get("weapon5") and "hookshot" in pl.weapons_unlocked:
                            pl.weapon = "hookshot"; SFX["select"].play()

                elif state == "playing":
                    if ev.key == pygame.K_ESCAPE:
                        state = "paused"
                        paused_player = players[0]
                    for pl in alive_players():
                        ik = pl.input_keys
                        if ev.key == ik["attack"]:
                            # If carrying a pot, throw it
                            if pl._carried_pot:
                                pot = pl._carried_pot
                                pot.throw_pot(pl.dir)
                                pl._carried_pot = None
                            # Swimming restricts weapons — only boomerang allowed
                            elif pl.swimming and pl.weapon != "boomerang":
                                pass  # Can't use sword/bow/bomb in water
                            else:
                                pl.attack(projectiles, cmap, particles)
                        elif ev.key == ik.get("interact"):
                            # If carrying a pot, throw it
                            if pl._carried_pot:
                                pot = pl._carried_pot
                                pot.throw_pot(pl.dir)
                                pl._carried_pot = None
                            else:
                                ir = pl.rect.inflate(12, 12)
                                # Try to pick up a nearby pot
                                picked_up = False
                                for pot in pots:
                                    if pot.alive and not pot.lifted and ir.colliderect(pot.rect):
                                        pot.lift(pl)
                                        pl._carried_pot = pot
                                        picked_up = True
                                        break
                                if not picked_up:
                                    # Locked doors
                                    door_opened = False
                                    for dr in range(MAP_ROWS):
                                        for dc in range(MAP_COLS):
                                            if cmap[dr][dc] == K:
                                                door_r = pygame.Rect(dc*TILE, dr*TILE, TILE, TILE)
                                                if ir.colliderect(door_r) and pl.keys > 0:
                                                    pl.keys -= 1
                                                    cmap[dr][dc] = D
                                                    SFX["door"].play()
                                                    door_opened = True
                                                    popup = "Door unlocked!"; popup_t = 60
                                                    for _ in range(8):
                                                        particles.append(Particle(dc * TILE + 8, dr * TILE + 8,
                                                            random.choice([YELLOW, WHITE]), life=20, size=2))
                                                elif ir.colliderect(door_r):
                                                    popup = "Need a key!"; popup_t = 40
                                            if door_opened: break
                                    # NPCs
                                    if not door_opened:
                                        for npc in npcs:
                                            if ir.colliderect(npc.rect):
                                                dialogue.start(npc.name, npc.lines)
                                                npc.talked = True
                                                break
                                    # Chests
                                    for ch in chests:
                                        if not ch.opened and ir.colliderect(ch.rect):
                                            ch.opened = True; SFX["chest"].play()
                                            if ch.item == "bow":
                                                if "bow" not in pl.weapons_unlocked:
                                                    pl.weapons_unlocked.append("bow")
                                                pl.arrows += 15
                                            elif ch.item == "bomb":
                                                if "bomb" not in pl.weapons_unlocked:
                                                    pl.weapons_unlocked.append("bomb")
                                                pl.bombs += 5
                                            elif ch.item == "heart_container":
                                                pl.max_hp += 2; pl.hp = pl.max_hp
                                            elif ch.item == "boomerang":
                                                if "boomerang" not in pl.weapons_unlocked:
                                                    pl.weapons_unlocked.append("boomerang")
                                            elif ch.item == "arrows":
                                                pl.arrows += 10
                                            elif ch.item == "bombs":
                                                pl.bombs += 5
                                            elif ch.item == "boots":
                                                pl.has_boots = True
                                            elif ch.item == "flippers":
                                                pl.has_flippers = True
                                            elif ch.item == "hookshot":
                                                if "hookshot" not in pl.weapons_unlocked:
                                                    pl.weapons_unlocked.append("hookshot")
                                                pl.has_hookshot = True
                                            elif ch.item == "lantern":
                                                pl.has_lantern = True
                                            elif ch.item == "magic":
                                                pl.has_magic = True
                                                pl.max_magic = 32
                                                pl.magic = 32
                                            popup = f"Got {ch.item_name}!"; popup_t = 90
                                            # ALttP-style item hold for key items
                                            if ch.item in ("bow", "bomb", "heart_container", "boomerang", "boots", "flippers", "hookshot", "lantern", "magic"):
                                                pl.holding_item = ch.item_name
                                                pl.holding_timer = 60
                                            for _ in range(8):
                                                particles.append(Particle(ch.x, ch.y,
                                                    random.choice([YELLOW, WHITE, CYAN]), life=20, size=2))
                                            break
                        elif ev.key == ik.get("weapon1") and "sword" in pl.weapons_unlocked:
                            pl.weapon = "sword"; SFX["select"].play()
                        elif ev.key == ik.get("weapon2") and "bow" in pl.weapons_unlocked:
                            pl.weapon = "bow"; SFX["select"].play()
                        elif ev.key == ik.get("weapon3") and "bomb" in pl.weapons_unlocked:
                            pl.weapon = "bomb"; SFX["select"].play()
                        elif ev.key == ik.get("weapon4") and "boomerang" in pl.weapons_unlocked:
                            pl.weapon = "boomerang"; SFX["select"].play()
                        elif ev.key == ik.get("weapon5") and "hookshot" in pl.weapons_unlocked:
                            pl.weapon = "hookshot"; SFX["select"].play()

                    if ev.key == pygame.K_TAB:
                        show_mm = not show_mm

                elif state in ("dead", "win"):
                    if ev.key == pygame.K_r:
                        return True
                    if ev.key == pygame.K_q:
                        return False

        keys_pressed = pygame.key.get_pressed()
        ticks = pygame.time.get_ticks()

        # -- UPDATE --
        if hitstop > 0:
            hitstop -= 1
        elif state == "playing" and not dialogue.is_active:
            # Update players
            for pl in players:
                if pl.dead:
                    pl.respawn_timer -= 1
                    if pl.respawn_timer <= 0:
                        alive = alive_players()
                        if alive:
                            pl.x = max(16, min(NATIVE_W - 16, alive[0].x + random.randint(-20, 20)))
                            pl.y = max(16, min(MAP_ROWS * TILE - 16, alive[0].y + random.randint(-10, 10)))
                        else:
                            pl.x, pl.y = 8 * TILE, 2 * TILE
                        pl.hp = pl.max_hp
                        pl.dead = False
                        pl.invincible = 90
                    continue
                pl.update(keys_pressed, cmap)

                # Hookshot wall/enemy detection
                if pl.hookshot_active and not pl.hookshot_retracting:
                    hc = int(pl.hookshot_x) // TILE
                    hr = int(pl.hookshot_y) // TILE
                    if 0 <= hr < MAP_ROWS and 0 <= hc < MAP_COLS:
                        htile = cmap[hr][hc]
                        if htile in (W, Q, T, L, K):
                            pl.hookshot_retracting = True
                            pl.hookshot_hit_wall = True
                            SFX["hit"].play()
                    else:
                        pl.hookshot_retracting = True
                    hook_rect = pygame.Rect(pl.hookshot_x - 4, pl.hookshot_y - 4, 8, 8)
                    if not pl.hookshot_retracting:
                        for enemy in enemies:
                            if hook_rect.colliderect(enemy.rect):
                                enemy.flash = 30
                                enemy.stun = 30
                                pl.hookshot_retracting = True
                                SFX["hit"].play()
                                dmg_nums.append(DmgNum(enemy.x, enemy.y - 10, "STUN", CYAN))
                                break

                # Footstep sound in dungeon (always stone, water sound if swimming)
                if getattr(pl, '_wants_step', False):
                    pl._wants_step = False
                    if pl.swimming:
                        SFX["step_water"].play()
                    else:
                        SFX["step_stone"].play()

                # Dungeon swimming detection (water tile Q=3 with flippers)
                tc_d = int(pl.x) // TILE
                tr_d = int(pl.y) // TILE
                if 0 <= tr_d < MAP_ROWS and 0 <= tc_d < MAP_COLS:
                    was_swimming = pl.swimming
                    pl.swimming = cmap[tr_d][tc_d] == Q and pl.has_flippers
                    if pl.swimming and not was_swimming:
                        SFX["step_water"].play()
                        for _ in range(5):
                            particles.append(Particle(pl.x, pl.y,
                                random.choice([(100, 160, 255), (140, 200, 255), (255, 255, 255)]),
                                life=15, size=2))
                    if pl.swimming:
                        pl.speed = 1.1
                        pl.swim_timer += 1
                        if pl.swim_timer >= 10:
                            pl.swim_frame = (pl.swim_frame + 1) % 2
                            pl.swim_timer = 0
                        if random.random() < 0.1:
                            particles.append(Particle(
                                pl.x + random.randint(-6, 6),
                                pl.y + random.randint(2, 6),
                                random.choice([(100, 160, 255), (140, 200, 255)]),
                                life=10, size=1))
                    elif was_swimming:
                        pl.speed = 1.8
                        pl.swimming = False
                        pl.swim_frame = 0
                        pl.swim_timer = 0

            # Push blocks
            for block in push_blocks:
                block.update()
                for pl in alive_players():
                    if not block.moving and pl.rect.colliderect(block.rect):
                        block.try_push(pl.dir, cmap)
                        SFX["door"].play()

            # Floor switches
            for sw in switches:
                sw.check(alive_players(), cmap)

            # Grass drops
            for gp in from_grass_pickups:
                kind, gx, gy = gp
                pickups.append(Pickup(gx, gy, kind))
            from_grass_pickups.clear()

            # Pots
            for pot in pots:
                pot.update(cmap, particles)
            for pot in pots:
                if pot.thrown and pot.alive:
                    for enemy in enemies:
                        if pot.rect.colliderect(enemy.rect):
                            enemy.take_damage(1, pot.x, pot.y)
                            cp = closest_player(pot.x, pot.y)
                            cp.dmg_dealt += 1
                            pot.smash(particles)
                            shake = 3
                            dmg_nums.append(DmgNum(enemy.x, enemy.y - 10, "1", YELLOW))
                            break

            # SWORD HITS -- every alive player's sword can hit enemies
            for pl in alive_players():
                if pl.attacking and pl.weapon == "sword":
                    sr = pl.sword_rect()
                    for enemy in enemies:
                        if sr.colliderect(enemy.rect) and enemy.flash == 0:
                            enemy.take_damage(1, pl.x, pl.y)
                            pl.dmg_dealt += 1; shake = 4; hitstop = 3
                            for _ in range(4):
                                particles.append(Particle(enemy.x, enemy.y, YELLOW))
                            dmg_nums.append(DmgNum(enemy.x, enemy.y - 10, "1", YELLOW))

            # Spin attack hits — check ALL alive players
            for pl in alive_players():
                if pl.spin_attacking:
                    radius = 24
                    for enemy in enemies:
                        dx_e = enemy.x - pl.x
                        dy_e = enemy.y - pl.y
                        if dx_e * dx_e + dy_e * dy_e < radius * radius and enemy.flash == 0:
                            enemy.take_damage(2, pl.x, pl.y)
                            pl.dmg_dealt += 2; shake = 6; hitstop = 3
                            for _ in range(5):
                                particles.append(Particle(enemy.x, enemy.y, random.choice([YELLOW, WHITE])))
                            dmg_nums.append(DmgNum(enemy.x, enemy.y - 10, "2", YELLOW))

            # Projectiles
            for proj in projectiles[:]:
                proj.update(cmap, particles)
                if not proj.alive:
                    projectiles.remove(proj); continue
                # Boomerang return: catch by any alive player
                if proj.kind == "boomerang" and proj.returning:
                    caught = False
                    for pl in alive_players():
                        if proj.rect.colliderect(pl.rect):
                            proj.alive = False
                            caught = True
                            break
                    if caught:
                        continue
                if proj.owner == "player":
                    for enemy in enemies:
                        if proj.rect.colliderect(enemy.rect) and enemy.flash == 0:
                            if proj.kind == "boomerang":
                                enemy.flash = 30
                                enemy.stun = 30
                                dmg_nums.append(DmgNum(enemy.x, enemy.y - 10, "STUN", CYAN))
                                SFX["hit"].play()
                            else:
                                d = 2 if proj.kind == "bomb" and proj.exploded else 1
                                enemy.take_damage(d, proj.x, proj.y)
                                cp = closest_player(proj.x, proj.y)
                                cp.dmg_dealt += d; shake = 3
                                dmg_nums.append(DmgNum(enemy.x, enemy.y - 10, str(d), YELLOW))
                                if proj.kind == "arrow": proj.alive = False
                elif proj.owner == "enemy":
                    for pl in alive_players():
                        if proj.rect.colliderect(pl.rect):
                            # Shield block check
                            blocked = False
                            if not pl.attacking:
                                pdx, pdy = proj.x - pl.x, proj.y - pl.y
                                if (pl.dir == "up" and pdy < 0) or (pl.dir == "down" and pdy > 0) or \
                                   (pl.dir == "left" and pdx < 0) or (pl.dir == "right" and pdx > 0):
                                    blocked = True
                            if blocked:
                                proj.dx, proj.dy = -proj.dx, -proj.dy
                                proj.owner = "player"
                                shake = 2; SFX["block"].play()
                                for _ in range(4):
                                    particles.append(Particle(pl.x, pl.y,
                                        random.choice([LTBLUE, WHITE, CYAN]), life=10, size=2))
                                dmg_nums.append(DmgNum(pl.x, pl.y - 10, "BLOCK!", CYAN))
                            else:
                                pl.take_damage(1, proj.x, proj.y)
                                if pl.invincible == 50:
                                    shake = 5
                                    for _ in range(3):
                                        particles.append(Particle(pl.x, pl.y, RED))
                                    dmg_nums.append(DmgNum(pl.x, pl.y - 10, "-1", RED))
                                proj.alive = False
                            break

            # Enemies -- chase closest player
            for enemy in enemies[:]:
                target = closest_player(enemy.x, enemy.y)
                enemy.update(target, cmap, projectiles)
                # Boss phase effects
                if enemy.kind == "boss":
                    ap = alive_players()
                    slam_shake = check_boss_slam_damage(enemy, ap, particles, dmg_nums)
                    if slam_shake > 0: shake = max(shake, slam_shake)
                    if enemy.phase == 3:
                        check_boss_fire_trail_damage(enemy, ap)
                    check_boss_clone_damage(enemy, ap)
                if enemy.hp <= 0:
                    if enemy.kind == "boss":
                        hitstop, shake = boss_death_sequence(enemy, particles, hitstop, shake)
                        popup = "THE SHADOW LORD IS DEFEATED!"
                        popup_t = 180
                    elif enemy.kind == "miniboss":
                        shake = 10; hitstop = 8
                        SFX["boss_hit"].play()
                        for _ in range(15):
                            particles.append(Particle(enemy.x, enemy.y,
                                random.choice([RED, ORANGE, YELLOW, WHITE]),
                                life=random.randint(20, 35), size=random.randint(2, 3)))
                        popup = "Mini-Boss defeated!"
                        popup_t = 90
                    else:
                        hitstop = 4
                        for _ in range(8):
                            particles.append(Particle(enemy.x, enemy.y,
                                random.choice([RED, ORANGE, YELLOW]), life=20))
                    closest_player(enemy.x, enemy.y).kills += 1
                    r = random.random()
                    if r < 0.3: pickups.append(Pickup(enemy.x, enemy.y, "rupee"))
                    elif r < 0.4: pickups.append(Pickup(enemy.x, enemy.y, "heart"))
                    elif r < 0.48: pickups.append(Pickup(enemy.x, enemy.y, "arrows"))
                    elif r < 0.52: pickups.append(Pickup(enemy.x, enemy.y, "bombs"))
                    enemies.remove(enemy); continue

                # Enemy touches ANY alive player (skip if boss is invisible during jump)
                if enemy.kind == "boss" and not enemy.visible:
                    pass
                else:
                    for pl in alive_players():
                        if enemy.rect.colliderect(pl.rect):
                            pl.take_damage(enemy.dmg, enemy.x, enemy.y)
                            if pl.invincible == 50:
                                shake = 6
                                dmg_nums.append(DmgNum(pl.x, pl.y - 10, f"-{enemy.dmg}", RED))

            # Pickups -- any player can collect
            for p in pickups:
                if p.collected: continue
                for pl in alive_players():
                    if p.rect.colliderect(pl.rect):
                        p.collected = True; SFX["pickup"].play()
                        if p.kind == "rupee":
                            pl.rupees += 1; dmg_nums.append(DmgNum(p.x, p.y-6, "+1", YELLOW))
                        elif p.kind == "heart":
                            h = min(2, pl.max_hp - pl.hp)
                            pl.hp = min(pl.max_hp, pl.hp + 2)
                            if h > 0: dmg_nums.append(DmgNum(p.x, p.y-6, f"+{h}", PINK))
                        elif p.kind == "arrows":
                            pl.arrows += 5; dmg_nums.append(DmgNum(p.x, p.y-6, "+5", WHITE))
                        elif p.kind == "bombs":
                            pl.bombs += 3; dmg_nums.append(DmgNum(p.x, p.y-6, "+3", WHITE))
                        elif p.kind == "key":
                            pl.keys += 1; dmg_nums.append(DmgNum(p.x, p.y-6, "+KEY", YELLOW))
                            SFX["chest"].play()
                        elif p.kind == "heart_piece":
                            pl.heart_pieces = getattr(pl, 'heart_pieces', 0) + 1
                            SFX["chest"].play()
                            if pl.heart_pieces >= 4:
                                pl.heart_pieces -= 4
                                pl.max_hp += 2
                                pl.hp = pl.max_hp
                                popup = "Heart Container complete!"
                                popup_t = 120
                            else:
                                popup = f"Heart Piece! ({pl.heart_pieces}/4)"
                                popup_t = 90
                            dmg_nums.append(DmgNum(p.x, p.y - 6, "+HP", PINK))
                        for _ in range(3):
                            particles.append(Particle(p.x, p.y, YELLOW, life=10))
                        break

            # Stairs -- any alive player on stairs with all enemies dead
            stair_used = False
            for pl in alive_players():
                if stair_used: break
                c, r = int(pl.x) // TILE, int(pl.y) // TILE
                if 0 <= r < MAP_ROWS and 0 <= c < MAP_COLS and cmap[r][c] == S:
                    if len(enemies) == 0:
                        if lvl < len(MAPS) - 1:
                            SFX["door"].play()
                            await iris_wipe("out", int(pl.x), int(pl.y) + GAME_Y, 18)
                            lvl += 1
                            cmap, enemies, pickups, npcs, chests, push_blocks, switches, pots = setup_level(lvl)
                            for p2 in players:
                                p2.x, p2.y = 8 * TILE, 2 * TILE
                                if p2.dead:
                                    p2.dead = False; p2.hp = p2.max_hp; p2.invincible = 60
                                p2._carried_pot = None
                            projectiles.clear(); from_grass_pickups.clear()
                            msg, msg_t = LEVEL_NAMES[lvl], 90
                            if lvl == 4:
                                play_music("boss")
                            else:
                                play_music("dungeon")
                            game_surf.fill(BLACK)
                            for ri in range(MAP_ROWS):
                                for ci in range(MAP_COLS):
                                    draw_tile(game_surf, cmap[ri][ci], ci, ri, 0)
                            draw_multiplayer_hud(game_surf, players, enemies)
                            await iris_wipe("in", int(pl.x), int(pl.y) + GAME_Y, 18)
                            stair_used = True
                        else:
                            SFX["win"].play(); stop_music(); state = "win"
                            stair_used = True
                    elif popup_t <= 0:
                        popup = f"Defeat {len(enemies)} enemies!"; popup_t = 50

            # Boss victory check
            if lvl == 4 and len(enemies) == 0 and state == "playing":
                stop_music(); SFX["win"].play(); SFX["fanfare"].play(); state = "win"

            # Deaths
            for pl in alive_players():
                if pl.hp <= 0:
                    pl.dead = True
                    pl.respawn_timer = RESPAWN_FRAMES
                    SFX["hurt"].play()

            if not alive_players():
                stop_music(); SFX["die"].play(); state = "dead"; shake = 12

        # Update particles etc
        dialogue.update()
        for p in particles[:]:
            p.update()
            if p.life <= 0: particles.remove(p)
        for d in dmg_nums[:]:
            d.update()
            if d.life <= 0: dmg_nums.remove(d)
        if msg_t > 0: msg_t -= 1
        if popup_t > 0: popup_t -= 1
        if shake > 0: shake -= 1

        # -- DRAW --
        game_surf.fill(BLACK)
        sx = random.randint(-shake, shake) if shake > 0 else 0
        sy = random.randint(-shake, shake) if shake > 0 else 0

        for r in range(MAP_ROWS):
            for c in range(MAP_COLS):
                draw_tile(game_surf, cmap[r][c], c, r, ticks)

        for sw in switches: sw.draw(game_surf)
        for block in push_blocks: block.draw(game_surf)
        for ch in chests: ch.draw(game_surf)
        for p in pickups:
            if not p.collected: p.draw(game_surf)
        for pot in pots: pot.draw(game_surf)
        for npc in npcs: npc.draw(game_surf)

        # Lantern darkness overlay (dungeons, level 1+)
        if lvl >= 1:
            dark = pygame.Surface((NATIVE_W, NATIVE_H), pygame.SRCALPHA)
            dark.fill((0, 0, 0, 180))
            for pl in (players if isinstance(players, list) else [players[0]]):
                if not getattr(pl, 'dead', False):
                    lantern_r = 48 if getattr(pl, 'has_lantern', False) else 24
                    pygame.draw.circle(dark, (0, 0, 0, 0), (int(pl.x), int(pl.y) + GAME_Y), lantern_r)
            for r_t in range(MAP_ROWS):
                for c_t in range(MAP_COLS):
                    if cmap[r_t][c_t] == F:
                        pygame.draw.circle(dark, (0, 0, 0, 0), (c_t * TILE + 8, r_t * TILE + 8 + GAME_Y), 28)
            game_surf.blit(dark, (0, 0))

        # Boss phase 2 darkness overlay
        boss_enemy = next((e for e in enemies if e.kind == "boss"), None)
        if boss_enemy and boss_enemy.phase == 2:
            player_positions = [(pl.x, pl.y) for pl in alive_players()]
            draw_boss_phase2_darkness(game_surf, boss_enemy, player_positions, cmap)

        for e in enemies: e.draw(game_surf)
        for proj in projectiles: proj.draw(game_surf)

        # Draw players sorted by Y (painter's algorithm)
        draw_order = sorted(players, key=lambda p: p.y)
        for pl in draw_order:
            if pl.dead:
                # Show respawn timer
                secs = max(1, (pl.respawn_timer // 60) + 1)
                t_surf = font_sm.render(f"P{pl.player_num}: {secs}s", True, (150, 150, 150))
                game_surf.blit(t_surf, (int(pl.x) - t_surf.get_width()//2, int(pl.y) + GAME_Y - 10))
            else:
                pl.draw(game_surf)
                # Player number label (except P1)
                if pl.player_num > 1:
                    colors = {2: (100,100,255), 3: (255,100,100), 4: (180,100,255)}
                    label = font_sm.render(f"P{pl.player_num}", True, colors.get(pl.player_num, WHITE))
                    game_surf.blit(label, (int(pl.x) - label.get_width()//2, int(pl.y) + GAME_Y - pl.h - 4))

        for p in particles: p.draw(game_surf)
        for d in dmg_nums: d.draw(game_surf)

        # Boss phase 3 arena edge glow
        if boss_enemy and boss_enemy.phase == 3:
            draw_boss_arena_edges(game_surf, boss_enemy.phase_timer)

        # HUD -- multiplayer HUD when more than 1 player, else single player
        if len(players) > 1:
            draw_multiplayer_hud(game_surf, players, enemies)
        else:
            draw_hud(game_surf, players[0], lvl, enemies)

        if show_mm: draw_minimap(game_surf, cmap, players[0], enemies)
        dialogue.draw(game_surf)

        # Pause / inventory overlay
        if state == "paused":
            draw_inventory_screen(game_surf, paused_player or players[0])

        # Popup
        if popup_t > 0:
            ps = font_md.render(popup, True, CYAN)
            pw = ps.get_width() + 8
            pbx = NATIVE_W // 2 - pw // 2
            pygame.draw.rect(game_surf, (8, 8, 24), (pbx, NATIVE_H // 2 - 22, pw, 16))
            pygame.draw.rect(game_surf, CYAN, (pbx, NATIVE_H // 2 - 22, pw, 16), 1)
            game_surf.blit(ps, (pbx + 4, NATIVE_H // 2 - 20))

        # Level message
        if msg_t > 0 and not dialogue.is_active:
            ms = font_md.render(msg, True, (248, 216, 0))
            mw = ms.get_width() + 12
            mbx = NATIVE_W // 2 - mw // 2
            pygame.draw.rect(game_surf, (0, 0, 0), (mbx, NATIVE_H // 2 - 14, mw, 24))
            pygame.draw.rect(game_surf, (184, 152, 48), (mbx, NATIVE_H // 2 - 14, mw, 24), 1)
            game_surf.blit(ms, (mbx + 6, NATIVE_H // 2 - 12))
            if lvl < len(LEVEL_SUBTITLES):
                sub = font_sm.render(LEVEL_SUBTITLES[lvl], True, (180, 180, 200))
                game_surf.blit(sub, (NATIVE_W // 2 - sub.get_width() // 2, NATIVE_H // 2 + 12))

        # Death
        if state == "dead":
            ov = pygame.Surface((NATIVE_W, NATIVE_H), pygame.SRCALPHA)
            ov.fill((0, 0, 0, 140))
            game_surf.blit(ov, (0, 0))
            gt = font_xl.render("GAME OVER", True, RED)
            game_surf.blit(gt, (NATIVE_W//2 - gt.get_width()//2, NATIVE_H//2 - 40))
            # Stats
            total_kills = sum(p.kills for p in players)
            total_rupees = sum(p.rupees for p in players)
            stats = [f"Level: {LEVEL_NAMES[lvl]}", f"Kills: {total_kills}", f"Rupees: {total_rupees}"]
            for i, s in enumerate(stats):
                st = font_sm.render(s, True, WHITE)
                game_surf.blit(st, (NATIVE_W//2 - st.get_width()//2, NATIVE_H//2 - 5 + i * 12))
            sub = font_sm.render("R:Restart  Q:Quit", True, GRAY)
            game_surf.blit(sub, (NATIVE_W//2 - sub.get_width()//2, NATIVE_H//2 + 40))

        # Win
        if state == "win":
            ov = pygame.Surface((NATIVE_W, NATIVE_H), pygame.SRCALPHA)
            ov.fill((0, 0, 0, 140))
            game_surf.blit(ov, (0, 0))
            wt = font_xl.render("VICTORY!", True, YELLOW)
            game_surf.blit(wt, (NATIVE_W//2 - wt.get_width()//2, NATIVE_H//2 - 50))
            total_kills = sum(p.kills for p in players)
            total_rupees = sum(p.rupees for p in players)
            ts = players[0].game_time // 60
            stats = [f"Time: {ts//60}m {ts%60}s", f"Heroes: {len(joined_players)} players",
                     f"Total Kills: {total_kills}", f"Total Rupees: {total_rupees}"]
            for i, s in enumerate(stats):
                st = font_sm.render(s, True, WHITE)
                game_surf.blit(st, (NATIVE_W//2 - st.get_width()//2, NATIVE_H//2 - 20 + i * 11))
            sub = font_sm.render("R:Restart  Q:Quit", True, GRAY)
            game_surf.blit(sub, (NATIVE_W//2 - sub.get_width()//2, NATIVE_H//2 + 35))

        scaled = pygame.transform.scale(game_surf, (SCREEN_W, SCREEN_H))
        screen.blit(scaled, (0, 0))
        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)

    return False


# ══════════════════════════════════════════
#  MODE SELECT
# ══════════════════════════════════════════
async def mode_select():
    """Show mode selection screen. Returns 'dungeon', 'overworld', or False (quit)."""
    selected = 0  # 0 = dungeon, 1 = overworld
    t = 0
    gold = (248, 216, 0)
    dim = (120, 100, 60)
    desc_col = (160, 160, 180)

    await fade("in", 12)

    while True:
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                return False
            if ev.type == pygame.KEYDOWN:
                if ev.key == pygame.K_ESCAPE:
                    return False
                if ev.key == pygame.K_1:
                    selected = 0
                    SFX["select"].play()
                elif ev.key == pygame.K_2:
                    selected = 1
                    SFX["select"].play()
                elif ev.key in (pygame.K_UP, pygame.K_w):
                    selected = (selected - 1) % 2
                    SFX["select"].play()
                elif ev.key in (pygame.K_DOWN, pygame.K_s):
                    selected = (selected + 1) % 2
                    SFX["select"].play()
                elif ev.key in (pygame.K_RETURN, pygame.K_SPACE):
                    SFX["chest"].play()
                    await fade("out", 10)
                    return "dungeon" if selected == 0 else "overworld"

        game_surf.fill(BLACK)

        # Title
        title = font_lg.render("SELECT MODE", True, WHITE)
        game_surf.blit(title, (NATIVE_W // 2 - title.get_width() // 2, 40))

        # Decorative line
        pygame.draw.line(game_surf, (60, 60, 80), (40, 60), (NATIVE_W - 40, 60))

        # Option 1: Dungeon Mode
        y1 = 80
        c1 = gold if selected == 0 else dim
        # Selection arrow
        if selected == 0:
            ax = 24
            ay = y1 + 4
            bob = int(math.sin(t * 0.1) * 2)
            pygame.draw.polygon(game_surf, gold, [(ax + bob, ay), (ax + bob, ay + 8), (ax + 6 + bob, ay + 4)])
        opt1 = font_md.render("[1] DUNGEON MODE", True, c1)
        game_surf.blit(opt1, (36, y1))
        d1 = font_sm.render("Fight through 5 levels together", True, desc_col if selected == 0 else (80, 80, 90))
        game_surf.blit(d1, (36, y1 + 16))
        d1b = font_sm.render("1-4 players, co-op boss fight!", True, desc_col if selected == 0 else (80, 80, 90))
        game_surf.blit(d1b, (36, y1 + 26))

        # Option 2: Overworld
        y2 = 130
        c2 = gold if selected == 1 else dim
        if selected == 1:
            ax = 24
            ay = y2 + 4
            bob = int(math.sin(t * 0.1) * 2)
            pygame.draw.polygon(game_surf, gold, [(ax + bob, ay), (ax + bob, ay + 8), (ax + 6 + bob, ay + 4)])
        opt2 = font_md.render("[2] OVERWORLD", True, c2)
        game_surf.blit(opt2, (36, y2))
        d2 = font_sm.render("Explore the Light World", True, desc_col if selected == 1 else (80, 80, 90))
        game_surf.blit(d2, (36, y2 + 16))
        d2b = font_sm.render("64 screens, 5 dungeons to find", True, desc_col if selected == 1 else (80, 80, 90))
        game_surf.blit(d2b, (36, y2 + 26))

        # Decorative line
        pygame.draw.line(game_surf, (60, 60, 80), (40, 175), (NATIVE_W - 40, 175))

        # Controls hint
        hint = font_sm.render("UP/DOWN or 1/2 to select, ENTER to confirm", True, (80, 80, 100))
        game_surf.blit(hint, (NATIVE_W // 2 - hint.get_width() // 2, 185))

        # Player join reminder
        join = font_sm.render("P2-P4 join in-game by pressing attack", True, (70, 70, 90))
        game_surf.blit(join, (NATIVE_W // 2 - join.get_width() // 2, 200))

        scaled = pygame.transform.scale(game_surf, (SCREEN_W, SCREEN_H))
        screen.blit(scaled, (0, 0))
        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)
        t += 1

    return False


# ══════════════════════════════════════════
#  SAVE SELECT
# ══════════════════════════════════════════
async def save_select_screen():
    """Show save slot selection. Returns slot number (1-3), 'new', or False."""
    saves = list_saves()
    selected = 0  # 0=slot1, 1=slot2, 2=slot3, 3=new game
    options = []
    for slot in range(1, 4):
        s = saves[slot]
        if s["exists"]:
            time_str = format_time(s["play_time"])
            options.append(f"Slot {slot}: {s['completed']}/5 crystals  {time_str}  {s['kills']} kills")
        else:
            options.append(f"Slot {slot}: Empty")
    options.append("New Game")

    while True:
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT: return False
            if ev.type == pygame.KEYDOWN:
                if ev.key in (pygame.K_UP, pygame.K_w): selected = (selected - 1) % len(options)
                if ev.key in (pygame.K_DOWN, pygame.K_s): selected = (selected + 1) % len(options)
                if ev.key in (pygame.K_RETURN, pygame.K_SPACE):
                    if selected < 3:
                        slot = selected + 1
                        if saves[slot]["exists"]:
                            return slot  # Load this save
                        else:
                            return "new"  # New game in this slot
                    else:
                        return "new"
                if ev.key == pygame.K_ESCAPE: return False

        game_surf.fill((0, 0, 0))
        title = font_lg.render("SELECT SAVE", True, (248, 216, 0))
        game_surf.blit(title, (NATIVE_W//2 - title.get_width()//2, 30))

        for i, opt in enumerate(options):
            color = (255, 255, 255) if i == selected else (120, 120, 140)
            prefix = "> " if i == selected else "  "
            text = font_md.render(prefix + opt, True, color)
            game_surf.blit(text, (30, 70 + i * 25))

        hint = font_sm.render("UP/DOWN: Select  ENTER: Confirm  ESC: Back", True, (80, 80, 100))
        game_surf.blit(hint, (NATIVE_W//2 - hint.get_width()//2, NATIVE_H - 15))

        scaled = pygame.transform.scale(game_surf, (SCREEN_W, SCREEN_H))
        screen.blit(scaled, (0, 0))
        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)


# ══════════════════════════════════════════
#  CONTROLLER LOBBY
# ══════════════════════════════════════════
async def controller_lobby():
    """Show controller connection screen. Returns dict of connected players or False (quit)."""
    import socket

    # Get local IP address
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
    except Exception:
        local_ip = "localhost"

    connected = {1: True}  # P1 always connected (keyboard)
    # Track which player keys have been pressed
    join_attacks = {
        PLAYER_KEYS[2]["attack"]: 2,
        PLAYER_KEYS[3]["attack"]: 3,
        PLAYER_KEYS[4]["attack"]: 4,
    }

    # Also detect movement keys as "connected" signals
    join_any = {}
    for pn in [2, 3, 4]:
        for key_list in PLAYER_KEYS[pn].values():
            if isinstance(key_list, list):
                for k in key_list:
                    join_any[k] = pn
            elif isinstance(key_list, int):
                join_any[key_list] = pn

    t = 0
    await fade("in", 12)

    while True:
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                return False
            if ev.type == pygame.KEYDOWN:
                if ev.key in (pygame.K_RETURN, pygame.K_SPACE):
                    SFX["chest"].play()
                    await fade("out", 10)
                    return connected  # Returns dict like {1: True, 3: True}
                if ev.key == pygame.K_ESCAPE:
                    return False
                if ev.key == pygame.K_F11:
                    toggle_fullscreen()
                # Detect player connections
                if ev.key in join_attacks:
                    if join_attacks[ev.key] not in connected:
                        connected[join_attacks[ev.key]] = True
                        SFX["pickup"].play()
                elif ev.key in join_any:
                    if join_any[ev.key] not in connected:
                        connected[join_any[ev.key]] = True
                        SFX["pickup"].play()

        game_surf.fill((0, 0, 0))
        t += 1

        # Title
        title = font_lg.render("CONNECT CONTROLLERS", True, (248, 216, 0))
        game_surf.blit(title, (NATIVE_W // 2 - title.get_width() // 2, 15))

        # URL
        url_label = font_sm.render("Open on your phone:", True, (160, 160, 180))
        game_surf.blit(url_label, (NATIVE_W // 2 - url_label.get_width() // 2, 40))

        url_text = font_md.render(f"http://{local_ip}:3000", True, (100, 200, 255))
        game_surf.blit(url_text, (NATIVE_W // 2 - url_text.get_width() // 2, 52))

        # Player cards
        card_w = 44
        card_h = 50
        total_w = card_w * 4 + 12 * 3  # 4 cards + 3 gaps
        start_x = (NATIVE_W - total_w) // 2
        card_y = 75

        player_colors = {
            1: (72, 184, 72),    # Green
            2: (80, 120, 240),   # Blue
            3: (220, 80, 80),    # Red
            4: (160, 80, 220),   # Purple
        }

        for pn in range(1, 5):
            cx = start_x + (pn - 1) * (card_w + 12)
            color = player_colors[pn]
            is_connected = connected.get(pn, False)

            # Card background
            if is_connected:
                pygame.draw.rect(game_surf, (color[0]//4, color[1]//4, color[2]//4),
                               (cx, card_y, card_w, card_h))
                pygame.draw.rect(game_surf, color, (cx, card_y, card_w, card_h), 2)
            else:
                pygame.draw.rect(game_surf, (20, 20, 28), (cx, card_y, card_w, card_h))
                pygame.draw.rect(game_surf, (60, 60, 70), (cx, card_y, card_w, card_h), 1)

            # Player number
            pn_text = font_md.render(f"P{pn}", True, color if is_connected else (80, 80, 90))
            game_surf.blit(pn_text, (cx + card_w // 2 - pn_text.get_width() // 2, card_y + 5))

            # Status icon
            if is_connected:
                check = font_md.render("OK", True, (100, 255, 100))
                game_surf.blit(check, (cx + card_w // 2 - check.get_width() // 2, card_y + 20))
            else:
                dots = "." * ((t // 20) % 4)
                dot_text = font_sm.render(dots, True, (80, 80, 90))
                game_surf.blit(dot_text, (cx + card_w // 2 - dot_text.get_width() // 2, card_y + 22))

            # Status label
            if is_connected:
                status = font_sm.render("READY", True, (100, 255, 100))
            else:
                status = font_sm.render("waiting", True, (80, 80, 90))
            game_surf.blit(status, (cx + card_w // 2 - status.get_width() // 2, card_y + 38))

        # Instructions
        p1_info = font_sm.render("P1: Keyboard (WASD + Space)", True, (120, 120, 140))
        game_surf.blit(p1_info, (NATIVE_W // 2 - p1_info.get_width() // 2, 140))

        p_info = font_sm.render("Others: Connect phone, pick player", True, (120, 120, 140))
        game_surf.blit(p_info, (NATIVE_W // 2 - p_info.get_width() // 2, 152))

        # Setup requirements
        setup_lines = [
            "1. Run: cd server && npm start",
            "2. Run: python3 bridge.py",
            "3. Open URL on phones",
        ]
        for i, line in enumerate(setup_lines):
            st = font_sm.render(line, True, (80, 80, 100))
            game_surf.blit(st, (NATIVE_W // 2 - st.get_width() // 2, 168 + i * 10))

        # Start prompt (pulsing)
        num_connected = sum(1 for v in connected.values() if v)
        alpha = int(160 + 95 * math.sin(t * 0.06))
        start_surf = pygame.Surface((200, 12), pygame.SRCALPHA)
        start_text = font_md.render(f"Press ENTER to start ({num_connected} player{'s' if num_connected > 1 else ''})", True, (255, 255, 255))
        start_surf.blit(start_text, (100 - start_text.get_width() // 2, 0))
        start_surf.set_alpha(alpha)
        game_surf.blit(start_surf, (NATIVE_W // 2 - 100, 205))

        scaled = pygame.transform.scale(game_surf, (SCREEN_W, SCREEN_H))
        screen.blit(scaled, (0, 0))
        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)


# ══════════════════════════════════════════
#  MAIN
# ══════════════════════════════════════════
async def main():
    # Start web controller bridge if running in browser
    if IS_WEB:
        try:
            from web_controller_bridge import start_bridge
            start_bridge()
        except Exception as e:
            print("[web bridge] failed to start:", e)

    while True:
        if not await title_screen():
            break
        mode = await mode_select()
        if mode is False:
            break
        connected_players = None
        save_slot = None
        skip_game = False
        if mode == "dungeon":
            lobby_result = await controller_lobby()
            if lobby_result is False:
                break
            if not lobby_result:
                continue  # Back to title screen
            connected_players = lobby_result
        elif mode == "overworld":
            save_result = await save_select_screen()
            if save_result is False:
                break
            if isinstance(save_result, int):
                save_slot = save_result
            else:
                save_slot = None  # New game, no slot yet
        if not await intro_scroll():
            break
        if mode == "dungeon":
            result = await dungeon_coop_loop(pre_connected=connected_players)
        else:
            result = await overworld_loop(current_save_slot=save_slot)
        if result is False:
            break
        # result is True: user pressed R to restart, loop back to title screen

    pygame.quit()


asyncio.run(main())
