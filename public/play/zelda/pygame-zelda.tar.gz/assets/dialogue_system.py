"""
ALttP-style dialogue system — gold-bordered text box with typewriter reveal.

Usage:
    dlg = DialogueBox(font)
    dlg.start("Elder", ["The Dark Lord grows stronger...", "You must find the crystals."])

    # In game loop:
    dlg.update()
    dlg.draw(surface)

    # On key press:
    dlg.advance()
"""
import pygame


class DialogueBox:
    """Gold-bordered dialogue box with character-by-character text reveal."""

    def __init__(self, font, native_w=256, native_h=224):
        self.font = font
        self.native_w = native_w
        self.native_h = native_h

        # Box dimensions (bottom of screen)
        self.box_margin = 8
        self.box_h = 48
        self.box_y = native_h - self.box_h - 4
        self.box_x = self.box_margin
        self.box_w = native_w - self.box_margin * 2

        # Text area (inside the border)
        self.text_x = self.box_x + 8
        self.text_y = self.box_y + 6
        self.text_w = self.box_w - 16
        self.max_lines = 3
        self.line_h = 12

        # State
        self.active = False
        self.speaker = ""
        self.pages = []        # List of strings (one per "page")
        self.current_page = 0
        self.reveal_pos = 0    # Characters revealed so far
        self.reveal_speed = 1  # Characters per frame (1 = normal, 2 = fast)
        self.fully_revealed = False
        self.tick_timer = 0

        # Colors (ALttP style)
        self.border_outer = (184, 152, 48)    # Gold
        self.border_inner = (248, 216, 0)     # Bright gold
        self.bg_color = (0, 0, 16)            # Near-black blue
        self.text_color = (255, 255, 255)     # White
        self.speaker_color = (248, 216, 0)    # Gold for speaker name
        self.arrow_color = (255, 255, 255)    # White advance arrow

        # Sound (set externally)
        self.text_sound = None  # Set to a pygame.mixer.Sound for typewriter tick

    def start(self, speaker, lines):
        """Start a dialogue sequence.

        Args:
            speaker: Name of the speaking character
            lines: List of strings (each becomes one page/screen of text)
        """
        self.active = True
        self.speaker = speaker
        self.pages = lines
        self.current_page = 0
        self.reveal_pos = 0
        self.fully_revealed = False

    def advance(self):
        """Called when player presses action button.

        If text is still revealing → show all immediately.
        If fully revealed → go to next page or close.
        """
        if not self.active:
            return

        if not self.fully_revealed:
            # Show all text immediately
            self.reveal_pos = len(self.pages[self.current_page])
            self.fully_revealed = True
        else:
            # Next page
            self.current_page += 1
            if self.current_page >= len(self.pages):
                self.active = False
            else:
                self.reveal_pos = 0
                self.fully_revealed = False

    def update(self):
        """Call once per frame to advance text reveal."""
        if not self.active or self.fully_revealed:
            return

        page_text = self.pages[self.current_page]
        self.tick_timer += 1

        if self.tick_timer >= 2:  # Reveal every 2 frames
            self.tick_timer = 0
            self.reveal_pos += self.reveal_speed

            # Play tick sound
            if self.text_sound and self.reveal_pos % 2 == 0:
                self.text_sound.play()

            if self.reveal_pos >= len(page_text):
                self.reveal_pos = len(page_text)
                self.fully_revealed = True

    def draw(self, surf):
        """Draw the dialogue box on the game surface."""
        if not self.active:
            return

        # -- Draw box background --
        # Outer border (gold)
        pygame.draw.rect(surf, self.border_outer,
                        (self.box_x, self.box_y, self.box_w, self.box_h))
        # Inner border (brighter gold, 1px inset)
        pygame.draw.rect(surf, self.border_inner,
                        (self.box_x + 1, self.box_y + 1, self.box_w - 2, self.box_h - 2))
        # Background fill (2px inset)
        pygame.draw.rect(surf, self.bg_color,
                        (self.box_x + 3, self.box_y + 3, self.box_w - 6, self.box_h - 6))

        # -- Draw speaker name (top-left, gold) --
        if self.speaker:
            name_surf = self.font.render(self.speaker + ":", True, self.speaker_color)
            surf.blit(name_surf, (self.text_x, self.text_y))
            text_start_y = self.text_y + self.line_h
        else:
            text_start_y = self.text_y

        # -- Draw revealed text --
        if self.current_page < len(self.pages):
            page_text = self.pages[self.current_page]
            visible_text = page_text[:self.reveal_pos]

            # Word wrap
            words = visible_text.split(' ')
            lines = []
            current_line = ""
            for word in words:
                test = current_line + (" " if current_line else "") + word
                test_w = self.font.size(test)[0]
                if test_w > self.text_w and current_line:
                    lines.append(current_line)
                    current_line = word
                else:
                    current_line = test
            if current_line:
                lines.append(current_line)

            # Draw lines (max 2 lines of body text)
            for i, line in enumerate(lines[:2]):
                line_surf = self.font.render(line, True, self.text_color)
                surf.blit(line_surf, (self.text_x, text_start_y + i * self.line_h))

        # -- Draw advance arrow (blinking) if fully revealed --
        if self.fully_revealed:
            if (pygame.time.get_ticks() // 300) % 2 == 0:
                arrow_x = self.box_x + self.box_w - 14
                arrow_y = self.box_y + self.box_h - 12
                pygame.draw.polygon(surf, self.arrow_color, [
                    (arrow_x, arrow_y),
                    (arrow_x + 6, arrow_y + 4),
                    (arrow_x, arrow_y + 8),
                ])

    @property
    def is_active(self):
        return self.active
