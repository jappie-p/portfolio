"""
Overworld map data — all 64 screens of the ALttP Light World.

The overworld is an 8×8 grid. Boundary screens (edges) are auto-generated.
Playable screens are hand-crafted tile grids (16 columns × 12 rows each).

Map key (short aliases imported from overworld_tiles):
  GR=Grass  DG=DarkGrass  PA=Path  SA=Sand  SW=Swamp
  WA=Water  DW=DeepWater  WF=Waterfall
  CF=CliffFace  CT=CliffTop  CL=CliffLeft  CR=CliffRight
  CB=CliffCornerTL  CE=CliffCornerTR  BL=CliffBL  BR=CliffBR
  MN=Mountain  CV=Cave  ST=Stairs
  TR=Tree  DT=DarkTree  BU=Bush  TG=TallGrass  FL=Flowers
  HR=HouseRoof  HW=HouseWall  HD=HouseDoor
  HRL/HRM/HRR=RoofL/M/R  HWL/HWM/HWR=WallL/M/R  HBL/HBM/HBR=BaseL/M/R
  CW=CastleWall  TO=CastleTower  CG=CastleGate
  BD=Bridge  FE=Fence  SI=Sign  TC=Torch
  DN=Dungeon  CH=Chest  BO=Boundary
"""

from overworld_tiles import (
    GR, DG, PA, SA, SW, WA, DW, WF,
    CF, CT, CL, CR, CB, CE, BL, BR, MN, CV, ST,
    TR, DT, BU, TG, FL,
    HR, HW, HD, CW, TO, CG, BD, FE, SI, TC,
    DN, CH, BO,
    HRL, HRM, HRR, HWL, HWM, HWR, HBL, HBM, HBR,
    CWT, CWB, CPR, CWI,
    OW_GRASS,
)


def _boundary_screen():
    """Generate a boundary screen (impassable cliffs)."""
    return {
        "tiles": [[BO] * 16 for _ in range(12)],
        "enemies": [],
        "boundary": True,
    }


def _screen(name, tiles, enemies=None, npcs=None, items=None, dungeon=None, signs=None, fairy=None):
    """Helper to create a screen data dict."""
    d = {
        "name": name,
        "tiles": tiles,
        "enemies": enemies or [],
        "npcs": npcs or [],
        "items": items or [],
        "dungeon": dungeon,
        "boundary": False,
    }
    if signs is not None:
        d["signs"] = signs
    if fairy is not None:
        d["fairy"] = fairy
    return d


# ══════════════════════════════════════════
#  ROW 0: Death Mountain
# ══════════════════════════════════════════

SCREEN_DEATH_MTN_WEST = _screen("Death Mountain West", [
    [MN, MN, MN, CF, CF, MN, MN, MN, CF, CF, MN, MN, MN, MN, CF, CF],
    [MN, MN, CF, CF, MN, MN, MN, CF, MN, MN, MN, CF, CF, MN, MN, MN],
    [MN, CF, MN, MN, MN, CF, CF, MN, MN, MN, CF, MN, MN, MN, CF, MN],
    [CF, MN, MN, MN, CF, MN, MN, CF, MN, CF, MN, MN, MN, CF, MN, MN],
    [MN, MN, CV, MN, MN, MN, CF, MN, MN, MN, MN, CF, MN, MN, MN, CF],
    [MN, CF, MN, MN, PA, PA, MN, MN, CF, MN, MN, MN, CF, MN, MN, MN],
    [CF, MN, MN, PA, PA, MN, MN, CF, MN, MN, CF, MN, MN, MN, MN, CF],
    [MN, MN, CF, PA, MN, MN, CF, MN, MN, CF, MN, MN, MN, CF, MN, MN],
    [MN, CF, MN, MN, CF, MN, MN, MN, CF, MN, MN, MN, CF, MN, MN, MN],
    [CF, MN, MN, CF, MN, MN, CF, MN, MN, MN, CF, MN, MN, CF, MN, MN],
    [MN, MN, CF, MN, MN, CF, MN, MN, MN, CF, MN, MN, CF, MN, MN, MN],
    [MN, CF, CF, MN, CF, MN, MN, CF, MN, MN, MN, CF, CF, MN, MN, CF],
], enemies=[("bat", 4, 4), ("bat", 10, 2), ("skeleton", 7, 6), ("skeleton", 13, 9), ("moblin", 11, 4)])

SCREEN_DEATH_MTN_TOWER = _screen("Death Mountain Tower", [
    [MN, MN, MN, MN, CF, MN, MN, MN, CF, MN, MN, MN, MN, CF, MN, MN],
    [MN, CF, MN, TO, TO, TO, MN, CF, MN, MN, CF, MN, MN, MN, CF, MN],
    [CF, MN, MN, TO, CW, TO, MN, MN, MN, CF, MN, MN, CF, MN, MN, MN],
    [MN, MN, CF, CW, DN, CW, CF, MN, MN, MN, CF, MN, MN, MN, CF, MN],
    [MN, CF, MN, TO, CW, TO, MN, CF, MN, CF, MN, MN, MN, CF, MN, MN],
    [CF, MN, MN, PA, PA, MN, MN, MN, CF, MN, MN, CF, MN, MN, MN, MN],
    [MN, MN, CF, PA, MN, MN, CF, MN, MN, MN, CF, MN, MN, MN, CF, MN],
    [MN, CF, MN, PA, MN, CF, MN, MN, MN, CF, MN, MN, CF, MN, MN, MN],
    [CF, MN, MN, PA, CF, MN, MN, CF, MN, MN, MN, CF, MN, MN, MN, CF],
    [MN, MN, CF, PA, MN, MN, CF, MN, MN, CF, MN, MN, MN, CF, MN, MN],
    [MN, CF, MN, MN, MN, CF, MN, MN, CF, MN, MN, MN, CF, MN, MN, MN],
    [CF, MN, MN, CF, MN, MN, MN, CF, MN, MN, CF, MN, MN, MN, CF, MN],
], enemies=[("bat", 7, 2), ("bat", 12, 6), ("skeleton", 5, 8), ("skeleton", 10, 4), ("moblin", 8, 6)], items=[("heart", 4, 5), ("rupee", 11, 9)], dungeon=4)

SCREEN_DEATH_MTN_EAST = _screen("Death Mountain East", [
    [MN, CF, MN, MN, MN, CF, MN, MN, CF, MN, MN, MN, CF, MN, MN, MN],
    [CF, MN, MN, CF, MN, MN, MN, CF, MN, MN, CF, MN, MN, MN, CF, MN],
    [MN, MN, CV, MN, MN, CF, MN, MN, MN, CF, MN, MN, MN, MN, MN, CF],
    [MN, CF, MN, MN, CF, MN, MN, CF, MN, MN, MN, CF, MN, MN, CF, MN],
    [CF, MN, MN, PA, MN, MN, CF, MN, MN, CF, MN, MN, MN, CF, MN, MN],
    [MN, MN, CF, PA, MN, CF, MN, MN, MN, MN, CF, MN, CV, MN, MN, MN],
    [MN, CF, MN, PA, CF, MN, MN, MN, CF, MN, MN, MN, MN, MN, CF, MN],
    [CF, MN, MN, PA, MN, MN, CF, MN, MN, MN, CF, MN, MN, MN, MN, CF],
    [MN, MN, CF, MN, MN, CF, MN, MN, MN, CF, MN, MN, MN, CF, MN, MN],
    [MN, CF, MN, MN, CF, MN, MN, CF, MN, MN, MN, CF, MN, MN, CF, MN],
    [CF, MN, MN, CF, MN, MN, CF, MN, MN, CF, MN, MN, CF, MN, MN, MN],
    [MN, MN, CF, MN, MN, CF, MN, CF, MN, MN, CF, MN, MN, CF, MN, MN],
], enemies=[("bat", 3, 1), ("bat", 12, 5), ("skeleton", 8, 7), ("bat", 5, 9)])

SCREEN_DEATH_MTN_CLIFFS = _screen("Death Mountain Cliffs", [
    [MN, MN, MN, CF, MN, MN, CF, MN, MN, MN, CF, MN, MN, CF, MN, MN],
    [MN, CF, MN, MN, MN, CF, MN, MN, CF, MN, MN, MN, CF, MN, MN, MN],
    [CF, MN, MN, MN, CF, MN, MN, CF, MN, MN, MN, CF, MN, MN, MN, CF],
    [MN, MN, WF, WF, MN, MN, CF, MN, MN, CF, MN, MN, MN, CF, MN, MN],
    [MN, CF, WA, WA, MN, CF, MN, MN, CF, MN, MN, MN, CF, MN, MN, MN],
    [CF, MN, WA, WA, CF, MN, MN, CF, MN, MN, MN, MN, MN, CF, MN, MN],
    [MN, MN, CF, MN, MN, MN, CF, MN, MN, CF, MN, MN, CF, MN, MN, CF],
    [MN, CF, MN, MN, CF, MN, MN, MN, CF, MN, MN, CF, MN, MN, MN, MN],
    [CF, MN, MN, CF, MN, MN, CF, MN, MN, MN, CF, MN, MN, MN, CF, MN],
    [MN, MN, MN, MN, MN, CF, MN, MN, MN, CF, MN, MN, MN, CF, MN, CF],
    [MN, CF, MN, MN, CF, MN, MN, CF, MN, MN, CF, MN, CF, MN, MN, MN],
    [CF, MN, CF, MN, MN, MN, CF, MN, CF, MN, MN, CF, MN, MN, MN, CF],
], enemies=[("bat", 5, 4), ("bat", 9, 1), ("skeleton", 3, 7), ("bat", 13, 5)])


# ══════════════════════════════════════════
#  ROW 1: Lost Woods, Castle North, River North, East Ruins
# ══════════════════════════════════════════

SCREEN_LOST_WOODS_N = _screen("Lost Woods North", [
    [DT, DT, DT, DT, DT, DT, DT, DT, DT, DT, DT, DT, DT, DT, DT, DT],
    [DT, DT, DG, DG, DT, DT, DT, DG, DG, DT, DT, DT, DG, DG, DT, DT],
    [DT, DG, DG, DG, DG, DT, DG, DG, DG, DG, DT, DG, DG, DG, DT, DT],
    [DT, DG, DG, PA, DG, DG, DG, PA, DG, DG, DG, DG, PA, DG, DT, DT],
    [DT, DT, DG, PA, PA, DG, DG, PA, PA, DG, DG, DG, PA, DG, DT, DT],
    [DT, DT, DT, DG, PA, PA, DG, DG, PA, PA, DG, DG, DG, DT, DT, DT],
    [DT, DT, DT, DT, DG, PA, DG, DG, DG, PA, DG, DT, DT, DT, DT, DT],
    [DT, DG, DT, DT, DG, PA, DG, DT, DG, PA, DG, DT, DT, DG, DT, DT],
    [DT, DG, DG, DT, DG, PA, DG, DG, DG, PA, DG, DG, DT, DG, DG, DT],
    [DT, DT, DG, DG, DG, PA, PA, DG, PA, PA, DG, DG, DG, DG, DT, DT],
    [DT, DT, DT, DG, DT, DT, PA, PA, PA, DT, DG, DT, DT, DT, DT, DT],
    [DT, DT, DT, DT, DT, DT, DT, PA, DT, DT, DT, DT, DT, DT, DT, DT],
], enemies=[("bat", 3, 3), ("bat", 11, 7), ("octorok", 7, 5), ("slime", 14, 2)], npcs=[
    ("Lost Child", 9, 8, ["I'm lost...", "The woods keep changing!", "Can you help me find the way out?"], (255, 220, 160)),
], items=[("heart_piece", 13, 9)])

SCREEN_LOST_WOODS_S = _screen("Lost Woods South", [
    [DT, DT, DT, DT, DT, DT, DT, PA, DT, DT, DT, DT, DT, DT, DT, DT],
    [DT, DT, DG, DT, DT, DT, DG, PA, DG, DT, DT, DT, DG, DT, DT, DT],
    [DT, DG, DG, DG, DT, DG, DG, PA, DG, DG, DT, DG, DG, DG, DT, DT],
    [DT, DG, DG, DG, DG, DG, DG, PA, DG, DG, DG, DG, DG, DG, DT, DT],
    [DT, DT, DG, DG, DG, DG, DG, PA, DG, DG, DG, DG, DG, DT, DT, DT],
    [DT, DT, DT, DG, DG, DG, DG, PA, DG, DG, DG, DG, DT, DT, DT, DT],
    [DT, DT, DT, DT, DG, DG, DG, PA, DG, DG, DG, DT, DT, DT, DT, DT],
    [DT, DT, DT, DT, DG, DG, DG, PA, DG, DG, DG, DT, DT, DT, DT, DT],
    [DT, DT, DG, DG, DG, DG, DG, PA, DG, DG, DG, DG, DG, DT, DT, DT],
    [DT, DG, DG, DG, DG, DG, DG, DG, DG, DG, DG, DG, DG, DG, DT, DT],
    [DT, DG, GR, GR, GR, DG, DG, DG, DG, GR, GR, GR, DG, DG, DT, DT],
    [DT, DT, GR, GR, GR, GR, DG, DG, GR, GR, GR, GR, DT, DT, DT, DT],
], enemies=[("bat", 5, 5), ("bat", 13, 3), ("slime", 3, 8), ("octorok", 10, 6)], items=[("rupee", 14, 1), ("rupee", 1, 10), ("rupee", 12, 9)])

SCREEN_CASTLE_NORTH = _screen("Castle North", [
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, WA, WA, WA, WA, WA, WA, WA, WA, WA, WA, GR, GR, GR, GR],
    [GR, WA, WA, WA, WA, WA, WA, WA, WA, WA, WA, WA, WA, GR, GR, GR],
    [WA, WA, WA, TO, CW, CW, CW, CW, CW, CW, TO, WA, WA, WA, GR, GR],
    [WA, WA, TO, CW, GR, GR, GR, GR, GR, GR, CW, TO, WA, WA, WA, GR],
    [WA, WA, CW, GR, GR, GR, GR, GR, GR, GR, GR, CW, WA, WA, WA, GR],
    [WA, WA, CW, GR, GR, GR, GR, GR, GR, GR, GR, CW, WA, WA, GR, GR],
    [WA, WA, CW, GR, GR, GR, TC, GR, TC, GR, GR, CW, WA, WA, GR, GR],
    [WA, WA, TO, CW, GR, GR, GR, GR, GR, GR, CW, TO, WA, WA, GR, GR],
    [WA, WA, WA, CW, CW, CW, CW, CW, CW, CW, CW, WA, WA, WA, GR, GR],
    [GR, WA, WA, WA, WA, WA, WA, WA, WA, WA, WA, WA, WA, GR, GR, GR],
    [GR, GR, WA, WA, WA, WA, WA, WA, WA, WA, WA, WA, GR, GR, GR, GR],
], enemies=[("bat", 6, 5), ("bat", 9, 7), ("knight", 5, 4), ("knight", 8, 8)], items=[("heart", 7, 10), ("bombs", 14, 3), ("rupee", 14, 9)], dungeon=2)

SCREEN_CASTLE_TOWER = _screen("Castle Tower", [
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, GR, WA, WA, WA, WA, WA, WA, WA, WA, GR, GR, GR, GR, GR],
    [GR, GR, WA, WA, WA, WA, WA, WA, WA, WA, WA, WA, GR, GR, GR, GR],
    [GR, WA, WA, CW, CW, CW, CW, CW, CW, CW, CW, WA, WA, GR, GR, GR],
    [GR, WA, CW, TO, GR, GR, GR, GR, GR, GR, TO, CW, WA, GR, GR, GR],
    [GR, WA, CW, GR, GR, GR, GR, GR, GR, GR, GR, CW, WA, GR, GR, GR],
    [GR, WA, CW, GR, GR, DN, GR, GR, DN, GR, GR, CW, WA, GR, GR, GR],
    [GR, WA, CW, GR, GR, GR, GR, GR, GR, GR, GR, CW, WA, GR, GR, GR],
    [GR, WA, CW, TO, GR, GR, GR, GR, GR, GR, TO, CW, WA, GR, GR, GR],
    [GR, WA, WA, CW, CW, CW, CW, CW, CW, CW, CW, WA, WA, GR, GR, GR],
    [GR, GR, WA, WA, WA, WA, WA, WA, WA, WA, WA, WA, GR, GR, GR, GR],
    [GR, GR, GR, WA, WA, WA, WA, WA, WA, WA, WA, GR, GR, GR, GR, GR],
], enemies=[("bat", 5, 6), ("bat", 10, 6), ("knight", 4, 4), ("skeleton", 9, 8)])

SCREEN_RIVER_NORTH = _screen("River North", [
    [GR, GR, GR, TR, GR, GR, GR, WA, WA, GR, GR, GR, TR, GR, GR, GR],
    [GR, GR, TR, GR, GR, TR, GR, WA, WA, GR, TR, GR, GR, GR, GR, GR],
    [GR, TR, GR, GR, GR, GR, GR, WA, WA, GR, GR, TR, GR, GR, TR, GR],
    [GR, GR, GR, TG, GR, GR, GR, WA, WA, GR, GR, GR, GR, TG, GR, GR],
    [GR, GR, GR, GR, GR, TR, GR, WA, WA, GR, TR, GR, GR, GR, GR, TR],
    [GR, TR, GR, GR, GR, GR, GR, WA, WA, GR, GR, GR, TR, GR, GR, GR],
    [GR, GR, TG, GR, GR, GR, GR, WA, WA, GR, GR, GR, GR, GR, TG, GR],
    [GR, GR, GR, GR, TR, GR, BD, BD, BD, BD, GR, TR, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, WA, WA, GR, GR, GR, GR, GR, GR, TR],
    [GR, TR, GR, GR, GR, GR, GR, WA, WA, GR, GR, GR, TR, GR, GR, GR],
    [GR, GR, GR, TG, GR, TR, GR, WA, WA, GR, TR, GR, GR, TG, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, WA, WA, GR, GR, GR, GR, GR, GR, GR],
], enemies=[("slime", 3, 5), ("slime", 12, 3), ("bat", 5, 2), ("bat", 14, 8)])

SCREEN_EAST_RUINS = _screen("East Ruins", [
    [GR, GR, GR, GR, GR, TR, GR, GR, GR, GR, GR, GR, TR, GR, GR, GR],
    [GR, CW, CW, CW, GR, GR, GR, GR, GR, CW, CW, CW, GR, GR, GR, GR],
    [GR, CW, GR, CW, GR, TR, GR, GR, GR, CW, GR, CW, GR, TR, GR, GR],
    [GR, CW, GR, CW, GR, GR, GR, GR, GR, CW, GR, CW, GR, GR, GR, GR],
    [GR, CW, CW, CW, GR, GR, CW, CW, CW, CW, CW, CW, GR, GR, TR, GR],
    [GR, GR, GR, GR, GR, GR, CW, GR, GR, GR, GR, CW, GR, GR, GR, GR],
    [GR, TR, GR, GR, GR, GR, CW, GR, CH, GR, GR, CW, GR, GR, GR, TR],
    [GR, GR, GR, CW, CW, CW, CW, GR, GR, GR, GR, CW, GR, GR, GR, GR],
    [GR, GR, GR, CW, GR, GR, GR, GR, GR, GR, CW, CW, GR, TR, GR, GR],
    [GR, GR, GR, CW, GR, GR, GR, TG, GR, GR, CW, GR, GR, GR, GR, GR],
    [GR, GR, GR, CW, CW, CW, CW, GR, GR, GR, CW, GR, GR, GR, TR, GR],
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
], enemies=[("slime", 5, 6), ("bat", 11, 2), ("knight", 3, 9), ("mage", 13, 4)])


# ══════════════════════════════════════════
#  ROW 2: Forest Clearing, Kakariko North, Castle Gate, Castle Garden, River Bridge, Eastern Palace
# ══════════════════════════════════════════

SCREEN_FOREST_CLEARING = _screen("Forest Clearing", [
    [DT, DT, DT, DT, DT, DT, DT, DT, DT, DT, DT, DT, DT, DT, DT, DT],
    [DT, DT, DG, DG, DT, DT, GR, GR, GR, DT, DT, DG, DG, DT, DT, DT],
    [DT, DG, GR, GR, DG, TR, GR, GR, GR, TR, DG, GR, GR, DG, DT, DT],
    [DT, DG, GR, TG, GR, GR, GR, FL, GR, GR, GR, TG, GR, DG, DT, DT],
    [DT, TR, GR, GR, GR, TR, GR, GR, GR, GR, TR, GR, GR, TR, DT, DT],
    [DT, DG, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, DG, DT, DT],
    [DT, DG, GR, FL, GR, GR, BU, GR, BU, GR, GR, FL, GR, DG, DT, DT],
    [DT, TR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, TR, DT, DT],
    [DT, DG, GR, GR, GR, TG, GR, GR, GR, TG, GR, GR, GR, DG, DT, DT],
    [DT, DG, GR, TG, GR, GR, TR, GR, TR, GR, GR, TG, GR, DG, DT, DT],
    [DT, DT, DG, GR, GR, DG, DG, GR, GR, DG, DG, GR, DG, DT, DT, DT],
    [DT, DT, DT, DG, DG, DT, DT, DG, DT, DT, DT, DG, DT, DT, DT, DT],
], enemies=[("slime", 7, 5), ("bat", 4, 3), ("octorok", 11, 8)], items=[("heart_piece", 2, 10), ("rupee", 14, 2), ("rupee", 1, 8)], fairy=(8, 5))

SCREEN_KAKARIKO_NORTH = _screen("Kakariko Village North", [
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, HRL,HRM,HRR,GR, HRL,HRM,HRR,GR, GR, HRL,HRM,HRR,GR, GR, GR],
    [GR, HWL,HWM,HWR,GR, HWL,HWM,HWR,GR, GR, HWL,HWM,HWR,TR, GR, GR],
    [GR, HBL,HBM,HBR,GR, HBL,HBM,HBR,GR, GR, HBL,HBM,HBR,GR, GR, GR],
    [GR, GR, PA, GR, GR, GR, PA, GR, GR, GR, GR, PA, GR, GR, TR, GR],
    [GR, GR, PA, PA, PA, PA, PA, PA, PA, PA, PA, PA, PA, GR, GR, GR],
    [GR, TR, GR, GR, GR, PA, GR, GR, GR, PA, GR, GR, GR, GR, GR, TR],
    [GR, GR, GR, GR, GR, PA, GR, GR, GR, PA, GR, GR, GR, GR, GR, GR],
    [GR, GR, HRL,HRM,HRR,PA, HRL,HRM,HRR,PA, GR, SI, GR, GR, GR, GR],
    [GR, GR, HWL,HWM,HWR,PA, HWL,HWM,HWR,PA, GR, GR, GR, TR, GR, GR],
    [GR, GR, HBL,HBM,HBR,PA, HBL,HBM,HBR,PA, GR, GR, GR, GR, GR, GR],
    [GR, GR, GR, PA, PA, PA, PA, GR, GR, PA, PA, PA, GR, GR, GR, GR],
], enemies=[("slime", 14, 4)], npcs=[
    ("Villager", 5, 3, ["Welcome to Kakariko Village!", "The elder lives to the south."], (120, 180, 240)),
    ("Guard", 12, 5, ["The castle is east of here.", "Be careful of the soldiers!"], (200, 160, 80)),
], signs=[(7, 9, "Welcome to Kakariko Village!")])

SCREEN_CASTLE_GATE = _screen("Castle Gate", [
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, WA, WA, WA, WA, WA, WA, WA, WA, WA, WA, WA, WA, GR, GR, GR],
    [GR, WA, WA, WA, WA, WA, WA, WA, WA, WA, WA, WA, WA, WA, GR, GR],
    [GR, WA, WA, TO, CW, CW, CW, CW, CW, CW, TO, WA, WA, WA, GR, GR],
    [GR, WA, WA, CW, GR, GR, GR, GR, GR, GR, CW, WA, WA, WA, GR, GR],
    [GR, WA, WA, CW, GR, GR, CG, GR, CG, GR, CW, WA, WA, WA, GR, GR],
    [GR, WA, BD, BD, BD, BD, BD, BD, BD, BD, BD, BD, WA, WA, GR, GR],
    [GR, WA, WA, CW, GR, GR, GR, GR, GR, GR, CW, WA, WA, WA, GR, GR],
    [GR, WA, WA, TO, CW, CW, CW, CW, CW, CW, TO, WA, WA, WA, GR, GR],
    [GR, WA, WA, WA, WA, WA, WA, WA, WA, WA, WA, WA, WA, GR, GR, GR],
    [GR, GR, WA, WA, WA, WA, WA, WA, WA, WA, WA, WA, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
], enemies=[("slime", 14, 6), ("knight", 4, 4), ("knight", 10, 7)], items=[("bombs", 14, 10), ("rupee", 14, 1), ("rupee", 13, 4)], signs=[(7, 10, "Hyrule Castle  — Authorized entry only")])

SCREEN_CASTLE_GARDEN = _screen("Castle Garden", [
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, TR, GR, GR, FL, GR, GR, GR, GR, FL, GR, GR, GR, TR, GR, GR],
    [GR, GR, GR, FL, GR, GR, TR, GR, TR, GR, GR, FL, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, FL, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, FL, GR, GR],
    [GR, GR, TR, GR, GR, GR, FE, FE, FE, GR, GR, GR, TR, GR, GR, GR],
    [GR, GR, GR, GR, FE, GR, GR, GR, GR, GR, FE, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, FE, GR, FL, GR, FL, GR, FE, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, FE, GR, GR, GR, GR, GR, FE, GR, GR, GR, GR, GR],
    [GR, FL, TR, GR, GR, GR, FE, FE, FE, GR, GR, GR, TR, FL, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, PA, PA, PA, PA, PA, PA, PA, GR, GR, GR, GR, GR],
], enemies=[("slime", 8, 6), ("knight", 3, 3), ("skeleton", 12, 8), ("moblin", 11, 3)], items=[("heart_piece", 10, 8)])

SCREEN_RIVER_BRIDGE = _screen("River Bridge", [
    [GR, GR, GR, TR, GR, GR, GR, WA, WA, GR, GR, GR, TR, GR, GR, GR],
    [GR, GR, TR, GR, GR, TR, GR, WA, WA, GR, TR, GR, GR, GR, GR, GR],
    [GR, TR, GR, GR, GR, GR, GR, WA, WA, GR, GR, TR, GR, GR, TR, GR],
    [GR, GR, GR, TG, GR, GR, GR, WA, WA, GR, GR, GR, GR, TG, GR, GR],
    [GR, GR, GR, GR, GR, GR, BD, BD, BD, BD, GR, GR, GR, GR, GR, TR],
    [GR, GR, GR, GR, GR, GR, GR, WA, WA, GR, GR, GR, GR, GR, GR, GR],
    [GR, TR, GR, GR, GR, GR, GR, WA, WA, GR, GR, GR, TR, GR, GR, GR],
    [GR, GR, TG, GR, GR, GR, GR, WA, WA, GR, GR, GR, GR, GR, TG, GR],
    [GR, GR, GR, GR, TR, GR, GR, WA, WA, GR, TR, GR, GR, GR, GR, GR],
    [GR, TR, GR, GR, GR, GR, GR, WA, WA, GR, GR, GR, TR, GR, GR, GR],
    [GR, GR, GR, TG, GR, TR, GR, WA, WA, GR, TR, GR, GR, TG, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, WA, WA, GR, GR, GR, GR, GR, GR, GR],
], enemies=[("slime", 3, 7), ("slime", 13, 3), ("bat", 5, 9), ("bat", 11, 1)])

SCREEN_EASTERN_PALACE = _screen("Eastern Palace", [
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, GR, CW, CW, CW, CW, CW, CW, CW, CW, GR, GR, GR, GR, GR],
    [GR, GR, CW, GR, GR, GR, GR, GR, GR, GR, GR, CW, GR, GR, GR, GR],
    [GR, GR, CW, GR, TO, CW, CW, CW, CW, TO, GR, CW, GR, GR, GR, GR],
    [GR, GR, CW, GR, CW, GR, GR, GR, GR, CW, GR, CW, GR, GR, GR, GR],
    [GR, GR, CW, GR, CW, GR, GR, GR, GR, CW, GR, CW, GR, GR, GR, GR],
    [GR, GR, CW, GR, CW, GR, GR, GR, GR, CW, GR, CW, GR, GR, GR, GR],
    [GR, GR, CW, GR, TO, CW, CW, CW, CW, TO, GR, CW, GR, GR, GR, GR],
    [GR, GR, CW, GR, GR, GR, DN, GR, GR, GR, GR, CW, GR, GR, GR, GR],
    [GR, GR, CW, CW, CW, CW, CW, CW, CW, CW, CW, CW, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
], enemies=[("slime", 6, 5), ("bat", 9, 4), ("knight", 4, 7), ("mage", 10, 3), ("moblin", 7, 6)], npcs=[
    ("Castle Guard", 7, 8, ["Halt! The castle is on high alert.", "The Dark Lord's forces are everywhere.", "Only the bravest may enter."], (180, 180, 200)),
    ("Scholar", 13, 5, ["This is the Eastern Palace.", "Ancient warriors once trained here.", "Now only monsters remain..."], (180, 220, 255)),
], items=[("heart", 6, 10), ("rupee", 14, 1)], dungeon=0, signs=[(4, 9, "Eastern Palace — Ancient training grounds")])


# ══════════════════════════════════════════
#  ROW 3: Kakariko South, Central Fields, River South, East Field
# ══════════════════════════════════════════

SCREEN_KAKARIKO_SOUTH = _screen("Kakariko Village South", [
    [GR, GR, GR, PA, PA, PA, PA, GR, GR, PA, PA, PA, GR, GR, GR, GR],
    [GR, GR, HRL,HRM,HRR,PA, GR, GR, GR, PA, HRL,HRM,HRR,GR, GR, GR],
    [GR, GR, HWL,HWM,HWR,PA, GR, GR, GR, PA, HWL,HWM,HWR,GR, GR, GR],
    [GR, GR, HBL,HBM,HBR,PA, GR, GR, GR, PA, HBL,HBM,HBR,GR, GR, GR],
    [GR, GR, GR, PA, PA, PA, PA, PA, PA, PA, GR, PA, GR, GR, GR, GR],
    [GR, TR, GR, PA, GR, GR, GR, GR, GR, GR, GR, GR, PA, GR, TR, GR],
    [GR, GR, GR, PA, HRL,HRM,HRR,GR, HRL,HRM,HRR,GR, PA, GR, GR, GR],
    [GR, GR, GR, PA, HWL,HWM,HWR,GR, HWL,HWM,HWR,GR, PA, GR, GR, GR],
    [GR, GR, GR, PA, HBL,HBM,HBR,GR, HBL,HBM,HBR,SI, PA, GR, GR, GR],
    [GR, GR, GR, PA, PA, PA, PA, PA, PA, PA, PA, PA, PA, GR, GR, GR],
    [GR, TR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, TR, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, PA, PA, GR, GR, GR, GR, GR, GR, GR],
], enemies=[("slime", 14, 5)], npcs=[
    ("Elder", 4, 5, ["The Dark Lord grows stronger...", "You must find the 5 dungeon crystals.", "Each dungeon holds one crystal."], (255, 255, 200)),
    ("Merchant", 10, 8, ["I've got bombs and arrows!", "If only I had a shop to sell them..."], (180, 120, 80)),
], items=[("heart_piece", 14, 2)])

SCREEN_CENTRAL_FIELD_W = _screen("Central Field West", [
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, TG, GR, GR, GR, GR, GR, GR, GR, TG, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, TR, GR, GR, GR, TR, GR, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, PA, PA, PA, PA, PA, GR, GR, GR, GR, GR, GR, GR],
    [GR, TG, GR, GR, PA, GR, GR, GR, PA, GR, GR, TG, GR, GR, GR, GR],
    [GR, GR, GR, GR, PA, GR, GR, GR, PA, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, TR, GR, PA, GR, GR, GR, PA, GR, TR, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, PA, GR, GR, GR, PA, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, PA, PA, PA, PA, PA, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, TG, GR, GR, GR],
    [GR, TR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, TR, GR],
    [GR, GR, GR, GR, GR, GR, GR, PA, PA, GR, GR, GR, GR, GR, GR, GR],
], enemies=[("slime", 6, 5), ("slime", 11, 2), ("slime", 2, 9), ("slime", 14, 7)], items=[("rupee", 1, 1), ("rupee", 14, 1), ("rupee", 14, 10)])

SCREEN_CENTRAL_FIELD = _screen("Central Field", [
    [GR, GR, GR, GR, GR, GR, GR, PA, PA, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, PA, PA, GR, GR, GR, TG, GR, GR, GR],
    [GR, TG, GR, GR, GR, TR, GR, PA, PA, GR, TR, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, PA, PA, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, PA, PA, GR, GR, GR, GR, GR, GR, TR, GR],
    [GR, GR, TR, GR, GR, GR, PA, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, PA, PA, GR, GR, GR, GR, GR, TG, GR, GR, GR],
    [GR, GR, GR, GR, PA, PA, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, GR, PA, PA, GR, GR, GR, TR, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, PA, PA, GR, GR, GR, GR, GR, GR, GR, GR, GR, TR, GR, GR],
    [GR, PA, PA, GR, GR, GR, TG, GR, GR, GR, GR, TG, GR, GR, GR, GR],
    [PA, PA, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
], enemies=[("octorok", 9, 4), ("slime", 4, 8), ("slime", 13, 1), ("slime", 1, 6)], items=[("heart_piece", 8, 6)], signs=[(8, 0, "North: Castle  South: Lake Hylia")])

SCREEN_CENTRAL_FIELD_E = _screen("Central Field East", [
    [GR, GR, GR, GR, GR, GR, GR, WA, WA, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, GR, TG, GR, GR, GR, WA, WA, GR, GR, TG, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, TR, GR, WA, WA, GR, TR, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, WA, WA, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, BD, BD, BD, BD, GR, GR, GR, GR, TR, GR],
    [GR, TR, GR, GR, GR, GR, GR, WA, WA, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, TG, GR, GR, GR, GR, WA, WA, GR, GR, GR, TG, GR, GR, GR],
    [GR, GR, GR, GR, TR, GR, GR, WA, WA, GR, TR, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, WA, WA, GR, GR, GR, GR, GR, GR, TR],
    [GR, TR, GR, GR, GR, GR, GR, WA, WA, GR, GR, GR, TR, GR, GR, GR],
    [GR, GR, GR, TG, GR, TR, GR, WA, WA, GR, TR, GR, GR, TG, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, WA, WA, GR, GR, GR, GR, GR, GR, GR],
], enemies=[("slime", 3, 5), ("slime", 12, 3), ("bat", 2, 1), ("bat", 14, 9)], items=[("rupee", 1, 1), ("rupee", 1, 11), ("rupee", 14, 11)])

SCREEN_RIVER_SOUTH = _screen("River South", [
    [GR, GR, GR, GR, GR, GR, GR, WA, WA, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, TR, GR, GR, GR, GR, WA, WA, GR, GR, GR, TR, GR, GR, GR],
    [GR, GR, GR, GR, GR, TR, GR, WA, WA, GR, TR, GR, GR, GR, GR, GR],
    [GR, GR, GR, TG, GR, GR, GR, WA, WA, GR, GR, GR, GR, TG, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, WA, WA, GR, GR, GR, GR, GR, TR, GR],
    [GR, TR, GR, GR, GR, GR, GR, WA, WA, GR, GR, TR, GR, GR, GR, GR],
    [GR, GR, TG, GR, GR, GR, GR, WA, WA, GR, GR, GR, GR, TG, GR, GR],
    [GR, GR, GR, GR, TR, GR, GR, WA, WA, GR, TR, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, WA, WA, GR, GR, GR, GR, GR, GR, TR],
    [GR, TR, GR, GR, GR, GR, BD, BD, BD, BD, GR, GR, TR, GR, GR, GR],
    [GR, GR, GR, TG, GR, TR, GR, WA, WA, GR, TR, GR, GR, TG, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, WA, WA, GR, GR, GR, GR, GR, GR, GR],
], enemies=[("slime", 3, 3), ("slime", 12, 8), ("bat", 5, 6), ("bat", 14, 2)], items=[("rupee", 1, 1), ("rupee", 14, 5), ("rupee", 1, 10)])

SCREEN_EAST_FIELD = _screen("East Field", [
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, TR, GR, GR, GR, GR, GR, GR, TR, GR, GR, GR, GR, GR, GR],
    [GR, TR, GR, GR, TG, GR, GR, GR, GR, GR, GR, TG, GR, TR, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, TR, GR, TR, GR, GR, GR, GR, GR, TR, GR],
    [GR, GR, TG, GR, GR, GR, GR, GR, GR, GR, GR, GR, TG, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, TR, GR, GR, GR, GR, GR, TG, GR, GR, GR, GR, GR, TR, GR, GR],
    [GR, GR, GR, TG, GR, GR, GR, GR, GR, TG, GR, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, TR, GR, GR, TR, GR, GR, GR, GR, GR, TR, GR],
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
], enemies=[("slime", 7, 4), ("slime", 12, 8), ("knight", 3, 2), ("mage", 13, 6), ("moblin", 10, 2)], items=[("rupee", 1, 1), ("rupee", 14, 1), ("rupee", 14, 10)])


# ══════════════════════════════════════════
#  ROW 4: Graveyard, South Woods, Link's House, Open Field, Witch Hut, East Lake
# ══════════════════════════════════════════

SCREEN_LINKS_HOUSE = _screen("Link's House", [
    [GR, GR, TR, GR, PA, PA, GR, GR, GR, GR, TR, GR, TG, GR, GR, GR],
    [GR, GR, GR, GR, PA, PA, GR, GR, GR, GR, GR, TR, GR, GR, GR, GR],
    [TR, GR, GR, PA, PA, GR, GR, GR, GR, GR, GR, GR, GR, GR, TR, GR],
    [GR, GR, PA, PA, GR, GR, GR, GR, HRL,HRM,HRR,GR, GR, GR, GR, GR],
    [GR, PA, PA, GR, GR, GR, GR, GR, HWL,HWM,HWR,GR, TG, GR, GR, GR],
    [GR, PA, PA, GR, GR, GR, GR, GR, HBL,HBM,HBR,GR, GR, TR, GR, GR],
    [GR, PA, PA, GR, TG, GR, GR, GR, GR, PA, GR, GR, GR, GR, GR, GR],
    [GR, PA, PA, PA, GR, GR, GR, GR, GR, PA, PA, GR, TG, GR, GR, GR],
    [GR, GR, PA, PA, PA, PA, PA, PA, PA, PA, PA, GR, GR, GR, GR, TR],
    [GR, GR, GR, GR, GR, PA, PA, GR, GR, GR, PA, PA, GR, GR, GR, GR],
    [TR, GR, TG, GR, GR, GR, GR, GR, GR, GR, GR, PA, PA, TG, GR, GR],
    [GR, GR, GR, GR, TR, GR, GR, GR, GR, GR, GR, GR, PA, PA, GR, GR],
], enemies=[("slime", 13, 3), ("slime", 14, 7)], npcs=[
    ("Uncle", 4, 3, ["Be careful out there, Link!", "Take the path north to the castle.", "Your sword is your best friend."], (160, 140, 100)),
], items=[("rupee", 14, 1), ("rupee", 1, 11)], signs=[(3, 8, "Link's House  \u2190  Castle \u2192")])

SCREEN_GRAVEYARD = _screen("Graveyard", [
    [CF, CF, CF, CF, CF, CF, GR, GR, GR, GR, GR, GR, GR, CF, CF, CF],
    [CF, GR, GR, GR, GR, GR, GR, PA, PA, GR, GR, GR, GR, GR, GR, CF],
    [GR, GR, CW, CW, GR, GR, PA, PA, GR, GR, CW, CW, GR, GR, GR, GR],
    [GR, GR, CW, CW, GR, PA, PA, GR, GR, GR, CW, CW, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, PA, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, CW, CW, GR, PA, GR, GR, CW, CW, GR, GR, CW, CW, GR, GR],
    [GR, GR, CW, CW, GR, PA, GR, GR, CW, CW, GR, GR, CW, CW, GR, GR],
    [GR, GR, GR, GR, PA, PA, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, CW, CW, PA, GR, GR, CW, CW, GR, GR, CW, CW, GR, GR, GR],
    [GR, GR, CW, CW, PA, GR, GR, CW, CW, GR, GR, CW, CW, GR, GR, GR],
    [GR, GR, GR, GR, PA, PA, PA, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [CF, CF, CF, CF, CF, PA, PA, GR, GR, CF, CF, CF, CF, CF, CF, CF],
], enemies=[("bat", 4, 2), ("bat", 11, 6), ("skeleton", 8, 4)], items=[("rupee", 13, 2), ("rupee", 1, 8), ("heart_piece", 13, 4)])

SCREEN_SOUTH_WOODS = _screen("South Woods", [
    [TR, TR, GR, GR, GR, PA, PA, GR, GR, GR, TR, TR, GR, GR, TR, TR],
    [TR, GR, GR, TG, GR, GR, PA, PA, GR, GR, GR, TR, GR, GR, GR, TR],
    [GR, GR, TG, GR, GR, GR, GR, PA, GR, GR, GR, GR, GR, TG, GR, GR],
    [GR, GR, GR, GR, TR, GR, GR, PA, GR, TR, GR, GR, GR, GR, GR, GR],
    [TR, GR, GR, GR, GR, GR, PA, PA, GR, GR, GR, GR, TR, GR, GR, GR],
    [GR, GR, TG, GR, GR, PA, PA, GR, GR, GR, TG, GR, GR, GR, GR, TR],
    [GR, GR, GR, GR, PA, PA, GR, GR, GR, GR, GR, GR, GR, TG, GR, GR],
    [TR, GR, GR, PA, PA, GR, GR, GR, TG, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, PA, PA, GR, GR, GR, GR, GR, GR, GR, TR, GR, GR, GR, TR],
    [GR, PA, PA, GR, GR, GR, TR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [PA, PA, GR, GR, TG, GR, GR, GR, GR, TG, GR, GR, GR, TG, GR, GR],
    [PA, GR, GR, GR, GR, TR, GR, GR, GR, GR, GR, TR, GR, GR, GR, GR],
], enemies=[("slime", 3, 5), ("octorok", 10, 2), ("bat", 7, 8)], items=[("heart_piece", 14, 10)])

SCREEN_OPEN_FIELD = _screen("Open Field", [
    [GR, GR, GR, TG, GR, GR, PA, PA, GR, GR, GR, TG, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, PA, PA, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, TG, GR, GR, PA, PA, GR, GR, GR, GR, TG, GR, GR, GR, TG, GR],
    [GR, GR, GR, PA, PA, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, PA, PA, GR, GR, GR, FL, FL, GR, GR, GR, GR, GR, GR, GR],
    [GR, PA, PA, GR, GR, GR, FL, GR, GR, FL, GR, GR, TG, GR, GR, GR],
    [GR, PA, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [PA, PA, GR, GR, TG, GR, GR, GR, GR, GR, GR, GR, GR, GR, TR, GR],
    [PA, GR, GR, GR, GR, GR, GR, GR, GR, GR, TG, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, TR, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, TG, GR, GR, GR, GR, GR, GR, GR, GR, GR, TG, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
], enemies=[("slime", 9, 3), ("slime", 5, 9)], items=[("heart_piece", 7, 5)])

SCREEN_WITCH_HUT = _screen("Witch's Hut", [
    [TR, GR, GR, PA, PA, GR, GR, GR, GR, TR, GR, GR, GR, GR, WA, WA],
    [GR, GR, PA, PA, GR, GR, GR, GR, GR, GR, GR, GR, GR, WA, WA, WA],
    [GR, PA, PA, GR, GR, HRL,HRM,HRR,GR, GR, GR, GR, WA, WA, GR, GR],
    [GR, PA, GR, GR, GR, HWL,HWM,HWR,GR, GR, GR, WA, WA, GR, GR, GR],
    [PA, PA, GR, GR, GR, HBL,HBM,HBR,GR, GR, WA, WA, GR, GR, GR, GR],
    [PA, GR, GR, GR, GR, GR, PA, GR, GR, WA, WA, GR, GR, GR, GR, GR],
    [GR, GR, TG, GR, GR, GR, PA, GR, WA, WA, GR, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, PA, PA, WA, WA, GR, GR, GR, GR, TG, GR, GR],
    [GR, TR, GR, GR, PA, PA, WA, WA, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, GR, PA, PA, WA, WA, GR, GR, GR, TR, GR, GR, GR, GR, GR],
    [GR, GR, PA, PA, WA, WA, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, PA, PA, WA, WA, GR, GR, GR, GR, GR, GR, GR, TG, GR, GR, GR],
], enemies=[("bat", 10, 4), ("bat", 12, 8)], items=[("rupee", 14, 1), ("rupee", 14, 10), ("rupee", 1, 5)])

SCREEN_EAST_LAKE = _screen("Eastern Lake", [
    [GR, GR, GR, GR, GR, GR, WA, WA, WA, WA, WA, DW, DW, DW, DW, DW],
    [GR, GR, GR, GR, GR, WA, WA, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [GR, GR, GR, GR, WA, WA, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [GR, GR, GR, WA, WA, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [GR, GR, WA, WA, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [GR, WA, WA, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [GR, WA, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [WA, WA, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [WA, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [WA, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
])


# ══════════════════════════════════════════
#  ROW 5: Desert, South Field, Meadow, Lake Hylia
# ══════════════════════════════════════════

SCREEN_DESERT_NORTH = _screen("Desert North", [
    [SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA],
    [SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA],
    [SA, SA, SA, SA, SA, BU, SA, SA, SA, SA, BU, SA, SA, SA, SA, SA],
    [SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA],
    [SA, SA, BU, SA, SA, SA, SA, SA, SA, SA, SA, SA, BU, SA, SA, SA],
    [SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA],
    [SA, SA, SA, SA, SA, SA, BU, SA, BU, SA, SA, SA, SA, SA, SA, SA],
    [SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA],
    [SA, SA, SA, BU, SA, SA, SA, SA, SA, SA, SA, BU, SA, SA, SA, SA],
    [SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA],
    [SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA],
    [SA, SA, SA, SA, GR, GR, GR, GR, GR, GR, GR, SA, SA, SA, SA, SA],
], enemies=[("slime", 6, 4), ("slime", 10, 8), ("skeleton", 3, 2), ("skeleton", 13, 6), ("mage", 8, 10)], npcs=[
    ("Desert Nomad", 11, 3, ["The desert hides many secrets.", "Beware the sandstorms!"], (240, 200, 100)),
], items=[("heart_piece", 12, 3)], signs=[(8, 2, "DANGER \u2014 Desert ahead! Bring water.")])

SCREEN_DESERT_PALACE = _screen("Desert Palace", [
    [SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA],
    [SA, SA, SA, SA, CW, CW, CW, CW, CW, CW, CW, SA, SA, SA, SA, SA],
    [SA, SA, SA, CW, TO, SA, SA, SA, SA, SA, TO, CW, SA, SA, SA, SA],
    [SA, SA, SA, CW, SA, SA, SA, SA, SA, SA, SA, CW, SA, SA, SA, SA],
    [SA, SA, SA, CW, SA, SA, SA, SA, SA, SA, SA, CW, SA, SA, SA, SA],
    [SA, SA, SA, CW, SA, SA, DN, SA, DN, SA, SA, CW, SA, SA, SA, SA],
    [SA, SA, SA, CW, SA, SA, SA, SA, SA, SA, SA, CW, SA, SA, SA, SA],
    [SA, SA, SA, CW, TO, SA, SA, SA, SA, SA, TO, CW, SA, SA, SA, SA],
    [SA, SA, SA, SA, CW, CW, CW, CW, CW, CW, CW, SA, SA, SA, SA, SA],
    [SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA],
    [SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA],
    [SA, SA, SA, SA, SA, SA, GR, GR, GR, SA, SA, SA, SA, SA, SA, SA],
], enemies=[("bat", 5, 4), ("bat", 10, 6), ("skeleton", 7, 2), ("mage", 12, 9)], items=[("heart", 6, 9), ("rupee", 2, 1)], dungeon=1)

SCREEN_SOUTH_FIELD = _screen("South Field", [
    [GR, GR, GR, GR, GR, GR, GR, PA, PA, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, PA, PA, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, TR, GR, GR, GR, GR, PA, PA, GR, GR, GR, TR, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, TG, GR, GR, GR, GR, TG, GR, GR, GR, GR, GR, GR],
    [GR, TR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, TR, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, TG, GR, GR, GR, GR, GR, GR, GR, GR, TG, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, TR, GR, GR, TR, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [SA, SA, SA, SA, GR, GR, GR, GR, GR, GR, GR, SA, SA, SA, SA, SA],
    [SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA],
], enemies=[("slime", 7, 5), ("slime", 3, 8)], npcs=[
    ("Traveler", 8, 6, ["I heard there's treasure in the desert.", "And a palace hidden in the swamp..."], (140, 160, 120)),
], signs=[(7, 3, "West: Desert  East: Lake Hylia")])

SCREEN_MEADOW = _screen("Meadow", [
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, FL, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, FL, GR, GR, GR],
    [GR, GR, GR, FL, GR, GR, GR, GR, GR, GR, GR, FL, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, TR, GR, GR, TR, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, FL, GR, GR, GR, GR, GR, GR, GR, GR, FL, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, FL, GR, FL, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, GR, TR, GR, GR, GR, GR, GR, GR, TR, GR, GR, GR, GR, GR],
    [GR, FL, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, FL, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, WA, WA, WA, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, WA, WA, DW, WA, WA, GR, GR, GR, GR, GR, GR],
], enemies=[("slime", 5, 5), ("slime", 11, 3)], items=[("heart_piece", 6, 9)], fairy=(8, 5))

SCREEN_LAKE_HYLIA_N = _screen("Lake Hylia North", [
    [GR, GR, GR, GR, WA, WA, WA, WA, WA, WA, WA, WA, GR, GR, GR, GR],
    [GR, GR, GR, WA, WA, DW, DW, DW, DW, DW, DW, WA, WA, GR, GR, GR],
    [GR, GR, WA, WA, DW, DW, DW, DW, DW, DW, DW, DW, WA, WA, GR, GR],
    [GR, WA, WA, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, WA, GR, GR],
    [GR, WA, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, WA, GR, GR],
    [WA, WA, DW, DW, DW, GR, GR, GR, GR, GR, DW, DW, DW, WA, WA, GR],
    [WA, DW, DW, DW, DW, GR, GR, TR, GR, GR, DW, DW, DW, DW, WA, GR],
    [WA, DW, DW, DW, DW, GR, GR, GR, GR, GR, DW, DW, DW, DW, WA, GR],
    [WA, WA, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, WA, WA, GR],
    [GR, WA, WA, DW, DW, DW, DW, DW, DW, DW, DW, DW, WA, WA, GR, GR],
    [GR, GR, WA, WA, DW, DW, DW, DW, DW, DW, DW, WA, WA, GR, GR, GR],
    [GR, GR, GR, WA, WA, WA, WA, WA, WA, WA, WA, WA, GR, GR, GR, GR],
], enemies=[("bat", 7, 6), ("slime", 4, 5), ("slime", 11, 7), ("bat", 2, 2)], npcs=[
    ("Fisherman", 7, 6, ["The lake used to be peaceful.", "Now monsters lurk beneath..."], (100, 180, 220)),
], items=[("heart_piece", 3, 8)], signs=[(3, 2, "Lake Hylia \u2014 Home of the Zoras")])

SCREEN_LAKE_HYLIA_E = _screen("Lake Hylia East", [
    [DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, GR, GR, GR, GR, GR],
    [DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, GR, GR, GR, GR, GR, GR],
    [DW, DW, DW, DW, DW, DW, DW, DW, DW, GR, GR, GR, GR, GR, GR, GR],
    [DW, DW, DW, DW, DW, DW, DW, DW, GR, GR, GR, GR, GR, GR, GR, GR],
    [DW, DW, DW, DW, DW, DW, DW, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [DW, DW, DW, DW, DW, DW, WA, WA, GR, GR, GR, GR, GR, GR, GR, GR],
    [DW, DW, DW, DW, DW, WA, WA, GR, GR, GR, TR, GR, GR, GR, GR, GR],
    [DW, DW, DW, DW, WA, WA, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [DW, DW, DW, WA, WA, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [DW, DW, WA, WA, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [DW, WA, WA, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
], enemies=[("slime", 11, 5), ("bat", 13, 8)])


# ══════════════════════════════════════════
#  ROW 6: Swamp, South Shore, Lake Hylia South, Lake Island, Ice Cave
# ══════════════════════════════════════════

SCREEN_SWAMP_NORTH = _screen("Swamp North", [
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [SA, SA, SA, SA, GR, GR, GR, GR, GR, GR, GR, SA, SA, SA, SA, SA],
    [SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA, SA],
    [SW, SW, SA, SA, SW, SW, SW, SW, SW, SW, SA, SA, SW, SW, SW, SW],
    [SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW],
    [SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW],
    [SW, SW, SW, BU, SW, SW, SW, SW, SW, SW, BU, SW, SW, SW, SW, SW],
    [SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW],
    [SW, SW, SW, SW, SW, SW, WA, WA, WA, SW, SW, SW, SW, SW, SW, SW],
    [SW, SW, SW, SW, SW, WA, WA, WA, WA, WA, SW, SW, SW, SW, SW, SW],
    [SW, SW, SW, SW, WA, WA, DW, DW, DW, WA, WA, SW, SW, SW, SW, SW],
], enemies=[("slime", 7, 7), ("bat", 13, 5), ("skeleton", 4, 9), ("skeleton", 11, 6), ("slime", 2, 5)], npcs=[
    ("Witch", 8, 1, ["Heh heh... brave adventurer.", "The swamp palace holds great power.", "But also great danger!"], (180, 100, 220)),
])

SCREEN_SWAMP_PALACE = _screen("Swamp Palace", [
    [SW, SW, SW, SW, WA, WA, DW, DW, DW, WA, WA, SW, SW, SW, SW, SW],
    [SW, SW, SW, SW, SW, SW, WA, WA, WA, SW, SW, SW, SW, SW, SW, SW],
    [SW, SW, SW, CW, CW, CW, CW, CW, CW, CW, CW, SW, SW, SW, SW, SW],
    [SW, SW, CW, TO, SW, SW, SW, SW, SW, SW, TO, CW, SW, SW, SW, SW],
    [SW, SW, CW, SW, SW, SW, SW, SW, SW, SW, SW, CW, SW, SW, SW, SW],
    [SW, SW, CW, SW, DN, SW, SW, SW, DN, SW, SW, CW, SW, SW, SW, SW],
    [SW, SW, CW, SW, SW, SW, SW, SW, SW, SW, SW, CW, SW, SW, SW, SW],
    [SW, SW, CW, TO, SW, SW, SW, SW, SW, SW, TO, CW, SW, SW, SW, SW],
    [SW, SW, SW, CW, CW, CW, CW, CW, CW, CW, CW, SW, SW, SW, SW, SW],
    [SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW],
    [SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW],
    [SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW, SW],
], enemies=[("bat", 5, 5), ("bat", 10, 4), ("slime", 7, 7), ("skeleton", 4, 3)], items=[("heart", 6, 8), ("rupee", 2, 10)], dungeon=3)

SCREEN_SOUTH_SHORE = _screen("South Shore", [
    [GR, GR, GR, GR, GR, GR, GR, PA, PA, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, PA, PA, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [GR, GR, TR, GR, GR, GR, GR, GR, GR, GR, GR, TR, GR, GR, GR, GR],
    [GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR],
    [WA, WA, WA, GR, GR, GR, GR, GR, GR, GR, GR, GR, WA, WA, WA, WA],
    [WA, DW, WA, WA, GR, GR, GR, GR, GR, GR, GR, WA, WA, DW, DW, DW],
    [DW, DW, DW, WA, WA, GR, GR, GR, GR, GR, WA, WA, DW, DW, DW, DW],
    [DW, DW, DW, DW, WA, WA, GR, GR, GR, WA, WA, DW, DW, DW, DW, DW],
    [DW, DW, DW, DW, DW, WA, WA, WA, WA, WA, DW, DW, DW, DW, DW, DW],
    [DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
], enemies=[("slime", 7, 3), ("slime", 12, 1), ("bat", 3, 6)], items=[("rupee", 1, 1), ("rupee", 14, 4), ("bombs", 14, 1)], fairy=(7, 6))

SCREEN_LAKE_HYLIA_S = _screen("Lake Hylia South", [
    [DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
], enemies=[("slime", 6, 3), ("bat", 12, 7)])

SCREEN_LAKE_ISLAND = _screen("Lake Island", [
    [DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [DW, DW, DW, DW, DW, WA, WA, WA, WA, WA, DW, DW, DW, DW, DW, DW],
    [DW, DW, DW, DW, WA, GR, GR, GR, GR, GR, WA, DW, DW, DW, DW, DW],
    [DW, DW, DW, DW, WA, GR, TR, GR, TR, GR, WA, DW, DW, DW, DW, DW],
    [DW, DW, DW, DW, WA, GR, GR, FL, GR, GR, WA, DW, DW, DW, DW, DW],
    [DW, DW, DW, DW, WA, GR, TR, GR, TR, GR, WA, DW, DW, DW, DW, DW],
    [DW, DW, DW, DW, WA, GR, GR, GR, GR, GR, WA, DW, DW, DW, DW, DW],
    [DW, DW, DW, DW, DW, WA, WA, WA, WA, WA, DW, DW, DW, DW, DW, DW],
    [DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
], enemies=[("bat", 7, 4), ("slime", 5, 7)])

SCREEN_ICE_CAVE = _screen("Ice Cave", [
    [MN, MN, MN, MN, MN, MN, MN, MN, MN, MN, MN, MN, MN, MN, MN, MN],
    [MN, MN, CF, CF, MN, MN, MN, CF, MN, MN, MN, CF, CF, MN, MN, MN],
    [MN, CF, MN, MN, MN, CF, CF, MN, MN, MN, CF, MN, MN, MN, CF, MN],
    [CF, MN, MN, MN, CF, MN, MN, CF, MN, CF, MN, MN, MN, CF, MN, MN],
    [MN, MN, CV, MN, MN, MN, CF, MN, MN, MN, MN, CF, MN, MN, MN, CF],
    [MN, CF, MN, MN, PA, PA, MN, MN, CF, MN, MN, MN, CF, MN, MN, MN],
    [CF, MN, MN, PA, PA, MN, MN, CF, MN, MN, CF, MN, MN, MN, MN, CF],
    [MN, MN, CF, PA, MN, MN, CF, MN, MN, CF, MN, MN, MN, CF, MN, MN],
    [MN, CF, MN, MN, CF, MN, MN, MN, CF, MN, MN, MN, CF, MN, MN, MN],
    [CF, MN, MN, CF, MN, MN, CF, MN, MN, MN, CF, MN, MN, CF, MN, MN],
    [MN, MN, CF, MN, MN, CF, MN, MN, MN, CF, MN, MN, CF, MN, MN, MN],
    [MN, CF, CF, MN, CF, MN, MN, CF, MN, MN, MN, CF, CF, MN, MN, CF],
], enemies=[("bat", 4, 4), ("bat", 10, 2)], items=[("heart_piece", 2, 3), ("rupee", 14, 1), ("rupee", 14, 10)])


# ══════════════════════════════════════════
#  ASSEMBLE FULL OVERWORLD (8×8 grid)
# ══════════════════════════════════════════

OVERWORLD = {}

# Auto-generate boundary screens for all edge positions
for _col in range(8):
    for _row in range(8):
        if _col == 0 or _col == 7 or _row == 0 or _row == 7:
            OVERWORLD[(_col, _row)] = _boundary_screen()

# Row 0: Death Mountain (playable screens at cols 2-5)
OVERWORLD[(2, 0)] = SCREEN_DEATH_MTN_WEST
OVERWORLD[(3, 0)] = SCREEN_DEATH_MTN_TOWER
OVERWORLD[(4, 0)] = SCREEN_DEATH_MTN_EAST
OVERWORLD[(5, 0)] = SCREEN_DEATH_MTN_CLIFFS

# Row 1
OVERWORLD[(1, 1)] = SCREEN_LOST_WOODS_N
OVERWORLD[(2, 1)] = SCREEN_LOST_WOODS_S
OVERWORLD[(3, 1)] = SCREEN_CASTLE_NORTH
OVERWORLD[(4, 1)] = SCREEN_CASTLE_TOWER
OVERWORLD[(5, 1)] = SCREEN_RIVER_NORTH
OVERWORLD[(6, 1)] = SCREEN_EAST_RUINS

# Row 2
OVERWORLD[(1, 2)] = SCREEN_FOREST_CLEARING
OVERWORLD[(2, 2)] = SCREEN_KAKARIKO_NORTH
OVERWORLD[(3, 2)] = SCREEN_CASTLE_GATE
OVERWORLD[(4, 2)] = SCREEN_CASTLE_GARDEN
OVERWORLD[(5, 2)] = SCREEN_RIVER_BRIDGE
OVERWORLD[(6, 2)] = SCREEN_EASTERN_PALACE

# Row 3
OVERWORLD[(1, 3)] = SCREEN_KAKARIKO_SOUTH
OVERWORLD[(2, 3)] = SCREEN_CENTRAL_FIELD_W
OVERWORLD[(3, 3)] = SCREEN_CENTRAL_FIELD
OVERWORLD[(4, 3)] = SCREEN_CENTRAL_FIELD_E
OVERWORLD[(5, 3)] = SCREEN_RIVER_SOUTH
OVERWORLD[(6, 3)] = SCREEN_EAST_FIELD

# Row 4
OVERWORLD[(1, 4)] = SCREEN_GRAVEYARD
OVERWORLD[(2, 4)] = SCREEN_SOUTH_WOODS
OVERWORLD[(3, 4)] = SCREEN_LINKS_HOUSE
OVERWORLD[(4, 4)] = SCREEN_OPEN_FIELD
OVERWORLD[(5, 4)] = SCREEN_WITCH_HUT
OVERWORLD[(6, 4)] = SCREEN_EAST_LAKE

# Row 5
OVERWORLD[(1, 5)] = SCREEN_DESERT_NORTH
OVERWORLD[(2, 5)] = SCREEN_DESERT_PALACE
OVERWORLD[(3, 5)] = SCREEN_SOUTH_FIELD
OVERWORLD[(4, 5)] = SCREEN_MEADOW
OVERWORLD[(5, 5)] = SCREEN_LAKE_HYLIA_N
OVERWORLD[(6, 5)] = SCREEN_LAKE_HYLIA_E

# Row 6
OVERWORLD[(1, 6)] = SCREEN_SWAMP_NORTH
OVERWORLD[(2, 6)] = SCREEN_SWAMP_PALACE
OVERWORLD[(3, 6)] = SCREEN_SOUTH_SHORE
OVERWORLD[(4, 6)] = SCREEN_LAKE_HYLIA_S
OVERWORLD[(5, 6)] = SCREEN_LAKE_ISLAND
OVERWORLD[(6, 6)] = SCREEN_ICE_CAVE

# ══════════════════════════════════════════
#  DUNGEON ENTRIES — screen position → dungeon level
# ══════════════════════════════════════════

DUNGEON_ENTRIES = {
    # Format: screen_pos → dungeon_level
    (6, 2): 0,   # Eastern Palace → Level 0
    (2, 5): 1,   # Desert Palace → Level 1
    (3, 1): 2,   # Castle → Level 2
    (2, 6): 3,   # Swamp Palace → Level 3
    (3, 0): 4,   # Death Mountain Tower → Level 4 (Boss)
}

# ══════════════════════════════════════════
#  STARTING POSITION
# ══════════════════════════════════════════

START_SCREEN = (3, 4)
START_X = 3 * 16 + 8   # On the wide path left of house
START_Y = 7 * 16 + 8   # On the path intersection
