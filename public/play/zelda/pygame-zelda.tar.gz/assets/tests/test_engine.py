# tests/test_engine.py
"""Tests for overworld engine coordinate math and screen management."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

# Minimal pygame init for Surface creation
import pygame
pygame.init()
pygame.display.set_mode((1, 1))

from overworld_tiles import OW_GRASS, OW_WATER, OW_BOUNDARY, OW_CLIFF_TOP
from overworld_engine import ScreenManager, MAP_COLS, MAP_ROWS, GAME_Y, NATIVE_W, CACHE_H

def _make_screen(fill_tile=OW_GRASS, boundary=False):
    return {
        "tiles": [[fill_tile] * MAP_COLS for _ in range(MAP_ROWS)],
        "enemies": [],
        "boundary": boundary,
    }

def _make_overworld():
    return {
        (1, 1): _make_screen(),
        (2, 1): _make_screen(),
        (1, 2): _make_screen(),
        (0, 0): _make_screen(OW_BOUNDARY, boundary=True),
    }

def test_enter_screen_sets_current():
    mgr = ScreenManager(_make_overworld())
    mgr.enter_screen((1, 1))
    assert mgr.current == (1, 1)

def test_enter_screen_caches_neighbors():
    mgr = ScreenManager(_make_overworld())
    mgr.enter_screen((1, 1))
    assert (1, 1) in mgr.cache
    assert (2, 1) in mgr.cache  # right neighbor
    assert (1, 2) in mgr.cache  # down neighbor

def test_transition_to_boundary_blocked():
    mgr = ScreenManager(_make_overworld())
    mgr.enter_screen((1, 1))
    result = mgr.start_transition("left")  # goes to (0,1) which doesn't exist
    assert result == False

def test_transition_to_valid_screen():
    mgr = ScreenManager(_make_overworld())
    mgr.enter_screen((1, 1))
    result = mgr.start_transition("right")  # goes to (2,1)
    assert result == True
    assert mgr.in_transition == True

def test_transition_completes():
    mgr = ScreenManager(_make_overworld())
    mgr.enter_screen((1, 1))
    mgr.start_transition("right")
    for _ in range(16):
        mgr.update_transition()
    assert mgr.current == (2, 1)
    assert mgr.in_transition == False

def test_edge_detection_left():
    mgr = ScreenManager(_make_overworld())
    mgr.enter_screen((1, 1))
    assert mgr.check_edge(0, 100, 16, 24) == "left"

def test_edge_detection_none_center():
    mgr = ScreenManager(_make_overworld())
    mgr.enter_screen((1, 1))
    assert mgr.check_edge(128, 120, 16, 24) is None

def test_cut_tile_tracked():
    mgr = ScreenManager(_make_overworld())
    mgr.enter_screen((1, 1))
    mgr.cut_tile((1, 1), 5, 3)
    assert mgr.get_tile((1, 1), 5, 3) == OW_GRASS

def test_player_entry_pos_from_right():
    mgr = ScreenManager(_make_overworld())
    x, y = mgr.get_player_entry_pos("right")
    assert x == 20  # Appears on left side
    assert y is None  # Keep existing y

if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    passed = failed = 0
    for t in tests:
        try:
            t()
            passed += 1
            print(f"  PASS  {t.__name__}")
        except (AssertionError, Exception) as e:
            failed += 1
            print(f"  FAIL  {t.__name__}: {e}")
    print(f"\n{passed} passed, {failed} failed")
    pygame.quit()
