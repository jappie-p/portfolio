# tests/test_tiles.py
"""Tests for overworld tile system."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from overworld_tiles import (
    OW_GRASS, OW_WATER, OW_CLIFF_FACE, OW_CLIFF_TOP, OW_TALL_GRASS,
    OW_BUSH, OW_PATH, OW_BRIDGE, OW_DUNGEON, OW_BOUNDARY,
    TILE_PROPS, is_walkable
)

def test_grass_is_walkable():
    assert is_walkable(OW_GRASS) == True

def test_water_is_not_walkable():
    assert is_walkable(OW_WATER) == False

def test_cliff_face_is_not_walkable():
    assert is_walkable(OW_CLIFF_FACE) == False

def test_cliff_top_ledge_allows_down():
    assert is_walkable(OW_CLIFF_TOP, direction="down") == True

def test_cliff_top_ledge_blocks_up():
    assert is_walkable(OW_CLIFF_TOP, direction="up") == False

def test_cliff_top_no_direction():
    assert is_walkable(OW_CLIFF_TOP) == True

def test_tall_grass_walkable_and_cuttable():
    assert is_walkable(OW_TALL_GRASS) == True
    assert TILE_PROPS[OW_TALL_GRASS]["cuttable"] == True

def test_bush_not_walkable_but_cuttable():
    assert is_walkable(OW_BUSH) == False
    assert TILE_PROPS[OW_BUSH]["cuttable"] == True

def test_bridge_walkable():
    assert is_walkable(OW_BRIDGE) == True

def test_dungeon_entrance_walkable():
    assert is_walkable(OW_DUNGEON) == True
    assert TILE_PROPS[OW_DUNGEON].get("entrance") == True

def test_boundary_not_walkable():
    assert is_walkable(OW_BOUNDARY) == False

def test_dungeon_tile_passthrough():
    """Dungeon tiles (ID < 100) use old logic."""
    assert is_walkable(0) == True    # G = grass
    assert is_walkable(1) == False   # W = wall
    assert is_walkable(2) == True    # P = path
    assert is_walkable(3) == False   # Q = water
    assert is_walkable(7) == False   # L = lava

def test_all_tiles_have_properties():
    """Every tile constant should have an entry in TILE_PROPS."""
    for tile_id, props in TILE_PROPS.items():
        assert "walkable" in props, f"Tile {tile_id} missing 'walkable'"
        assert "animated" in props, f"Tile {tile_id} missing 'animated'"

if __name__ == "__main__":
    tests = [v for k, v in globals().items() if k.startswith("test_")]
    passed = failed = 0
    for t in tests:
        try:
            t()
            passed += 1
            print(f"  PASS  {t.__name__}")
        except AssertionError as e:
            failed += 1
            print(f"  FAIL  {t.__name__}: {e}")
    print(f"\n{passed} passed, {failed} failed")
