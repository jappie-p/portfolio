"""Tests for tileset loading system."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import pygame
pygame.init()
pygame.display.set_mode((1, 1))

from tileset import Tileset, TilesetManager, AutoTiler

def test_tileset_missing_file():
    ts = Tileset("nonexistent.png")
    assert ts.loaded == False
    assert ts.get_tile(0, 0) is None

def test_tileset_manager_no_sprites():
    mgr = TilesetManager("nonexistent_dir")
    assert mgr.get_tile(100) is None
    assert mgr.has_tile(100) == False

def test_tileset_manager_draw_returns_false():
    mgr = TilesetManager()
    surf = pygame.Surface((16, 16))
    assert mgr.draw_tile(surf, 100, 0, 0) == False

def test_autotiler_neighbor_mask_center():
    """A tile surrounded by same group should have mask 255."""
    at = AutoTiler()
    at.set_group("grass", {1})
    tiles = [[1]*5 for _ in range(5)]
    mask = at.get_neighbor_mask(tiles, 2, 2, "grass")
    assert mask == 255

def test_autotiler_neighbor_mask_corner():
    """Top-left corner has limited neighbors."""
    at = AutoTiler()
    at.set_group("grass", {1})
    tiles = [[1]*3 for _ in range(3)]
    mask = at.get_neighbor_mask(tiles, 0, 0, "grass")
    # N, NE, NW are out of bounds (counted as same group)
    # So all bits should be set
    assert mask == 255

def test_autotiler_neighbor_mask_edge():
    """A grass tile with water to the east."""
    at = AutoTiler()
    at.set_group("grass", {1})
    tiles = [
        [1, 1, 2],
        [1, 1, 2],
        [1, 1, 2],
    ]
    mask = at.get_neighbor_mask(tiles, 1, 1, "grass")
    # E, NE, SE should NOT be set (they're water=2)
    assert not (mask & (1 << 1))  # NE not set
    assert not (mask & (1 << 2))  # E not set
    assert not (mask & (1 << 3))  # SE not set

def test_select_variant_returns_base():
    """Without sprite variants loaded, should return base tile."""
    at = AutoTiler()
    at.set_group("grass", {1})
    tiles = [[1]*3 for _ in range(3)]
    result = at.select_variant(tiles, 1, 1, 1, "grass")
    assert result == 1

if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    passed = failed = 0
    for t in tests:
        try:
            t()
            passed += 1
            print(f"  PASS  {t.__name__}")
        except (AssertionError, Exception) as e:
            failed += 1
            print(f"  FAIL  {t.__name__}: {e}")
    print(f"\n{passed} passed, {failed} failed")
    pygame.quit()
