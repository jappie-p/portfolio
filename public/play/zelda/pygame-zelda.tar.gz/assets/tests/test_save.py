"""Tests for save system."""
import sys, os, tempfile, shutil
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import save_system

# Use temp directory for test saves
_original_dir = save_system.SAVE_DIR

def setup():
    save_system.SAVE_DIR = tempfile.mkdtemp()

def teardown():
    shutil.rmtree(save_system.SAVE_DIR, ignore_errors=True)
    save_system.SAVE_DIR = _original_dir

def test_save_and_load():
    setup()
    try:
        data = {"player_hp": 6, "rupees": 42, "completed_dungeons": [0, 1]}
        save_system.save_game(1, data)
        loaded = save_system.load_game(1)
        assert loaded["player_hp"] == 6
        assert loaded["rupees"] == 42
        assert loaded["completed_dungeons"] == [0, 1]
    finally:
        teardown()

def test_load_empty_slot():
    setup()
    try:
        assert save_system.load_game(1) is None
    finally:
        teardown()

def test_delete_save():
    setup()
    try:
        save_system.save_game(1, {"player_hp": 6})
        assert save_system.load_game(1) is not None
        save_system.delete_save(1)
        assert save_system.load_game(1) is None
    finally:
        teardown()

def test_list_saves():
    setup()
    try:
        save_system.save_game(1, {"player_hp": 6, "player_max_hp": 8, "completed_dungeons": [0], "play_time_seconds": 300, "player_kills": 15, "game_mode": "overworld"})
        saves = save_system.list_saves()
        assert saves[1]["exists"] == True
        assert saves[1]["completed"] == 1
        assert saves[2]["exists"] == False
        assert saves[3]["exists"] == False
    finally:
        teardown()

def test_format_time():
    assert save_system.format_time(65) == "1:05"
    assert save_system.format_time(3661) == "1:01:01"
    assert save_system.format_time(0) == "0:00"

def test_screen_tuple_preserved():
    setup()
    try:
        save_system.save_game(1, {"current_screen": (3, 4)})
        loaded = save_system.load_game(1)
        assert loaded["current_screen"] == (3, 4)
        assert isinstance(loaded["current_screen"], tuple)
    finally:
        teardown()

if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    passed = failed = 0
    for t in tests:
        try:
            t()
            passed += 1
            print(f"  PASS  {t.__name__}")
        except (AssertionError, Exception) as e:
            failed += 1
            print(f"  FAIL  {t.__name__}: {e}")
    print(f"\n{passed} passed, {failed} failed")
