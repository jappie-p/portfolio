import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import pygame
pygame.init()
pygame.display.set_mode((1, 1))

from dialogue_system import DialogueBox

def test_start_and_advance():
    font = pygame.font.SysFont("arial", 8)
    dlg = DialogueBox(font)
    dlg.start("Elder", ["Line 1", "Line 2"])
    assert dlg.active == True
    assert dlg.current_page == 0

    # Fast-forward reveal
    dlg.reveal_pos = 100
    dlg.fully_revealed = True

    # Advance to next page
    dlg.advance()
    assert dlg.current_page == 1

    # Advance past last page → closes
    dlg.reveal_pos = 100
    dlg.fully_revealed = True
    dlg.advance()
    assert dlg.active == False

def test_advance_reveals_first():
    font = pygame.font.SysFont("arial", 8)
    dlg = DialogueBox(font)
    dlg.start("NPC", ["Hello world"])
    assert dlg.fully_revealed == False

    # Pressing advance while text is revealing → show all
    dlg.advance()
    assert dlg.fully_revealed == True
    assert dlg.current_page == 0  # Still on same page

def test_draw_no_crash():
    font = pygame.font.SysFont("arial", 8)
    dlg = DialogueBox(font)
    surf = pygame.Surface((256, 224))

    # Draw when inactive
    dlg.draw(surf)

    # Draw when active
    dlg.start("Test", ["Testing text"])
    dlg.draw(surf)

if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    passed = failed = 0
    for t in tests:
        try:
            t()
            passed += 1
            print(f"  PASS  {t.__name__}")
        except (AssertionError, Exception) as e:
            failed += 1
            print(f"  FAIL  {t.__name__}: {e}")
    print(f"\n{passed} passed, {failed} failed")
    pygame.quit()
