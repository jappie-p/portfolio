"""
Overworld tile definitions for ALttP Light World recreation.

Tile IDs start at 100 to avoid collision with existing dungeon tiles (0-10).
Each tile type has a draw function and properties (walkable, cuttable, animated).
"""
import pygame
import math
import random

# ══════════════════════════════════════════
#  TILE ID CONSTANTS (100+ to avoid dungeon collision)
# ══════════════════════════════════════════
# Terrain
OW_GRASS       = 100
OW_DARK_GRASS  = 101
OW_PATH        = 102
OW_SAND        = 103
OW_SWAMP       = 104

# Water
OW_WATER       = 110
OW_DEEP_WATER  = 111
OW_WATERFALL   = 112

# Elevation
OW_CLIFF_FACE  = 120
OW_CLIFF_TOP   = 121
OW_CLIFF_LEFT  = 122
OW_CLIFF_RIGHT = 123
OW_CLIFF_TL    = 124
OW_CLIFF_TR    = 125
OW_CLIFF_BL    = 126
OW_CLIFF_BR    = 127
OW_MOUNTAIN    = 128
OW_CAVE        = 129
OW_STAIRS      = 130

# Vegetation
OW_TREE        = 140
OW_DARK_TREE   = 141
OW_BUSH        = 142
OW_TALL_GRASS  = 143
OW_FLOWERS     = 144

# Structures
OW_HOUSE_ROOF  = 150
OW_HOUSE_WALL  = 151
OW_HOUSE_DOOR  = 152
OW_CASTLE_WALL = 153
OW_CASTLE_TOWER= 154
OW_CASTLE_GATE = 155
OW_BRIDGE      = 156
OW_FENCE       = 157
OW_SIGN        = 158
OW_TORCH       = 159

# Special
OW_DUNGEON     = 160
OW_CHEST       = 161
OW_BOUNDARY    = 199

# Short aliases for map data readability
# Note: use GR not G to avoid collision with G=0 (dungeon grass) in main.py
GR = OW_GRASS
DG = OW_DARK_GRASS
PA = OW_PATH
SA = OW_SAND
SW = OW_SWAMP
WA = OW_WATER
DW = OW_DEEP_WATER
WF = OW_WATERFALL
CF = OW_CLIFF_FACE
CT = OW_CLIFF_TOP
CL = OW_CLIFF_LEFT
CR = OW_CLIFF_RIGHT
CB = OW_CLIFF_TL    # corner aliases
CE = OW_CLIFF_TR
BL = OW_CLIFF_BL
BR = OW_CLIFF_BR
MN = OW_MOUNTAIN
CV = OW_CAVE
ST = OW_STAIRS
TR = OW_TREE
DT = OW_DARK_TREE
BU = OW_BUSH
TG = OW_TALL_GRASS
FL = OW_FLOWERS
HR = OW_HOUSE_ROOF
HW = OW_HOUSE_WALL
HD = OW_HOUSE_DOOR
CW = OW_CASTLE_WALL
TO = OW_CASTLE_TOWER
CG = OW_CASTLE_GATE
BD = OW_BRIDGE
FE = OW_FENCE
SI = OW_SIGN
TC = OW_TORCH
DN = OW_DUNGEON
CH = OW_CHEST
BO = OW_BOUNDARY

# ══════════════════════════════════════════
#  MULTI-TILE STRUCTURE VARIANTS
# ══════════════════════════════════════════
# These tile IDs represent specific parts of multi-tile structures.
# They render as part of a larger composition.

# House variants (a house is 3 wide × 3 tall)
OW_HOUSE_ROOF_L  = 170  # Left roof edge
OW_HOUSE_ROOF_M  = 171  # Middle roof (peak + chimney)
OW_HOUSE_ROOF_R  = 172  # Right roof edge
OW_HOUSE_WALL_L  = 173  # Left wall
OW_HOUSE_WALL_M  = 174  # Middle wall (with window)
OW_HOUSE_WALL_R  = 175  # Right wall
OW_HOUSE_BASE_L  = 176  # Left base / foundation
OW_HOUSE_BASE_M  = 177  # Middle base (door — walkable, entrance)
OW_HOUSE_BASE_R  = 178  # Right base / foundation

# Castle wall variants
OW_CASTLE_WALL_T = 180  # Castle wall top edge with crenellation
OW_CASTLE_WALL_B = 181  # Castle wall body (lower section)
OW_CASTLE_PARAPET= 182  # Castle parapet / battlement
OW_CASTLE_WINDOW = 183  # Castle wall section with arrow-slit window

# Short aliases for map data readability
HRL = OW_HOUSE_ROOF_L
HRM = OW_HOUSE_ROOF_M
HRR = OW_HOUSE_ROOF_R
HWL = OW_HOUSE_WALL_L
HWM = OW_HOUSE_WALL_M
HWR = OW_HOUSE_WALL_R
HBL = OW_HOUSE_BASE_L
HBM = OW_HOUSE_BASE_M
HBR = OW_HOUSE_BASE_R
CWT = OW_CASTLE_WALL_T
CWB = OW_CASTLE_WALL_B
CPR = OW_CASTLE_PARAPET
CWI = OW_CASTLE_WINDOW

# ══════════════════════════════════════════
#  ALttP COLOR PALETTE
# ══════════════════════════════════════════
# Terrain
GRASS_GREEN     = (72, 184, 72)
GRASS_DOT       = (56, 152, 56)
DARK_GRASS_BASE = (48, 136, 48)
DARK_GRASS_DOT  = (32, 112, 32)
PATH_TAN        = (200, 168, 112)
PATH_DARK       = (184, 152, 96)
SAND_LIGHT      = (232, 216, 160)
SAND_DOT        = (216, 200, 144)
SWAMP_GREEN     = (72, 120, 72)
SWAMP_DARK      = (56, 104, 56)
SWAMP_MUD       = (48, 88, 40)

# Water
WATER_BLUE      = (40, 88, 192)
WATER_LIGHT     = (136, 200, 248)
WATER_MID       = (56, 104, 208)
DEEP_BLUE       = (24, 64, 160)
DEEP_MID        = (40, 80, 184)

# Cliffs (signature ALttP mauve-brown)
CLIFF_MAIN      = (152, 104, 88)
CLIFF_SHADOW    = (120, 80, 64)
CLIFF_LIGHT     = (168, 120, 104)
CLIFF_EDGE      = (40, 120, 40)

# Mountain
ROCK_GRAY       = (128, 128, 120)
ROCK_DARK       = (104, 104, 96)
ROCK_LIGHT      = (152, 152, 144)

# Vegetation
TREE_BASE       = (48, 160, 48)
TREE_HIGHLIGHT  = (88, 200, 88)
TREE_SHADOW     = (32, 136, 32)
TREE_TRUNK      = (128, 96, 48)
DARK_TREE_BASE  = (32, 128, 32)
DARK_TREE_HI    = (56, 160, 56)
DARK_TREE_SH    = (16, 112, 16)

# Structures
HOUSE_ROOF_MAIN = (216, 120, 120)
HOUSE_ROOF_DARK = (184, 96, 96)
HOUSE_WALL_MAIN = (232, 208, 160)
HOUSE_WALL_DARK = (208, 184, 136)
HOUSE_DOOR_MAIN = (160, 112, 48)
HOUSE_DOOR_DARK = (128, 80, 32)
CASTLE_STONE    = (200, 200, 208)
CASTLE_DARK     = (168, 168, 184)
CASTLE_LIGHT    = (224, 224, 232)
WINDOW_BLUE     = (40, 72, 160)
DOOR_HANDLE     = (232, 200, 64)
BRIDGE_WOOD     = (200, 168, 112)
BRIDGE_DARK     = (176, 144, 80)
FENCE_WOOD      = (200, 168, 112)
FENCE_DARK      = (168, 136, 80)
SIGN_BOARD      = (216, 184, 104)
SIGN_DARK       = (184, 152, 72)
SIGN_POST       = (160, 128, 64)

# Special
TORCH_FLAME1    = (248, 216, 0)
TORCH_FLAME2    = (224, 120, 24)
TORCH_FLAME3    = (200, 40, 40)
CAVE_DARK       = (16, 16, 24)
CAVE_FRAME      = (152, 152, 144)

# ══════════════════════════════════════════
#  TILE PROPERTIES
# ══════════════════════════════════════════
TILE_PROPS = {
    OW_GRASS:       {"walkable": True,  "cuttable": False, "animated": False},
    OW_DARK_GRASS:  {"walkable": True,  "cuttable": False, "animated": False},
    OW_PATH:        {"walkable": True,  "cuttable": False, "animated": False},
    OW_SAND:        {"walkable": True,  "cuttable": False, "animated": False},
    OW_SWAMP:       {"walkable": True,  "cuttable": False, "animated": False, "damage": 0},
    OW_WATER:       {"walkable": False, "cuttable": False, "animated": True},
    OW_DEEP_WATER:  {"walkable": False, "cuttable": False, "animated": True},
    OW_WATERFALL:   {"walkable": False, "cuttable": False, "animated": True},
    OW_CLIFF_FACE:  {"walkable": False, "cuttable": False, "animated": False},
    OW_CLIFF_TOP:   {"walkable": True,  "cuttable": False, "animated": False, "ledge": "down"},
    OW_CLIFF_LEFT:  {"walkable": False, "cuttable": False, "animated": False},
    OW_CLIFF_RIGHT: {"walkable": False, "cuttable": False, "animated": False},
    OW_CLIFF_TL:    {"walkable": False, "cuttable": False, "animated": False},
    OW_CLIFF_TR:    {"walkable": False, "cuttable": False, "animated": False},
    OW_CLIFF_BL:    {"walkable": False, "cuttable": False, "animated": False},
    OW_CLIFF_BR:    {"walkable": False, "cuttable": False, "animated": False},
    OW_MOUNTAIN:    {"walkable": False, "cuttable": False, "animated": False},
    OW_CAVE:        {"walkable": True,  "cuttable": False, "animated": False, "entrance": True},
    OW_STAIRS:      {"walkable": True,  "cuttable": False, "animated": False},
    OW_TREE:        {"walkable": False, "cuttable": False, "animated": False, "overlay": True},
    OW_DARK_TREE:   {"walkable": False, "cuttable": False, "animated": False, "overlay": True},
    OW_BUSH:        {"walkable": False, "cuttable": True,  "animated": False},
    OW_TALL_GRASS:  {"walkable": True,  "cuttable": True,  "animated": True},
    OW_FLOWERS:     {"walkable": True,  "cuttable": False, "animated": False},
    OW_HOUSE_ROOF:  {"walkable": False, "cuttable": False, "animated": False},
    OW_HOUSE_WALL:  {"walkable": False, "cuttable": False, "animated": False},
    OW_HOUSE_DOOR:  {"walkable": True,  "cuttable": False, "animated": False, "entrance": True},
    OW_CASTLE_WALL: {"walkable": False, "cuttable": False, "animated": False},
    OW_CASTLE_TOWER:{"walkable": False, "cuttable": False, "animated": False},
    OW_CASTLE_GATE: {"walkable": True,  "cuttable": False, "animated": False, "entrance": True},
    OW_BRIDGE:      {"walkable": True,  "cuttable": False, "animated": False},
    OW_FENCE:       {"walkable": False, "cuttable": False, "animated": False},
    OW_SIGN:        {"walkable": False, "cuttable": False, "animated": False},
    OW_TORCH:       {"walkable": False, "cuttable": False, "animated": True},
    OW_DUNGEON:     {"walkable": True,  "cuttable": False, "animated": False, "entrance": True},
    OW_CHEST:       {"walkable": False, "cuttable": False, "animated": False},
    OW_BOUNDARY:    {"walkable": False, "cuttable": False, "animated": False},
    # Multi-tile structure parts
    OW_HOUSE_ROOF_L:  {"walkable": True, "cuttable": False, "animated": False, "overlay": True},
    OW_HOUSE_ROOF_M:  {"walkable": True, "cuttable": False, "animated": False, "overlay": True},
    OW_HOUSE_ROOF_R:  {"walkable": True, "cuttable": False, "animated": False, "overlay": True},
    OW_HOUSE_WALL_L:  {"walkable": False, "cuttable": False, "animated": False},
    OW_HOUSE_WALL_M:  {"walkable": False, "cuttable": False, "animated": False},
    OW_HOUSE_WALL_R:  {"walkable": False, "cuttable": False, "animated": False},
    OW_HOUSE_BASE_L:  {"walkable": False, "cuttable": False, "animated": False},
    OW_HOUSE_BASE_M:  {"walkable": True,  "cuttable": False, "animated": False, "entrance": True},
    OW_HOUSE_BASE_R:  {"walkable": False, "cuttable": False, "animated": False},
    OW_CASTLE_WALL_T: {"walkable": False, "cuttable": False, "animated": False},
    OW_CASTLE_WALL_B: {"walkable": False, "cuttable": False, "animated": False},
    OW_CASTLE_PARAPET:{"walkable": False, "cuttable": False, "animated": False},
    OW_CASTLE_WINDOW: {"walkable": False, "cuttable": False, "animated": False},
}


def is_walkable(tile_id, direction=None):
    """Check if a tile can be walked on.

    For overworld tiles (ID >= 100), uses TILE_PROPS lookup.
    For dungeon tiles (ID 0-10), uses the existing hardcoded list.

    Args:
        tile_id: The tile type at the target position.
        direction: Optional movement direction ("up"/"down"/"left"/"right")
                   for one-way ledge tiles.

    Returns:
        True if the tile can be walked on.
    """
    if tile_id >= 100:
        props = TILE_PROPS.get(tile_id)
        if props is None:
            return False
        if not props.get("walkable", False):
            return False
        ledge_dir = props.get("ledge")
        if ledge_dir and direction and direction != ledge_dir:
            return False
        return True
    else:
        # Dungeon tiles: existing logic from main.py _wall()
        return tile_id not in (1, 3, 4, 7, 10)  # W, Q, T, L, K


# ══════════════════════════════════════════
#  TILE DRAWING — ALttP-accurate procedural rendering
# ══════════════════════════════════════════
TILE = 16

# ---------- ALttP-style 8x8 grass texture (tiled 2x2 into 16x16) ----------
# Values: 0=base, 1=dark dot, 2=highlight, 3=deep shadow
_GRASS_PAT = [
    [0,0,1,0,0,2,1,0],
    [0,1,0,0,1,0,0,0],
    [1,0,0,1,0,0,0,1],
    [0,0,1,0,0,1,0,0],
    [0,1,0,0,2,0,1,0],
    [1,0,0,0,1,0,0,1],
    [0,0,1,0,0,1,0,0],
    [0,1,0,2,1,0,0,0],
]
_GRASS_COLS = [GRASS_GREEN, GRASS_DOT, (88, 200, 88), (48, 136, 48)]

_DARK_GRASS_PAT = [
    [0,0,1,0,0,2,1,0],
    [0,1,0,0,1,0,0,0],
    [1,0,0,1,0,0,0,1],
    [0,0,1,0,0,1,0,0],
    [0,1,0,0,2,0,1,0],
    [1,0,0,0,1,0,0,1],
    [0,0,1,0,0,1,0,0],
    [0,1,0,2,1,0,0,0],
]
_DARK_GRASS_COLS = [DARK_GRASS_BASE, DARK_GRASS_DOT, (56, 160, 56), (24, 96, 24)]


def _fill_grass_pattern(surf, x, y, pat, cols):
    """Tile an 8x8 pattern 2x2 into a 16x16 tile."""
    for dy in range(16):
        py = dy & 7
        for dx in range(16):
            px = dx & 7
            surf.set_at((x + dx, y + dy), cols[pat[py][px]])


def _draw_grass(surf, x, y, _ticks):
    """ALttP grass — dense 8x8 repeating texture with 4 green shades."""
    _fill_grass_pattern(surf, x, y, _GRASS_PAT, _GRASS_COLS)
    # Per-tile variation: shift a few extra highlight/shadow pixels
    rng = random.Random(x * 137 + y * 97)
    for _ in range(4):
        vx, vy = rng.randint(0, 15), rng.randint(0, 15)
        surf.set_at((x + vx, y + vy), (88, 200, 88))
    for _ in range(3):
        vx, vy = rng.randint(0, 15), rng.randint(0, 15)
        surf.set_at((x + vx, y + vy), (48, 136, 48))


def _draw_dark_grass(surf, x, y, _ticks):
    """Dark grass variant — Lost Woods / shadow areas."""
    _fill_grass_pattern(surf, x, y, _DARK_GRASS_PAT, _DARK_GRASS_COLS)
    rng = random.Random(x * 137 + y * 97)
    for _ in range(3):
        vx, vy = rng.randint(0, 15), rng.randint(0, 15)
        surf.set_at((x + vx, y + vy), (24, 96, 24))
    for _ in range(2):
        vx, vy = rng.randint(0, 15), rng.randint(0, 15)
        surf.set_at((x + vx, y + vy), (56, 160, 56))


def _draw_path(surf, x, y, _ticks):
    """ALttP dirt path — tan base with pebble texture and subtle variation."""
    surf.fill(PATH_TAN, (x, y, TILE, TILE))
    rng = random.Random(x * 137 + y * 97)
    path_mid = (192, 160, 104)
    path_pebble = (176, 144, 88)
    path_light = (216, 184, 128)
    # Subtle colour variation over entire tile
    for dy in range(16):
        for dx in range(16):
            n = rng.random()
            if n < 0.15:
                surf.set_at((x + dx, y + dy), PATH_DARK)
            elif n < 0.30:
                surf.set_at((x + dx, y + dy), path_mid)
            elif n < 0.38:
                surf.set_at((x + dx, y + dy), path_light)
    # Larger pebble spots (2x1 or 1x2)
    for _ in range(5):
        px, py = rng.randint(1, 14), rng.randint(1, 14)
        surf.set_at((x + px, y + py), path_pebble)
        surf.set_at((x + px + 1, y + py), path_pebble)
    for _ in range(3):
        px, py = rng.randint(1, 14), rng.randint(1, 14)
        surf.set_at((x + px, y + py), path_pebble)
        surf.set_at((x + px, y + py + 1), path_pebble)


def _draw_sand(surf, x, y, _ticks):
    """Sandy shore — warm beige with fine grain texture."""
    surf.fill(SAND_LIGHT, (x, y, TILE, TILE))
    rng = random.Random(x * 137 + y * 97)
    sand_mid = (224, 208, 152)
    sand_shadow = (208, 192, 136)
    sand_bright = (240, 224, 168)
    for dy in range(16):
        for dx in range(16):
            n = rng.random()
            if n < 0.12:
                surf.set_at((x + dx, y + dy), SAND_DOT)
            elif n < 0.22:
                surf.set_at((x + dx, y + dy), sand_mid)
            elif n < 0.28:
                surf.set_at((x + dx, y + dy), sand_shadow)
            elif n < 0.33:
                surf.set_at((x + dx, y + dy), sand_bright)
    # Occasional shell-like specks
    for _ in range(2):
        sx, sy = rng.randint(2, 13), rng.randint(2, 13)
        surf.set_at((x + sx, y + sy), (240, 232, 200))


def _draw_swamp(surf, x, y, _ticks):
    """ALttP swamp — murky green with puddles and organic texture."""
    surf.fill(SWAMP_GREEN, (x, y, TILE, TILE))
    rng = random.Random(x * 137 + y * 97)
    swamp_light = (80, 136, 80)
    swamp_vdark = (40, 72, 32)
    # Dense texture
    for dy in range(16):
        for dx in range(16):
            n = rng.random()
            if n < 0.15:
                surf.set_at((x + dx, y + dy), SWAMP_DARK)
            elif n < 0.25:
                surf.set_at((x + dx, y + dy), swamp_light)
            elif n < 0.32:
                surf.set_at((x + dx, y + dy), swamp_vdark)
    # Murky puddles (2-3 per tile)
    for _ in range(rng.randint(2, 3)):
        px, py = rng.randint(2, 11), rng.randint(2, 11)
        pw, ph = rng.randint(2, 4), rng.randint(2, 3)
        pygame.draw.rect(surf, SWAMP_MUD, (x + px, y + py, pw, ph))
        # Puddle highlight edge
        surf.set_at((x + px, y + py), swamp_light)


def _draw_water(surf, x, y, ticks):
    """ALttP water — animated rippling waves with multi-shade blue and foam."""
    phase = (ticks // 10) % 16
    water_dark = (32, 72, 176)
    water_mid2 = (48, 96, 200)
    foam_white = (200, 232, 255)
    # Base: alternating horizontal bands of two blue shades
    for dy in range(16):
        band = ((dy + phase) >> 2) & 1
        col = WATER_BLUE if band == 0 else water_dark
        pygame.draw.line(surf, col, (x, y + dy), (x + 15, y + dy))
    # Mid-tone ripple lines
    for i in range(4):
        ry = (i * 4 + phase) % 16
        rx_start = (i * 3 + phase) % 6
        for rx in range(rx_start, 16, 6):
            w = min(4, 16 - rx)
            pygame.draw.rect(surf, WATER_MID, (x + rx, y + ry, w, 1))
    # Bright wave crests (3-4px wide)
    for i in range(3):
        wy = (2 + i * 5 + phase) % 16
        wx = (1 + i * 4 + phase * 2) % 12
        crest_w = 3 + (i & 1)
        pygame.draw.rect(surf, WATER_LIGHT, (x + wx, y + wy, crest_w, 1))
        # Foam pixel at leading edge
        if wx + crest_w < 16:
            surf.set_at((x + wx + crest_w, y + wy), foam_white)
    # Scattered light sparkle pixels
    rng_phase = random.Random(x * 137 + y * 97 + phase)
    for _ in range(3):
        sx, sy = rng_phase.randint(0, 15), rng_phase.randint(0, 15)
        surf.set_at((x + sx, y + sy), foam_white)


def _draw_deep_water(surf, x, y, ticks):
    """Deep water — darker palette with slow subtle waves."""
    phase = (ticks // 14) % 16
    deep_vdark = (16, 48, 136)
    deep_light = (56, 96, 200)
    deep_sparkle = (96, 144, 224)
    for dy in range(16):
        band = ((dy + phase) >> 2) & 1
        col = DEEP_BLUE if band == 0 else deep_vdark
        pygame.draw.line(surf, col, (x, y + dy), (x + 15, y + dy))
    # Subtle mid ripples
    for i in range(3):
        ry = (3 + i * 5 + phase) % 16
        rx = (2 + i * 4 + phase) % 10
        pygame.draw.rect(surf, DEEP_MID, (x + rx, y + ry, 3, 1))
    # Rare light crests
    for i in range(2):
        wy = (1 + i * 7 + phase) % 16
        wx = (4 + i * 6 + phase * 2) % 12
        pygame.draw.rect(surf, deep_light, (x + wx, y + wy, 3, 1))
    rng_phase = random.Random(x * 137 + y * 97 + phase)
    for _ in range(2):
        sx, sy = rng_phase.randint(0, 15), rng_phase.randint(0, 15)
        surf.set_at((x + sx, y + sy), deep_sparkle)


def _draw_waterfall(surf, x, y, ticks):
    """Waterfall — vertical cascading water with white foam streaks."""
    phase = (ticks // 3) % 16
    wf_light = (72, 128, 224)
    wf_streak = (160, 208, 248)
    wf_foam = (220, 240, 255)
    # Base: vertical bands of varying blue
    for dx in range(16):
        band = (dx >> 2) & 1
        col = WATER_BLUE if band == 0 else wf_light
        pygame.draw.line(surf, col, (x + dx, y), (x + dx, y + 15))
    # Falling white streaks — 3 columns, shift with phase
    for ci, col_x in enumerate([3, 8, 13]):
        for seg in range(4):
            sy = (phase * 2 + seg * 4 + ci * 2) % 16
            h = min(3, 16 - sy)
            pygame.draw.rect(surf, WATER_LIGHT, (x + col_x, y + sy, 1, h))
            pygame.draw.rect(surf, wf_streak, (x + col_x - 1, y + sy, 1, max(1, h - 1)))
    # Foam sparkles
    for ci, col_x in enumerate([2, 7, 12]):
        fy = (phase * 3 + ci * 5) % 16
        surf.set_at((x + col_x, y + fy), wf_foam)
        if fy + 1 < 16:
            surf.set_at((x + col_x + 1, y + fy + 1), (255, 255, 255))


def _cliff_texture(surf, x, y, rx, ry, rw, rh):
    """Fill a rectangle with detailed cliff rock texture (5 shades)."""
    rng = random.Random(rx * 137 + ry * 97)
    cliff_mid = (144, 96, 80)
    cliff_grain = (136, 88, 72)
    cliff_vlight = (176, 128, 112)
    for dy in range(rh):
        ay = ry + dy
        if ay < y or ay >= y + 16:
            continue
        for dx in range(rw):
            ax = rx + dx
            if ax < x or ax >= x + 16:
                continue
            n = rng.random()
            if n < 0.10:
                surf.set_at((ax, ay), CLIFF_SHADOW)
            elif n < 0.22:
                surf.set_at((ax, ay), cliff_grain)
            elif n < 0.35:
                surf.set_at((ax, ay), cliff_mid)
            elif n < 0.42:
                surf.set_at((ax, ay), cliff_vlight)
            # else leave as base


def _draw_cliff_face(surf, x, y, _ticks):
    """ALttP cliff face — warm mauve-brown with layered rock texture and 3D depth."""
    surf.fill(CLIFF_MAIN, (x, y, TILE, TILE))
    rng = random.Random(x * 137 + y * 97)
    cliff_mid = (144, 96, 80)
    cliff_grain = (136, 88, 72)
    cliff_vlight = (176, 128, 112)
    # Dense rock grain over entire surface
    for dy in range(16):
        for dx in range(16):
            n = rng.random()
            if n < 0.08:
                surf.set_at((x + dx, y + dy), CLIFF_SHADOW)
            elif n < 0.18:
                surf.set_at((x + dx, y + dy), cliff_grain)
            elif n < 0.28:
                surf.set_at((x + dx, y + dy), cliff_mid)
            elif n < 0.34:
                surf.set_at((x + dx, y + dy), cliff_vlight)
    # Horizontal rock bands every 4-5 rows for layered look
    for band_y in [3, 7, 12]:
        band_y_a = band_y + (rng.randint(-1, 0))
        pygame.draw.rect(surf, CLIFF_SHADOW, (x, y + band_y_a, TILE, 1))
    # Shadow at top edge (2px) — cliff overhang
    pygame.draw.rect(surf, CLIFF_SHADOW, (x, y, TILE, 1))
    for dx in range(16):
        if rng.random() < 0.6:
            surf.set_at((x + dx, y + 1), CLIFF_SHADOW)
    # Highlight at bottom edge — light catching bottom
    pygame.draw.rect(surf, CLIFF_LIGHT, (x, y + 15, TILE, 1))
    for dx in range(16):
        if rng.random() < 0.5:
            surf.set_at((x + dx, y + 14), CLIFF_LIGHT)
    # Small stone block outlines (subtle)
    for _ in range(3):
        bx = rng.randint(1, 10)
        by = rng.randint(3, 11)
        bw = rng.randint(3, 5)
        bh = rng.randint(2, 3)
        # Bottom and right edges of block slightly lighter
        if bx + bw < 16:
            for d in range(bh):
                if by + d < 16:
                    surf.set_at((x + bx + bw, y + by + d), cliff_vlight)
        if by + bh < 16:
            for d in range(bw):
                surf.set_at((x + bx + d, y + by + bh), cliff_grain)


def _draw_cliff_top(surf, x, y, _ticks):
    """Grass-to-cliff transition — textured grass top, dark edge, cliff below."""
    # Top half: textured grass (rows 0-6)
    for dy in range(7):
        for dx in range(16):
            px, py = dx & 7, dy & 7
            surf.set_at((x + dx, y + dy), _GRASS_COLS[_GRASS_PAT[py][px]])
    # Dark green edge (rows 7-8) — the cliff lip
    pygame.draw.rect(surf, CLIFF_EDGE, (x, y + 7, TILE, 1))
    edge_dark = (32, 104, 32)
    pygame.draw.rect(surf, edge_dark, (x, y + 8, TILE, 1))
    # Bottom: cliff face (rows 9-15)
    rng = random.Random(x * 137 + y * 97)
    cliff_mid = (144, 96, 80)
    cliff_grain = (136, 88, 72)
    surf.fill(CLIFF_MAIN, (x, y + 9, TILE, 7))
    # Shadow just below edge
    pygame.draw.rect(surf, CLIFF_SHADOW, (x, y + 9, TILE, 1))
    for dx in range(16):
        if rng.random() < 0.5:
            surf.set_at((x + dx, y + 10), CLIFF_SHADOW)
    # Rock texture in lower portion
    for dy in range(11, 16):
        for dx in range(16):
            n = rng.random()
            if n < 0.10:
                surf.set_at((x + dx, y + dy), CLIFF_SHADOW)
            elif n < 0.22:
                surf.set_at((x + dx, y + dy), cliff_grain)
            elif n < 0.32:
                surf.set_at((x + dx, y + dy), cliff_mid)
    # Highlight at very bottom
    for dx in range(16):
        if rng.random() < 0.4:
            surf.set_at((x + dx, y + 15), CLIFF_LIGHT)


def _draw_cliff_left(surf, x, y, _ticks):
    """Left cliff edge — cliff on left, grass on right, vertical shadow edge."""
    rng = random.Random(x * 137 + y * 97)
    cliff_mid = (144, 96, 80)
    cliff_grain = (136, 88, 72)
    # Left half: cliff (cols 0-6)
    surf.fill(CLIFF_MAIN, (x, y, 7, TILE))
    for dy in range(16):
        for dx in range(7):
            n = rng.random()
            if n < 0.10:
                surf.set_at((x + dx, y + dy), CLIFF_SHADOW)
            elif n < 0.20:
                surf.set_at((x + dx, y + dy), cliff_grain)
            elif n < 0.28:
                surf.set_at((x + dx, y + dy), cliff_mid)
    # Vertical shadow edge (cols 7-8)
    pygame.draw.rect(surf, CLIFF_SHADOW, (x + 7, y, 1, TILE))
    edge_col = (96, 72, 56)
    pygame.draw.rect(surf, edge_col, (x + 6, y, 1, TILE))
    # Right half: textured grass (cols 9-15)
    for dy in range(16):
        for dx in range(9, 16):
            px, py = dx & 7, dy & 7
            surf.set_at((x + dx, y + dy), _GRASS_COLS[_GRASS_PAT[py][px]])


def _draw_cliff_right(surf, x, y, _ticks):
    """Right cliff edge — grass on left, cliff on right, vertical shadow edge."""
    rng = random.Random(x * 137 + y * 97)
    cliff_mid = (144, 96, 80)
    cliff_grain = (136, 88, 72)
    # Left half: textured grass (cols 0-6)
    for dy in range(16):
        for dx in range(7):
            px, py = dx & 7, dy & 7
            surf.set_at((x + dx, y + dy), _GRASS_COLS[_GRASS_PAT[py][px]])
    # Vertical shadow edge (cols 7-8)
    pygame.draw.rect(surf, CLIFF_SHADOW, (x + 7, y, 1, TILE))
    edge_col = (96, 72, 56)
    pygame.draw.rect(surf, edge_col, (x + 8, y, 1, TILE))
    # Right half: cliff (cols 9-15)
    surf.fill(CLIFF_MAIN, (x + 9, y, 7, TILE))
    for dy in range(16):
        for dx in range(9, 16):
            n = rng.random()
            if n < 0.10:
                surf.set_at((x + dx, y + dy), CLIFF_SHADOW)
            elif n < 0.20:
                surf.set_at((x + dx, y + dy), cliff_grain)
            elif n < 0.28:
                surf.set_at((x + dx, y + dy), cliff_mid)


def _draw_cliff_tl(surf, x, y, _ticks):
    """Top-left cliff corner — cliff fills tile, grass in top-right quadrant."""
    rng = random.Random(x * 137 + y * 97)
    cliff_mid = (144, 96, 80)
    cliff_grain = (136, 88, 72)
    surf.fill(CLIFF_MAIN, (x, y, TILE, TILE))
    # Rock texture over whole tile
    for dy in range(16):
        for dx in range(16):
            n = rng.random()
            if n < 0.08:
                surf.set_at((x + dx, y + dy), CLIFF_SHADOW)
            elif n < 0.18:
                surf.set_at((x + dx, y + dy), cliff_grain)
            elif n < 0.26:
                surf.set_at((x + dx, y + dy), cliff_mid)
    # Grass in top-right corner (cols 9-15, rows 0-6)
    for dy in range(7):
        for dx in range(9, 16):
            px, py = dx & 7, dy & 7
            surf.set_at((x + dx, y + dy), _GRASS_COLS[_GRASS_PAT[py][px]])
    # Shadow edges at corner boundary
    pygame.draw.rect(surf, CLIFF_SHADOW, (x + 8, y, 1, 8))
    pygame.draw.rect(surf, CLIFF_SHADOW, (x + 8, y + 7, 8, 1))


def _draw_cliff_tr(surf, x, y, _ticks):
    """Top-right cliff corner — cliff fills tile, grass in top-left quadrant."""
    rng = random.Random(x * 137 + y * 97)
    cliff_mid = (144, 96, 80)
    cliff_grain = (136, 88, 72)
    surf.fill(CLIFF_MAIN, (x, y, TILE, TILE))
    for dy in range(16):
        for dx in range(16):
            n = rng.random()
            if n < 0.08:
                surf.set_at((x + dx, y + dy), CLIFF_SHADOW)
            elif n < 0.18:
                surf.set_at((x + dx, y + dy), cliff_grain)
            elif n < 0.26:
                surf.set_at((x + dx, y + dy), cliff_mid)
    # Grass in top-left corner (cols 0-6, rows 0-6)
    for dy in range(7):
        for dx in range(7):
            px, py = dx & 7, dy & 7
            surf.set_at((x + dx, y + dy), _GRASS_COLS[_GRASS_PAT[py][px]])
    pygame.draw.rect(surf, CLIFF_SHADOW, (x + 7, y, 1, 8))
    pygame.draw.rect(surf, CLIFF_SHADOW, (x, y + 7, 8, 1))


def _draw_cliff_bl(surf, x, y, _ticks):
    """Bottom-left cliff corner — cliff fills tile, grass in bottom-right quadrant."""
    rng = random.Random(x * 137 + y * 97)
    cliff_mid = (144, 96, 80)
    cliff_grain = (136, 88, 72)
    surf.fill(CLIFF_MAIN, (x, y, TILE, TILE))
    for dy in range(16):
        for dx in range(16):
            n = rng.random()
            if n < 0.08:
                surf.set_at((x + dx, y + dy), CLIFF_SHADOW)
            elif n < 0.18:
                surf.set_at((x + dx, y + dy), cliff_grain)
            elif n < 0.26:
                surf.set_at((x + dx, y + dy), cliff_mid)
    # Grass in bottom-right corner (cols 9-15, rows 9-15)
    for dy in range(9, 16):
        for dx in range(9, 16):
            px, py = dx & 7, dy & 7
            surf.set_at((x + dx, y + dy), _GRASS_COLS[_GRASS_PAT[py][px]])
    pygame.draw.rect(surf, CLIFF_SHADOW, (x + 8, y + 8, 1, 8))
    pygame.draw.rect(surf, CLIFF_SHADOW, (x + 8, y + 8, 8, 1))


def _draw_cliff_br(surf, x, y, _ticks):
    """Bottom-right cliff corner — cliff fills tile, grass in bottom-left quadrant."""
    rng = random.Random(x * 137 + y * 97)
    cliff_mid = (144, 96, 80)
    cliff_grain = (136, 88, 72)
    surf.fill(CLIFF_MAIN, (x, y, TILE, TILE))
    for dy in range(16):
        for dx in range(16):
            n = rng.random()
            if n < 0.08:
                surf.set_at((x + dx, y + dy), CLIFF_SHADOW)
            elif n < 0.18:
                surf.set_at((x + dx, y + dy), cliff_grain)
            elif n < 0.26:
                surf.set_at((x + dx, y + dy), cliff_mid)
    # Grass in bottom-left corner (cols 0-6, rows 9-15)
    for dy in range(9, 16):
        for dx in range(7):
            px, py = dx & 7, dy & 7
            surf.set_at((x + dx, y + dy), _GRASS_COLS[_GRASS_PAT[py][px]])
    pygame.draw.rect(surf, CLIFF_SHADOW, (x + 7, y + 8, 1, 8))
    pygame.draw.rect(surf, CLIFF_SHADOW, (x, y + 8, 8, 1))


def _draw_mountain(surf, x, y, _ticks):
    """Mountain rock — multi-shade gray stone with cracks and lichen."""
    surf.fill(ROCK_GRAY, (x, y, TILE, TILE))
    rng = random.Random(x * 137 + y * 97)
    rock_mid = (120, 120, 112)
    rock_vdark = (88, 88, 80)
    rock_vlight = (168, 168, 160)
    lichen = (104, 128, 96)
    # Dense stone texture
    for dy in range(16):
        for dx in range(16):
            n = rng.random()
            if n < 0.10:
                surf.set_at((x + dx, y + dy), ROCK_DARK)
            elif n < 0.20:
                surf.set_at((x + dx, y + dy), rock_mid)
            elif n < 0.28:
                surf.set_at((x + dx, y + dy), ROCK_LIGHT)
            elif n < 0.32:
                surf.set_at((x + dx, y + dy), rock_vdark)
            elif n < 0.35:
                surf.set_at((x + dx, y + dy), rock_vlight)
    # Horizontal cracks
    for crack_y in [4, 9, 14]:
        cy = crack_y + rng.randint(-1, 0)
        cx_start = rng.randint(0, 4)
        cx_len = rng.randint(6, 12)
        for dx in range(cx_start, min(cx_start + cx_len, 16)):
            surf.set_at((x + dx, y + cy), rock_vdark)
    # Top highlight edge
    for dx in range(16):
        if rng.random() < 0.6:
            surf.set_at((x + dx, y), ROCK_LIGHT)
    # Occasional lichen patch
    lx, ly = rng.randint(2, 10), rng.randint(2, 10)
    for d in range(3):
        surf.set_at((x + lx + d, y + ly), lichen)
        if ly + 1 < 16:
            surf.set_at((x + lx + d, y + ly + 1), lichen)


def _draw_cave(surf, x, y, _ticks):
    """Cave entrance — stone archway with deep dark interior."""
    rng = random.Random(x * 137 + y * 97)
    rock_mid = (120, 120, 112)
    # Stone surround with texture
    surf.fill(ROCK_GRAY, (x, y, TILE, TILE))
    for dy in range(16):
        for dx in range(16):
            n = rng.random()
            if n < 0.12:
                surf.set_at((x + dx, y + dy), ROCK_DARK)
            elif n < 0.22:
                surf.set_at((x + dx, y + dy), ROCK_LIGHT)
            elif n < 0.30:
                surf.set_at((x + dx, y + dy), rock_mid)
    # Dark opening — arched shape
    pygame.draw.rect(surf, CAVE_DARK, (x + 3, y + 5, 10, 11))
    pygame.draw.rect(surf, CAVE_DARK, (x + 4, y + 4, 8, 1))
    pygame.draw.rect(surf, CAVE_DARK, (x + 5, y + 3, 6, 1))
    pygame.draw.rect(surf, CAVE_DARK, (x + 6, y + 2, 4, 1))
    # Slightly lighter interior hint at bottom
    cave_inner = (24, 24, 32)
    pygame.draw.rect(surf, cave_inner, (x + 5, y + 12, 6, 2))
    # Stone frame (carved) with mortar detail
    pygame.draw.rect(surf, CAVE_FRAME, (x + 2, y + 5, 1, 11))
    pygame.draw.rect(surf, CAVE_FRAME, (x + 13, y + 5, 1, 11))
    pygame.draw.rect(surf, CAVE_FRAME, (x + 3, y + 4, 1, 1))
    pygame.draw.rect(surf, CAVE_FRAME, (x + 12, y + 4, 1, 1))
    pygame.draw.rect(surf, CAVE_FRAME, (x + 4, y + 3, 1, 1))
    pygame.draw.rect(surf, CAVE_FRAME, (x + 11, y + 3, 1, 1))
    # Top lintel
    pygame.draw.rect(surf, CAVE_FRAME, (x + 1, y + 1, 14, 1))
    pygame.draw.rect(surf, ROCK_LIGHT, (x + 1, y, 14, 1))


def _draw_stairs(surf, x, y, _ticks):
    """Stone stairs — individual steps with shadow and highlight edges."""
    rng = random.Random(x * 137 + y * 97)
    surf.fill(PATH_DARK, (x, y, TILE, TILE))
    step_colors = [
        ((88, 80, 64), (112, 104, 88), (72, 64, 48)),
        ((96, 88, 72), (120, 112, 96), (80, 72, 56)),
        ((104, 96, 80), (128, 120, 104), (88, 80, 64)),
        ((112, 104, 88), (136, 128, 112), (96, 88, 72)),
    ]
    for i in range(4):
        base, light, dark = step_colors[i]
        sy = i * 4
        # Step surface
        pygame.draw.rect(surf, base, (x + 1, y + sy, 14, 3))
        # Highlight on front edge
        pygame.draw.rect(surf, light, (x + 1, y + sy, 14, 1))
        # Shadow on riser
        pygame.draw.rect(surf, dark, (x + 1, y + sy + 3, 14, 1))
        # Side walls
        surf.set_at((x, y + sy), dark)
        surf.set_at((x + 15, y + sy), dark)
        surf.set_at((x, y + sy + 1), base)
        surf.set_at((x + 15, y + sy + 1), base)
        # Subtle texture on step surface
        for _ in range(2):
            tx = rng.randint(2, 13)
            ty = sy + rng.randint(1, 2)
            if ty < 16:
                surf.set_at((x + tx, y + ty), dark)


def _draw_tree(surf, x, y, _ticks):
    """ALttP tree — lush broccoli canopy with highlight/shadow crescents and bark trunk."""
    # Grass background with texture
    for dy in range(16):
        for dx in range(16):
            px, py = dx & 7, dy & 7
            surf.set_at((x + dx, y + dy), _GRASS_COLS[_GRASS_PAT[py][px]])
    # Trunk with bark texture (2 shades)
    trunk_light = (144, 112, 64)
    trunk_dark = (104, 72, 32)
    for dy in range(10, 16):
        for dx in range(6, 10):
            surf.set_at((x + dx, y + dy), TREE_TRUNK)
    # Bark detail
    surf.set_at((x + 7, y + 11), trunk_dark)
    surf.set_at((x + 8, y + 12), trunk_light)
    surf.set_at((x + 7, y + 13), trunk_dark)
    surf.set_at((x + 6, y + 14), trunk_light)
    surf.set_at((x + 8, y + 14), trunk_dark)
    surf.set_at((x + 9, y + 11), trunk_dark)
    surf.set_at((x + 6, y + 12), trunk_light)
    # Round canopy — pixel circle r~5.5 centered at (8, 6)
    cx, cy = 8, 6
    specular = (104, 216, 104)
    very_dark = (24, 136, 24)
    for dy in range(-6, 7):
        for dx in range(-6, 7):
            d2 = dx * dx + dy * dy
            if d2 > 30:
                continue
            px, py = cx + dx, cy + dy
            if px < 0 or px > 15 or py < 0 or py > 15:
                continue
            # Determine shade based on position (light from top-left)
            shade_val = dx + dy  # negative = top-left, positive = bottom-right
            if shade_val <= -5:
                col = specular  # Bright specular at very top-left
            elif shade_val <= -2:
                col = TREE_HIGHLIGHT  # Upper-left highlight crescent
            elif shade_val <= 2:
                col = TREE_BASE  # Mid
            elif shade_val <= 5:
                col = TREE_SHADOW  # Lower-right shadow crescent
            else:
                col = very_dark  # Deepest shadow
            surf.set_at((x + px, y + py), col)
    # Extra specular pixels at very top
    surf.set_at((x + 6, y + 1), specular)
    surf.set_at((x + 7, y + 1), specular)
    # Extra deep shadow at very bottom
    surf.set_at((x + 9, y + 11), very_dark)
    surf.set_at((x + 10, y + 10), very_dark)


def _draw_dark_tree(surf, x, y, _ticks):
    """Dark tree variant — Lost Woods style with deeper greens."""
    # Dark grass background
    for dy in range(16):
        for dx in range(16):
            px, py = dx & 7, dy & 7
            surf.set_at((x + dx, y + dy), _DARK_GRASS_COLS[_DARK_GRASS_PAT[py][px]])
    # Dark trunk
    trunk_dk = (56, 40, 20)
    trunk_lt = (80, 56, 28)
    for dy in range(10, 16):
        for dx in range(6, 10):
            surf.set_at((x + dx, y + dy), (64, 48, 24))
    surf.set_at((x + 7, y + 11), trunk_dk)
    surf.set_at((x + 8, y + 12), trunk_lt)
    surf.set_at((x + 7, y + 13), trunk_dk)
    surf.set_at((x + 9, y + 11), trunk_dk)
    # Dark canopy
    cx, cy = 8, 6
    dk_specular = (72, 176, 72)
    dk_vdark = (8, 96, 8)
    for dy in range(-6, 7):
        for dx in range(-6, 7):
            d2 = dx * dx + dy * dy
            if d2 > 30:
                continue
            px, py = cx + dx, cy + dy
            if px < 0 or px > 15 or py < 0 or py > 15:
                continue
            shade_val = dx + dy
            if shade_val <= -5:
                col = dk_specular
            elif shade_val <= -2:
                col = DARK_TREE_HI
            elif shade_val <= 2:
                col = DARK_TREE_BASE
            elif shade_val <= 5:
                col = DARK_TREE_SH
            else:
                col = dk_vdark
            surf.set_at((x + px, y + py), col)
    surf.set_at((x + 6, y + 1), dk_specular)
    surf.set_at((x + 7, y + 1), dk_specular)
    surf.set_at((x + 9, y + 11), dk_vdark)
    surf.set_at((x + 10, y + 10), dk_vdark)


def _draw_bush(surf, x, y, _ticks):
    """ALttP bush — round-ish shrub on grass with highlight and shadow."""
    # Grass background
    for dy in range(16):
        for dx in range(16):
            px, py = dx & 7, dy & 7
            surf.set_at((x + dx, y + dy), _GRASS_COLS[_GRASS_PAT[py][px]])
    bush_light = (72, 184, 72)
    bush_vdark = (24, 120, 24)
    # Rounded bush body
    cx, cy = 8, 9
    for dy in range(-4, 5):
        for dx in range(-5, 6):
            d2 = dx * dx + dy * dy
            if d2 > 20:
                continue
            px, py = cx + dx, cy + dy
            if px < 1 or px > 14 or py < 3 or py > 14:
                continue
            shade = dx + dy
            if shade <= -4:
                col = TREE_HIGHLIGHT
            elif shade <= -1:
                col = bush_light
            elif shade <= 2:
                col = TREE_BASE
            elif shade <= 4:
                col = TREE_SHADOW
            else:
                col = bush_vdark
            surf.set_at((x + px, y + py), col)
    # Outline pixels at bottom
    surf.set_at((x + 4, y + 13), bush_vdark)
    surf.set_at((x + 11, y + 13), bush_vdark)
    # Top highlight specular
    surf.set_at((x + 5, y + 5), (96, 208, 96))
    surf.set_at((x + 6, y + 5), (96, 208, 96))


def _draw_tall_grass(surf, x, y, ticks):
    """Animated tall grass — swaying blades over grass base."""
    # Base grass texture
    for dy in range(16):
        for dx in range(16):
            px, py = dx & 7, dy & 7
            surf.set_at((x + dx, y + dy), _GRASS_COLS[_GRASS_PAT[py][px]])
    sway = int(math.sin(ticks * 0.05 + x * 0.3) * 1.5)
    blade_hi = (96, 216, 96)
    blade_base = TREE_BASE
    blade_mid = (56, 176, 56)
    blade_dk = TREE_SHADOW
    # Multiple grass blades at different positions
    blade_xs = [1, 4, 7, 10, 13]
    for i, bx in enumerate(blade_xs):
        s = sway if (i & 1) == 0 else -sway
        actual_bx = max(0, min(14, bx + s))
        # Each blade: tip=highlight, middle=base, bottom=dark
        for dy_off, col in [(3, blade_hi), (4, blade_hi), (5, blade_mid),
                            (6, blade_mid), (7, blade_base), (8, blade_base),
                            (9, blade_base), (10, blade_dk), (11, blade_dk),
                            (12, blade_dk), (13, blade_dk)]:
            if 0 <= actual_bx <= 15 and 0 <= dy_off <= 15:
                surf.set_at((x + actual_bx, y + dy_off), col)
            if 0 <= actual_bx + 1 <= 15 and 0 <= dy_off <= 15:
                surf.set_at((x + actual_bx + 1, y + dy_off), col)


def _draw_flowers(surf, x, y, _ticks):
    """Flower field — grass base with colourful petals and stems."""
    # Grass base
    for dy in range(16):
        for dx in range(16):
            px, py = dx & 7, dy & 7
            surf.set_at((x + dx, y + dy), _GRASS_COLS[_GRASS_PAT[py][px]])
    rng = random.Random(x * 137 + y * 97)
    flower_colors = [
        (240, 128, 128), (240, 240, 96), (240, 160, 240),
        (128, 200, 240), (240, 180, 128),
    ]
    stem_col = (40, 144, 40)
    # 5-6 flowers scattered
    for _ in range(rng.randint(5, 6)):
        fx = rng.randint(1, 13)
        fy = rng.randint(2, 11)
        fc = flower_colors[rng.randint(0, len(flower_colors) - 1)]
        # Stem (2-3px tall)
        stem_h = rng.randint(2, 3)
        for sh in range(stem_h):
            surf.set_at((x + fx, y + fy + 2 + sh), stem_col)
        # Petal: cross pattern (5 pixels)
        surf.set_at((x + fx, y + fy), fc)
        if fx > 0:
            surf.set_at((x + fx - 1, y + fy + 1), fc)
        if fx < 15:
            surf.set_at((x + fx + 1, y + fy + 1), fc)
        surf.set_at((x + fx, y + fy + 1), (240, 232, 64))  # Center yellow
        surf.set_at((x + fx, y + fy + 2), fc)


def _draw_house_roof(surf, x, y, _ticks):
    """ALttP house roof — triangular with shingle lines and edge outlines."""
    # Sky/transparent background (use grass as context)
    for dy in range(16):
        for dx in range(16):
            px, py = dx & 7, dy & 7
            surf.set_at((x + dx, y + dy), _GRASS_COLS[_GRASS_PAT[py][px]])
    roof_hi = (224, 136, 136)
    roof_edge = (160, 80, 80)
    roof_outline = (120, 64, 64)
    # Build triangular roof shape (peak at row 0, full width at row 7-ish)
    for dy in range(16):
        half_w = min((dy + 1), 8)
        left = 8 - half_w
        right = 8 + half_w
        if left < 0:
            left = 0
        if right > 16:
            right = 16
        for dx in range(left, right):
            # Alternating shingle rows (every 3 pixels)
            row_idx = dy // 3
            if row_idx & 1:
                col = HOUSE_ROOF_DARK
            else:
                col = HOUSE_ROOF_MAIN
            # Edge highlight on left side of each row
            if dx == left:
                col = roof_outline
            elif dx == left + 1:
                col = roof_edge
            elif dx == right - 1:
                col = roof_outline
            elif dx == right - 2:
                col = roof_edge
            surf.set_at((x + dx, y + dy), col)
    # Shingle separator lines
    for row_y in [3, 6, 9, 12]:
        half_w = min((row_y + 1), 8)
        left = 8 - half_w
        right = 8 + half_w
        for dx in range(max(0, left + 1), min(16, right - 1)):
            surf.set_at((x + dx, y + row_y), roof_edge)
    # Highlight along upper-left slope
    for dy in range(1, 8):
        px = 8 - dy
        if 0 <= px <= 15:
            surf.set_at((x + px, y + dy), roof_hi)


def _draw_house_wall(surf, x, y, _ticks):
    """ALttP house wall — cream plaster with mortar lines, window with frame."""
    surf.fill(HOUSE_WALL_MAIN, (x, y, TILE, TILE))
    wall_mortar = (200, 176, 128)
    wall_light = (240, 216, 168)
    # Horizontal mortar/plaster lines
    for mortar_y in [3, 7, 11]:
        pygame.draw.line(surf, wall_mortar, (x, y + mortar_y), (x + 15, y + mortar_y))
    # Vertical mortar (staggered brick pattern)
    for mortar_y_start, offsets in [(0, [4, 12]), (4, [0, 8]), (8, [4, 12]), (12, [0, 8])]:
        for mx in offsets:
            end_y = min(mortar_y_start + 3, 15)
            if mx < 16:
                pygame.draw.line(surf, wall_mortar, (x + mx, y + mortar_y_start), (x + mx, y + end_y))
    # Subtle plaster texture
    rng = random.Random(x * 137 + y * 97)
    for _ in range(12):
        tx, ty = rng.randint(0, 15), rng.randint(0, 15)
        surf.set_at((x + tx, y + ty), HOUSE_WALL_DARK)
    for _ in range(6):
        tx, ty = rng.randint(0, 15), rng.randint(0, 15)
        surf.set_at((x + tx, y + ty), wall_light)
    # Border outlines
    pygame.draw.rect(surf, HOUSE_WALL_DARK, (x, y, TILE, 1))
    pygame.draw.rect(surf, HOUSE_WALL_DARK, (x, y, 1, TILE))
    pygame.draw.rect(surf, HOUSE_WALL_DARK, (x + 15, y, 1, TILE))
    # Window with proper frame
    frame_col = (176, 152, 104)
    # Outer frame
    pygame.draw.rect(surf, frame_col, (x + 4, y + 3, 8, 8))
    # Glass panes (2x2 grid)
    pygame.draw.rect(surf, WINDOW_BLUE, (x + 5, y + 4, 3, 3))
    pygame.draw.rect(surf, WINDOW_BLUE, (x + 9, y + 4, 3, 3))
    pygame.draw.rect(surf, WINDOW_BLUE, (x + 5, y + 8, 3, 3))
    pygame.draw.rect(surf, WINDOW_BLUE, (x + 9, y + 8, 3, 3))
    # Window light reflection
    surf.set_at((x + 5, y + 4), (72, 112, 200))
    surf.set_at((x + 9, y + 4), (72, 112, 200))
    # Cross-frame dividers
    pygame.draw.rect(surf, frame_col, (x + 8, y + 4, 1, 6))
    pygame.draw.rect(surf, frame_col, (x + 5, y + 7, 6, 1))


def _draw_house_door(surf, x, y, _ticks):
    """House door — wooden door with frame, handle, and threshold."""
    surf.fill(HOUSE_WALL_MAIN, (x, y, TILE, TILE))
    # Wall texture
    rng = random.Random(x * 137 + y * 97)
    for _ in range(8):
        tx, ty = rng.randint(0, 15), rng.randint(0, 15)
        surf.set_at((x + tx, y + ty), HOUSE_WALL_DARK)
    # Border
    pygame.draw.rect(surf, HOUSE_WALL_DARK, (x, y, 1, TILE))
    pygame.draw.rect(surf, HOUSE_WALL_DARK, (x + 15, y, 1, TILE))
    # Door frame
    frame = (144, 104, 40)
    pygame.draw.rect(surf, frame, (x + 3, y + 2, 10, 14))
    # Door panel
    pygame.draw.rect(surf, HOUSE_DOOR_MAIN, (x + 4, y + 3, 8, 13))
    # Door plank lines (vertical)
    pygame.draw.line(surf, HOUSE_DOOR_DARK, (x + 6, y + 3), (x + 6, y + 15))
    pygame.draw.line(surf, HOUSE_DOOR_DARK, (x + 9, y + 3), (x + 9, y + 15))
    # Horizontal brace
    pygame.draw.rect(surf, HOUSE_DOOR_DARK, (x + 4, y + 8, 8, 1))
    # Frame edges
    pygame.draw.rect(surf, HOUSE_DOOR_DARK, (x + 3, y + 2, 1, 14))
    pygame.draw.rect(surf, HOUSE_DOOR_DARK, (x + 12, y + 2, 1, 14))
    pygame.draw.rect(surf, HOUSE_DOOR_DARK, (x + 3, y + 2, 10, 1))
    # Handle
    pygame.draw.rect(surf, DOOR_HANDLE, (x + 10, y + 9, 1, 2))
    surf.set_at((x + 10, y + 10), (200, 168, 48))
    # Threshold
    pygame.draw.rect(surf, (160, 136, 88), (x + 4, y + 15, 8, 1))


def _draw_castle_wall(surf, x, y, _ticks):
    """Castle wall — pale stone bricks with visible mortar gaps and texture."""
    surf.fill(CASTLE_STONE, (x, y, TILE, TILE))
    rng = random.Random(x * 137 + y * 97)
    stone_mid = (192, 192, 200)
    stone_vlight = (232, 232, 240)
    # Dense stone texture
    for dy in range(16):
        for dx in range(16):
            n = rng.random()
            if n < 0.08:
                surf.set_at((x + dx, y + dy), CASTLE_DARK)
            elif n < 0.16:
                surf.set_at((x + dx, y + dy), stone_mid)
            elif n < 0.22:
                surf.set_at((x + dx, y + dy), stone_vlight)
    # Brick mortar pattern — horizontal lines every 5px, staggered verticals
    mortar = (152, 152, 168)
    for my in [0, 5, 10, 15]:
        if my < 16:
            for dx in range(16):
                surf.set_at((x + dx, y + my), mortar)
    # Staggered vertical mortar
    for section, offsets in [(0, [8]), (5, [0, 4, 12]), (10, [8]), (15, [0, 4, 12])]:
        for mx in offsets:
            for dy in range(min(5, 16 - section)):
                if section + dy < 16 and mx < 16:
                    surf.set_at((x + mx, y + section + dy), mortar)
    # Subtle highlight on top edge of each brick row
    for my in [1, 6, 11]:
        if my < 16:
            for dx in range(16):
                if rng.random() < 0.3:
                    surf.set_at((x + dx, y + my), CASTLE_LIGHT)


def _draw_castle_tower(surf, x, y, _ticks):
    """Castle tower — battlements on top, stone body, arrow slit window."""
    rng = random.Random(x * 137 + y * 97)
    stone_mid = (192, 192, 200)
    mortar = (152, 152, 168)
    # Tower body with texture
    surf.fill(CASTLE_STONE, (x + 1, y + 4, 14, 12))
    for dy in range(4, 16):
        for dx in range(1, 15):
            n = rng.random()
            if n < 0.08:
                surf.set_at((x + dx, y + dy), CASTLE_DARK)
            elif n < 0.16:
                surf.set_at((x + dx, y + dy), stone_mid)
    # Mortar lines on body
    for my in [7, 11]:
        pygame.draw.line(surf, mortar, (x + 1, y + my), (x + 14, y + my))
    # Battlements (3 merlons with gaps)
    for bx, bw in [(0, 4), (6, 4), (12, 4)]:
        pygame.draw.rect(surf, CASTLE_LIGHT, (x + bx, y, bw, 5))
        pygame.draw.rect(surf, CASTLE_STONE, (x + bx + 1, y + 1, bw - 2, 3))
        pygame.draw.rect(surf, CASTLE_DARK, (x + bx, y + 4, bw, 1))
    # Gaps between merlons (show sky/dark)
    pygame.draw.rect(surf, (80, 120, 180), (x + 4, y, 2, 4))
    pygame.draw.rect(surf, (80, 120, 180), (x + 10, y, 2, 4))
    # Arrow slit window
    pygame.draw.rect(surf, CAVE_DARK, (x + 7, y + 6, 2, 5))
    pygame.draw.rect(surf, CAVE_DARK, (x + 6, y + 8, 4, 1))
    # Window frame highlight
    surf.set_at((x + 6, y + 6), CASTLE_DARK)
    surf.set_at((x + 9, y + 6), CASTLE_DARK)


def _draw_castle_gate(surf, x, y, _ticks):
    """Castle gate — arched portcullis entry with iron bands."""
    rng = random.Random(x * 137 + y * 97)
    surf.fill(CASTLE_STONE, (x, y, TILE, TILE))
    # Stone texture
    for dy in range(16):
        for dx in range(16):
            n = rng.random()
            if n < 0.08:
                surf.set_at((x + dx, y + dy), CASTLE_DARK)
            elif n < 0.14:
                surf.set_at((x + dx, y + dy), CASTLE_LIGHT)
    # Arched opening
    pygame.draw.rect(surf, HOUSE_DOOR_DARK, (x + 2, y + 4, 12, 12))
    pygame.draw.rect(surf, HOUSE_DOOR_DARK, (x + 3, y + 3, 10, 1))
    pygame.draw.rect(surf, HOUSE_DOOR_DARK, (x + 4, y + 2, 8, 1))
    pygame.draw.rect(surf, HOUSE_DOOR_DARK, (x + 5, y + 1, 6, 1))
    # Interior (slightly lighter wood)
    pygame.draw.rect(surf, HOUSE_DOOR_MAIN, (x + 3, y + 5, 10, 11))
    pygame.draw.rect(surf, HOUSE_DOOR_MAIN, (x + 4, y + 4, 8, 1))
    pygame.draw.rect(surf, HOUSE_DOOR_MAIN, (x + 5, y + 3, 6, 1))
    # Iron bands (horizontal)
    iron = (80, 80, 88)
    iron_light = (112, 112, 120)
    for band_y in [6, 10, 14]:
        pygame.draw.rect(surf, iron, (x + 3, y + band_y, 10, 1))
        # Rivet dots
        surf.set_at((x + 4, y + band_y), iron_light)
        surf.set_at((x + 12, y + band_y), iron_light)
    # Vertical portcullis bars
    for bar_x in [5, 8, 11]:
        pygame.draw.line(surf, iron, (x + bar_x, y + 4), (x + bar_x, y + 15))


def _draw_bridge(surf, x, y, _ticks):
    """Wooden bridge over water — plank detail with nail heads and water peeking through."""
    # Water background (still)
    for dy in range(16):
        band = (dy >> 2) & 1
        col = WATER_BLUE if band == 0 else (32, 72, 176)
        pygame.draw.line(surf, col, (x, y + dy), (x + 15, y + dy))
    rng = random.Random(x * 137 + y * 97)
    bridge_light = (216, 184, 128)
    bridge_vdark = (152, 120, 64)
    nail = (128, 128, 136)
    # Main bridge planks (rows 2-13)
    pygame.draw.rect(surf, BRIDGE_WOOD, (x, y + 2, TILE, 12))
    # Individual plank lines (horizontal gaps)
    for plank_y in [4, 7, 10]:
        pygame.draw.line(surf, BRIDGE_DARK, (x, y + plank_y), (x + 15, y + plank_y))
    # Wood grain (subtle horizontal streaks)
    for _ in range(8):
        gx = rng.randint(0, 14)
        gy = rng.randint(3, 12)
        gw = rng.randint(2, 4)
        for dx in range(gw):
            if gx + dx < 16:
                surf.set_at((x + gx + dx, y + gy), bridge_light)
    for _ in range(5):
        gx = rng.randint(0, 14)
        gy = rng.randint(3, 12)
        surf.set_at((x + gx, y + gy), bridge_vdark)
    # Railing edges (top and bottom)
    pygame.draw.rect(surf, FENCE_DARK, (x, y + 2, TILE, 1))
    pygame.draw.rect(surf, FENCE_DARK, (x, y + 13, TILE, 1))
    pygame.draw.rect(surf, FENCE_WOOD, (x, y + 1, TILE, 1))
    pygame.draw.rect(surf, FENCE_WOOD, (x, y + 14, TILE, 1))
    # Nail heads
    for nx in [2, 8, 14]:
        surf.set_at((x + nx, y + 3), nail)
        surf.set_at((x + nx, y + 12), nail)


def _draw_fence(surf, x, y, _ticks):
    """Wooden fence — posts with cross rails, on textured grass."""
    # Grass background
    for dy in range(16):
        for dx in range(16):
            px, py = dx & 7, dy & 7
            surf.set_at((x + dx, y + dy), _GRASS_COLS[_GRASS_PAT[py][px]])
    fence_hi = (216, 184, 128)
    fence_nail = (136, 104, 56)
    # Posts (3 vertical posts)
    for post_x in [1, 7, 13]:
        pygame.draw.rect(surf, FENCE_WOOD, (x + post_x, y + 4, 2, 10))
        # Post cap
        pygame.draw.rect(surf, fence_hi, (x + post_x, y + 4, 2, 1))
        # Post shadow
        pygame.draw.rect(surf, FENCE_DARK, (x + post_x + 1, y + 5, 1, 9))
        # Post base
        pygame.draw.rect(surf, FENCE_DARK, (x + post_x, y + 13, 2, 1))
    # Top rail
    pygame.draw.rect(surf, FENCE_WOOD, (x, y + 6, TILE, 2))
    pygame.draw.rect(surf, fence_hi, (x, y + 6, TILE, 1))
    pygame.draw.rect(surf, FENCE_DARK, (x, y + 8, TILE, 1))
    # Bottom rail
    pygame.draw.rect(surf, FENCE_WOOD, (x, y + 10, TILE, 2))
    pygame.draw.rect(surf, fence_hi, (x, y + 10, TILE, 1))
    pygame.draw.rect(surf, FENCE_DARK, (x, y + 12, TILE, 1))
    # Nail details where rails meet posts
    for post_x in [1, 7, 13]:
        surf.set_at((x + post_x, y + 7), fence_nail)
        surf.set_at((x + post_x, y + 11), fence_nail)


def _draw_sign(surf, x, y, _ticks):
    """Signpost — wooden board on a post, with carved text lines."""
    # Grass background
    for dy in range(16):
        for dx in range(16):
            px, py = dx & 7, dy & 7
            surf.set_at((x + dx, y + dy), _GRASS_COLS[_GRASS_PAT[py][px]])
    post_shadow = (136, 104, 48)
    board_hi = (224, 192, 112)
    # Post
    pygame.draw.rect(surf, SIGN_POST, (x + 7, y + 8, 2, 7))
    pygame.draw.rect(surf, post_shadow, (x + 8, y + 9, 1, 6))
    # Board with beveled edge
    pygame.draw.rect(surf, SIGN_BOARD, (x + 2, y + 1, 12, 8))
    # Top highlight
    pygame.draw.rect(surf, board_hi, (x + 2, y + 1, 12, 1))
    # Bottom shadow
    pygame.draw.rect(surf, SIGN_DARK, (x + 2, y + 8, 12, 1))
    # Left/right edges
    pygame.draw.rect(surf, SIGN_DARK, (x + 2, y + 1, 1, 8))
    pygame.draw.rect(surf, SIGN_DARK, (x + 13, y + 1, 1, 8))
    # "Text" lines (carved grooves)
    for ty in [3, 5, 7]:
        pygame.draw.line(surf, SIGN_DARK, (x + 4, y + ty), (x + 11, y + ty))
    # Nails holding board to post
    surf.set_at((x + 7, y + 4), (160, 160, 168))
    surf.set_at((x + 8, y + 6), (160, 160, 168))


def _draw_torch(surf, x, y, ticks):
    """Wall torch — animated flickering flame on a stone wall bracket."""
    rng_wall = random.Random(x * 137 + y * 97)
    # Stone wall background with texture
    surf.fill(ROCK_GRAY, (x, y, TILE, TILE))
    rock_mid = (120, 120, 112)
    for dy in range(16):
        for dx in range(16):
            n = rng_wall.random()
            if n < 0.10:
                surf.set_at((x + dx, y + dy), ROCK_DARK)
            elif n < 0.18:
                surf.set_at((x + dx, y + dy), rock_mid)
            elif n < 0.24:
                surf.set_at((x + dx, y + dy), ROCK_LIGHT)
    # Mortar line
    pygame.draw.rect(surf, CASTLE_DARK, (x, y, TILE, 1))
    # Torch bracket (dark metal)
    bracket = (80, 72, 64)
    pygame.draw.rect(surf, bracket, (x + 5, y + 9, 6, 1))
    pygame.draw.rect(surf, bracket, (x + 5, y + 10, 1, 2))
    pygame.draw.rect(surf, bracket, (x + 10, y + 10, 1, 2))
    # Torch handle (wood)
    pygame.draw.rect(surf, TREE_TRUNK, (x + 6, y + 7, 4, 5))
    trunk_dk = (104, 72, 32)
    surf.set_at((x + 7, y + 8), trunk_dk)
    surf.set_at((x + 8, y + 10), trunk_dk)
    # Animated flame — flickers based on ticks
    flk = random.Random(ticks * 7 + x * 13 + y * 3)
    sway = flk.randint(-1, 1)
    # Flame layers (bottom=red, mid=orange, top=yellow, tip=white)
    # Outer flame (orange-red)
    pygame.draw.rect(surf, TORCH_FLAME2, (x + 5 + sway, y + 4, 6, 4))
    # Inner flame (yellow)
    pygame.draw.rect(surf, TORCH_FLAME1, (x + 6 + sway, y + 3, 4, 4))
    # Hot core (bright yellow-white)
    core = (255, 248, 160)
    pygame.draw.rect(surf, core, (x + 7 + sway, y + 4, 2, 2))
    # Flame tip
    surf.set_at((x + 7 + sway, y + 2), TORCH_FLAME1)
    surf.set_at((x + 8 + sway, y + 1), TORCH_FLAME2)
    # Red base
    pygame.draw.rect(surf, TORCH_FLAME3, (x + 6 + sway, y + 7, 4, 1))
    # Glow effect
    glow = pygame.Surface((TILE, TILE), pygame.SRCALPHA)
    pygame.draw.circle(glow, (255, 200, 50, 25), (8, 6), 10)
    pygame.draw.circle(glow, (255, 180, 40, 15), (8, 6), 6)
    surf.blit(glow, (x, y))


def _draw_dungeon(surf, x, y, _ticks):
    """Dungeon entrance — stone frame with dark interior on grass."""
    # Grass background
    for dy in range(16):
        for dx in range(16):
            px, py = dx & 7, dy & 7
            surf.set_at((x + dx, y + dy), _GRASS_COLS[_GRASS_PAT[py][px]])
    rng = random.Random(x * 137 + y * 97)
    rock_mid = (120, 120, 112)
    # Stone frame
    pygame.draw.rect(surf, ROCK_GRAY, (x + 1, y + 1, 14, 14))
    for dy in range(1, 15):
        for dx in range(1, 15):
            n = rng.random()
            if n < 0.10:
                surf.set_at((x + dx, y + dy), ROCK_DARK)
            elif n < 0.18:
                surf.set_at((x + dx, y + dy), ROCK_LIGHT)
            elif n < 0.24:
                surf.set_at((x + dx, y + dy), rock_mid)
    # Top lintel highlight
    pygame.draw.rect(surf, ROCK_LIGHT, (x + 1, y + 1, 14, 1))
    # Dark opening arch
    pygame.draw.rect(surf, CAVE_DARK, (x + 3, y + 5, 10, 10))
    pygame.draw.rect(surf, CAVE_DARK, (x + 4, y + 4, 8, 1))
    pygame.draw.rect(surf, CAVE_DARK, (x + 5, y + 3, 6, 1))
    pygame.draw.rect(surf, CAVE_DARK, (x + 6, y + 2, 4, 1))
    # Inner depth hint
    cave_inner = (24, 24, 32)
    pygame.draw.rect(surf, cave_inner, (x + 5, y + 10, 6, 3))
    # Frame edge detail
    pygame.draw.rect(surf, CAVE_FRAME, (x + 1, y + 1, 14, 1))
    pygame.draw.rect(surf, ROCK_DARK, (x + 1, y + 14, 14, 1))


def _draw_chest(surf, x, y, _ticks):
    """Treasure chest — detailed with bands, lock, and lid highlight."""
    # Dark floor background
    surf.fill((40, 40, 48), (x, y, TILE, TILE))
    rng = random.Random(x * 137 + y * 97)
    floor_mid = (48, 48, 56)
    for _ in range(10):
        fx, fy = rng.randint(0, 15), rng.randint(0, 15)
        surf.set_at((x + fx, y + fy), floor_mid)
    # Chest body
    chest_base = (192, 136, 32)
    chest_lid = (216, 160, 48)
    chest_dark = (160, 112, 24)
    chest_hi = (232, 184, 64)
    band_col = (128, 96, 24)
    # Base/bottom half
    pygame.draw.rect(surf, chest_base, (x + 3, y + 8, 10, 5))
    # Lid/top half (slightly lighter)
    pygame.draw.rect(surf, chest_lid, (x + 3, y + 4, 10, 4))
    # Lid highlight along top
    pygame.draw.rect(surf, chest_hi, (x + 3, y + 4, 10, 1))
    # Dark line between lid and base
    pygame.draw.rect(surf, chest_dark, (x + 3, y + 8, 10, 1))
    # Metal bands
    pygame.draw.rect(surf, band_col, (x + 3, y + 6, 10, 1))
    pygame.draw.rect(surf, band_col, (x + 3, y + 10, 10, 1))
    # Side edges
    pygame.draw.rect(surf, chest_dark, (x + 3, y + 4, 1, 9))
    pygame.draw.rect(surf, chest_dark, (x + 12, y + 4, 1, 9))
    # Bottom edge
    pygame.draw.rect(surf, chest_dark, (x + 3, y + 12, 10, 1))
    # Lock/clasp (golden)
    lock_gold = (240, 208, 64)
    lock_dark = (200, 168, 32)
    pygame.draw.rect(surf, lock_gold, (x + 7, y + 7, 2, 3))
    surf.set_at((x + 7, y + 9), lock_dark)
    # Keyhole
    surf.set_at((x + 8, y + 8), chest_dark)


def _draw_boundary(surf, x, y, _ticks):
    """Map boundary — dense cliff rock, impassable edge tile."""
    surf.fill(CLIFF_MAIN, (x, y, TILE, TILE))
    rng = random.Random(x * 137 + y * 97)
    cliff_mid = (144, 96, 80)
    cliff_grain = (136, 88, 72)
    cliff_vdark = (104, 64, 48)
    for dy in range(16):
        for dx in range(16):
            n = rng.random()
            if n < 0.12:
                surf.set_at((x + dx, y + dy), CLIFF_SHADOW)
            elif n < 0.24:
                surf.set_at((x + dx, y + dy), cliff_grain)
            elif n < 0.34:
                surf.set_at((x + dx, y + dy), cliff_mid)
            elif n < 0.40:
                surf.set_at((x + dx, y + dy), cliff_vdark)
    # Horizontal crack lines
    for crack_y in [3, 8, 13]:
        cy = crack_y + rng.randint(-1, 0)
        pygame.draw.line(surf, cliff_vdark, (x, y + cy), (x + 15, y + cy))


# ══════════════════════════════════════════
#  MULTI-TILE STRUCTURE DRAW FUNCTIONS
# ══════════════════════════════════════════
# Each function draws one 16x16 tile that is part of a larger 3×3 house composition.
# Colors: HOUSE_ROOF_MAIN/DARK for roof, HOUSE_WALL_MAIN/DARK for walls,
#         HOUSE_DOOR_MAIN/DARK for door, DOOR_HANDLE for knob.

_FOUNDATION = (160, 150, 130)   # Stone foundation colour
_FOUNDATION_DARK = (130, 120, 100)

def _draw_house_roof_l(surf, x, y, _ticks):
    """Left edge of peaked roof — grass background with triangular roof section."""
    # Grass background
    for dy in range(16):
        for dx in range(16):
            px, py = dx & 7, dy & 7
            surf.set_at((x + dx, y + dy), _GRASS_COLS[_GRASS_PAT[py][px]])
    # Triangular roof section grows from 0 width at top-right to full width at bottom
    roof_hi = (224, 136, 136)
    for row in range(16):
        # Diagonal left edge of roof: col = TILE-1-row, capped at 0
        left_edge = max(0, TILE - 1 - row)
        for col in range(left_edge, TILE):
            row_idx = row // 3
            c = HOUSE_ROOF_DARK if row_idx & 1 else HOUSE_ROOF_MAIN
            if col == left_edge:
                c = (120, 64, 64)   # Dark diagonal edge
            elif col == left_edge + 1:
                c = (184, 96, 96)   # Shadow next to edge
            surf.set_at((x + col, y + row), c)
    # Shingle separator lines across the roof area
    for row in [3, 6, 9, 12]:
        left_edge = max(0, TILE - 1 - row)
        pygame.draw.line(surf, HOUSE_ROOF_DARK, (x + left_edge, y + row), (x + 15, y + row))
    # Right edge shared with middle — strong vertical shadow
    pygame.draw.line(surf, (104, 56, 56), (x + 15, y + 0), (x + 15, y + 15))
    # Highlight near diagonal
    for row in range(1, 9):
        col = TILE - row
        if 0 <= col <= 15:
            surf.set_at((x + col, y + row), roof_hi)


def _draw_house_roof_m(surf, x, y, _ticks):
    """Middle roof tile — full salmon rectangle with shingles and chimney."""
    surf.fill(HOUSE_ROOF_MAIN, (x, y, TILE, TILE))
    # Shingle rows
    for row in [3, 6, 9, 12]:
        pygame.draw.line(surf, HOUSE_ROOF_DARK, (x, y + row), (x + 15, y + row))
    # Shingle highlight below each line
    for row in [4, 7, 10, 13]:
        pygame.draw.line(surf, (224, 136, 136), (x, y + row), (x + 15, y + row))
    # Chimney (upper right area)
    chimney = (110, 88, 72)
    chimney_dark = (88, 68, 52)
    chimney_cap = (80, 60, 48)
    pygame.draw.rect(surf, chimney, (x + 10, y, 4, 7))
    pygame.draw.rect(surf, chimney_dark, (x + 10, y, 4, 1))  # top cap shadow
    pygame.draw.rect(surf, chimney_cap, (x + 9, y, 6, 1))    # cap overhang
    # Mortar line on chimney
    pygame.draw.line(surf, chimney_dark, (x + 10, y + 3), (x + 13, y + 3))


def _draw_house_roof_r(surf, x, y, _ticks):
    """Right edge of peaked roof — grass background with triangular roof section."""
    # Grass background
    for dy in range(16):
        for dx in range(16):
            px, py = dx & 7, dy & 7
            surf.set_at((x + dx, y + dy), _GRASS_COLS[_GRASS_PAT[py][px]])
    # Triangular roof section: starts full width at top-left, shrinks toward bottom-left
    roof_hi = (224, 136, 136)
    for row in range(16):
        right_edge = min(15, row)
        for col in range(0, right_edge + 1):
            row_idx = row // 3
            c = HOUSE_ROOF_DARK if row_idx & 1 else HOUSE_ROOF_MAIN
            if col == right_edge:
                c = (120, 64, 64)   # Dark diagonal edge
            elif col == right_edge - 1:
                c = (184, 96, 96)   # Shadow next to edge
            surf.set_at((x + col, y + row), c)
    # Shingle separator lines
    for row in [3, 6, 9, 12]:
        right_edge = min(15, row)
        pygame.draw.line(surf, HOUSE_ROOF_DARK, (x, y + row), (x + right_edge, y + row))
    # Left edge shared with middle — strong vertical shadow
    pygame.draw.line(surf, (104, 56, 56), (x, y), (x, y + 15))


def _draw_house_wall_l(surf, x, y, _ticks):
    """Left wall section — plaster wall with brick pattern and left edge."""
    surf.fill(HOUSE_WALL_MAIN, (x, y, TILE, TILE))
    wall_mortar = (200, 176, 128)
    # Horizontal mortar lines
    for my in [4, 8, 12]:
        pygame.draw.line(surf, wall_mortar, (x, y + my), (x + 15, y + my))
    # Staggered vertical mortar
    for row_start, cols in [(0, [8]), (4, [4, 12]), (8, [8]), (12, [4])]:
        for mx in cols:
            if mx < 16:
                end_y = min(row_start + 4, 16)
                pygame.draw.line(surf, wall_mortar, (x + mx, y + row_start), (x + mx, y + end_y - 1))
    # Left edge shadow (wall depth)
    pygame.draw.line(surf, HOUSE_WALL_DARK, (x, y, ), (x, y + 15))
    pygame.draw.line(surf, HOUSE_WALL_DARK, (x, y), (x + 15, y))
    # Subtle plaster variation
    rng = random.Random(x * 137 + y * 97)
    for _ in range(8):
        tx, ty = rng.randint(1, 15), rng.randint(1, 15)
        surf.set_at((x + tx, y + ty), HOUSE_WALL_DARK)


def _draw_house_wall_m(surf, x, y, _ticks):
    """Middle wall section — plaster wall with double-pane window."""
    surf.fill(HOUSE_WALL_MAIN, (x, y, TILE, TILE))
    wall_mortar = (200, 176, 128)
    frame_col = (176, 152, 104)
    # Top mortar line
    pygame.draw.line(surf, HOUSE_WALL_DARK, (x, y), (x + 15, y))
    # Horizontal mortar bands below window
    for my in [13]:
        pygame.draw.line(surf, wall_mortar, (x, y + my), (x + 15, y + my))
    # Window frame
    pygame.draw.rect(surf, frame_col, (x + 2, y + 2, 12, 9))
    # Glass panes (2x2 grid in 10x7 interior)
    pane = WINDOW_BLUE
    pygame.draw.rect(surf, pane, (x + 3, y + 3, 4, 3))
    pygame.draw.rect(surf, pane, (x + 9, y + 3, 4, 3))
    pygame.draw.rect(surf, pane, (x + 3, y + 7, 4, 3))
    pygame.draw.rect(surf, pane, (x + 9, y + 7, 4, 3))
    # Window reflections
    surf.set_at((x + 3, y + 3), (80, 120, 210))
    surf.set_at((x + 9, y + 3), (80, 120, 210))
    # Cross dividers
    pygame.draw.line(surf, frame_col, (x + 8, y + 3), (x + 8, y + 9))   # vertical
    pygame.draw.line(surf, frame_col, (x + 3, y + 6), (x + 13, y + 6))  # horizontal
    # Window sill
    pygame.draw.rect(surf, HOUSE_WALL_DARK, (x + 1, y + 11, 14, 2))
    # Subtle plaster
    rng = random.Random(x * 137 + y * 97)
    for _ in range(5):
        tx, ty = rng.randint(0, 15), rng.randint(0, 15)
        surf.set_at((x + tx, y + ty), (240, 216, 168))


def _draw_house_wall_r(surf, x, y, _ticks):
    """Right wall section — plaster wall with right edge shadow."""
    surf.fill(HOUSE_WALL_MAIN, (x, y, TILE, TILE))
    wall_mortar = (200, 176, 128)
    # Horizontal mortar lines
    for my in [4, 8, 12]:
        pygame.draw.line(surf, wall_mortar, (x, y + my), (x + 15, y + my))
    # Staggered vertical mortar (mirror of left)
    for row_start, cols in [(0, [8]), (4, [4, 12]), (8, [8]), (12, [12])]:
        for mx in cols:
            if mx < 16:
                end_y = min(row_start + 4, 16)
                pygame.draw.line(surf, wall_mortar, (x + mx, y + row_start), (x + mx, y + end_y - 1))
    # Right edge shadow and top border
    pygame.draw.line(surf, HOUSE_WALL_DARK, (x + 15, y), (x + 15, y + 15))
    pygame.draw.line(surf, HOUSE_WALL_DARK, (x, y), (x + 15, y))
    # Subtle plaster variation
    rng = random.Random(x * 137 + y * 97)
    for _ in range(8):
        tx, ty = rng.randint(0, 14), rng.randint(1, 15)
        surf.set_at((x + tx, y + ty), HOUSE_WALL_DARK)


def _draw_house_base_l(surf, x, y, _ticks):
    """Left base — lower wall with stone foundation strip."""
    surf.fill(HOUSE_WALL_MAIN, (x, y, TILE, TILE))
    wall_mortar = (200, 176, 128)
    # Horizontal mortar
    for my in [4, 8]:
        pygame.draw.line(surf, wall_mortar, (x, y + my), (x + 15, y + my))
    # Left edge shadow
    pygame.draw.line(surf, HOUSE_WALL_DARK, (x, y), (x, y + 11))
    # Foundation stone strip (bottom 4 rows)
    pygame.draw.rect(surf, _FOUNDATION, (x, y + 12, TILE, 4))
    pygame.draw.line(surf, _FOUNDATION_DARK, (x, y + 12), (x + 15, y + 12))  # top shadow of foundation
    # Foundation mortar
    pygame.draw.line(surf, _FOUNDATION_DARK, (x + 8, y + 12), (x + 8, y + 15))
    # Subtle plaster
    rng = random.Random(x * 137 + y * 97)
    for _ in range(6):
        tx, ty = rng.randint(1, 15), rng.randint(0, 11)
        surf.set_at((x + tx, y + ty), HOUSE_WALL_DARK)


def _draw_house_base_m(surf, x, y, _ticks):
    """Middle base — lower wall with centred wooden door and stone foundation."""
    surf.fill(HOUSE_WALL_MAIN, (x, y, TILE, TILE))
    # Door frame
    frame = (144, 104, 40)
    pygame.draw.rect(surf, frame, (x + 4, y, 8, 12))
    # Door panel
    pygame.draw.rect(surf, HOUSE_DOOR_MAIN, (x + 5, y + 1, 6, 10))
    # Plank lines
    pygame.draw.line(surf, HOUSE_DOOR_DARK, (x + 7, y + 1), (x + 7, y + 10))
    pygame.draw.line(surf, HOUSE_DOOR_DARK, (x + 9, y + 1), (x + 9, y + 10))
    # Horizontal brace
    pygame.draw.rect(surf, HOUSE_DOOR_DARK, (x + 5, y + 5, 6, 1))
    # Frame edges
    pygame.draw.line(surf, HOUSE_DOOR_DARK, (x + 4, y), (x + 4, y + 11))
    pygame.draw.line(surf, HOUSE_DOOR_DARK, (x + 11, y), (x + 11, y + 11))
    pygame.draw.line(surf, HOUSE_DOOR_DARK, (x + 4, y), (x + 11, y))
    # Handle
    pygame.draw.rect(surf, DOOR_HANDLE, (x + 10, y + 6, 1, 2))
    # Threshold
    pygame.draw.rect(surf, (160, 136, 88), (x + 5, y + 11, 6, 1))
    # Foundation stone
    pygame.draw.rect(surf, _FOUNDATION, (x, y + 12, TILE, 4))
    pygame.draw.line(surf, _FOUNDATION_DARK, (x, y + 12), (x + 15, y + 12))
    # Foundation mortar
    pygame.draw.line(surf, _FOUNDATION_DARK, (x + 8, y + 12), (x + 8, y + 15))


def _draw_house_base_r(surf, x, y, _ticks):
    """Right base — lower wall with stone foundation strip."""
    surf.fill(HOUSE_WALL_MAIN, (x, y, TILE, TILE))
    wall_mortar = (200, 176, 128)
    # Horizontal mortar
    for my in [4, 8]:
        pygame.draw.line(surf, wall_mortar, (x, y + my), (x + 15, y + my))
    # Right edge shadow
    pygame.draw.line(surf, HOUSE_WALL_DARK, (x + 15, y), (x + 15, y + 11))
    # Foundation stone strip
    pygame.draw.rect(surf, _FOUNDATION, (x, y + 12, TILE, 4))
    pygame.draw.line(surf, _FOUNDATION_DARK, (x, y + 12), (x + 15, y + 12))
    # Foundation mortar
    pygame.draw.line(surf, _FOUNDATION_DARK, (x + 8, y + 12), (x + 8, y + 15))
    # Subtle plaster
    rng = random.Random(x * 137 + y * 97)
    for _ in range(6):
        tx, ty = rng.randint(0, 14), rng.randint(0, 11)
        surf.set_at((x + tx, y + ty), HOUSE_WALL_DARK)


def _draw_castle_wall_t(surf, x, y, _ticks):
    """Castle wall top edge — pale stone with crenellation silhouette."""
    rng = random.Random(x * 137 + y * 97)
    stone_mid = (192, 192, 200)
    mortar = (152, 152, 168)
    surf.fill(CASTLE_STONE, (x, y, TILE, TILE))
    # Stone texture
    for dy in range(16):
        for dx in range(16):
            n = rng.random()
            if n < 0.08:
                surf.set_at((x + dx, y + dy), CASTLE_DARK)
            elif n < 0.16:
                surf.set_at((x + dx, y + dy), stone_mid)
    # Horizontal mortar lines
    for my in [5, 10, 15]:
        pygame.draw.line(surf, mortar, (x, y + my), (x + 15, y + my))
    # Top crenellation hint (alternating dark notches)
    for notch_x in [0, 5, 10]:
        pygame.draw.rect(surf, mortar, (x + notch_x, y, 3, 3))


def _draw_castle_wall_b(surf, x, y, _ticks):
    """Castle wall body — pale stone bricks (lower section)."""
    rng = random.Random(x * 137 + y * 97)
    stone_mid = (192, 192, 200)
    mortar = (152, 152, 168)
    surf.fill(CASTLE_STONE, (x, y, TILE, TILE))
    for dy in range(16):
        for dx in range(16):
            n = rng.random()
            if n < 0.08:
                surf.set_at((x + dx, y + dy), CASTLE_DARK)
            elif n < 0.16:
                surf.set_at((x + dx, y + dy), stone_mid)
    for my in [0, 5, 10, 15]:
        pygame.draw.line(surf, mortar, (x, y + my), (x + 15, y + my))
    # Staggered verticals
    for section, offsets in [(0, [8]), (5, [4, 12]), (10, [8])]:
        for mx in offsets:
            for dy in range(5):
                if mx < 16:
                    surf.set_at((x + mx, y + section + dy), mortar)


def _draw_castle_parapet(surf, x, y, _ticks):
    """Castle parapet / battlement tile — merlons with sky gaps."""
    rng = random.Random(x * 137 + y * 97)
    stone_mid = (192, 192, 200)
    mortar = (152, 152, 168)
    sky = (80, 120, 180)
    surf.fill(sky, (x, y, TILE, TILE))
    # Three merlons
    for bx, bw in [(0, 4), (6, 4), (12, 4)]:
        pygame.draw.rect(surf, CASTLE_LIGHT, (x + bx, y, bw, 10))
        for dy in range(10):
            for dx in range(bw):
                n = rng.random()
                if n < 0.1:
                    surf.set_at((x + bx + dx, y + dy), CASTLE_DARK)
                elif n < 0.18:
                    surf.set_at((x + bx + dx, y + dy), stone_mid)
        pygame.draw.rect(surf, mortar, (x + bx, y + 5, bw, 1))
        pygame.draw.rect(surf, CASTLE_DARK, (x + bx, y + 9, bw, 1))
    # Bottom wall strip
    pygame.draw.rect(surf, CASTLE_STONE, (x, y + 10, TILE, 6))
    pygame.draw.line(surf, mortar, (x, y + 10), (x + 15, y + 10))
    pygame.draw.line(surf, mortar, (x, y + 15), (x + 15, y + 15))


def _draw_castle_window(surf, x, y, _ticks):
    """Castle wall section with narrow arrow-slit window."""
    rng = random.Random(x * 137 + y * 97)
    stone_mid = (192, 192, 200)
    mortar = (152, 152, 168)
    surf.fill(CASTLE_STONE, (x, y, TILE, TILE))
    for dy in range(16):
        for dx in range(16):
            n = rng.random()
            if n < 0.08:
                surf.set_at((x + dx, y + dy), CASTLE_DARK)
            elif n < 0.16:
                surf.set_at((x + dx, y + dy), stone_mid)
    # Mortar lines
    for my in [5, 10, 15]:
        pygame.draw.line(surf, mortar, (x, y + my), (x + 15, y + my))
    # Arrow slit
    pygame.draw.rect(surf, CAVE_DARK, (x + 7, y + 2, 2, 8))
    pygame.draw.rect(surf, CAVE_DARK, (x + 5, y + 5, 6, 2))
    # Stone arch above slit
    surf.set_at((x + 6, y + 2), CASTLE_DARK)
    surf.set_at((x + 9, y + 2), CASTLE_DARK)


# ══════════════════════════════════════════
#  DISPATCH — maps tile ID → draw function
# ══════════════════════════════════════════
_TILE_DRAW = {
    OW_GRASS:        _draw_grass,
    OW_DARK_GRASS:   _draw_dark_grass,
    OW_PATH:         _draw_path,
    OW_SAND:         _draw_sand,
    OW_SWAMP:        _draw_swamp,
    OW_WATER:        _draw_water,
    OW_DEEP_WATER:   _draw_deep_water,
    OW_WATERFALL:    _draw_waterfall,
    OW_CLIFF_FACE:   _draw_cliff_face,
    OW_CLIFF_TOP:    _draw_cliff_top,
    OW_CLIFF_LEFT:   _draw_cliff_left,
    OW_CLIFF_RIGHT:  _draw_cliff_right,
    OW_CLIFF_TL:     _draw_cliff_tl,
    OW_CLIFF_TR:     _draw_cliff_tr,
    OW_CLIFF_BL:     _draw_cliff_bl,
    OW_CLIFF_BR:     _draw_cliff_br,
    OW_MOUNTAIN:     _draw_mountain,
    OW_CAVE:         _draw_cave,
    OW_STAIRS:       _draw_stairs,
    OW_TREE:         _draw_tree,
    OW_DARK_TREE:    _draw_dark_tree,
    OW_BUSH:         _draw_bush,
    OW_TALL_GRASS:   _draw_tall_grass,
    OW_FLOWERS:      _draw_flowers,
    OW_HOUSE_ROOF:   _draw_house_roof,
    OW_HOUSE_WALL:   _draw_house_wall,
    OW_HOUSE_DOOR:   _draw_house_door,
    OW_CASTLE_WALL:  _draw_castle_wall,
    OW_CASTLE_TOWER: _draw_castle_tower,
    OW_CASTLE_GATE:  _draw_castle_gate,
    # Multi-tile structure parts
    OW_HOUSE_ROOF_L:  _draw_house_roof_l,
    OW_HOUSE_ROOF_M:  _draw_house_roof_m,
    OW_HOUSE_ROOF_R:  _draw_house_roof_r,
    OW_HOUSE_WALL_L:  _draw_house_wall_l,
    OW_HOUSE_WALL_M:  _draw_house_wall_m,
    OW_HOUSE_WALL_R:  _draw_house_wall_r,
    OW_HOUSE_BASE_L:  _draw_house_base_l,
    OW_HOUSE_BASE_M:  _draw_house_base_m,
    OW_HOUSE_BASE_R:  _draw_house_base_r,
    OW_CASTLE_WALL_T: _draw_castle_wall_t,
    OW_CASTLE_WALL_B: _draw_castle_wall_b,
    OW_CASTLE_PARAPET:_draw_castle_parapet,
    OW_CASTLE_WINDOW: _draw_castle_window,
    OW_BRIDGE:       _draw_bridge,
    OW_FENCE:        _draw_fence,
    OW_SIGN:         _draw_sign,
    OW_TORCH:        _draw_torch,
    OW_DUNGEON:      _draw_dungeon,
    OW_CHEST:        _draw_chest,
    OW_BOUNDARY:     _draw_boundary,
}

def draw_overworld_tile(surf, tile_id, x, y, ticks):
    """Draw a single overworld tile at pixel position (x, y).

    No GAME_Y offset — caller handles screen positioning.
    """
    fn = _TILE_DRAW.get(tile_id)
    if fn:
        fn(surf, x, y, ticks)

def get_overlay_tiles():
    """Return set of tile IDs that have canopy overlays (drawn above sprites)."""
    return {tid for tid, props in TILE_PROPS.items() if props.get("overlay")}
