"""
Bridge: Controller → Keyboard Simulator

Connects to the relay server via socket.io, receives controller input,
and simulates keyboard key presses so the Pygame game works unmodified.

Usage:
    pip3 install python-socketio[client]
    python3 bridge.py

Uses macOS Quartz for reliable keyboard simulation.

Key mapping (matches main.py):
    Player 1:
      Left joystick  → W/A/S/D (movement)
      Attack button  → Space (attack)
      Shield button  → Left Shift (block)
      Item slot 1/2/3 → 1/2/3 keys
      Pause          → Escape

    Player 2:
      Left joystick  → I/J/K/L (movement)
      Attack button  → Enter (attack)
      Shield button  → Right Shift (block)
      Item slot 1/2/3 → 7/8/9 keys

    Player 3:
      Left joystick  → T/F/G/H (movement)
      Attack button  → Y (attack)
      Shield button  → U (block)
      Item slot 1/2/3 → 4/5/6 keys

    Player 4:
      Left joystick  → Numpad 8/4/5/6 (movement)
      Attack button  → Numpad 0 (attack)
      Shield button  → Numpad Enter (block)
      Item slot 1/2/3 → Numpad 1/2/3 keys
"""

import socketio
import sys
import time
from Quartz import (
    CGEventCreateKeyboardEvent,
    CGEventPost,
    kCGHIDEventTap,
    CGEventSetFlags,
)

# ══════════════════════════════════════════
#  CONFIG
# ══════════════════════════════════════════
SERVER_URL = 'http://localhost:3000'
DEADZONE = 0.15
DEBUG = True

# ══════════════════════════════════════════
#  macOS VIRTUAL KEY CODES
# ══════════════════════════════════════════
KEY_CODES = {
    'w': 13, 'a': 0, 's': 1, 'd': 2,
    'i': 34, 'j': 38, 'k': 40, 'l': 37,
    'space': 49, 'return': 36, 'escape': 53,
    'shift_l': 56, 'shift_r': 60,
    'tab': 48,
    '1': 18, '2': 19, '3': 20,
    '7': 26, '8': 28, '9': 25,
    # Player 3
    't': 17, 'g': 5, 'f': 3, 'h': 4,
    'y': 16, 'u': 32,
    '4': 21, '5': 23, '6': 22,
    # Player 4 (numpad)
    'kp0': 82, 'kp1': 83, 'kp2': 84, 'kp3': 85,
    'kp4': 86, 'kp5': 87, 'kp6': 88, 'kp8': 91,
    'kp_enter': 76,
}

# ══════════════════════════════════════════
#  KEYBOARD SIMULATION (Quartz)
# ══════════════════════════════════════════
held_keys = set()

def key_down(key_name):
    code = KEY_CODES.get(key_name)
    if code is None:
        return
    if key_name not in held_keys:
        held_keys.add(key_name)
        event = CGEventCreateKeyboardEvent(None, code, True)
        CGEventPost(kCGHIDEventTap, event)

def key_up(key_name):
    code = KEY_CODES.get(key_name)
    if code is None:
        return
    if key_name in held_keys:
        held_keys.discard(key_name)
        event = CGEventCreateKeyboardEvent(None, code, False)
        CGEventPost(kCGHIDEventTap, event)

def key_tap(key_name):
    """Press and release a key (for one-shot actions like weapon switch)."""
    code = KEY_CODES.get(key_name)
    if code is None:
        return
    down = CGEventCreateKeyboardEvent(None, code, True)
    up = CGEventCreateKeyboardEvent(None, code, False)
    CGEventPost(kCGHIDEventTap, down)
    CGEventPost(kCGHIDEventTap, up)

def release_all():
    for key_name in list(held_keys):
        key_up(key_name)

# ══════════════════════════════════════════
#  PLAYER KEY MAPS
# ══════════════════════════════════════════
PLAYER_KEYS = {
    1: {
        'up': 'w', 'down': 's', 'left': 'a', 'right': 'd',
        'attack': 'space',
        'shield': 'shift_l',
        'slot1': '1', 'slot2': '2', 'slot3': '3',
        'pause': 'escape',
    },
    2: {
        'up': 'i', 'down': 'k', 'left': 'j', 'right': 'l',
        'attack': 'return',
        'shield': 'shift_r',
        'slot1': '7', 'slot2': '8', 'slot3': '9',
        'pause': 'escape',
    },
    3: {
        'up': 't', 'down': 'g', 'left': 'f', 'right': 'h',
        'attack': 'y',
        'shield': 'u',
        'slot1': '4', 'slot2': '5', 'slot3': '6',
        'pause': 'escape',
    },
    4: {
        'up': 'kp8', 'down': 'kp5', 'left': 'kp4', 'right': 'kp6',
        'attack': 'kp0',
        'shield': 'kp_enter',
        'slot1': 'kp1', 'slot2': 'kp2', 'slot3': 'kp3',
        'pause': 'escape',
    },
}

# ══════════════════════════════════════════
#  INPUT TRANSLATION
# ══════════════════════════════════════════
player_state = {
    1: {'last_slot': 1, 'last_paused': False},
    2: {'last_slot': 1, 'last_paused': False},
    3: {'last_slot': 1, 'last_paused': False},
    4: {'last_slot': 1, 'last_paused': False},
}

def handle_input(data):
    player = data.get('player', 1)
    if player not in (1, 2, 3, 4):
        player = 1

    keys = PLAYER_KEYS[player]
    ps = player_state[player]

    if DEBUG:
        mx = data.get('moveX', 0)
        my = data.get('moveY', 0)
        atk = data.get('attack', False)
        shd = data.get('shield', False)
        parts = []
        if abs(mx) > DEADZONE or abs(my) > DEADZONE:
            parts.append('move({:.1f},{:.1f})'.format(mx, my))
        if atk:
            parts.append('ATTACK')
        if shd:
            parts.append('SHIELD')
        if parts:
            print('  P{}: {}'.format(player, ' '.join(parts)))

    # --- Movement ---
    mx = data.get('moveX', 0)
    my = data.get('moveY', 0)

    if my < -DEADZONE:
        key_down(keys['up'])
    else:
        key_up(keys['up'])

    if my > DEADZONE:
        key_down(keys['down'])
    else:
        key_up(keys['down'])

    if mx < -DEADZONE:
        key_down(keys['left'])
    else:
        key_up(keys['left'])

    if mx > DEADZONE:
        key_down(keys['right'])
    else:
        key_up(keys['right'])

    # --- Attack (tap → key tap for KEYDOWN event) ---
    if data.get('attack', False):
        key_down(keys['attack'])
    else:
        key_up(keys['attack'])

    # --- Shield (hold) ---
    if data.get('shield', False):
        key_down(keys['shield'])
    else:
        key_up(keys['shield'])

    # --- Item slots (tap only on change) ---
    slot = data.get('slot', 1)
    if slot != ps['last_slot']:
        ps['last_slot'] = slot
        slot_key = keys.get('slot' + str(slot))
        if slot_key:
            key_tap(slot_key)
            if DEBUG:
                print('  P{}: weapon slot {}'.format(player, slot))

    # --- Pause (tap only on change) ---
    paused = data.get('paused', False)
    if paused != ps['last_paused']:
        ps['last_paused'] = paused
        key_tap(keys['pause'])
        if DEBUG:
            print('  P{}: {}'.format(player, 'PAUSED' if paused else 'RESUMED'))

# ══════════════════════════════════════════
#  SOCKET.IO CLIENT
# ══════════════════════════════════════════
sio = socketio.Client(reconnection=True, reconnection_delay=1)

@sio.on('connect')
def on_connect():
    sio.emit('register', 'game')
    print('[+] Connected to relay server')
    print('    Waiting for controller input...')
    print('')

@sio.on('disconnect')
def on_disconnect():
    print('[-] Disconnected from relay server')
    release_all()

@sio.on('input')
def on_input(data):
    handle_input(data)

# ══════════════════════════════════════════
#  MAIN
# ══════════════════════════════════════════
def main():
    print('')
    print('  Zelda Controller Bridge')
    print('  ───────────────────────')
    print('  Connecting to ' + SERVER_URL + '...')
    print('')
    print('  1. Start relay server   (cd server && npm start)')
    print('  2. Start this bridge    (python3 bridge.py)')
    print('  3. Start the game       (python3 main.py)')
    print('  4. CLICK THE GAME WINDOW to focus it!')
    print('  5. Open controller on your phone')
    print('')
    print('  Player 1: WASD + Space + Shift')
    print('  Player 2: IJKL + Enter + RShift')
    print('  Player 3: TFGH + Y + U')
    print('  Player 4: Numpad 8456 + Num0 + NumEnter')
    print('')

    try:
        sio.connect(SERVER_URL)
        sio.wait()
    except KeyboardInterrupt:
        print('\n[!] Shutting down...')
        release_all()
        sio.disconnect()
    except Exception as e:
        print('[!] Connection failed: ' + str(e))
        print('    Is the relay server running?')
        sys.exit(1)

if __name__ == '__main__':
    main()
