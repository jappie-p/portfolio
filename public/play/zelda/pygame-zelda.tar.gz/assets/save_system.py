"""
Save system — persist game progress to JSON files.

Saves: player stats, completed dungeons, collected items,
current screen position, unlocked weapons.
"""
import json
import os

SAVE_DIR = os.path.join(os.path.dirname(__file__), "saves")
MAX_SLOTS = 3


def _save_path(slot):
    return os.path.join(SAVE_DIR, f"save_{slot}.json")


def ensure_save_dir():
    os.makedirs(SAVE_DIR, exist_ok=True)


def save_game(slot, data):
    """Save game state to a slot (1-3).

    Args:
        slot: Save slot number (1-3)
        data: Dict with game state:
            - player_hp, player_max_hp
            - rupees, arrows, bombs, keys
            - weapons_unlocked: list of weapon names
            - completed_dungeons: list of completed level numbers
            - current_screen: (col, row) tuple for overworld
            - player_x, player_y: position
            - hearts_collected: list of heart piece IDs
            - play_time_seconds: int
            - player_kills: int
            - game_mode: "overworld" or "dungeon"
            - dungeon_level: current dungeon level (if in dungeon mode)
    """
    ensure_save_dir()
    save_data = {
        "slot": slot,
        "version": 1,
        **data,
    }
    # Convert tuples to lists for JSON serialization
    if "current_screen" in save_data and isinstance(save_data["current_screen"], tuple):
        save_data["current_screen"] = list(save_data["current_screen"])

    with open(_save_path(slot), 'w') as f:
        json.dump(save_data, f, indent=2)
    return True


def load_game(slot):
    """Load game state from a slot.

    Returns:
        Dict with game state, or None if slot is empty.
    """
    path = _save_path(slot)
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'r') as f:
            data = json.load(f)
        # Convert lists back to tuples where needed
        if "current_screen" in data and isinstance(data["current_screen"], list):
            data["current_screen"] = tuple(data["current_screen"])
        return data
    except (json.JSONDecodeError, IOError):
        return None


def delete_save(slot):
    """Delete a save slot."""
    path = _save_path(slot)
    if os.path.exists(path):
        os.remove(path)
        return True
    return False


def list_saves():
    """List all save slots with basic info.

    Returns:
        Dict of slot → {exists, player_hp, completed_dungeons, play_time, ...} or None
    """
    ensure_save_dir()
    saves = {}
    for slot in range(1, MAX_SLOTS + 1):
        data = load_game(slot)
        if data:
            saves[slot] = {
                "exists": True,
                "hp": data.get("player_hp", 0),
                "max_hp": data.get("player_max_hp", 6),
                "completed": len(data.get("completed_dungeons", [])),
                "play_time": data.get("play_time_seconds", 0),
                "kills": data.get("player_kills", 0),
                "mode": data.get("game_mode", "unknown"),
            }
        else:
            saves[slot] = {"exists": False}
    return saves


def format_time(seconds):
    """Format seconds as H:MM:SS or M:SS."""
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    if h > 0:
        return f"{h}:{m:02d}:{s:02d}"
    return f"{m}:{s:02d}"
