# Technisch Ontwerp — Zelda Remote Controller

## 1. Inleiding

Dit document beschrijft de technische opbouw van het Zelda Remote Controller project. Het bevat de gekozen technologieën, architectuur, datastructuren en technische eisen per component.

## 2. Architectuur

```
Telefoon (browser)       Node.js server        Pygame game (laptop)
┌──────────────┐        ┌──────────────┐       ┌──────────────┐
│ HTML/CSS/JS   │──ws──▶│  Relay server │──ws──▶│ Python game   │
│ Touch events  │       │  (socket.io)  │       │ Leest input   │
│ Controller UI │       │              │◀──ws──│ Stuurt state  │
└──────────────┘        └──────────────┘       └──────────────┘
    ▲                                               │
    └───────────────── game state ──────────────────┘
```

Alle communicatie verloopt via WebSockets (socket.io) voor real-time bidirectionele verbinding met minimale latency.

## 3. Technologieën

| Component | Technologie | Versie | Doel |
|-----------|------------|--------|------|
| Game engine | Python + Pygame | Python 3.x, Pygame 2.x | 2D game rendering, input, collision detection |
| Relay server | Node.js + socket.io | Node.js 18+, socket.io 4.x | WebSocket relay tussen controller en game |
| Controller | HTML5 + CSS3 + JavaScript | ES6+ | Responsive touch controller in de browser |
| Game WebSocket client | python-socketio | 5.x | Pygame ontvangt input van relay server |
| Versiebeheer | Git + GitHub | - | Code hosting en samenwerking |

## 4. Component: Pygame Game

### 4.1 Rendering

- **SNES-style rendering**: intern canvas van 256×224 pixels, opgeschaald 3× naar 768×672 voor scherpe pixels
- **Tile-based maps**: 16×12 grid per level, tile grootte 16×16 pixels
- **HUD**: 28px bovenbalk met health, rupees, wapen, munitie
- **60 FPS** game loop met `pygame.time.Clock`

### 4.2 Sprite systeem

- Speler sprites geladen uit `link_sprites.png` spritesheet
- 4 richtingen (up/down/left/right), 2 animatieframes per richting
- Left sprites = horizontaal gespiegelde right sprites
- Vijandsprites procedureel gegenereerd met `pygame.draw`
- Teal achtergrond (0, 128, 128) wordt per-pixel vervangen door transparantie

### 4.3 Tile types

| Code | Tile | Beschrijving |
|------|------|-------------|
| 0 | Grass | Begaanbaar, groen |
| 1 | Wall | Niet begaanbaar, stenen muur |
| 2 | Path | Begaanbaar, zandpad |
| 3 | Water | Niet begaanbaar, geanimeerd |
| 4 | Tree | Niet begaanbaar, boom |
| 5 | Tall grass | Begaanbaar, kan geknipt worden voor drops |
| 6 | Stairs | Begaanbaar, level overgang |
| 7 | Lava | Niet begaanbaar, geanimeerd |
| 8 | Dark floor | Begaanbaar, dungeon vloer |
| 9 | Torch wall | Niet begaanbaar, muur met fakkel |

### 4.4 Game classes

| Class | Verantwoordelijkheid |
|-------|---------------------|
| `Player` | Positie, movement, combat, inventory, animatie |
| `Enemy` | AI, movement patterns, health, damage, boss fases |
| `Projectile` | Pijlen, bommen, vijand vuurballen — positie, richting, collision |
| `NPC` | Positie, dialoogteksten, interactie trigger |
| `Chest` | Positie, item type, open/dicht state |
| `Pickup` | Positie, item type (heart, rupee, arrows, bombs) |
| `Particle` | Visuele effecten (damage, explosies) |
| `DmgNum` | Floating damage numbers |
| `Dialogue` | Tekstbox rendering met typewriter effect |

### 4.5 Vijand types

| Type | HP | Speed | Damage | AI gedrag |
|------|-----|-------|--------|-----------|
| Slime | 2 | 0.6 | 1 | Willekeurige richting, verandert periodiek |
| Bat | 1 | 1.2 | 1 | Zigzag richting speler (sinusgolf) |
| Skeleton | 3 | 0.5 | 1 | Volgt speler direct |
| Knight | 5 | 0.4 | 2 | Volgt speler direct, meer HP en damage |
| Mage | 3 | 0.3 | 1 | Volgt speler, schiet magische projectielen |
| Boss | 30 | 0.6→1.5 | 2 | 3 fases met toenemende snelheid en projectielen |

### 4.6 Levels

| Level | Naam | Omgeving | Vijanden | Speciale items |
|-------|------|----------|----------|----------------|
| 0 | The Forest | Bos met bomen en gras | 4 slimes, 1 bat | — |
| 1 | Dark Cave | Donkere grot met fakkels | 3 bats, 2 skeletons, 1 slime | Boog (chest) |
| 2 | Castle Halls | Kasteel kamers | 2 knights, 3 skeletons, 1 mage | Bommen (chest) |
| 3 | Lava Depths | Lava dungeon | 2 mages, 3 knights, 2 bats | Hart container (chest) |
| 4 | Shadow Lord | Boss arena | 1 boss | — |

### 4.7 Geluidseffecten

Procedureel gegenereerd via `pygame.mixer` met waveforms (square, sine, noise). Geen externe audiobestanden nodig.

| Effect | Frequentie | Waveform | Trigger |
|--------|-----------|----------|---------|
| Sword | 280→560 Hz | Square | Zwaard aanval |
| Arrow | 700→350 Hz | Sine | Pijl schieten |
| Bomb | 60 Hz | Noise | Bom explosie |
| Hit/Hurt | 180/280 Hz | Square | Schade geven/ontvangen |
| Pickup | 600→900 Hz | Sine | Item oprapen |

## 5. Component: Node.js Relay Server

### 5.1 Doel

De relay server fungeert als tussenstuk tussen de telefoon (controller) en de Pygame game. Beide clients verbinden via socket.io.

### 5.2 Technische opzet

```javascript
// Pseudocode relay server
const io = require("socket.io")(server);

io.on("connection", (socket) => {
    // Controller stuurt input
    socket.on("input", (data) => {
        socket.broadcast.emit("input", data);
    });

    // Game stuurt state terug
    socket.on("game_state", (data) => {
        socket.broadcast.emit("game_state", data);
    });
});
```

### 5.3 Vereisten

- Draait op **hetzelfde lokale netwerk** als de telefoon en laptop
- Poort: standaard `3000` (configureerbaar)
- Dependencies: `express`, `socket.io`
- Minimale logica — stuurt JSON berichten ongewijzigd door

## 6. Component: Controller (telefoon)

### 6.1 Technische opzet

- **Responsive layout**: CSS Grid/Flexbox, schaalt naar verschillende telefoonformaten
- **Touch events**: `touchstart`, `touchend`, `touchmove` voor D-pad en knoppen
- **Haptic feedback**: `navigator.vibrate()` bij knopdruk (waar ondersteund)
- **Visuele feedback**: knoppen lichten op bij aanraking (CSS `:active` / JS class toggle)
- **Fullscreen**: optie om in fullscreen modus te draaien (geen browser UI)

### 6.2 Data versturen

Bij elke touch event wordt de huidige input state als JSON naar de relay server gestuurd:

```json
{
    "type": "input",
    "dpad": "up",
    "a": false,
    "b": false,
    "start": false,
    "select": false
}
```

D-pad waarden: `"up"`, `"down"`, `"left"`, `"right"`, `"none"`

### 6.3 State ontvangen

De controller ontvangt game state voor de HUD display:

```json
{
    "type": "state",
    "hp": 6,
    "maxHp": 6,
    "rupees": 12,
    "weapon": "sword",
    "arrows": 15,
    "bombs": 5,
    "area": "The Forest"
}
```

## 7. Component: Pygame WebSocket Client

### 7.1 Doel

De Pygame game moet input ontvangen van de relay server in plaats van (of naast) het toetsenbord.

### 7.2 Technische opzet

- Library: `python-socketio` (async client)
- Draait in een aparte thread naast de Pygame game loop
- Vertaalt JSON input naar hetzelfde formaat als `pygame.key.get_pressed()`
- Input handler abstractie: zowel keyboard als WebSocket input wordt via dezelfde interface verwerkt

```python
# Pseudocode input abstractie
class InputHandler:
    def __init__(self):
        self.state = {"dpad": "none", "a": False, "b": False}

    def update_from_websocket(self, data):
        self.state = data

    def get_pressed(self):
        # Combineert keyboard + WebSocket input
        keys = pygame.key.get_pressed()
        # Override met WebSocket data als beschikbaar
        return merged_input
```

## 8. Dataflow diagram

```
┌─────────────┐     touchstart/end      ┌──────────────┐
│  D-pad /    │ ──────────────────────▶ │  JavaScript  │
│  Buttons    │                         │  Event       │
│  (HTML)     │                         │  Handler     │
└─────────────┘                         └──────┬───────┘
                                               │
                                    JSON: { dpad, a, b }
                                               │
                                               ▼
                                    ┌──────────────────┐
                                    │  socket.io       │
                                    │  emit("input")   │
                                    └──────┬───────────┘
                                           │ WebSocket
                                           ▼
                                    ┌──────────────────┐
                                    │  Node.js Relay   │
                                    │  Server          │
                                    └──────┬───────────┘
                                           │ WebSocket
                                           ▼
                                    ┌──────────────────┐
                                    │  python-socketio │
                                    │  client          │
                                    └──────┬───────────┘
                                           │
                                    InputHandler.update()
                                           │
                                           ▼
                                    ┌──────────────────┐
                                    │  Pygame Game     │
                                    │  Loop (60 FPS)   │
                                    └──────────────────┘
```

## 9. Technische eisen

| Eis | Specificatie |
|-----|-------------|
| Latency | < 50ms van controller input tot game reactie |
| Framerate | Stabiel 60 FPS |
| Resolutie | 256×224 intern, 768×672 weergave (3× schaal) |
| Browser support | Safari (iOS), Chrome (Android) |
| Netwerk | Lokaal WiFi netwerk (zelfde subnet) |
| Minimaal 4 interacties | D-pad, A-knop, B-knop, Start |

## 10. Bestandsstructuur

```
pygame-zelda/
├── main.py                  # Pygame game (1550 regels)
├── link_sprites.png         # Spritesheet voor Link
├── extract_sprites.py       # Tool om sprites uit sheet te halen
├── sprites/                 # Geëxtraheerde sprite bestanden
├── server/                  # Node.js relay server
│   ├── server.js            # Socket.io relay
│   ├── package.json         # Dependencies
│   └── public/              # Controller HTML/CSS/JS
│       ├── index.html       # Controller pagina
│       ├── style.css        # Controller styling
│       └── controller.js    # Touch events + socket.io client
├── docs/                    # Documentatie
│   ├── plan-van-aanpak.md
│   ├── functioneel-ontwerp.md
│   ├── technisch-ontwerp.md
│   └── concept.md
├── venv/                    # Python virtual environment
└── README.md
```

## 11. API / Protocol specificatie

### Events (socket.io)

| Event naam | Richting | Payload | Beschrijving |
|------------|----------|---------|-------------|
| `input` | Controller → Server → Game | `{ dpad, a, b, start, select }` | Controller input state |
| `game_state` | Game → Server → Controller | `{ hp, maxHp, weapon, area, ... }` | Game state voor controller HUD |
| `connect` | Beide | — | Socket.io verbinding gemaakt |
| `disconnect` | Beide | — | Verbinding verbroken |
