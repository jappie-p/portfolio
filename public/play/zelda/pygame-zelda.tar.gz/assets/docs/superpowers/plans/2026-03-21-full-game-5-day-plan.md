# Full ALttP Game — 5-Day Build Plan

> **Goal:** Transform the demo into a polished ALttP recreation that looks and feels authentic.
> Each day has a clear deliverable you can play-test at the end.

---

## Day 1: Foundation — Tileset System + Auto-Tiling (TODAY/TOMORROW)
**Deliverable:** Game renders tiles from sprite sheets instead of code-drawn shapes

### Morning (3-4 hours)
- [ ] Build `tileset.py` — sprite sheet loader that cuts 16x16 tiles from a PNG grid
- [ ] Build tile mapping system: `TILE_ID → (sheet, x, y)` lookup
- [ ] Create a fallback: if sprite sheet missing, use current procedural drawing
- [ ] Download/prepare ALttP overworld tileset (USER ACTION)

### Afternoon (3-4 hours)
- [ ] Replace `draw_overworld_tile()` to use sprite-based rendering when available
- [ ] Build auto-tiling engine: checks 4/8 neighbors, picks correct edge variant
  - Grass-to-path transitions (8 edge variants + 4 corners)
  - Grass-to-water transitions (8 edges + 4 corners)
  - Cliff edges (top, left, right, corners)
- [ ] Update screen cache to work with sprite tiles
- [ ] Play-test: overworld should look dramatically better

### Evening (2 hours)
- [ ] Build dungeon tileset loader (walls, floors, doors)
- [ ] Replace dungeon `draw_tile()` with sprite-based
- [ ] Play-test dungeon mode with real tiles

**End of Day 1:** Game uses real ALttP tile graphics everywhere

---

## Day 2: Structures + HUD + Dialogue (NEXT DAY)
**Deliverable:** Multi-tile buildings, authentic HUD, gold-bordered dialogue boxes

### Morning (3-4 hours)
- [ ] Multi-tile structure system:
  - Define structures as tile groups: `HOUSE_3x4`, `CASTLE_GATE_5x4`, etc.
  - `place_structure(screen_tiles, structure, x, y)` helper
  - Rebuild Kakariko screens with proper multi-tile houses
  - Rebuild Castle screens with proper castle structure
- [ ] Add chimney smoke particles to houses

### Afternoon (3-4 hours)
- [ ] ALttP HUD overhaul:
  - Item box (top-left): shows B-button item with gold border
  - Rupee counter with green rupee icon
  - Bomb counter with bomb icon
  - Arrow counter with arrow icon
  - Key counter
  - Heart row with "- LIFE -" label (top-right)
  - Mini-map toggle
- [ ] Multiplayer HUD variant: compact 4-player hearts

### Evening (2 hours)
- [ ] ALttP dialogue system:
  - Gold-bordered text box at bottom of screen
  - Character-by-character text reveal with sound
  - Speaker name at top of box
  - Press button to advance / auto-scroll
- [ ] Update all NPC dialogues to use new system
- [ ] Play-test: buildings look like buildings, HUD feels authentic

**End of Day 2:** Visually much closer to ALttP, proper UI

---

## Day 3: Enemies + Combat + Items (DAY 3)
**Deliverable:** Sprite-based enemies, more weapons, better combat feel

### Morning (3-4 hours)
- [ ] Enemy sprite system:
  - Load enemy sprite sheets
  - Animated walk cycles (2-4 frames per direction)
  - Death animation (spin + poof)
  - Damage flash effect
- [ ] Overworld enemy types with proper sprites:
  - Soldiers (green/blue/red variants near castle)
  - Octoroks (shoot rocks)
  - Moblins (spear enemies in forest)
  - Zoras (pop up from water, shoot fireballs)

### Afternoon (3-4 hours)
- [ ] New items/weapons:
  - Boomerang (flies out and returns, stuns enemies)
  - Hookshot (grapple to posts/chests, cross gaps)
  - Lantern (lights dark rooms in dungeons)
  - Pegasus Boots (dash attack, break pots)
- [ ] Item pickup animations (hold above head like ALttP)
- [ ] Chest opening animation (lid flips up)

### Evening (2 hours)
- [ ] Combat polish:
  - Sword spin attack (hold + release)
  - Better hit feedback (enemy knockback, flash, particles)
  - Screen shake on big hits
  - Hitstop frames for impactful combat
- [ ] Play-test: combat should feel crunchy and satisfying

**End of Day 3:** Enemies look real, combat feels great, more weapons

---

## Day 4: World Polish + Dungeons (DAY 4)
**Deliverable:** Rich overworld with secrets, better dungeons, save system

### Morning (3-4 hours)
- [ ] Overworld secrets:
  - Bombable walls (place bomb near cracked wall → opens cave)
  - Pushable rocks (hold against rock → slides, reveals stairs)
  - Heart pieces (4 pieces = 1 heart container, 20 hidden across overworld)
  - Fairy fountains (restore all HP)
  - Hidden caves with rupee rewards
- [ ] Overworld interactables:
  - Pots (lift + throw, break for items)
  - Signs (read with E key)
  - Bushes (lift or cut)

### Afternoon (3-4 hours)
- [ ] Dungeon improvements:
  - Unique tileset per dungeon (forest dungeon, desert dungeon, ice dungeon)
  - Locked doors requiring keys
  - Puzzle elements (switches, floor plates, push blocks)
  - Mini-boss rooms
  - Dungeon maps (found in chests, reveals floor layout)
  - Compass (found in chest, shows boss location)
- [ ] Boss improvements:
  - Phase transitions (boss changes behavior at 50% HP)
  - Unique attack patterns per boss
  - Victory fanfare + crystal collection animation

### Evening (2 hours)
- [ ] Save system:
  - Save on dungeon completion
  - Save player stats, completed dungeons, collected items
  - Save to JSON file
  - Load game option on title screen
  - 3 save slots
- [ ] Play-test: world feels alive with secrets to discover

**End of Day 4:** Complete game loop with secrets, better dungeons, persistence

---

## Day 5: Final Polish + Title + Audio (DAY 5)
**Deliverable:** Release-quality game

### Morning (3-4 hours)
- [ ] Title screen overhaul:
  - Scenic background (mountains, lake, castle, rain)
  - Animated rain with thunder flashes
  - Large stylized title text
  - Mode select with previews
- [ ] Screen transitions:
  - Smooth scrolling with parallax (foreground scrolls faster)
  - Iris wipe improvements
  - Fade transitions for dungeon entry/exit
  - Map name display on screen enter

### Afternoon (3-4 hours)
- [ ] Audio overhaul:
  - Longer, more complex music loops per area
  - Dungeon music (dark, atmospheric)
  - Boss music (intense)
  - Victory fanfare
  - More sound effects (footsteps on different terrain, water splash)
- [ ] Visual effects:
  - Weather system (rain in some areas)
  - Day/night tinting (optional)
  - Torch lighting in dungeons (light radius around torches)
  - Water reflections
  - Grass particles when walking through

### Evening (2-3 hours)
- [ ] Controller polish:
  - Vibration patterns for different events
  - Controller UI shows current HP/items
  - Quick-swap items from controller
- [ ] Final testing:
  - Play through entire game solo
  - Play through with 4 players
  - Fix any remaining bugs
  - Performance optimization if needed
- [ ] Tag as v1.0

**End of Day 5:** Release-quality ALttP recreation

---

## Time Estimates

| Phase | Estimated Hours | Complexity |
|-------|----------------|------------|
| Day 1: Tileset system | 8-10h | High (foundational) |
| Day 2: Structures + HUD | 8-10h | Medium-High |
| Day 3: Enemies + Combat | 8-10h | High |
| Day 4: World + Dungeons | 8-10h | Medium-High |
| Day 5: Polish + Audio | 8-10h | Medium |
| **Total** | **40-50h** | |

## What Can Be Built Without Sprite Sheets

These don't need real sprite PNGs:
- Tileset loader code (ready for sprites when they arrive)
- Auto-tiling engine logic
- HUD redesign
- Dialogue system
- Item/weapon mechanics
- Save system
- Enemy AI improvements
- Dungeon puzzles
- Secret system
- Combat improvements

## User Actions Required

1. **Download ALttP sprite sheets** from The Spriters Resource:
   - Search "Legend of Zelda A Link to the Past"
   - Download: Overworld tiles, Dungeon tiles, Enemies, NPCs, Items, HUD
   - Save as PNGs in `sprites/` directory
2. **Play-test each day's build** and give feedback
3. **Provide feedback on what feels wrong** — the earlier the better
