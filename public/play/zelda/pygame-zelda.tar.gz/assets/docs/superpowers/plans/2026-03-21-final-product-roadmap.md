# Final Product Roadmap — ALttP Zelda Game

## Current State (v0.1-demo)
- 4-player co-op dungeon + overworld modes
- Procedurally drawn tiles (functional but not visually authentic)
- 64-screen overworld, 5 dungeon levels
- Phone controller support, synthesized music
- **Main gap: visuals don't match ALttP quality**

## Phase 1: Authentic Tile Graphics (HIGH PRIORITY)

### Problem
The sprite sheets in `sprites/` are broken downloads (HTML files, not PNGs).
Only `ganon.png` and the Link sheet are real images. All overworld/dungeon
tiles are drawn procedurally with pygame.draw calls — functional but blocky.

### Solution
1. **Download real ALttP sprite sheets** from The Spriters Resource:
   - Overworld tileset (terrain, structures, vegetation)
   - Dungeon tileset (walls, floors, doors, chests)
   - Enemy sprites (overworld enemies)
   - NPC sprites
   - Item sprites
   - HUD elements

2. **Build a tileset loader** — `tileset.py`:
   - Load sprite sheet PNG
   - Cut 16x16 tiles from grid positions
   - Map tile IDs to sprite sheet coordinates
   - Cache cut tiles as Surfaces

3. **Replace procedural drawing** — update `draw_overworld_tile()` to blit
   from the loaded tileset instead of using pygame.draw calls

4. **Add auto-tiling** — for grass/path/water/cliff edges:
   - Check neighboring tiles
   - Pick the correct edge/corner variant
   - This makes terrain transitions smooth instead of blocky

### What the user needs to do
- Visit The Spriters Resource and download ALttP sprite sheets
- Save them as proper PNGs in `sprites/` directory
- We'll build the loading/rendering code

## Phase 2: Multi-Tile Structures

### Problem
Houses, castle, trees are single 16x16 tiles. In ALttP they're
multi-tile structures with proper 3D perspective.

### Solution
- Define "structures" as groups of tiles placed together
- A house = 3x3 tile group (roof tiles on top, wall tiles middle, door at bottom)
- Castle = large multi-tile composition
- Place structures in map data as a single call: `place_house(screen, x, y)`

## Phase 3: Proper HUD

### Problem
Current HUD doesn't match ALttP (item box, rupee/bomb/arrow counters,
heart row with "LIFE" label).

### Solution
- Draw ALttP-style HUD: item box (B button), selected item, rupee counter,
  bomb counter, arrow counter, key counter, heart row
- For multiplayer: compact version showing all players

## Phase 4: Enemy Sprites

### Problem
Enemies are procedurally drawn (simple shapes). Real ALttP enemies have
detailed animated sprites.

### Solution
- Load enemy sprite sheets
- Replace procedural Enemy.draw() with sprite-based rendering
- Add proper animation frames (walk cycles, attack animations)

## Phase 5: Polish
- Auto-tiling edge transitions
- Proper dialogue boxes (gold border like ALttP)
- Screen transition effects (iris wipe already exists)
- Rain effect on title screen
- More dungeon variety
- Save system

## Priority Order
1. Get real sprite sheets (user action)
2. Build tileset loader (code)
3. Replace overworld tile rendering (code)
4. Multi-tile structures (code)
5. HUD overhaul (code)
6. Enemy sprites (code)
7. Polish (code)
