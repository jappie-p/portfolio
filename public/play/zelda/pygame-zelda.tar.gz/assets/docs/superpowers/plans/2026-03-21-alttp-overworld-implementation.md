# ALttP Light World Overworld — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a full ALttP-inspired Light World overworld (64 screens, 35 tile types, screen transitions) to the existing Pygame Zelda game.

**Architecture:** Four modules — `overworld_tiles.py` (tile definitions + drawing), `overworld_engine.py` (screen manager + cache + transitions), `overworld_maps.py` (64 screen grids), and modifications to `main.py` (game mode switch, auto-scaling, collision API). All tiles drawn procedurally. Static tiles cached per-screen for performance.

**Tech Stack:** Python 3.9, Pygame, no external dependencies

**Spec:** `docs/superpowers/specs/2026-03-21-alttp-light-world-overworld-design.md`

**Critical coordinate convention:** Player and enemy Y coordinates are in **tile-local space** (0-192), NOT screen space. `GAME_Y` (28px) is added only during rendering. This matches how the existing dungeon code works. All spawn positions, edge detection, and collision must use tile-local Y.

---

## File Structure

| File | Responsibility | Status |
|------|---------------|--------|
| `overworld_tiles.py` | Tile ID constants, ALttP palette, TILE_PROPS dict, `draw_overworld_tile()` for all 35 types | Create |
| `overworld_engine.py` | `ScreenManager` class: screen cache, transition animation, `is_walkable()` collision API | Create |
| `overworld_maps.py` | `OVERWORLD` dict (64 screens), boundary generator, template helpers, spawn data | Create |
| `main.py` | Auto-scaling, fullscreen, `game_mode` switch, overworld rendering loop, edge detection, dungeon entry/exit | Modify |
| `tests/test_tiles.py` | Unit tests for tile properties and collision API | Create |
| `tests/test_engine.py` | Unit tests for screen manager coordinate math | Create |

---

### Task 1: Tile System — Constants, Palette, and Properties

**Files:**
- Create: `overworld_tiles.py`
- Create: `tests/test_tiles.py`

This task creates the foundation: all tile IDs, the ALttP color palette, and the tile properties dictionary that drives collision, cutting, and animation logic.

- [ ] **Step 1: Create `overworld_tiles.py` with tile ID constants**

```python
"""
Overworld tile definitions for ALttP Light World recreation.

Tile IDs start at 100 to avoid collision with existing dungeon tiles (0-10).
Each tile type has a draw function and properties (walkable, cuttable, animated).
"""
import pygame
import math
import random

# ══════════════════════════════════════════
#  TILE ID CONSTANTS (100+ to avoid dungeon collision)
# ══════════════════════════════════════════
# Terrain
OW_GRASS       = 100
OW_DARK_GRASS  = 101
OW_PATH        = 102
OW_SAND        = 103
OW_SWAMP       = 104

# Water
OW_WATER       = 110
OW_DEEP_WATER  = 111
OW_WATERFALL   = 112

# Elevation
OW_CLIFF_FACE  = 120
OW_CLIFF_TOP   = 121
OW_CLIFF_LEFT  = 122
OW_CLIFF_RIGHT = 123
OW_CLIFF_TL    = 124
OW_CLIFF_TR    = 125
OW_CLIFF_BL    = 126
OW_CLIFF_BR    = 127
OW_MOUNTAIN    = 128
OW_CAVE        = 129
OW_STAIRS      = 130

# Vegetation
OW_TREE        = 140
OW_DARK_TREE   = 141
OW_BUSH        = 142
OW_TALL_GRASS  = 143
OW_FLOWERS     = 144

# Structures
OW_HOUSE_ROOF  = 150
OW_HOUSE_WALL  = 151
OW_HOUSE_DOOR  = 152
OW_CASTLE_WALL = 153
OW_CASTLE_TOWER= 154
OW_CASTLE_GATE = 155
OW_BRIDGE      = 156
OW_FENCE       = 157
OW_SIGN        = 158
OW_TORCH       = 159

# Special
OW_DUNGEON     = 160
OW_CHEST       = 161
OW_BOUNDARY    = 199

# Short aliases for map data readability
# Note: use GR not G to avoid collision with G=0 (dungeon grass) in main.py
GR = OW_GRASS
DG = OW_DARK_GRASS
PA = OW_PATH
SA = OW_SAND
SW = OW_SWAMP
WA = OW_WATER
DW = OW_DEEP_WATER
WF = OW_WATERFALL
CF = OW_CLIFF_FACE
CT = OW_CLIFF_TOP
CL = OW_CLIFF_LEFT
CR = OW_CLIFF_RIGHT
CB = OW_CLIFF_TL    # corner aliases
CE = OW_CLIFF_TR
BL = OW_CLIFF_BL
BR = OW_CLIFF_BR
MN = OW_MOUNTAIN
CV = OW_CAVE
ST = OW_STAIRS
TR = OW_TREE
DT = OW_DARK_TREE
BU = OW_BUSH
TG = OW_TALL_GRASS
FL = OW_FLOWERS
HR = OW_HOUSE_ROOF
HW = OW_HOUSE_WALL
HD = OW_HOUSE_DOOR
CW = OW_CASTLE_WALL
TO = OW_CASTLE_TOWER
CG = OW_CASTLE_GATE
BD = OW_BRIDGE
FE = OW_FENCE
SI = OW_SIGN
TC = OW_TORCH
DN = OW_DUNGEON
CH = OW_CHEST
BO = OW_BOUNDARY
```

- [ ] **Step 2: Add ALttP color palette**

```python
# ══════════════════════════════════════════
#  ALttP COLOR PALETTE
# ══════════════════════════════════════════
# Terrain
GRASS_GREEN     = (72, 184, 72)
GRASS_DOT       = (56, 152, 56)
DARK_GRASS_BASE = (48, 136, 48)
DARK_GRASS_DOT  = (32, 112, 32)
PATH_TAN        = (200, 168, 112)
PATH_DARK       = (184, 152, 96)
SAND_LIGHT      = (232, 216, 160)
SAND_DOT        = (216, 200, 144)
SWAMP_GREEN     = (72, 120, 72)
SWAMP_DARK      = (56, 104, 56)
SWAMP_MUD       = (48, 88, 40)

# Water
WATER_BLUE      = (40, 88, 192)
WATER_LIGHT     = (136, 200, 248)
WATER_MID       = (56, 104, 208)
DEEP_BLUE       = (24, 64, 160)
DEEP_MID        = (40, 80, 184)

# Cliffs (signature ALttP mauve-brown)
CLIFF_MAIN      = (152, 104, 88)
CLIFF_SHADOW    = (120, 80, 64)
CLIFF_LIGHT     = (168, 120, 104)
CLIFF_EDGE      = (40, 120, 40)

# Mountain
ROCK_GRAY       = (128, 128, 120)
ROCK_DARK       = (104, 104, 96)
ROCK_LIGHT      = (152, 152, 144)

# Vegetation
TREE_BASE       = (48, 160, 48)
TREE_HIGHLIGHT  = (88, 200, 88)
TREE_SHADOW     = (32, 136, 32)
TREE_TRUNK      = (128, 96, 48)
DARK_TREE_BASE  = (32, 128, 32)
DARK_TREE_HI    = (56, 160, 56)
DARK_TREE_SH    = (16, 112, 16)

# Structures
HOUSE_ROOF_MAIN = (216, 120, 120)
HOUSE_ROOF_DARK = (184, 96, 96)
HOUSE_WALL_MAIN = (232, 208, 160)
HOUSE_WALL_DARK = (208, 184, 136)
HOUSE_DOOR_MAIN = (160, 112, 48)
HOUSE_DOOR_DARK = (128, 80, 32)
CASTLE_STONE    = (200, 200, 208)
CASTLE_DARK     = (168, 168, 184)
CASTLE_LIGHT    = (224, 224, 232)
WINDOW_BLUE     = (40, 72, 160)
DOOR_HANDLE     = (232, 200, 64)
BRIDGE_WOOD     = (200, 168, 112)
BRIDGE_DARK     = (176, 144, 80)
FENCE_WOOD      = (200, 168, 112)
FENCE_DARK      = (168, 136, 80)
SIGN_BOARD      = (216, 184, 104)
SIGN_DARK       = (184, 152, 72)
SIGN_POST       = (160, 128, 64)

# Special
TORCH_FLAME1    = (248, 216, 0)
TORCH_FLAME2    = (224, 120, 24)
TORCH_FLAME3    = (200, 40, 40)
CAVE_DARK       = (16, 16, 24)
CAVE_FRAME      = (152, 152, 144)
```

- [ ] **Step 3: Add tile properties dictionary**

```python
# ══════════════════════════════════════════
#  TILE PROPERTIES
# ══════════════════════════════════════════
TILE_PROPS = {
    OW_GRASS:       {"walkable": True,  "cuttable": False, "animated": False},
    OW_DARK_GRASS:  {"walkable": True,  "cuttable": False, "animated": False},
    OW_PATH:        {"walkable": True,  "cuttable": False, "animated": False},
    OW_SAND:        {"walkable": True,  "cuttable": False, "animated": False},
    OW_SWAMP:       {"walkable": True,  "cuttable": False, "animated": False, "damage": 0},
    OW_WATER:       {"walkable": False, "cuttable": False, "animated": True},
    OW_DEEP_WATER:  {"walkable": False, "cuttable": False, "animated": True},
    OW_WATERFALL:   {"walkable": False, "cuttable": False, "animated": True},
    OW_CLIFF_FACE:  {"walkable": False, "cuttable": False, "animated": False},
    OW_CLIFF_TOP:   {"walkable": True,  "cuttable": False, "animated": False, "ledge": "down"},
    OW_CLIFF_LEFT:  {"walkable": False, "cuttable": False, "animated": False},
    OW_CLIFF_RIGHT: {"walkable": False, "cuttable": False, "animated": False},
    OW_CLIFF_TL:    {"walkable": False, "cuttable": False, "animated": False},
    OW_CLIFF_TR:    {"walkable": False, "cuttable": False, "animated": False},
    OW_CLIFF_BL:    {"walkable": False, "cuttable": False, "animated": False},
    OW_CLIFF_BR:    {"walkable": False, "cuttable": False, "animated": False},
    OW_MOUNTAIN:    {"walkable": False, "cuttable": False, "animated": False},
    OW_CAVE:        {"walkable": True,  "cuttable": False, "animated": False, "entrance": True},
    OW_STAIRS:      {"walkable": True,  "cuttable": False, "animated": False},
    OW_TREE:        {"walkable": False, "cuttable": False, "animated": False, "overlay": True},
    OW_DARK_TREE:   {"walkable": False, "cuttable": False, "animated": False, "overlay": True},
    OW_BUSH:        {"walkable": False, "cuttable": True,  "animated": False},
    OW_TALL_GRASS:  {"walkable": True,  "cuttable": True,  "animated": True},
    OW_FLOWERS:     {"walkable": True,  "cuttable": False, "animated": False},
    OW_HOUSE_ROOF:  {"walkable": False, "cuttable": False, "animated": False},
    OW_HOUSE_WALL:  {"walkable": False, "cuttable": False, "animated": False},
    OW_HOUSE_DOOR:  {"walkable": True,  "cuttable": False, "animated": False, "entrance": True},
    OW_CASTLE_WALL: {"walkable": False, "cuttable": False, "animated": False},
    OW_CASTLE_TOWER:{"walkable": False, "cuttable": False, "animated": False},
    OW_CASTLE_GATE: {"walkable": True,  "cuttable": False, "animated": False, "entrance": True},
    OW_BRIDGE:      {"walkable": True,  "cuttable": False, "animated": False},
    OW_FENCE:       {"walkable": False, "cuttable": False, "animated": False},
    OW_SIGN:        {"walkable": False, "cuttable": False, "animated": False},
    OW_TORCH:       {"walkable": False, "cuttable": False, "animated": True},
    OW_DUNGEON:     {"walkable": True,  "cuttable": False, "animated": False, "entrance": True},
    OW_CHEST:       {"walkable": False, "cuttable": False, "animated": False},
    OW_BOUNDARY:    {"walkable": False, "cuttable": False, "animated": False},
}


def is_walkable(tile_id, direction=None):
    """Check if a tile can be walked on.

    For overworld tiles (ID >= 100), uses TILE_PROPS lookup.
    For dungeon tiles (ID 0-10), uses the existing hardcoded list.

    Args:
        tile_id: The tile type at the target position.
        direction: Optional movement direction ("up"/"down"/"left"/"right")
                   for one-way ledge tiles.

    Returns:
        True if the tile can be walked on.
    """
    if tile_id >= 100:
        props = TILE_PROPS.get(tile_id)
        if props is None:
            return False
        if not props.get("walkable", False):
            return False
        ledge_dir = props.get("ledge")
        if ledge_dir and direction and direction != ledge_dir:
            return False
        return True
    else:
        # Dungeon tiles: existing logic from main.py _wall()
        return tile_id not in (1, 3, 4, 7, 10)  # W, Q, T, L, K
```

- [ ] **Step 4: Write tests for tile properties and collision**

```python
# tests/test_tiles.py
"""Tests for overworld tile system."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from overworld_tiles import (
    OW_GRASS, OW_WATER, OW_CLIFF_FACE, OW_CLIFF_TOP, OW_TALL_GRASS,
    OW_BUSH, OW_PATH, OW_BRIDGE, OW_DUNGEON, OW_BOUNDARY,
    TILE_PROPS, is_walkable
)

def test_grass_is_walkable():
    assert is_walkable(OW_GRASS) == True

def test_water_is_not_walkable():
    assert is_walkable(OW_WATER) == False

def test_cliff_face_is_not_walkable():
    assert is_walkable(OW_CLIFF_FACE) == False

def test_cliff_top_ledge_allows_down():
    assert is_walkable(OW_CLIFF_TOP, direction="down") == True

def test_cliff_top_ledge_blocks_up():
    assert is_walkable(OW_CLIFF_TOP, direction="up") == False

def test_cliff_top_no_direction():
    assert is_walkable(OW_CLIFF_TOP) == True

def test_tall_grass_walkable_and_cuttable():
    assert is_walkable(OW_TALL_GRASS) == True
    assert TILE_PROPS[OW_TALL_GRASS]["cuttable"] == True

def test_bush_not_walkable_but_cuttable():
    assert is_walkable(OW_BUSH) == False
    assert TILE_PROPS[OW_BUSH]["cuttable"] == True

def test_bridge_walkable():
    assert is_walkable(OW_BRIDGE) == True

def test_dungeon_entrance_walkable():
    assert is_walkable(OW_DUNGEON) == True
    assert TILE_PROPS[OW_DUNGEON].get("entrance") == True

def test_boundary_not_walkable():
    assert is_walkable(OW_BOUNDARY) == False

def test_dungeon_tile_passthrough():
    """Dungeon tiles (ID < 100) use old logic."""
    assert is_walkable(0) == True    # G = grass
    assert is_walkable(1) == False   # W = wall
    assert is_walkable(2) == True    # P = path
    assert is_walkable(3) == False   # Q = water
    assert is_walkable(7) == False   # L = lava

def test_all_tiles_have_properties():
    """Every tile constant should have an entry in TILE_PROPS."""
    for tile_id, props in TILE_PROPS.items():
        assert "walkable" in props, f"Tile {tile_id} missing 'walkable'"
        assert "animated" in props, f"Tile {tile_id} missing 'animated'"

if __name__ == "__main__":
    tests = [v for k, v in globals().items() if k.startswith("test_")]
    passed = failed = 0
    for t in tests:
        try:
            t()
            passed += 1
            print(f"  PASS  {t.__name__}")
        except AssertionError as e:
            failed += 1
            print(f"  FAIL  {t.__name__}: {e}")
    print(f"\n{passed} passed, {failed} failed")
```

- [ ] **Step 5: Run tests**

Run: `cd /Users/jasper/Sites/localhost/pygame-zelda && python3 tests/test_tiles.py`
Expected: All tests pass

- [ ] **Step 6: Commit**

```bash
git add overworld_tiles.py tests/test_tiles.py
git commit -m "feat: add overworld tile system — constants, palette, properties, collision API"
```

---

### Task 2: Tile Drawing Functions

**Files:**
- Modify: `overworld_tiles.py`

Add the `draw_overworld_tile()` function with ALttP-accurate procedural rendering for all 35 tile types. Each tile is drawn at 16×16 pixels using `pygame.draw` calls.

- [ ] **Step 1: Add the terrain draw functions**

Append to `overworld_tiles.py`:

```python
# ══════════════════════════════════════════
#  TILE DRAWING — ALttP-accurate procedural rendering
# ══════════════════════════════════════════
TILE = 16

def _draw_grass(surf, x, y, _ticks):
    surf.fill(GRASS_GREEN, (x, y, TILE, TILE))
    for dy in range(0, TILE, 4):
        for dx in range(0, TILE, 4):
            surf.set_at((x + dx + 1, y + dy + 1), GRASS_DOT)
            surf.set_at((x + dx + 3, y + dy + 3), GRASS_DOT)

def _draw_dark_grass(surf, x, y, _ticks):
    surf.fill(DARK_GRASS_BASE, (x, y, TILE, TILE))
    for dy in range(0, TILE, 4):
        for dx in range(0, TILE, 4):
            surf.set_at((x + dx + 1, y + dy + 1), DARK_GRASS_DOT)
            surf.set_at((x + dx + 3, y + dy + 3), DARK_GRASS_DOT)

def _draw_path(surf, x, y, _ticks):
    surf.fill(PATH_TAN, (x, y, TILE, TILE))
    rng = random.Random(x * 137 + y * 97)
    for _ in range(3):
        surf.set_at((x + rng.randint(2, 13), y + rng.randint(2, 13)), PATH_DARK)

def _draw_sand(surf, x, y, _ticks):
    surf.fill(SAND_LIGHT, (x, y, TILE, TILE))
    rng = random.Random(x * 137 + y * 97)
    for _ in range(3):
        surf.set_at((x + rng.randint(2, 13), y + rng.randint(2, 13)), SAND_DOT)

def _draw_swamp(surf, x, y, _ticks):
    surf.fill(SWAMP_GREEN, (x, y, TILE, TILE))
    rng = random.Random(x * 137 + y * 97)
    for dy in range(0, TILE, 3):
        for dx in range(0, TILE, 4):
            surf.set_at((x + dx + (dy % 2) * 2, y + dy), SWAMP_DARK)
    # Murky puddles
    px, py = rng.randint(4, 8), rng.randint(4, 8)
    pygame.draw.rect(surf, SWAMP_MUD, (x + px, y + py, 4, 3))
```

- [ ] **Step 2: Add the water draw functions (animated)**

```python
def _draw_water(surf, x, y, ticks):
    surf.fill(WATER_BLUE, (x, y, TILE, TILE))
    # Animated wave highlights
    phase = (ticks // 12) % 4
    for i in range(3):
        wx = (2 + i * 5 + phase) % 14
        wy = 3 + i * 4
        pygame.draw.rect(surf, WATER_LIGHT, (x + wx, y + wy, 3, 1))
    pygame.draw.rect(surf, WATER_MID, (x + 1, y + 6 + phase % 3, 2, 1))

def _draw_deep_water(surf, x, y, ticks):
    surf.fill(DEEP_BLUE, (x, y, TILE, TILE))
    phase = (ticks // 16) % 4
    pygame.draw.rect(surf, DEEP_MID, (x + 3 + phase, y + 4, 3, 1))
    pygame.draw.rect(surf, DEEP_MID, (x + 10 - phase, y + 10, 3, 1))

def _draw_waterfall(surf, x, y, ticks):
    surf.fill(WATER_BLUE, (x, y, TILE, TILE))
    phase = (ticks // 4) % 8
    for col in [2, 7, 12]:
        pygame.draw.rect(surf, WATER_LIGHT, (x + col, y, 2, TILE))
    # Falling highlights
    for col in [3, 8, 13]:
        hy = (phase * 2 + col) % TILE
        surf.set_at((x + col, y + hy), (255, 255, 255))
```

- [ ] **Step 3: Add elevation draw functions**

```python
def _draw_cliff_face(surf, x, y, _ticks):
    surf.fill(CLIFF_MAIN, (x, y, TILE, TILE))
    pygame.draw.rect(surf, CLIFF_SHADOW, (x, y, TILE, 2))
    pygame.draw.rect(surf, CLIFF_LIGHT, (x, y + 14, TILE, 2))
    rng = random.Random(x * 137 + y * 97)
    for _ in range(2):
        rx, ry = rng.randint(2, 10), rng.randint(4, 11)
        pygame.draw.rect(surf, (CLIFF_MAIN[0] - 8, CLIFF_MAIN[1] + 8, CLIFF_MAIN[2] + 4),
                         (x + rx, y + ry, 3, 2))

def _draw_cliff_top(surf, x, y, _ticks):
    surf.fill(GRASS_GREEN, (x, y, TILE, 8))
    for dy in range(0, 8, 4):
        for dx in range(0, TILE, 4):
            surf.set_at((x + dx + 1, y + dy + 1), GRASS_DOT)
    pygame.draw.rect(surf, CLIFF_EDGE, (x, y + 7, TILE, 2))
    surf.fill(CLIFF_MAIN, (x, y + 9, TILE, 7))
    pygame.draw.rect(surf, CLIFF_SHADOW, (x, y + 9, TILE, 1))

def _draw_cliff_left(surf, x, y, _ticks):
    surf.fill(CLIFF_MAIN, (x, y, 8, TILE))
    surf.fill(GRASS_GREEN, (x + 8, y, 8, TILE))
    pygame.draw.rect(surf, CLIFF_SHADOW, (x + 7, y, 2, TILE))
    for dy in range(0, TILE, 4):
        surf.set_at((x + 10, y + dy + 1), GRASS_DOT)

def _draw_cliff_right(surf, x, y, _ticks):
    surf.fill(GRASS_GREEN, (x, y, 8, TILE))
    surf.fill(CLIFF_MAIN, (x + 8, y, 8, TILE))
    pygame.draw.rect(surf, CLIFF_SHADOW, (x + 7, y, 2, TILE))
    for dy in range(0, TILE, 4):
        surf.set_at((x + 2, y + dy + 1), GRASS_DOT)

def _draw_cliff_tl(surf, x, y, _ticks):
    surf.fill(CLIFF_MAIN, (x, y, TILE, TILE))
    surf.fill(GRASS_GREEN, (x + 8, y, 8, 8))
    pygame.draw.rect(surf, CLIFF_SHADOW, (x + 7, y, 2, 9))
    pygame.draw.rect(surf, CLIFF_SHADOW, (x + 7, y + 7, 9, 2))

def _draw_cliff_tr(surf, x, y, _ticks):
    surf.fill(CLIFF_MAIN, (x, y, TILE, TILE))
    surf.fill(GRASS_GREEN, (x, y, 8, 8))
    pygame.draw.rect(surf, CLIFF_SHADOW, (x + 7, y, 2, 9))
    pygame.draw.rect(surf, CLIFF_SHADOW, (x, y + 7, 9, 2))

def _draw_cliff_bl(surf, x, y, _ticks):
    surf.fill(CLIFF_MAIN, (x, y, TILE, TILE))
    surf.fill(GRASS_GREEN, (x + 8, y + 8, 8, 8))
    pygame.draw.rect(surf, CLIFF_SHADOW, (x + 7, y + 7, 2, 9))
    pygame.draw.rect(surf, CLIFF_SHADOW, (x + 7, y + 7, 9, 2))

def _draw_cliff_br(surf, x, y, _ticks):
    surf.fill(CLIFF_MAIN, (x, y, TILE, TILE))
    surf.fill(GRASS_GREEN, (x, y + 8, 8, 8))
    pygame.draw.rect(surf, CLIFF_SHADOW, (x + 7, y + 7, 2, 9))
    pygame.draw.rect(surf, CLIFF_SHADOW, (x, y + 7, 9, 2))

def _draw_mountain(surf, x, y, _ticks):
    surf.fill(ROCK_GRAY, (x, y, TILE, TILE))
    rng = random.Random(x * 137 + y * 97)
    pygame.draw.rect(surf, ROCK_DARK, (x + rng.randint(1, 5), y + rng.randint(2, 5), 4, 3))
    pygame.draw.rect(surf, ROCK_DARK, (x + rng.randint(8, 11), y + rng.randint(7, 10), 3, 3))
    pygame.draw.rect(surf, ROCK_LIGHT, (x, y, TILE, 1))

def _draw_cave(surf, x, y, _ticks):
    surf.fill(ROCK_GRAY, (x, y, TILE, TILE))
    # Dark opening arch
    pygame.draw.rect(surf, CAVE_DARK, (x + 3, y + 5, 10, 11))
    pygame.draw.rect(surf, CAVE_DARK, (x + 4, y + 4, 8, 1))
    pygame.draw.rect(surf, CAVE_DARK, (x + 5, y + 3, 6, 1))
    # Stone frame
    pygame.draw.rect(surf, CAVE_FRAME, (x + 2, y + 5, 1, 11))
    pygame.draw.rect(surf, CAVE_FRAME, (x + 13, y + 5, 1, 11))
    pygame.draw.rect(surf, CAVE_FRAME, (x + 1, y + 2, 14, 1))

def _draw_stairs(surf, x, y, _ticks):
    surf.fill(PATH_DARK, (x, y, TILE, TILE))
    for i in range(4):
        v = 80 + i * 15
        pygame.draw.rect(surf, (v, v - 10, v - 20), (x + 2, y + i * 4, 12, 3))
        pygame.draw.rect(surf, (60, 50, 40), (x + 2, y + i * 4 + 3, 12, 1))
```

- [ ] **Step 4: Add vegetation draw functions**

```python
def _draw_tree(surf, x, y, _ticks):
    # Grass background
    surf.fill(GRASS_GREEN, (x, y, TILE, TILE))
    surf.set_at((x + 1, y + 13), GRASS_DOT)
    surf.set_at((x + 13, y + 14), GRASS_DOT)
    # Trunk
    pygame.draw.rect(surf, TREE_TRUNK, (x + 6, y + 10, 4, 5))
    # Round canopy (ALttP broccoli style)
    for dy in range(-5, 5):
        for dx in range(-5, 5):
            if dx * dx + dy * dy <= 22:
                surf.set_at((x + 8 + dx, y + 6 + dy), TREE_BASE)
    # Highlight (top-left)
    for dy in range(-4, 1):
        for dx in range(-4, 1):
            if dx * dx + dy * dy <= 12:
                surf.set_at((x + 7 + dx, y + 5 + dy), TREE_HIGHLIGHT)
    # Shadow (bottom-right)
    for dy in range(0, 5):
        for dx in range(0, 5):
            if dx * dx + dy * dy <= 16 and (dx + dy) > 3:
                surf.set_at((x + 8 + dx, y + 6 + dy), TREE_SHADOW)

def _draw_dark_tree(surf, x, y, _ticks):
    surf.fill(DARK_GRASS_BASE, (x, y, TILE, TILE))
    surf.set_at((x + 2, y + 13), DARK_GRASS_DOT)
    pygame.draw.rect(surf, (64, 48, 24), (x + 6, y + 10, 4, 5))
    for dy in range(-5, 5):
        for dx in range(-5, 5):
            if dx * dx + dy * dy <= 22:
                surf.set_at((x + 8 + dx, y + 6 + dy), DARK_TREE_BASE)
    for dy in range(-4, 1):
        for dx in range(-4, 1):
            if dx * dx + dy * dy <= 12:
                surf.set_at((x + 7 + dx, y + 5 + dy), DARK_TREE_HI)
    for dy in range(0, 5):
        for dx in range(0, 5):
            if dx * dx + dy * dy <= 16 and (dx + dy) > 3:
                surf.set_at((x + 8 + dx, y + 6 + dy), DARK_TREE_SH)

def _draw_bush(surf, x, y, _ticks):
    surf.fill(GRASS_GREEN, (x, y, TILE, TILE))
    pygame.draw.rect(surf, TREE_BASE, (x + 3, y + 5, 10, 8))
    pygame.draw.rect(surf, TREE_BASE, (x + 4, y + 4, 8, 1))
    pygame.draw.rect(surf, TREE_BASE, (x + 4, y + 13, 8, 1))
    pygame.draw.rect(surf, TREE_HIGHLIGHT, (x + 4, y + 5, 4, 3))
    pygame.draw.rect(surf, TREE_SHADOW, (x + 8, y + 10, 4, 3))

def _draw_tall_grass(surf, x, y, ticks):
    surf.fill(GRASS_GREEN, (x, y, TILE, TILE))
    sway = int(math.sin(ticks * 0.04 + x * 0.2) * 1)
    for bx in [2, 6, 10, 14]:
        pygame.draw.rect(surf, TREE_BASE, (x + bx + sway, y + 3, 2, 11))
        pygame.draw.rect(surf, TREE_HIGHLIGHT, (x + bx + sway, y + 3, 2, 3))

def _draw_flowers(surf, x, y, _ticks):
    surf.fill(GRASS_GREEN, (x, y, TILE, TILE))
    # Small colored dots
    pygame.draw.rect(surf, (240, 128, 128), (x + 3, y + 4, 2, 2))
    pygame.draw.rect(surf, (240, 240, 96), (x + 7, y + 3, 2, 2))
    pygame.draw.rect(surf, (240, 160, 240), (x + 12, y + 8, 2, 2))
    pygame.draw.rect(surf, (240, 128, 128), (x + 2, y + 10, 2, 2))
    pygame.draw.rect(surf, (240, 240, 96), (x + 10, y + 12, 2, 2))
    # Stems
    pygame.draw.rect(surf, TREE_BASE, (x + 3, y + 6, 1, 2))
    pygame.draw.rect(surf, TREE_BASE, (x + 7, y + 5, 1, 2))
    pygame.draw.rect(surf, TREE_BASE, (x + 12, y + 10, 1, 2))
```

- [ ] **Step 5: Add structure and special draw functions**

```python
def _draw_house_roof(surf, x, y, _ticks):
    surf.fill(HOUSE_ROOF_MAIN, (x, y + 6, TILE, 10))
    for i in range(7):
        pygame.draw.rect(surf, HOUSE_ROOF_MAIN, (x + i, y + 6 - i, TILE - 2 * i, 1))
    pygame.draw.rect(surf, HOUSE_ROOF_DARK, (x, y + 6, TILE, 1))
    pygame.draw.rect(surf, HOUSE_ROOF_DARK, (x, y + 10, TILE, 1))
    pygame.draw.rect(surf, HOUSE_ROOF_DARK, (x, y + 14, TILE, 1))

def _draw_house_wall(surf, x, y, _ticks):
    surf.fill(HOUSE_WALL_MAIN, (x, y, TILE, TILE))
    pygame.draw.rect(surf, HOUSE_WALL_DARK, (x, y, TILE, 1))
    pygame.draw.rect(surf, HOUSE_WALL_DARK, (x, y, 1, TILE))
    pygame.draw.rect(surf, HOUSE_WALL_DARK, (x + 15, y, 1, TILE))
    # Window
    pygame.draw.rect(surf, WINDOW_BLUE, (x + 5, y + 4, 6, 6))
    pygame.draw.rect(surf, HOUSE_WALL_DARK, (x + 8, y + 4, 1, 6))
    pygame.draw.rect(surf, HOUSE_WALL_DARK, (x + 5, y + 7, 6, 1))

def _draw_house_door(surf, x, y, _ticks):
    surf.fill(HOUSE_WALL_MAIN, (x, y, TILE, TILE))
    pygame.draw.rect(surf, HOUSE_WALL_DARK, (x, y, 1, TILE))
    pygame.draw.rect(surf, HOUSE_WALL_DARK, (x + 15, y, 1, TILE))
    pygame.draw.rect(surf, HOUSE_DOOR_MAIN, (x + 4, y + 3, 8, 13))
    pygame.draw.rect(surf, HOUSE_DOOR_DARK, (x + 4, y + 3, 8, 1))
    pygame.draw.rect(surf, HOUSE_DOOR_DARK, (x + 4, y + 3, 1, 13))
    pygame.draw.rect(surf, HOUSE_DOOR_DARK, (x + 11, y + 3, 1, 13))
    pygame.draw.rect(surf, DOOR_HANDLE, (x + 9, y + 9, 2, 2))

def _draw_castle_wall(surf, x, y, _ticks):
    surf.fill(CASTLE_STONE, (x, y, TILE, TILE))
    pygame.draw.rect(surf, CASTLE_DARK, (x, y + 5, TILE, 1))
    pygame.draw.rect(surf, CASTLE_DARK, (x, y + 10, TILE, 1))
    pygame.draw.rect(surf, CASTLE_DARK, (x + 8, y, 1, 5))
    pygame.draw.rect(surf, CASTLE_DARK, (x + 4, y + 5, 1, 5))
    pygame.draw.rect(surf, CASTLE_DARK, (x + 12, y + 10, 1, 6))

def _draw_castle_tower(surf, x, y, _ticks):
    surf.fill(CASTLE_STONE, (x + 2, y + 4, 12, 12))
    # Battlements
    for bx in [0, 6, 12]:
        pygame.draw.rect(surf, CASTLE_LIGHT, (x + bx, y, 4, 6))
        pygame.draw.rect(surf, CASTLE_DARK, (x + bx, y + 5, 4, 1))
    # Window
    pygame.draw.rect(surf, CAVE_DARK, (x + 6, y + 7, 4, 5))
    pygame.draw.rect(surf, CAVE_DARK, (x + 7, y + 6, 2, 1))

def _draw_castle_gate(surf, x, y, _ticks):
    surf.fill(CASTLE_STONE, (x, y, TILE, TILE))
    pygame.draw.rect(surf, HOUSE_DOOR_DARK, (x + 3, y + 4, 10, 12))
    pygame.draw.rect(surf, HOUSE_DOOR_MAIN, (x + 4, y + 5, 8, 11))
    # Iron bands
    pygame.draw.rect(surf, ROCK_DARK, (x + 3, y + 7, 10, 1))
    pygame.draw.rect(surf, ROCK_DARK, (x + 3, y + 11, 10, 1))

def _draw_bridge(surf, x, y, _ticks):
    surf.fill(WATER_BLUE, (x, y, TILE, TILE))
    pygame.draw.rect(surf, BRIDGE_WOOD, (x, y + 3, TILE, 10))
    pygame.draw.rect(surf, BRIDGE_DARK, (x, y + 5, TILE, 1))
    pygame.draw.rect(surf, BRIDGE_DARK, (x, y + 8, TILE, 1))
    pygame.draw.rect(surf, BRIDGE_DARK, (x, y + 11, TILE, 1))
    pygame.draw.rect(surf, FENCE_DARK, (x, y + 3, TILE, 1))
    pygame.draw.rect(surf, FENCE_DARK, (x, y + 12, TILE, 1))

def _draw_fence(surf, x, y, _ticks):
    surf.fill(GRASS_GREEN, (x, y, TILE, TILE))
    for post_x in [1, 7, 13]:
        pygame.draw.rect(surf, FENCE_WOOD, (x + post_x, y + 5, 2, 9))
        pygame.draw.rect(surf, FENCE_DARK, (x + post_x, y + 5, 2, 1))
    pygame.draw.rect(surf, FENCE_WOOD, (x, y + 7, TILE, 2))
    pygame.draw.rect(surf, FENCE_WOOD, (x, y + 11, TILE, 2))

def _draw_sign(surf, x, y, _ticks):
    surf.fill(GRASS_GREEN, (x, y, TILE, TILE))
    pygame.draw.rect(surf, SIGN_POST, (x + 7, y + 8, 2, 7))
    pygame.draw.rect(surf, SIGN_BOARD, (x + 3, y + 2, 10, 7))
    pygame.draw.rect(surf, SIGN_DARK, (x + 3, y + 2, 10, 1))
    pygame.draw.rect(surf, SIGN_DARK, (x + 3, y + 8, 10, 1))
    pygame.draw.rect(surf, SIGN_DARK, (x + 3, y + 2, 1, 7))
    pygame.draw.rect(surf, SIGN_DARK, (x + 12, y + 2, 1, 7))

def _draw_torch(surf, x, y, ticks):
    surf.fill(ROCK_GRAY, (x, y, TILE, TILE))
    pygame.draw.rect(surf, CASTLE_DARK, (x, y, TILE, 1))
    pygame.draw.rect(surf, TREE_TRUNK, (x + 6, y + 6, 4, 6))
    flk = random.randint(-1, 1)
    pygame.draw.rect(surf, TORCH_FLAME1, (x + 6 + flk, y + 3, 4, 4))
    pygame.draw.rect(surf, TORCH_FLAME2, (x + 7 + flk, y + 2, 2, 3))
    pygame.draw.rect(surf, TORCH_FLAME3, (x + 7 + flk, y + 1, 2, 2))
    # Glow
    glow = pygame.Surface((TILE, TILE), pygame.SRCALPHA)
    pygame.draw.circle(glow, (255, 200, 50, 20), (8, 8), 10)
    surf.blit(glow, (x, y))

def _draw_dungeon(surf, x, y, _ticks):
    surf.fill(GRASS_GREEN, (x, y, TILE, TILE))
    pygame.draw.rect(surf, ROCK_GRAY, (x + 1, y + 2, 14, 13))
    pygame.draw.rect(surf, CAVE_DARK, (x + 3, y + 5, 10, 10))
    pygame.draw.rect(surf, CAVE_DARK, (x + 4, y + 4, 8, 1))
    pygame.draw.rect(surf, CAVE_DARK, (x + 5, y + 3, 6, 1))
    pygame.draw.rect(surf, CAVE_FRAME, (x + 1, y + 2, 14, 1))

def _draw_chest(surf, x, y, _ticks):
    surf.fill((40, 40, 48), (x, y, TILE, TILE))
    pygame.draw.rect(surf, (192, 136, 32), (x + 3, y + 5, 10, 8))
    pygame.draw.rect(surf, (216, 160, 48), (x + 3, y + 5, 10, 4))
    pygame.draw.rect(surf, (160, 112, 24), (x + 3, y + 8, 10, 1))
    pygame.draw.rect(surf, (240, 208, 64), (x + 7, y + 7, 2, 3))

def _draw_boundary(surf, x, y, _ticks):
    surf.fill(CLIFF_MAIN, (x, y, TILE, TILE))
    rng = random.Random(x * 137 + y * 97)
    for _ in range(3):
        rx, ry = rng.randint(1, 12), rng.randint(1, 12)
        pygame.draw.rect(surf, CLIFF_SHADOW, (x + rx, y + ry, 3, 2))
```

- [ ] **Step 6: Add the dispatch function and overlay helper**

```python
# ══════════════════════════════════════════
#  DISPATCH — maps tile ID → draw function
# ══════════════════════════════════════════
_TILE_DRAW = {
    OW_GRASS:        _draw_grass,
    OW_DARK_GRASS:   _draw_dark_grass,
    OW_PATH:         _draw_path,
    OW_SAND:         _draw_sand,
    OW_SWAMP:        _draw_swamp,
    OW_WATER:        _draw_water,
    OW_DEEP_WATER:   _draw_deep_water,
    OW_WATERFALL:    _draw_waterfall,
    OW_CLIFF_FACE:   _draw_cliff_face,
    OW_CLIFF_TOP:    _draw_cliff_top,
    OW_CLIFF_LEFT:   _draw_cliff_left,
    OW_CLIFF_RIGHT:  _draw_cliff_right,
    OW_CLIFF_TL:     _draw_cliff_tl,
    OW_CLIFF_TR:     _draw_cliff_tr,
    OW_CLIFF_BL:     _draw_cliff_bl,
    OW_CLIFF_BR:     _draw_cliff_br,
    OW_MOUNTAIN:     _draw_mountain,
    OW_CAVE:         _draw_cave,
    OW_STAIRS:       _draw_stairs,
    OW_TREE:         _draw_tree,
    OW_DARK_TREE:    _draw_dark_tree,
    OW_BUSH:         _draw_bush,
    OW_TALL_GRASS:   _draw_tall_grass,
    OW_FLOWERS:      _draw_flowers,
    OW_HOUSE_ROOF:   _draw_house_roof,
    OW_HOUSE_WALL:   _draw_house_wall,
    OW_HOUSE_DOOR:   _draw_house_door,
    OW_CASTLE_WALL:  _draw_castle_wall,
    OW_CASTLE_TOWER: _draw_castle_tower,
    OW_CASTLE_GATE:  _draw_castle_gate,
    OW_BRIDGE:       _draw_bridge,
    OW_FENCE:        _draw_fence,
    OW_SIGN:         _draw_sign,
    OW_TORCH:        _draw_torch,
    OW_DUNGEON:      _draw_dungeon,
    OW_CHEST:        _draw_chest,
    OW_BOUNDARY:     _draw_boundary,
}

def draw_overworld_tile(surf, tile_id, x, y, ticks):
    """Draw a single overworld tile at pixel position (x, y).

    No GAME_Y offset — caller handles screen positioning.
    """
    fn = _TILE_DRAW.get(tile_id)
    if fn:
        fn(surf, x, y, ticks)

def get_overlay_tiles():
    """Return set of tile IDs that have canopy overlays (drawn above sprites)."""
    return {tid for tid, props in TILE_PROPS.items() if props.get("overlay")}
```

- [ ] **Step 7: Verify tile drawing manually**

Run a quick visual test:

```bash
cd /Users/jasper/Sites/localhost/pygame-zelda
python3 -c "
import pygame
pygame.init()
screen = pygame.display.set_mode((800, 400))
pygame.display.set_caption('Tile Test')
from overworld_tiles import draw_overworld_tile, OW_GRASS, OW_TREE, OW_WATER, OW_CLIFF_FACE, OW_CLIFF_TOP, OW_HOUSE_ROOF, OW_HOUSE_WALL, OW_HOUSE_DOOR, OW_CASTLE_TOWER, OW_PATH, OW_BRIDGE
tiles = [OW_GRASS, OW_PATH, OW_TREE, OW_WATER, OW_CLIFF_FACE, OW_CLIFF_TOP, OW_HOUSE_ROOF, OW_HOUSE_WALL, OW_HOUSE_DOOR, OW_CASTLE_TOWER, OW_BRIDGE]
running = True
while running:
    for ev in pygame.event.get():
        if ev.type == pygame.QUIT: running = False
    screen.fill((0,0,0))
    ticks = pygame.time.get_ticks()
    for i, t in enumerate(tiles):
        x = 20 + (i % 8) * 80
        y = 20 + (i // 8) * 80
        # Draw 4x scaled
        s = pygame.Surface((16,16))
        draw_overworld_tile(s, t, 0, 0, ticks)
        scaled = pygame.transform.scale(s, (64, 64))
        screen.blit(scaled, (x, y))
    pygame.display.flip()
pygame.quit()
"
```

Expected: Window shows all tile types rendered. Close window to continue.

- [ ] **Step 8: Commit**

```bash
git add overworld_tiles.py
git commit -m "feat: add ALttP-accurate tile draw functions for all 35 tile types"
```

---

### Task 3: Screen Manager — Caching and Rendering

**Files:**
- Create: `overworld_engine.py`
- Create: `tests/test_engine.py`

The ScreenManager handles pre-rendering screens, drawing the game world, and managing screen transitions.

- [ ] **Step 1: Create `overworld_engine.py` with ScreenManager skeleton**

```python
"""
Overworld engine — screen management, tile caching, and transitions.

The ScreenManager pre-renders static tiles to cached Surfaces for performance,
handles smooth screen-by-screen transitions, and manages overworld state.
"""
import pygame
from overworld_tiles import (
    TILE_PROPS, draw_overworld_tile, get_overlay_tiles,
    OW_GRASS, OW_BOUNDARY, TILE
)

# Screen dimensions (must match main.py)
NATIVE_W = 256
NATIVE_H = 224
HUD_H = 28
GAME_Y = HUD_H
MAP_COLS = NATIVE_W // TILE   # 16
MAP_ROWS = (NATIVE_H - HUD_H) // TILE  # 12
CACHE_H = MAP_ROWS * TILE     # 192 — tile area only, no HUD

# Transition speed
TRANSITION_FRAMES = 16  # ~0.27s at 60fps

# Directions → offsets
DIR_OFFSET = {
    "left":  (-1, 0),
    "right": (1, 0),
    "up":    (0, -1),
    "down":  (0, 1),
}


class ScreenManager:
    """Manages the overworld screen grid, caching, and transitions.

    Usage:
        mgr = ScreenManager(overworld_data)
        mgr.enter_screen((3, 4))  # Start at Link's House

        # In game loop:
        mgr.draw(game_surf, ticks)
        mgr.check_edge(player)    # Triggers transition if player at edge
        mgr.update()              # Advances transition animation
    """

    def __init__(self, overworld_data):
        """
        Args:
            overworld_data: dict of (col, row) → screen dict with "tiles", "enemies", etc.
        """
        self.data = overworld_data
        self.current = None           # (col, row) tuple
        self.cache = {}               # (col, row) → pygame.Surface (256×192)
        self.transition = None        # Active transition state or None
        self.cut_tiles = {}           # (col, row) → set of (tile_col, tile_row) that were cut
        self._overlay_ids = get_overlay_tiles()

    def enter_screen(self, screen_pos):
        """Set current screen and pre-cache it + neighbors."""
        self.current = screen_pos
        self._cache_screen(screen_pos)
        # Pre-cache adjacent screens
        for dx, dy in DIR_OFFSET.values():
            adj = (screen_pos[0] + dx, screen_pos[1] + dy)
            if adj in self.data:
                self._cache_screen(adj)

    def _cache_screen(self, pos):
        """Render static tiles to a 256×192 Surface."""
        if pos in self.cache:
            return
        screen_data = self.data.get(pos)
        if not screen_data:
            return
        surf = pygame.Surface((NATIVE_W, CACHE_H))
        surf.fill((0, 0, 0))
        tiles = screen_data["tiles"]
        cut = self.cut_tiles.get(pos, set())
        for row in range(MAP_ROWS):
            for col in range(MAP_COLS):
                tile = tiles[row][col]
                if (col, row) in cut:
                    tile = OW_GRASS
                props = TILE_PROPS.get(tile, {})
                if not props.get("animated", False):
                    draw_overworld_tile(surf, tile, col * TILE, row * TILE, 0)
        self.cache[pos] = surf

    def invalidate_cache(self, pos):
        """Force re-render after tile change (e.g., cutting grass)."""
        self.cache.pop(pos, None)

    def cut_tile(self, pos, tile_col, tile_row):
        """Record a tile as cut (tall grass/bush → grass)."""
        if pos not in self.cut_tiles:
            self.cut_tiles[pos] = set()
        self.cut_tiles[pos].add((tile_col, tile_row))
        self.invalidate_cache(pos)

    def get_tile(self, pos, col, row):
        """Get the effective tile at a position (accounting for cuts)."""
        if pos not in self.data:
            return OW_BOUNDARY
        cut = self.cut_tiles.get(pos, set())
        if (col, row) in cut:
            return OW_GRASS
        return self.data[pos]["tiles"][row][col]

    def draw(self, game_surf, ticks):
        """Draw the current screen (and transition if active) to game_surf."""
        if self.transition:
            self._draw_transition(game_surf, ticks)
        else:
            self._draw_screen(game_surf, self.current, 0, 0, ticks)

    def _draw_screen(self, game_surf, pos, offset_x, offset_y, ticks):
        """Draw a screen at the given offset."""
        # Blit cached static background
        if pos not in self.cache:
            self._cache_screen(pos)
        if pos in self.cache:
            game_surf.blit(self.cache[pos], (offset_x, GAME_Y + offset_y))

        # Draw animated tiles on top
        screen_data = self.data.get(pos)
        if not screen_data:
            return
        tiles = screen_data["tiles"]
        cut = self.cut_tiles.get(pos, set())
        for row in range(MAP_ROWS):
            for col in range(MAP_COLS):
                tile = tiles[row][col]
                if (col, row) in cut:
                    continue
                props = TILE_PROPS.get(tile, {})
                if props.get("animated", False):
                    draw_overworld_tile(game_surf, tile,
                                       offset_x + col * TILE,
                                       GAME_Y + offset_y + row * TILE,
                                       ticks)

    def draw_overlays(self, game_surf, pos, offset_x, offset_y, ticks):
        """Draw tree canopy overlays (rendered above sprites)."""
        screen_data = self.data.get(pos)
        if not screen_data:
            return
        tiles = screen_data["tiles"]
        for row in range(MAP_ROWS):
            for col in range(MAP_COLS):
                if tiles[row][col] in self._overlay_ids:
                    # Redraw just the canopy portion (top half of tree)
                    draw_overworld_tile(game_surf, tiles[row][col],
                                       offset_x + col * TILE,
                                       GAME_Y + offset_y + row * TILE,
                                       ticks)

    # ── Screen Transitions ──

    def check_edge(self, player_x, player_y, player_w, player_h):
        """Check if player has reached a screen edge. Returns direction or None.

        Uses tile-local coordinates (player_y is 0-192, NOT screen Y).
        """
        if self.transition:
            return None
        hw = player_w // 2
        if player_x - hw <= 0:
            return "left"
        if player_x + hw >= NATIVE_W:
            return "right"
        if player_y <= 0:
            return "up"
        if player_y + player_h >= MAP_ROWS * TILE:
            return "down"
        return None

    def start_transition(self, direction):
        """Begin scrolling to the adjacent screen.

        Returns:
            True if transition started, False if blocked (boundary/missing screen).
        """
        dx, dy = DIR_OFFSET[direction]
        next_pos = (self.current[0] + dx, self.current[1] + dy)
        if next_pos not in self.data:
            return False
        # Don't transition into boundary screens
        screen_data = self.data.get(next_pos, {})
        if screen_data.get("boundary", False):
            return False
        # Pre-cache the target
        self._cache_screen(next_pos)
        self.transition = {
            "direction": direction,
            "from": self.current,
            "to": next_pos,
            "progress": 0,
            "total": TRANSITION_FRAMES,
        }
        return True

    def update_transition(self):
        """Advance transition animation by one frame.

        Returns:
            True if transition just completed, False otherwise.
        """
        if not self.transition:
            return False
        self.transition["progress"] += 1
        if self.transition["progress"] >= self.transition["total"]:
            # Transition complete
            self.enter_screen(self.transition["to"])
            self.transition = None
            return True
        return False

    @property
    def in_transition(self):
        return self.transition is not None

    def _draw_transition(self, game_surf, ticks):
        """Draw the scrolling transition between two screens."""
        t = self.transition
        progress = t["progress"] / t["total"]  # 0.0 → 1.0
        d = t["direction"]

        if d == "left":
            off_x = int(NATIVE_W * progress)
            self._draw_screen(game_surf, t["from"], off_x, 0, ticks)
            self._draw_screen(game_surf, t["to"], off_x - NATIVE_W, 0, ticks)
        elif d == "right":
            off_x = int(-NATIVE_W * progress)
            self._draw_screen(game_surf, t["from"], off_x, 0, ticks)
            self._draw_screen(game_surf, t["to"], off_x + NATIVE_W, 0, ticks)
        elif d == "up":
            off_y = int(CACHE_H * progress)
            self._draw_screen(game_surf, t["from"], 0, off_y, ticks)
            self._draw_screen(game_surf, t["to"], 0, off_y - CACHE_H, ticks)
        elif d == "down":
            off_y = int(-CACHE_H * progress)
            self._draw_screen(game_surf, t["from"], 0, off_y, ticks)
            self._draw_screen(game_surf, t["to"], 0, off_y + CACHE_H, ticks)

    def get_player_entry_pos(self, direction):
        """Get player position after arriving from a transition.

        Returns (x, y) in tile-local coordinates (no GAME_Y).
        """
        if direction == "left":
            return NATIVE_W - 20, None  # Keep y, set x to right edge
        elif direction == "right":
            return 20, None
        elif direction == "up":
            return None, CACHE_H - 20  # Keep x, set y to bottom (tile-local)
        elif direction == "down":
            return None, 20
        return None, None
```

- [ ] **Step 2: Write engine tests**

```python
# tests/test_engine.py
"""Tests for overworld engine coordinate math and screen management."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

# Minimal pygame init for Surface creation
import pygame
pygame.init()
pygame.display.set_mode((1, 1))

from overworld_tiles import OW_GRASS, OW_WATER, OW_BOUNDARY, OW_CLIFF_TOP
from overworld_engine import ScreenManager, MAP_COLS, MAP_ROWS, GAME_Y, NATIVE_W, CACHE_H

def _make_screen(fill_tile=OW_GRASS, boundary=False):
    return {
        "tiles": [[fill_tile] * MAP_COLS for _ in range(MAP_ROWS)],
        "enemies": [],
        "boundary": boundary,
    }

def _make_overworld():
    return {
        (1, 1): _make_screen(),
        (2, 1): _make_screen(),
        (1, 2): _make_screen(),
        (0, 0): _make_screen(OW_BOUNDARY, boundary=True),
    }

def test_enter_screen_sets_current():
    mgr = ScreenManager(_make_overworld())
    mgr.enter_screen((1, 1))
    assert mgr.current == (1, 1)

def test_enter_screen_caches_neighbors():
    mgr = ScreenManager(_make_overworld())
    mgr.enter_screen((1, 1))
    assert (1, 1) in mgr.cache
    assert (2, 1) in mgr.cache  # right neighbor
    assert (1, 2) in mgr.cache  # down neighbor

def test_transition_to_boundary_blocked():
    mgr = ScreenManager(_make_overworld())
    mgr.enter_screen((1, 1))
    result = mgr.start_transition("left")  # goes to (0,1) which doesn't exist
    assert result == False

def test_transition_to_valid_screen():
    mgr = ScreenManager(_make_overworld())
    mgr.enter_screen((1, 1))
    result = mgr.start_transition("right")  # goes to (2,1)
    assert result == True
    assert mgr.in_transition == True

def test_transition_completes():
    mgr = ScreenManager(_make_overworld())
    mgr.enter_screen((1, 1))
    mgr.start_transition("right")
    for _ in range(16):
        mgr.update_transition()
    assert mgr.current == (2, 1)
    assert mgr.in_transition == False

def test_edge_detection_left():
    mgr = ScreenManager(_make_overworld())
    mgr.enter_screen((1, 1))
    assert mgr.check_edge(0, 100, 16, 24) == "left"

def test_edge_detection_none_center():
    mgr = ScreenManager(_make_overworld())
    mgr.enter_screen((1, 1))
    assert mgr.check_edge(128, 120, 16, 24) is None

def test_cut_tile_tracked():
    mgr = ScreenManager(_make_overworld())
    mgr.enter_screen((1, 1))
    mgr.cut_tile((1, 1), 5, 3)
    assert mgr.get_tile((1, 1), 5, 3) == OW_GRASS

def test_player_entry_pos_from_right():
    mgr = ScreenManager(_make_overworld())
    x, y = mgr.get_player_entry_pos("right")
    assert x == 20  # Appears on left side
    assert y is None  # Keep existing y

if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    passed = failed = 0
    for t in tests:
        try:
            t()
            passed += 1
            print(f"  PASS  {t.__name__}")
        except (AssertionError, Exception) as e:
            failed += 1
            print(f"  FAIL  {t.__name__}: {e}")
    print(f"\n{passed} passed, {failed} failed")
    pygame.quit()
```

- [ ] **Step 3: Run tests**

Run: `cd /Users/jasper/Sites/localhost/pygame-zelda && python3 tests/test_engine.py`
Expected: All tests pass

- [ ] **Step 4: Commit**

```bash
git add overworld_engine.py tests/test_engine.py
git commit -m "feat: add ScreenManager with caching, transitions, and edge detection"
```

---

### Task 4: Overworld Map Data

**Files:**
- Create: `overworld_maps.py`

This is the largest data task. We define all 64 screens of the overworld grid: 38 hand-crafted playable screens + 26 auto-generated boundary screens.

- [ ] **Step 1: Create `overworld_maps.py` with structure and helpers**

```python
"""
Overworld map data — all 64 screens of the ALttP Light World.

The overworld is an 8×8 grid. Boundary screens (edges) are auto-generated.
Playable screens are hand-crafted tile grids (16 columns × 12 rows each).

Map key (short aliases imported from overworld_tiles):
  G=Grass  DG=DarkGrass  PA=Path  SA=Sand  SW=Swamp
  WA=Water  DW=DeepWater  WF=Waterfall
  CF=CliffFace  CT=CliffTop  CL=CliffLeft  CR=CliffRight
  CB=CliffCornerTL  CE=CliffCornerTR  BL=CliffBL  BR=CliffBR
  MN=Mountain  CV=Cave  ST=Stairs
  TR=Tree  DT=DarkTree  BU=Bush  TG=TallGrass  FL=Flowers
  HR=HouseRoof  HW=HouseWall  HD=HouseDoor
  CW=CastleWall  TO=CastleTower  CG=CastleGate
  BD=Bridge  FE=Fence  SI=Sign  TC=Torch
  DN=Dungeon  CH=Chest  BO=Boundary
"""

from overworld_tiles import (
    GR, DG, PA, SA, SW, WA, DW, WF,
    CF, CT, CL, CR, CB, CE, BL, BR, MN, CV, ST,
    TR, DT, BU, TG, FL,
    HR, HW, HD, CW, TO, CG, BD, FE, SI, TC,
    DN, CH, BO,
    OW_GRASS,
)


def _boundary_screen():
    """Generate a boundary screen (impassable cliffs)."""
    return {
        "tiles": [[BO] * 16 for _ in range(12)],
        "enemies": [],
        "boundary": True,
    }


def _screen(name, tiles, enemies=None, npcs=None, items=None, dungeon=None):
    """Helper to create a screen data dict."""
    return {
        "name": name,
        "tiles": tiles,
        "enemies": enemies or [],
        "npcs": npcs or [],
        "items": items or [],
        "dungeon": dungeon,
        "boundary": False,
    }
```

- [ ] **Step 2: Add Link's House and surrounding screens (Row 4)**

```python
# ══════════════════════════════════════════
#  ROW 4: Graveyard, South Woods, Link's House, Open Field, Witch Hut, East Lake
# ══════════════════════════════════════════

SCREEN_LINKS_HOUSE = _screen("Link's House", [
    [GR, GR, TR, GR, GR,  PA, PA, GR, GR,  TR, GR, GR,  TG, GR, GR,  G ],
    [GR, GR, GR,  G,  PA, PA, GR, GR,  G,  G,  G,  TR, GR, GR,  G,  G ],
    [TR, GR, GR,  PA, PA, GR, GR,  G,  G,  G,  G,  G,  G,  G,  TR, G ],
    [GR, GR, PA, PA, GR, GR,  HR, HR, HR, GR, GR,  G,  G,  G,  G,  G ],
    [GR, PA, PA, GR, GR,  G,  HW, HW, HW, GR, GR,  TG, GR, GR,  G,  G ],
    [GR, PA, GR, GR,  G,  G,  HW, HD, HW, GR, GR,  G,  G,  TR, GR, G ],
    [GR, PA, GR, GR,  TG, GR, GR,  PA, GR, GR,  G,  G,  G,  G,  G,  G ],
    [GR, PA, PA, GR, GR,  G,  G,  PA, PA, GR, GR,  G,  TG, GR, GR,  G ],
    [GR, GR, PA, PA, PA, PA, PA, PA, PA, PA, GR, GR,  G,  G,  G,  TR],
    [GR, GR, GR,  G,  G,  G,  PA, GR, GR,  PA, PA, GR, GR,  G,  G,  G ],
    [TR, GR, TG, GR, GR,  G,  G,  G,  G,  G,  PA, PA, GR, TG, GR, G ],
    [GR, GR, GR,  G,  TR, GR, GR,  G,  G,  G,  G,  PA, PA, GR, GR,  G ],
], enemies=[("slime", 12, 3), ("slime", 14, 7)])

SCREEN_GRAVEYARD = _screen("Graveyard", [
    [CF, CF, CF, CF, CF, CF, GR, GR,  G,  G,  G,  G,  G,  CF, CF, CF],
    [CF, GR, GR,  G,  G,  G,  G,  PA, PA, GR, GR,  G,  G,  G,  G,  CF],
    [GR, GR, CW, CW, GR, GR,  PA, PA, GR, GR,  CW, CW, GR, GR,  G,  G ],
    [GR, GR, CW, CW, GR, PA, PA, GR, GR,  G,  CW, CW, GR, GR,  G,  G ],
    [GR, GR, GR,  G,  G,  PA, GR, GR,  G,  G,  G,  G,  G,  G,  G,  G ],
    [GR, GR, CW, CW, GR, PA, GR, GR,  CW, CW, GR, GR,  CW, CW, GR, G ],
    [GR, GR, CW, CW, GR, PA, GR, GR,  CW, CW, GR, GR,  CW, CW, GR, G ],
    [GR, GR, GR,  G,  PA, PA, GR, GR,  G,  G,  G,  G,  G,  G,  G,  G ],
    [GR, GR, CW, CW, PA, GR, GR,  CW, CW, GR, GR,  CW, CW, GR, GR,  G ],
    [GR, GR, CW, CW, PA, GR, GR,  CW, CW, GR, GR,  CW, CW, GR, GR,  G ],
    [GR, GR, GR,  G,  PA, PA, PA, GR, GR,  G,  G,  G,  G,  G,  G,  G ],
    [CF, CF, CF, CF, CF, PA, PA, GR, GR,  CF, CF, CF, CF, CF, CF, CF],
], enemies=[("bat", 4, 2), ("bat", 11, 6), ("skeleton", 8, 4)])

SCREEN_SOUTH_WOODS = _screen("South Woods", [
    [TR, TR, GR, GR,  G,  PA, PA, GR, GR,  G,  TR, TR, GR, GR,  TR, TR],
    [TR, GR, GR,  TG, GR, GR,  PA, PA, GR, GR,  G,  TR, GR, GR,  G,  TR],
    [GR, GR, TG, GR, GR,  G,  G,  PA, GR, GR,  G,  G,  G,  TG, GR, G ],
    [GR, GR, GR,  G,  TR, GR, GR,  PA, GR, TR, GR, GR,  G,  G,  G,  G ],
    [TR, GR, GR,  G,  G,  G,  PA, PA, GR, GR,  G,  G,  TR, GR, GR,  G ],
    [GR, GR, TG, GR, GR,  PA, PA, GR, GR,  G,  TG, GR, GR,  G,  G,  TR],
    [GR, GR, GR,  G,  PA, PA, GR, GR,  G,  G,  G,  G,  G,  TG, GR, G ],
    [TR, GR, GR,  PA, PA, GR, GR,  G,  TG, GR, GR,  G,  G,  G,  G,  G ],
    [GR, GR, PA, PA, GR, GR,  G,  G,  G,  G,  G,  TR, GR, GR,  G,  TR],
    [GR, PA, PA, GR, GR,  G,  TR, GR, GR,  G,  G,  G,  G,  G,  G,  G ],
    [PA, PA, GR, GR,  TG, GR, GR,  G,  G,  TG, GR, GR,  G,  TG, GR, G ],
    [PA, GR, GR,  G,  G,  TR, GR, GR,  G,  G,  G,  TR, GR, GR,  G,  G ],
], enemies=[("slime", 3, 5), ("slime", 10, 2), ("bat", 7, 8)])

SCREEN_OPEN_FIELD = _screen("Open Field", [
    [GR, GR, GR,  TG, GR, GR,  PA, PA, GR, GR,  G,  TG, GR, GR,  G,  G ],
    [GR, GR, GR,  G,  G,  PA, PA, GR, GR,  G,  G,  G,  G,  G,  G,  G ],
    [GR, TG, GR, GR,  PA, PA, GR, GR,  G,  G,  TG, GR, GR,  G,  TG, G ],
    [GR, GR, GR,  PA, PA, GR, GR,  G,  G,  G,  G,  G,  G,  G,  G,  G ],
    [GR, GR, PA, PA, GR, GR,  G,  FL, FL, GR, GR,  G,  G,  G,  G,  G ],
    [GR, PA, PA, GR, GR,  G,  FL, GR, GR,  FL, GR, GR,  TG, GR, GR,  G ],
    [GR, PA, GR, GR,  G,  G,  G,  G,  G,  G,  G,  G,  G,  G,  G,  G ],
    [PA, PA, GR, GR,  TG, GR, GR,  G,  G,  G,  G,  G,  G,  G,  TR, G ],
    [PA, GR, GR,  G,  G,  G,  G,  G,  G,  G,  TG, GR, GR,  G,  G,  G ],
    [GR, GR, GR,  G,  G,  G,  G,  TR, GR, GR,  G,  G,  G,  G,  G,  G ],
    [GR, GR, TG, GR, GR,  G,  G,  G,  G,  G,  G,  G,  TG, GR, GR,  G ],
    [GR, GR, GR,  G,  G,  G,  G,  G,  G,  G,  G,  G,  G,  G,  G,  G ],
], enemies=[("slime", 9, 3), ("slime", 5, 9)])

SCREEN_WITCH_HUT = _screen("Witch's Hut", [
    [TR, GR, GR,  PA, PA, GR, GR,  G,  G,  TR, GR, GR,  G,  G,  WA, WA],
    [GR, GR, PA, PA, GR, GR,  G,  G,  G,  G,  G,  G,  G,  WA, WA, WA],
    [GR, PA, PA, GR, GR,  HR, HR, HR, GR, GR,  G,  G,  WA, WA, GR, G ],
    [GR, PA, GR, GR,  G,  HW, HW, HW, GR, GR,  G,  WA, WA, GR, GR,  G ],
    [PA, PA, GR, GR,  G,  HW, HD, HW, GR, GR,  WA, WA, GR, GR,  G,  G ],
    [PA, GR, GR,  G,  G,  G,  PA, GR, GR,  WA, WA, GR, GR,  G,  G,  G ],
    [GR, GR, TG, GR, GR,  G,  PA, GR, WA, WA, GR, GR,  G,  G,  G,  G ],
    [GR, GR, GR,  G,  G,  PA, PA, WA, WA, GR, GR,  G,  G,  TG, GR, G ],
    [GR, TR, GR, GR,  PA, PA, WA, WA, GR, GR,  G,  G,  G,  G,  G,  G ],
    [GR, GR, GR,  PA, PA, WA, WA, GR, GR,  G,  TR, GR, GR,  G,  G,  G ],
    [GR, GR, PA, PA, WA, WA, GR, GR,  G,  G,  G,  G,  G,  G,  G,  G ],
    [GR, PA, PA, WA, WA, GR, GR,  G,  G,  G,  G,  G,  TG, GR, GR,  G ],
], enemies=[("bat", 10, 4), ("bat", 12, 8)])

SCREEN_EAST_LAKE = _screen("Eastern Lake", [
    [GR, GR, GR,  G,  G,  G,  WA, WA, WA, WA, WA, DW, DW, DW, DW, DW],
    [GR, GR, GR,  G,  G,  WA, WA, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [GR, GR, GR,  G,  WA, WA, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [GR, GR, GR,  WA, WA, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [GR, GR, WA, WA, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [GR, WA, WA, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [GR, WA, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [WA, WA, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [WA, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [WA, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
    [DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW, DW],
])
```

- [ ] **Step 3: Add remaining screen data for all other rows**

Continue defining screens for rows 0-3 and rows 5-6 following the same pattern. Each screen gets:
- A 16×12 tile grid using the short aliases
- Enemy spawn list (type, tile_col, tile_row)
- Optional NPC, items, dungeon entry

Key screens to build carefully:
- **(2,0)-(5,0):** Death Mountain — mostly `MN`, `CF`, `CV` tiles
- **(1,1)-(2,1):** Lost Woods — dense `DT` dark trees
- **(3,1)-(4,1):** Castle North/Tower — `CW`, `TO`, `CG` tiles
- **(2,2):** Kakariko North — houses with `HR`, `HW`, `HD`
- **(3,2):** Castle Gate — moat with `WA`, drawbridge with `BD`
- **(4,2):** Castle Garden — `FL`, `TR` around castle
- **(5,1)-(5,3):** River screens — `WA` with `BD` bridges
- **(6,2):** Eastern Palace — `CW`, `DN` entrance
- **(1,5)-(2,5):** Desert — `SA` sand with `DN` palace
- **(4,5)-(5,6):** Lake Hylia — `DW` with island
- **(1,6)-(2,6):** Swamp — `SW` terrain with `DN` palace

Each screen should be about 20 lines. Build them one at a time, referencing the overworld grid layout from the spec.

- [ ] **Step 4: Assemble the OVERWORLD dict**

```python
# ══════════════════════════════════════════
#  ASSEMBLE FULL OVERWORLD (8×8 grid)
# ══════════════════════════════════════════

OVERWORLD = {}

# Auto-generate boundary screens for all edge positions
for col in range(8):
    for row in range(8):
        if col == 0 or col == 7 or row == 0 or row == 7:
            # Only add boundary if not already a playable screen
            if (col, row) not in OVERWORLD:
                OVERWORLD[(col, row)] = _boundary_screen()

# Row 0: Death Mountain (playable screens at cols 2-5)
OVERWORLD[(2, 0)] = SCREEN_DEATH_MTN_WEST
OVERWORLD[(3, 0)] = SCREEN_DEATH_MTN_TOWER
OVERWORLD[(4, 0)] = SCREEN_DEATH_MTN_EAST
OVERWORLD[(5, 0)] = SCREEN_DEATH_MTN_CLIFFS

# Row 1
OVERWORLD[(1, 1)] = SCREEN_LOST_WOODS_N
OVERWORLD[(2, 1)] = SCREEN_LOST_WOODS_S
OVERWORLD[(3, 1)] = SCREEN_CASTLE_NORTH
OVERWORLD[(4, 1)] = SCREEN_CASTLE_TOWER
OVERWORLD[(5, 1)] = SCREEN_RIVER_NORTH
OVERWORLD[(6, 1)] = SCREEN_EAST_RUINS

# Row 2
OVERWORLD[(1, 2)] = SCREEN_FOREST_CLEARING
OVERWORLD[(2, 2)] = SCREEN_KAKARIKO_NORTH
OVERWORLD[(3, 2)] = SCREEN_CASTLE_GATE
OVERWORLD[(4, 2)] = SCREEN_CASTLE_GARDEN
OVERWORLD[(5, 2)] = SCREEN_RIVER_BRIDGE
OVERWORLD[(6, 2)] = SCREEN_EASTERN_PALACE

# Row 3
OVERWORLD[(1, 3)] = SCREEN_KAKARIKO_SOUTH
OVERWORLD[(2, 3)] = SCREEN_CENTRAL_FIELD_W
OVERWORLD[(3, 3)] = SCREEN_CENTRAL_FIELD
OVERWORLD[(4, 3)] = SCREEN_CENTRAL_FIELD_E
OVERWORLD[(5, 3)] = SCREEN_RIVER_SOUTH
OVERWORLD[(6, 3)] = SCREEN_EAST_FIELD

# Row 4
OVERWORLD[(1, 4)] = SCREEN_GRAVEYARD
OVERWORLD[(2, 4)] = SCREEN_SOUTH_WOODS
OVERWORLD[(3, 4)] = SCREEN_LINKS_HOUSE
OVERWORLD[(4, 4)] = SCREEN_OPEN_FIELD
OVERWORLD[(5, 4)] = SCREEN_WITCH_HUT
OVERWORLD[(6, 4)] = SCREEN_EAST_LAKE

# Row 5
OVERWORLD[(1, 5)] = SCREEN_DESERT_NORTH
OVERWORLD[(2, 5)] = SCREEN_DESERT_PALACE
OVERWORLD[(3, 5)] = SCREEN_SOUTH_FIELD
OVERWORLD[(4, 5)] = SCREEN_MEADOW
OVERWORLD[(5, 5)] = SCREEN_LAKE_HYLIA_N
OVERWORLD[(6, 5)] = SCREEN_LAKE_HYLIA_E

# Row 6
OVERWORLD[(1, 6)] = SCREEN_SWAMP_NORTH
OVERWORLD[(2, 6)] = SCREEN_SWAMP_PALACE
OVERWORLD[(3, 6)] = SCREEN_SOUTH_SHORE
OVERWORLD[(4, 6)] = SCREEN_LAKE_HYLIA_S
OVERWORLD[(5, 6)] = SCREEN_LAKE_ISLAND
OVERWORLD[(6, 6)] = SCREEN_ICE_CAVE

# Dungeon entry mapping: (screen_col, screen_row, tile_col, tile_row) → level
DUNGEON_ENTRIES = {
    # Map dungeon entrance tile positions to existing dungeon levels
    # Format: screen_pos → dungeon_level
    (6, 2): 0,   # Eastern Palace → Level 0
    (2, 5): 1,   # Desert Palace → Level 1
    (3, 1): 2,   # Castle → Level 2
    (2, 6): 3,   # Swamp Palace → Level 3
    (3, 0): 4,   # Death Mountain Tower → Level 4 (Boss)
}

# Starting position
START_SCREEN = (3, 4)
START_X = 7 * 16 + 8   # Centered on path near house
START_Y = 6 * 16       # In front of door (tile-local Y, GAME_Y added during draw)
```

- [ ] **Step 5: Verify map data loads**

```bash
cd /Users/jasper/Sites/localhost/pygame-zelda
python3 -c "
from overworld_maps import OVERWORLD, START_SCREEN, DUNGEON_ENTRIES
print(f'Total screens: {len(OVERWORLD)}')
playable = sum(1 for v in OVERWORLD.values() if not v.get('boundary'))
boundary = sum(1 for v in OVERWORLD.values() if v.get('boundary'))
print(f'Playable: {playable}, Boundary: {boundary}')
print(f'Start screen: {START_SCREEN}')
print(f'Start screen name: {OVERWORLD[START_SCREEN][\"name\"]}')
print(f'Dungeon entries: {len(DUNGEON_ENTRIES)}')
# Verify all screens have correct dimensions
for pos, data in OVERWORLD.items():
    tiles = data['tiles']
    assert len(tiles) == 12, f'Screen {pos} has {len(tiles)} rows (expected 12)'
    for i, row in enumerate(tiles):
        assert len(row) == 16, f'Screen {pos} row {i} has {len(row)} cols (expected 16)'
print('All screen dimensions valid!')
"
```

Expected: Shows 64 total screens, ~38 playable, ~26 boundary, all dimensions valid.

- [ ] **Step 6: Commit**

```bash
git add overworld_maps.py
git commit -m "feat: add overworld map data — 64 screens covering the full Light World"
```

---

### Task 5: Main Game Integration — Auto-Scaling and Game Mode

**Files:**
- Modify: `main.py:21-36` (scaling setup)
- Modify: `main.py:1518-1860` (game loop)
- Modify: `main.py:1862-1873` (main entry)

This task connects everything: auto-scaling viewport, overworld game mode, screen transitions, and dungeon entry/exit.

- [ ] **Step 1: Replace hardcoded scaling with auto-detect**

In `main.py`, replace lines 21-36:

```python
# ══════════════════════════════════════════
#  SNES-STYLE RENDERING
# ══════════════════════════════════════════
NATIVE_W, NATIVE_H = 256, 224
TILE = 16
HUD_H = 28
GAME_Y = HUD_H
GAME_H = NATIVE_H - HUD_H
MAP_COLS = NATIVE_W // TILE   # 16
MAP_ROWS = GAME_H // TILE     # 12
FPS = 60

# Auto-detect best integer scale for this monitor
_info = pygame.display.Info()
_max_w = _info.current_w // NATIVE_W
_max_h = _info.current_h // NATIVE_H
SCALE = max(2, min(_max_w, _max_h) - 1)  # -1 for taskbar, min 2
SCREEN_W = NATIVE_W * SCALE
SCREEN_H = NATIVE_H * SCALE

# All drawing goes to this surface, then scaled for crisp pixels
game_surf = pygame.Surface((NATIVE_W, NATIVE_H))
screen = pygame.display.set_mode((SCREEN_W, SCREEN_H))
pygame.display.set_caption("The Legend of Link")
clock = pygame.time.Clock()
fullscreen = False

def toggle_fullscreen():
    global fullscreen, SCALE, SCREEN_W, SCREEN_H, screen
    fullscreen = not fullscreen
    info = pygame.display.Info()
    if fullscreen:
        SCALE = min(info.current_w // NATIVE_W, info.current_h // NATIVE_H)
        screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
    else:
        SCALE = max(2, min(info.current_w // NATIVE_W, info.current_h // NATIVE_H) - 1)
        screen = pygame.display.set_mode((NATIVE_W * SCALE, NATIVE_H * SCALE))
    SCREEN_W = NATIVE_W * SCALE
    SCREEN_H = NATIVE_H * SCALE
```

- [ ] **Step 2: Add overworld game loop function**

First, add a `game_loop_dungeon()` function that runs a dungeon level and returns to caller (unlike `game_loop()` which runs all levels). Add this after `game_loop()`:

```python
def game_loop_dungeon(lvl, player_ref):
    """Run a single dungeon level, returning True when complete, False on quit."""
    global from_grass_pickups
    cmap, enemies, pickups, npcs, chests = setup_level(lvl)
    # Use existing player stats but reset position
    player = player_ref
    old_x, old_y = player.x, player.y
    player.x, player.y = 8 * TILE, 2 * TILE
    particles, dmg_nums, projectiles = [], [], []
    dialogue = Dialogue()
    shake, hitstop = 0, 0
    state = "playing"
    msg, msg_t = LEVEL_NAMES[lvl], 90
    from_grass_pickups = []

    fade("in", 10)

    while True:
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                return False
            if ev.type == pygame.KEYDOWN:
                if ev.key == pygame.K_ESCAPE:
                    # Exit dungeon, return to overworld
                    player.x, player.y = old_x, old_y
                    return True
                # ... (same key handling as game_loop for combat/items)

        keys = pygame.key.get_pressed()
        ticks = pygame.time.get_ticks()

        if hitstop > 0:
            hitstop -= 1
        elif state == "playing" and not dialogue.active:
            player.update(keys, cmap)
            # ... (same update logic as game_loop)

            # Stairs = dungeon complete, return to overworld
            c, r = int(player.x) // TILE, int(player.y) // TILE
            if 0 <= r < MAP_ROWS and 0 <= c < MAP_COLS and cmap[r][c] == S:
                if len(enemies) == 0:
                    SFX["win"].play()
                    player.x, player.y = old_x, old_y
                    return True

        # ... (same draw logic as game_loop)
        # Note: This is a simplified outline — copy relevant sections from game_loop()
        # and modify stairs to return True instead of advancing levels.

        game_surf.fill(BLACK)
        for ri in range(MAP_ROWS):
            for ci in range(MAP_COLS):
                draw_tile(game_surf, cmap[ri][ci], ci, ri, ticks)
        for ch in chests: ch.draw(game_surf)
        for p in pickups: p.draw(game_surf)
        for e in enemies: e.draw(game_surf)
        player.draw(game_surf)
        draw_hud(game_surf, player, lvl, enemies)

        scaled = pygame.transform.scale(game_surf, (SCREEN_W, SCREEN_H))
        screen.blit(scaled, (0, 0))
        pygame.display.flip()
        clock.tick(FPS)

    return False
```

Then add the `overworld_loop()` function. This is the overworld equivalent that uses the ScreenManager:

```python
def overworld_loop():
    """Main game loop for the overworld mode."""
    global from_grass_pickups
    from overworld_engine import ScreenManager
    from overworld_maps import OVERWORLD, START_SCREEN, START_X, START_Y, DUNGEON_ENTRIES
    from overworld_tiles import TILE_PROPS, is_walkable, OW_GRASS, OW_TALL_GRASS, OW_BUSH

    mgr = ScreenManager(OVERWORLD)
    mgr.enter_screen(START_SCREEN)

    player = Player(START_X, START_Y)
    particles, dmg_nums, projectiles = [], [], []
    dialogue = Dialogue()
    shake, hitstop = 0, 0
    state = "playing"
    msg, msg_t = OVERWORLD[START_SCREEN]["name"], 90
    show_mm = True
    popup, popup_t = "", 0
    from_grass_pickups = []

    # Spawn enemies for current screen
    screen_data = OVERWORLD[mgr.current]
    enemies = []
    pickups, npcs, chests = [], [], []
    def spawn_screen_entities():
        nonlocal enemies, pickups, npcs, chests
        enemies = []
        pickups = []
        sd = OVERWORLD.get(mgr.current, {})
        for etype, tc, tr in sd.get("enemies", []):
            # Tile-local coords — same space as player (GAME_Y added at draw time)
            enemies.append(Enemy(tc * TILE, tr * TILE, etype))

    spawn_screen_entities()
    fade("in", 10)

    # Overworld collision map helper
    def ow_cmap():
        """Build a collision-compatible map for the current screen."""
        sd = OVERWORLD.get(mgr.current, {})
        return sd.get("tiles", [[OW_GRASS] * MAP_COLS for _ in range(MAP_ROWS)])

    # Override player wall check for overworld tiles
    original_wall = Player._wall
    def overworld_wall(self, rect, cmap_arg):
        for cx, cy in [(rect.left, rect.top), (rect.right - 1, rect.top),
                       (rect.left, rect.bottom - 1), (rect.right - 1, rect.bottom - 1)]:
            c = int(cx) // TILE
            r = int(cy) // TILE  # tile-local Y, no GAME_Y subtraction
            if 0 <= r < MAP_ROWS and 0 <= c < MAP_COLS:
                tile = mgr.get_tile(mgr.current, c, r)
                if not is_walkable(tile, self.dir):
                    return True
            else:
                # Allow walking slightly past edges for transition detection
                # But block going way off screen
                if cx < -8 or cx > NATIVE_W + 8 or cy < -8 or cy > MAP_ROWS * TILE + 8:
                    return True
        return False
    Player._wall = overworld_wall

    # Disable player position clamping in overworld (so edge transitions work)
    # Save original clamp bounds and expand them
    original_update = Player.update
    def overworld_update(self, keys_pressed, cmap):
        original_update(self, keys_pressed, cmap)
        # Re-clamp with wider bounds to allow edge reach
        hw, hh = self.w // 2, self.h // 2
        self.x = max(-4, min(NATIVE_W + 4, self.x))
        self.y = max(-4, min(MAP_ROWS * TILE + 4, self.y))
    Player.update = overworld_update

    while True:
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                Player._wall = original_wall
                return False
            if ev.type == pygame.KEYDOWN:
                if ev.key == pygame.K_F11:
                    toggle_fullscreen()
                elif dialogue.active:
                    if ev.key in (pygame.K_e, pygame.K_RETURN, pygame.K_SPACE):
                        dialogue.advance()
                elif state == "playing" and not mgr.in_transition:
                    if ev.key == pygame.K_SPACE:
                        player.attack(projectiles, ow_cmap(), particles)
                        # Check for grass/bush cutting
                        if player.weapon == "sword":
                            sr = player.sword_rect()
                            gc = sr.centerx // TILE
                            gr = sr.centery // TILE  # tile-local Y
                            if 0 <= gr < MAP_ROWS and 0 <= gc < MAP_COLS:
                                tile = mgr.get_tile(mgr.current, gc, gr)
                                if TILE_PROPS.get(tile, {}).get("cuttable"):
                                    mgr.cut_tile(mgr.current, gc, gr)
                                    SFX["grass"].play()
                                    # Random item drops from cut vegetation
                                    if random.random() < 0.25:
                                        drop = "rupee" if random.random() < 0.7 else "heart"
                                        pickups.append(Pickup(gc * TILE + 8, gr * TILE + 8, drop))
                    elif ev.key == pygame.K_e:
                        # Check for dungeon/cave entrances
                        pc = int(player.x) // TILE
                        pr = (int(player.y) - GAME_Y) // TILE
                        if 0 <= pr < MAP_ROWS and 0 <= pc < MAP_COLS:
                            tile = mgr.get_tile(mgr.current, pc, pr)
                            if TILE_PROPS.get(tile, {}).get("entrance"):
                                dungeon_lvl = DUNGEON_ENTRIES.get(mgr.current)
                                if dungeon_lvl is not None:
                                    # Save overworld state & enter dungeon
                                    Player._wall = original_wall
                                    SFX["door"].play()
                                    iris_wipe("out", int(player.x), int(player.y), 18)
                                    result = game_loop_dungeon(dungeon_lvl, player)
                                    Player._wall = overworld_wall
                                    if not result:
                                        Player._wall = original_wall
                                        return False
                                    iris_wipe("in", int(player.x), int(player.y), 18)
                    elif ev.key == pygame.K_1 and "sword" in player.weapons_unlocked:
                        player.weapon = "sword"; SFX["select"].play()
                    elif ev.key == pygame.K_2 and "bow" in player.weapons_unlocked:
                        player.weapon = "bow"; SFX["select"].play()
                    elif ev.key == pygame.K_3 and "bomb" in player.weapons_unlocked:
                        player.weapon = "bomb"; SFX["select"].play()
                    elif ev.key == pygame.K_TAB:
                        show_mm = not show_mm
                elif state == "dead":
                    if ev.key == pygame.K_r:
                        Player._wall = original_wall
                        return True
                    if ev.key == pygame.K_q:
                        Player._wall = original_wall
                        return False

        keys = pygame.key.get_pressed()
        ticks = pygame.time.get_ticks()

        # ── UPDATE ──
        if hitstop > 0:
            hitstop -= 1
        elif state == "playing" and not dialogue.active:
            if mgr.in_transition:
                # Save direction BEFORE update clears it
                last_dir = mgr.transition["direction"]
                completed = mgr.update_transition()
                if completed:
                    # Player wraps to opposite edge
                    new_x, new_y = mgr.get_player_entry_pos(last_dir)
                    if new_x is not None:
                        player.x = new_x
                    if new_y is not None:
                        player.y = new_y
                    spawn_screen_entities()
                    msg = OVERWORLD[mgr.current].get("name", "")
                    msg_t = 60
            else:
                player.update(keys, ow_cmap())

                # Check screen edge transitions
                edge = mgr.check_edge(player.x, player.y, player.w, player.h)
                if edge:
                    started = mgr.start_transition(edge)
                    if not started:
                        # Clamp at edge
                        hw = player.w // 2
                        player.x = max(hw + 1, min(NATIVE_W - hw - 1, player.x))
                        player.y = max(GAME_Y + 1, min(GAME_Y + MAP_ROWS * TILE - player.h - 1, player.y))

                # Projectile updates — with overworld-aware collision
                for proj in projectiles[:]:
                    proj.update(ow_cmap(), particles)
                    if not proj.alive:
                        projectiles.remove(proj); continue
                    # Override wall check: projectiles die on non-walkable tiles
                    pc = int(proj.x) // TILE
                    pr = int(proj.y) // TILE
                    if 0 <= pr < MAP_ROWS and 0 <= pc < MAP_COLS:
                        tile = mgr.get_tile(mgr.current, pc, pr)
                        if not is_walkable(tile):
                            proj.alive = False
                            continue
                    if proj.owner == "player":
                        for enemy in enemies:
                            if proj.rect.colliderect(enemy.rect) and enemy.flash == 0:
                                d = 2 if proj.kind == "bomb" and proj.exploded else 1
                                enemy.take_damage(d, proj.x, proj.y)
                                player.dmg_dealt += d; shake = 3
                                dmg_nums.append(DmgNum(enemy.x, enemy.y - 10, str(d), YELLOW))
                                if proj.kind == "arrow":
                                    proj.alive = False

                # Enemy updates with loot drops
                for enemy in enemies[:]:
                    enemy.update(player, ow_cmap(), projectiles)
                    if enemy.hp <= 0:
                        hitstop = 4
                        for _ in range(8):
                            particles.append(Particle(enemy.x, enemy.y,
                                random.choice([RED, ORANGE, YELLOW]), life=20))
                        player.kills += 1
                        # Loot drops (same as dungeon)
                        r = random.random()
                        if r < 0.3:   pickups.append(Pickup(enemy.x, enemy.y, "rupee"))
                        elif r < 0.4: pickups.append(Pickup(enemy.x, enemy.y, "heart"))
                        elif r < 0.48: pickups.append(Pickup(enemy.x, enemy.y, "arrows"))
                        elif r < 0.52: pickups.append(Pickup(enemy.x, enemy.y, "bombs"))
                        enemies.remove(enemy)
                        continue
                    if enemy.rect.colliderect(player.rect):
                        player.take_damage(enemy.dmg, enemy.x, enemy.y)
                        if player.invincible == 50:
                            shake = 6

                # Pickup collection
                for p in pickups:
                    if not p.collected and p.rect.colliderect(player.rect):
                        p.collected = True; SFX["pickup"].play()
                        if p.kind == "rupee":
                            player.rupees += 1
                        elif p.kind == "heart":
                            player.hp = min(player.max_hp, player.hp + 2)
                        elif p.kind == "arrows":
                            player.arrows += 5
                        elif p.kind == "bombs":
                            player.bombs += 3

                if player.hp <= 0:
                    SFX["die"].play(); state = "dead"; shake = 12

        dialogue.update()
        for p in particles[:]:
            p.update()
            if p.life <= 0: particles.remove(p)
        for d in dmg_nums[:]:
            d.update()
            if d.life <= 0: dmg_nums.remove(d)
        if msg_t > 0: msg_t -= 1
        if popup_t > 0: popup_t -= 1
        if shake > 0: shake -= 1

        # ── DRAW ──
        game_surf.fill(BLACK)
        sx = random.randint(-shake, shake) if shake > 0 else 0
        sy = random.randint(-shake, shake) if shake > 0 else 0

        mgr.draw(game_surf, ticks)

        for p in pickups:
            if not p.collected: p.draw(game_surf)
        for e in enemies: e.draw(game_surf)
        for proj in projectiles: proj.draw(game_surf)
        player.draw(game_surf)
        # Tree canopy overlay (drawn above Link for depth)
        if not mgr.in_transition:
            mgr.draw_overlays(game_surf, mgr.current, 0, 0, ticks)
        for p in particles: p.draw(game_surf)
        for d in dmg_nums: d.draw(game_surf)

        draw_hud(game_surf, player, 0, enemies)
        dialogue.draw(game_surf)

        # Level name popup
        if msg_t > 0 and not dialogue.active:
            ms = font_md.render(msg, True, WHITE)
            mw = ms.get_width() + 8
            mbx = NATIVE_W // 2 - mw // 2
            pygame.draw.rect(game_surf, (0, 0, 0), (mbx, NATIVE_H // 2 - 10, mw, 16))
            pygame.draw.rect(game_surf, WHITE, (mbx, NATIVE_H // 2 - 10, mw, 16), 1)
            game_surf.blit(ms, (mbx + 4, NATIVE_H // 2 - 8))

        # Death screen
        if state == "dead":
            ov = pygame.Surface((NATIVE_W, NATIVE_H), pygame.SRCALPHA)
            ov.fill((0, 0, 0, 140))
            game_surf.blit(ov, (0, 0))
            gt = font_xl.render("GAME OVER", True, RED)
            game_surf.blit(gt, (NATIVE_W // 2 - gt.get_width() // 2, NATIVE_H // 2 - 40))
            sub = font_sm.render("R:Restart  Q:Quit", True, GRAY)
            game_surf.blit(sub, (NATIVE_W // 2 - sub.get_width() // 2, NATIVE_H // 2 + 40))

        # Scale and display
        scaled = pygame.transform.scale(game_surf, (SCREEN_W, SCREEN_H))
        screen.blit(scaled, (0, 0))
        pygame.display.flip()
        clock.tick(FPS)

    Player._wall = original_wall
    return False
```

- [ ] **Step 3: Add title screen mode selection**

Modify the title screen or main entry to let the player choose overworld vs dungeon mode. In the main entry (lines 1865-1873), replace with:

```python
# ══════════════════════════════════════════
#  MAIN
# ══════════════════════════════════════════
while True:
    if not title_screen():
        break
    if not intro_scroll():
        break
    # Launch overworld mode
    if not overworld_loop():
        break

pygame.quit()
```

- [ ] **Step 4: Test the full integration**

```bash
cd /Users/jasper/Sites/localhost/pygame-zelda && python3 main.py
```

Expected:
- Window auto-scales to monitor size
- Game starts in overworld at Link's House
- Walking to screen edges triggers smooth transitions
- Tiles render with ALttP colors
- Enemies spawn per screen
- F11 toggles fullscreen

- [ ] **Step 5: Commit**

```bash
git add main.py
git commit -m "feat: integrate overworld — auto-scaling, game mode, screen transitions"
```

---

### Task 6: Polish — Minimap, Screen Transition Fix-ups, Final Testing

**Files:**
- Modify: `main.py` (add minimap drawing)
- Modify: `overworld_engine.py` (transition player position wrap)

- [ ] **Step 1: Add overworld minimap to HUD**

Add a `draw_overworld_minimap()` function in `main.py`:

```python
def draw_overworld_minimap(surf, mgr):
    """Draw a small overworld map in the HUD corner."""
    mm_x, mm_y = NATIVE_W - 42, 2
    mm_w, mm_h = 40, 24

    # Background
    pygame.draw.rect(surf, (0, 0, 0), (mm_x - 1, mm_y - 1, mm_w + 2, mm_h + 2))

    # Color per screen
    AREA_COLORS = {
        "boundary": (40, 40, 40),
        "default": (48, 120, 48),
    }

    for col in range(8):
        for row in range(8):
            px = mm_x + col * 5
            py = mm_y + row * 3
            pos = (col, row)
            if pos in mgr.data:
                sd = mgr.data[pos]
                if sd.get("boundary"):
                    c = (40, 40, 40)
                else:
                    name = sd.get("name", "").lower()
                    if "water" in name or "lake" in name or "river" in name:
                        c = (40, 88, 192)
                    elif "mountain" in name or "death" in name:
                        c = (152, 104, 88)
                    elif "castle" in name:
                        c = (200, 200, 208)
                    elif "kakariko" in name or "house" in name:
                        c = (216, 120, 120)
                    elif "desert" in name or "sand" in name:
                        c = (232, 216, 160)
                    elif "swamp" in name:
                        c = (72, 120, 72)
                    elif "lost" in name or "dark" in name:
                        c = (32, 100, 32)
                    elif "grave" in name:
                        c = (90, 74, 58)
                    else:
                        c = (48, 160, 48)
                pygame.draw.rect(surf, c, (px, py, 4, 2))

    # Current screen marker (blinking)
    if mgr.current and (pygame.time.get_ticks() // 300) % 2 == 0:
        cx = mm_x + mgr.current[0] * 5
        cy = mm_y + mgr.current[1] * 3
        pygame.draw.rect(surf, (255, 255, 255), (cx, cy, 4, 2))
    pygame.draw.rect(surf, (180, 180, 180), (mm_x - 1, mm_y - 1, mm_w + 2, mm_h + 2), 1)
```

- [ ] **Step 2: Wire minimap into overworld_loop draw section**

In the `overworld_loop()` draw section, after `draw_hud()`:

```python
        if show_mm:
            draw_overworld_minimap(game_surf, mgr)
```

- [ ] **Step 3: Full play test**

Run the game and verify:
- Auto-scaling works on your screen
- Screen transitions are smooth, player wraps correctly
- Minimap shows in HUD corner, current screen blinks
- Tile colors match ALttP style
- Enemies spawn and combat works
- Cutting grass works in overworld
- F11 fullscreen works

```bash
cd /Users/jasper/Sites/localhost/pygame-zelda && python3 main.py
```

- [ ] **Step 5: Commit**

```bash
git add main.py overworld_engine.py
git commit -m "feat: add overworld minimap, fix transition wrapping, final polish"
```

---

### Task 7: Run All Tests and Final Commit

**Files:** All

- [ ] **Step 1: Run all tests**

```bash
cd /Users/jasper/Sites/localhost/pygame-zelda
python3 tests/test_tiles.py && python3 tests/test_engine.py
```

Expected: All tests pass

- [ ] **Step 2: Run the game for final verification**

```bash
python3 main.py
```

Walk through several screens, test combat, cut grass, check minimap.

- [ ] **Step 3: Final commit if any remaining changes**

```bash
git add -A
git status  # Review what's staged
git commit -m "chore: final cleanup and test verification for overworld implementation"
```
