# ALttP Light World Overworld — Design Spec

## Project Context

This document describes the design for adding a full overworld to our existing Pygame Zelda game. The game currently has 5 dungeon levels played in sequence. We are adding an open-world overworld inspired by *The Legend of Zelda: A Link to the Past* (ALttP, 1991, SNES) — one of the most influential top-down action-adventure games ever made.

### Why This Design?

We studied the original ALttP to understand what makes it feel so good, and identified three pillars:

1. **Screen-based exploration** — the world is divided into screens. Walking to the edge smoothly scrolls to the next screen. This creates a sense of discovery as each new screen reveals a new area.
2. **Tile-based world building** — every element (grass, trees, houses, cliffs) is built from 16×16 pixel tiles on a grid. This constraint forces clean, readable level design.
3. **Layered rendering** — background tiles, then sprites, then overlay effects. This creates depth even in a 2D game.

We keep these design pillars but use modern code architecture: separated modules, cached rendering for performance, and clean data structures.

## Goal

Recreate the full ALttP Light World overworld as a playable map in the existing Pygame Zelda game. Authentic retro feel, modern clean code, solid performance.

## Scope

- Full Light World: 8×8 screen grid (64 screens total, ~38 playable, ~26 boundary)
- Each screen: 16×12 tiles at 16px = 256×192px of tile content
- Full world: 128×96 tiles = 2048×1536px
- All major areas: Death Mountain, Lost Woods, Hyrule Castle, Kakariko Village, Eastern Palace, Link's House, Desert, Lake Hylia, Swamp, Graveyard
- ALttP-accurate color palette and tile art style
- Screen-by-screen transitions (authentic ALttP feel)
- Auto-scaling viewport for MacBook/monitor fullscreen
- No save system (intentional retro decision — progress resets on close, like the original arcade experience)

## Architecture

### File Structure

We split the code into focused modules. Each file has one responsibility:

```
pygame-zelda/
├── main.py                 # Game loop, player, combat (modified)
├── overworld_tiles.py      # Tile definitions, drawing, palette
├── overworld_maps.py       # All 64 screen map data
├── overworld_engine.py     # Screen manager, cache, transitions
```

**Why split?** The current `main.py` is already 1873 lines. Adding 64 screens of map data plus 35+ tile draw functions would push it past 5000 lines — too much for one file. Separating by responsibility makes each file understandable on its own.

### Render Pipeline (per frame)

Every frame, the game draws 5 layers in order, bottom to top:

```
Layer 1: Screen Cache      — pre-rendered static tiles, ONE blit per frame
Layer 2: Animated Tiles    — water shimmer, grass sway (redrawn each frame)
Layer 3: Sprites           — Link, enemies, NPCs, items, projectiles
Layer 4: Overlay           — tree canopy tops (Link walks behind trees)
Layer 5: HUD               — hearts, items, minimap
```

All drawing happens on a native 256×224 `pygame.Surface` (the SNES resolution), then scaled up to display size with integer scaling. This ensures crisp pixels at any screen size.

### Performance Strategy

**The problem:** Drawing 192 tiles (16×12 grid) with `pygame.draw` calls every frame = ~2000 draw operations. For one screen that's fine, but during screen transitions we show two screens = ~4000 draws. And we want 60fps.

**The solution:** Pre-render static tiles once, cache the result.

```
Screen enter → render all 192 tiles ONCE onto a cached pygame.Surface
Every frame  → blit that ONE cached surface (1 draw call)
             → redraw only animated tiles on top (~10-20 draws)
             → draw sprites on top (~5-15 draws)
Total: ~30 draw calls per frame instead of ~2000
```

This is actually how the SNES hardware works — it has a tilemap in video RAM that the PPU (Picture Processing Unit) composites automatically. Our cache simulates this.

**Adjacent screen pre-caching:** When Link enters a screen, we also cache the 4 adjacent screens (up/down/left/right). This way, when Link triggers a screen transition, the next screen's cache is already ready — zero lag.

**Cache invalidation:** If Link cuts tall grass or a bush, we mark the screen cache as dirty and re-render it. This only happens on player interaction, not every frame.

## Tile System

### Tile ID Scheme

The existing game uses tile IDs 0-10 for dungeon tiles. To avoid conflicts, overworld tiles start at ID 100:

```python
# Existing dungeon tiles (unchanged, IDs 0-10)
W, G, P, Q, T, H, S, L, D, F, K = 1, 0, 2, 3, 4, 5, 6, 7, 8, 9, 10

# Overworld tiles (new, IDs 100+)
OW_GRASS       = 100
OW_DARK_GRASS  = 101
OW_PATH        = 102
OW_SAND        = 103
OW_SWAMP       = 104
OW_WATER       = 110
OW_DEEP_WATER  = 111
OW_WATERFALL   = 112
OW_CLIFF_FACE  = 120
OW_CLIFF_TOP   = 121
OW_CLIFF_LEFT  = 122
OW_CLIFF_RIGHT = 123
OW_CLIFF_TL    = 124  # corner: top-left
OW_CLIFF_TR    = 125  # corner: top-right
OW_MOUNTAIN    = 126
OW_CAVE        = 127
OW_STAIRS      = 128
OW_TREE        = 130
OW_DARK_TREE   = 131
OW_BUSH        = 132
OW_TALL_GRASS  = 133
OW_FLOWERS     = 134
OW_HOUSE_ROOF  = 140
OW_HOUSE_WALL  = 141
OW_HOUSE_DOOR  = 142
OW_CASTLE_WALL = 143
OW_CASTLE_TOWER= 144
OW_CASTLE_GATE = 145
OW_BRIDGE      = 146
OW_FENCE       = 147
OW_SIGN        = 148
OW_TORCH       = 149  # animated, for castle gates and dungeon entries
OW_DUNGEON     = 150
OW_CHEST       = 151
OW_BOUNDARY    = 199
```

**Why separate ID ranges?** The existing dungeon levels (0-4) continue using the old tile IDs (0-10) and the existing `draw_tile()` function. The overworld uses new IDs (100+) and a new `draw_overworld_tile()` function. Both can coexist — the game checks which range the tile ID falls in and calls the appropriate renderer.

### Tile Properties

Each tile has properties that the game logic reads for collision, interaction, and rendering decisions:

```python
TILE_PROPS = {
    OW_GRASS:      {"walkable": True,  "cuttable": False, "animated": False, "damage": 0},
    OW_WATER:      {"walkable": False, "cuttable": False, "animated": True,  "damage": 0},
    OW_DEEP_WATER: {"walkable": False, "cuttable": False, "animated": True,  "damage": 0},
    OW_WATERFALL:  {"walkable": False, "cuttable": False, "animated": True,  "damage": 0},
    OW_TALL_GRASS: {"walkable": True,  "cuttable": True,  "animated": True,  "damage": 0},
    OW_BUSH:       {"walkable": False, "cuttable": True,  "animated": False, "damage": 0},
    OW_CLIFF_FACE: {"walkable": False, "cuttable": False, "animated": False, "damage": 0},
    OW_CLIFF_TOP:  {"walkable": True,  "cuttable": False, "animated": False, "damage": 0, "ledge": "down"},
    OW_TORCH:      {"walkable": False, "cuttable": False, "animated": True,  "damage": 0},
    OW_DUNGEON:    {"walkable": True,  "cuttable": False, "animated": False, "damage": 0, "entrance": True},
    # ... etc for all 35 tiles
}
```

### Collision API

The existing game hardcodes collision checks like `if cmap[r][c] in (W, Q, T, L, K)`. For the overworld, we replace this with a clean function that all game objects use:

```python
def is_walkable(tile_id, direction=None):
    """Check if a tile can be walked on.

    Args:
        tile_id: The tile at the target position
        direction: Optional — for ledge tiles, which direction Link is moving

    Returns:
        True if Link/enemies can walk on this tile
    """
    if tile_id >= 100:  # overworld tile
        props = TILE_PROPS.get(tile_id, {})
        if not props.get("walkable", False):
            return False
        # Ledge check: can only walk OFF a ledge (downward), not climb up
        if props.get("ledge") and direction and direction != props["ledge"]:
            return False
        return True
    else:  # dungeon tile — use existing logic
        return tile_id not in (W, Q, T, L, K)
```

**Why a function instead of inline checks?** Three classes (Player, Enemy, Projectile) all need collision detection. A shared function means we fix bugs in one place, and ledge logic (directional one-way tiles) is handled consistently.

### ALttP Color Palette

We studied the actual ALttP sprite data to extract the authentic colors:

```python
# Terrain
GRASS_GREEN     = (72, 184, 72)    # #48b848 — vibrant, not too dark
GRASS_DARK_DOT  = (56, 152, 56)    # #389838 — subtle dot texture
DARK_GRASS      = (48, 136, 48)    # #308830 — Lost Woods undertone
PATH_TAN        = (200, 168, 112)  # #c8a870 — warm dirt
SAND_LIGHT      = (232, 216, 160)  # #e8d8a0 — desert

# Water
WATER_BLUE      = (40, 88, 192)    # #2858c0 — vivid blue
WATER_HIGHLIGHT = (136, 200, 248)  # #88c8f8 — wave shimmer
DEEP_WATER      = (24, 64, 160)    # #1840a0 — lake depths

# Cliffs (THE signature ALttP visual — warm mauve-brown, not plain brown)
CLIFF_MAIN      = (152, 104, 88)   # #986858
CLIFF_SHADOW    = (120, 80, 64)    # #785040
CLIFF_LIGHT     = (168, 120, 104)  # #a87868

# Structures
HOUSE_ROOF      = (216, 120, 120)  # #d87878 — salmon pink (not red!)
HOUSE_WALL      = (232, 208, 160)  # #e8d0a0 — cream
CASTLE_STONE    = (200, 200, 208)  # #c8c8d0 — pale gray

# Vegetation
TREE_GREEN      = (48, 160, 48)    # #30a030 — canopy base
TREE_HIGHLIGHT  = (88, 200, 88)    # #58c858 — top-left highlight
TREE_SHADOW     = (32, 136, 32)    # #208820 — bottom-right shadow
```

### Drawing Approach

All tiles drawn procedurally with `pygame.draw` calls — no external PNG image files needed. Each tile type has a dedicated draw function that renders authentic ALttP pixel patterns at 16×16 resolution.

**Why procedural instead of PNG tilesets?**
- The game is self-contained — no external asset files to manage
- 16×16 pixel tiles only need ~5-10 draw calls each
- Easy to tweak colors and add random variations
- Animations are natural — just vary the drawing based on frame count
- Consistent with how the existing game already draws tiles

Animated tiles (water, torches, tall grass) use a `ticks` parameter for frame-varying animation. Static tiles render identically every call — which is what makes caching possible.

## Screen System

### Coordinate System

The game uses two levels of coordinates:

```
World position = which screen + position within that screen

Screen position: (col, row) — e.g., (3, 4) = Link's House
Local position:  (x, y) in pixels — 0..255 horizontal, 0..191 vertical

The game area on screen starts at y=28 (below HUD, which is 28px tall).
This offset (GAME_Y = 28) is added during rendering, not stored in tile data.
```

**Important coordinate detail:** The native resolution is 256×224. The HUD occupies the top 28 pixels (`HUD_H = 28`). The remaining game area is `GAME_H = NATIVE_H - HUD_H = 196` pixels. However, 12 rows × 16px = 192px of tiles, leaving 4px at the bottom. This matches the original SNES game which had a similar small gap. The screen cache Surface is sized at `(256, 192)` — just the tile area, no HUD, no GAME_Y offset. The `draw_overworld_tile()` functions draw relative to the cache surface (starting at y=0), and the cache is blitted to `game_surf` at offset `(0, GAME_Y)`.

### Overworld Grid (8×8)

The Light World is mapped to an 8×8 grid. Each cell is one screen:

```
     Col 0    Col 1      Col 2      Col 3      Col 4      Col 5      Col 6    Col 7
R0  [BOUND] [BOUND]   [DeathMtW] [DeathMtT] [DeathMtE] [DeathMtC] [BOUND]  [BOUND]
R1  [BOUND] [LostWdN] [LostWdS]  [CastleN]  [CastleTw] [RiverN]   [EastRu] [BOUND]
R2  [BOUND] [ForClr]  [KakariN]  [CastleGt] [CastleGd] [RiverBr]  [EastPl] [BOUND]
R3  [BOUND] [KakariS] [CntrlFW]  [CntrlF]   [CntrlFE]  [RiverS]   [EastFd] [BOUND]
R4  [BOUND] [Gravyrd] [SouthWd]  [LinkHse]  [OpenFld]  [WitchHt]  [EastLk] [BOUND]
R5  [BOUND] [DesrtN]  [DesrtPl]  [SouthFd]  [Meadow]   [LkHylN]   [LkHylE] [BOUND]
R6  [BOUND] [SwampN]  [SwampPl]  [SthShore] [LkHylS]   [LkIsland] [IceCve] [BOUND]
R7  [BOUND] [BOUND]   [BOUND]    [BOUND]    [BOUND]    [BOUND]    [BOUND]  [BOUND]
```

Boundary screens are all identical (solid cliff/mountain tiles) and auto-generated — not hand-coded. This saves defining 26 screens of repetitive data.

### Screen Data Format

Each playable screen is defined as a dictionary with tiles, enemies, and metadata:

```python
OVERWORLD = {
    (3, 4): {
        "name": "Link's House",
        "tiles": [
            [G, G, T, G, G, P, P, G, G, T, G, G, G, G, G, G],
            [G, G, G, G, P, P, G, G, G, G, G, G, T, G, G, G],
            # ... 12 rows × 16 columns
        ],
        "enemies": [("slime", 5, 3), ("slime", 12, 8)],
        # Enemy format: (type, tile_col, tile_row) — converted to pixels by engine
        "npcs": [],
        "items": [("chest", 14, 2)],
        "dungeon": None,  # or dungeon level number (0-4)
    },
}
```

Enemy/NPC/item positions use **tile coordinates** (0-15 col, 0-11 row). The engine multiplies by `TILE` (16) to get pixel positions. This keeps the map data readable and matches how tile grids work.

### Screen Transitions

When Link walks to a screen edge, a smooth transition plays:

1. **Trigger:** Link's position reaches the edge of the game area
2. **Freeze:** Player input is locked, Link plays walk animation
3. **Scroll:** Both screens (current + next) scroll together over 16 frames (~0.27s at 60fps)
4. **Land:** Link appears on the opposite edge of the new screen
5. **Resume:** Player input unlocked, enemies spawn

```python
class ScreenManager:
    def __init__(self):
        self.current_screen = (3, 4)    # Start at Link's House
        self.screen_cache = {}          # (col,row) → pygame.Surface (256×192)
        self.transition = None          # Active transition state or None
        self.cut_tiles = {}             # (col,row) → set of (tile_col,tile_row) cut

    def enter_screen(self, screen_pos):
        """Cache this screen and all adjacent screens."""
        self.current_screen = screen_pos
        self._cache_screen(screen_pos)
        # Pre-cache neighbors for instant transitions
        for dx, dy in [(-1,0), (1,0), (0,-1), (0,1)]:
            adj = (screen_pos[0]+dx, screen_pos[1]+dy)
            if adj in OVERWORLD:
                self._cache_screen(adj)

    def _cache_screen(self, pos):
        """Render all STATIC tiles to a 256×192 Surface."""
        if pos in self.screen_cache:
            return
        surf = pygame.Surface((NATIVE_W, MAP_ROWS * TILE))  # 256×192
        tiles = OVERWORLD[pos]["tiles"]
        cut = self.cut_tiles.get(pos, set())
        for row in range(MAP_ROWS):
            for col in range(MAP_COLS):
                tile = tiles[row][col]
                # If this tile was cut, draw grass instead
                if (col, row) in cut:
                    tile = OW_GRASS
                if not TILE_PROPS[tile].get("animated", False):
                    draw_overworld_tile(surf, tile, col * TILE, row * TILE, ticks=0)
        self.screen_cache[pos] = surf

    def invalidate_cache(self, screen_pos):
        """Force re-render after tile changes (cutting grass)."""
        self.screen_cache.pop(screen_pos, None)

    def start_transition(self, direction):
        """Begin scrolling to adjacent screen."""
        dx, dy = {"left":(-1,0), "right":(1,0), "up":(0,-1), "down":(0,1)}[direction]
        next_pos = (self.current_screen[0]+dx, self.current_screen[1]+dy)
        if next_pos not in OVERWORLD or OVERWORLD[next_pos].get("boundary"):
            return  # Can't go there
        self._cache_screen(next_pos)
        self.transition = {
            "direction": direction,
            "from": self.current_screen,
            "to": next_pos,
            "progress": 0,   # 0..16 frames
            "total": 16,
        }
```

### Edge Detection — How Link Triggers Transitions

The existing `Player.update()` clamps Link's position within the screen. For overworld mode, we change this: instead of clamping at the edge, we detect when Link reaches the boundary and trigger a transition.

```python
# In Player.update(), after movement:
hw = self.w // 2
if self.x - hw < 0:
    screen_mgr.start_transition("left")
elif self.x + hw > NATIVE_W:
    screen_mgr.start_transition("right")
elif self.y < GAME_Y:
    screen_mgr.start_transition("up")
elif self.y + self.h > GAME_Y + MAP_ROWS * TILE:
    screen_mgr.start_transition("down")
```

After transition completes, Link's position wraps to the opposite edge of the new screen.

## Dungeon Entry & Exit

### How Dungeons Connect to the Overworld

Specific overworld screens have dungeon_entrance tiles mapped to dungeon levels:

```python
DUNGEON_ENTRIES = {
    # (screen_col, screen_row, tile_col, tile_row) → dungeon_level
    (2, 2, 8, 5): 0,   # Kakariko area cave → Level 0 (Forest)
    (3, 2, 7, 3): 1,   # Castle gate → Level 1 (Cave)
    (6, 2, 8, 6): 2,   # Eastern Palace → Level 2 (Castle Halls)
    (2, 5, 7, 5): 3,   # Desert Palace → Level 3 (Lava Depths)
    (3, 1, 7, 2): 4,   # Death Mountain Tower → Level 4 (Boss Arena)
}
```

### Entry Trigger

When Link walks onto a `dungeon_entrance` tile and presses the action key (or just walks into it, like ALttP cave entrances):

1. Save overworld state: current screen position, Link's position, cut tiles
2. Load dungeon level using existing `setup_level(level_num)`
3. Game switches to dungeon mode (existing level system)

### Exit Mechanism

The existing stairs tile (`S`) at the end of each dungeon currently advances to the next level. In overworld mode:

- If the dungeon was entered from the overworld → stairs return to overworld at the saved position
- If playing the existing linear dungeon mode → stairs advance to the next level (unchanged)

```python
# Modified stairs handling:
if on_stairs_tile:
    if overworld_return_point:
        # Return to overworld
        screen_mgr.enter_screen(overworld_return_point["screen"])
        player.x = overworld_return_point["x"]
        player.y = overworld_return_point["y"]
        game_mode = "overworld"
    else:
        # Original behavior: next dungeon level
        setup_level(current_level + 1)
```

## Viewport & Scaling

### Auto-Scale

The game detects the monitor size and picks the largest integer scale that fits:

```python
info = pygame.display.Info()
max_scale_w = info.current_w // NATIVE_W   # e.g., 1440/256 = 5
max_scale_h = info.current_h // NATIVE_H   # e.g., 900/224 = 4
SCALE = min(max_scale_w, max_scale_h) - 1  # -1 for taskbar/dock

screen = pygame.display.set_mode((NATIVE_W * SCALE, NATIVE_H * SCALE))
```

**Why integer scaling?** Non-integer scaling (e.g., 3.5×) causes some pixels to be 3px wide and others 4px wide, creating a shimmery/uneven look. Integer scaling keeps every pixel the same size — crisp and clean.

### Fullscreen Toggle (F11)

```python
fullscreen = False

def toggle_fullscreen():
    global fullscreen, SCALE, screen
    fullscreen = not fullscreen
    info = pygame.display.Info()
    if fullscreen:
        SCALE = min(info.current_w // NATIVE_W, info.current_h // NATIVE_H)
        screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
    else:
        SCALE = min(info.current_w // NATIVE_W, info.current_h // NATIVE_H) - 1
        screen = pygame.display.set_mode((NATIVE_W * SCALE, NATIVE_H * SCALE))
```

## Gameplay Features

### Cuttable Vegetation

- Sword attack on `OW_TALL_GRASS` / `OW_BUSH` tiles → replace with `OW_GRASS`
- Random item drops: hearts, rupees, arrows, bombs
- Cut state tracked per-screen in `ScreenManager.cut_tiles`
- Resets when re-entering a screen (authentic ALttP behavior)

### Cliff Ledges

- `OW_CLIFF_TOP` tiles have `"ledge": "down"` property
- Link can walk OFF a ledge downward (small hop animation)
- Cannot climb up — one-way vertical traversal
- Key ALttP navigation mechanic (shortcuts that only work one direction)

### Tree Overlay

- Tree canopy tops render on Layer 4 (above Link sprite)
- Walking near a tree → Link appears partially behind the canopy
- Adds depth perception to the 2D world

### Screen Enemies

- Each screen's `enemies` list defines spawn positions (tile coordinates)
- Engine converts tile coords to pixel coords: `x = tile_col * TILE`, `y = tile_row * TILE + GAME_Y`
- Enemies respawn when re-entering a screen (ALttP behavior)
- Enemy types match the area theme: slimes in grass, bats in caves, soldiers near castle

### Minimap (HUD)

- Small color-coded overview in the HUD corner
- Each screen = 1 colored pixel block (green=field, blue=water, brown=mountain)
- Current screen highlighted with blinking marker
- Optional: fog of war (screens revealed as player visits them)

## Integration with Existing Game

### What Changes in main.py

- Add `game_mode` variable: `"overworld"` or `"dungeon"`
- Overworld mode uses `ScreenManager` for rendering and transitions
- Dungeon mode uses existing `MAPS` and `setup_level()` (unchanged)
- Player collision calls `is_walkable()` instead of hardcoded tile checks
- Auto-scaling replaces hardcoded `SCALE = 3`
- Fullscreen toggle on F11
- Edge detection triggers screen transitions instead of clamping

### What Stays the Same

- Player class (movement, combat, inventory, sprites)
- Enemy classes and AI behavior
- Projectile system (arrows, bombs)
- Sound effects
- HUD rendering (hearts, items — minimap added)
- Controller bridge system (phone-as-controller)
- Sprite sheet loading

## Map Data Strategy

The full overworld is 38 playable screens × 192 tiles each = 7,296 tile values. This is a lot of data to hand-code. Strategy:

1. **Boundary screens (26):** Auto-generated — all `OW_BOUNDARY` tiles. Zero manual work.
2. **Template helpers:** Common patterns as reusable functions:
   ```python
   def grass_field():
       """Return a 16×12 grid of mostly grass with random trees."""
   def water_body(rows):
       """Return rows of deep water with shore edges."""
   ```
3. **Hand-crafted key areas:** Castle, Kakariko, Link's House — carefully designed tile-by-tile for authenticity.
4. **Verification:** A debug mode that renders the full 8×8 minimap to verify screen connectivity and visual consistency.

## Implementation Order

1. **overworld_tiles.py** — tile constants, properties, palette, draw functions for all 35 tile types
2. **overworld_engine.py** — ScreenManager with caching, transitions, collision API
3. **overworld_maps.py** — all screen tile grids, boundary generation, template helpers
4. **main.py modifications** — game_mode switch, auto-scaling, fullscreen, edge detection, dungeon entry/exit
5. **Polish** — minimap, cliff ledge hop animation, tree overlay, cuttable vegetation
