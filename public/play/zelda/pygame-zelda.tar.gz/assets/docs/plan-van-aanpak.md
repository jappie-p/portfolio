# Plan van Aanpak — Zelda Remote Controller

## 1. Projectomschrijving

We bouwen een SNES-style Zelda game in Python/Pygame die je bestuurt vanaf je telefoon via een responsive webpagina en WebSockets. De game draait op de laptop, de controller draait in de browser op je telefoon (werkt op zowel iPhone als Android).

### Gekozen software/techniek
- **Python + Pygame** — game engine (2D game development)
- **Node.js + socket.io** — real-time WebSocket relay server
- **HTML/CSS/JS** — responsive telefoon controller (touch events)
- **Python websockets** — Pygame ontvangt input van de relay server

### Waarom deze keuze? (beoordelingscriterium 1)
- **Python/Pygame** is relevant voor de arbeidsmarkt: Python is de #1 programmeertaal (TIOBE index), Pygame leert game-loops, rendering, collision detection — fundamenten die overal in software terugkomen
- **WebSockets** is de standaard voor real-time communicatie op het web (chat apps, live dashboards, gaming) — direct toepasbaar in webdevelopment
- **Node.js** is een van de meest gevraagde backend-technologieën op de arbeidsmarkt
- Deze combinatie toont beheersing van meerdere talen en technieken tegelijk (Python + JavaScript + HTML/CSS)

### Meerwaarde van deze keuze (beoordelingscriterium 2)
- Combineert frontend (controller UI), backend (relay server) en applicatie (Pygame) — full-stack
- Real-time communicatie tussen apparaten is een veelgevraagde skill (IoT, gaming, dashboards)
- Cross-platform: de controller werkt op elk apparaat met een browser (iPhone, Android, tablet)
- Laat zien dat je meerdere technologieën kunt integreren tot één werkend product

## 2. Architectuur / Technisch Ontwerp (beoordelingscriterium 3)

```
Telefoon (browser)       Node.js server        Pygame game (laptop)
┌──────────────┐        ┌──────────────┐       ┌──────────────┐
│ D-pad         │──ws──>│  Relay server │──ws──>│ Leest input  │
│ A-knop        │       │  (socket.io)  │       │ Beweegt Link │
│ B-knop        │       │              │<──ws──│ Stuurt state │
│ Start-knop    │       └──────────────┘       └──────────────┘
└──────────────┘
```

### Data structure (JSON)
```json
// Controller → Server → Game
{ "type": "input", "dpad": "up", "a": false, "b": false, "start": false }

// Game → Server → Controller (optioneel)
{ "type": "state", "hp": 3, "maxHp": 5, "area": "overworld" }
```

### Componenten
1. **Pygame Game** (Python) — de Zelda game, ontvangt input via WebSocket ipv keyboard
2. **Relay Server** (Node.js + socket.io) — ontvangt controller input, stuurt door naar game
3. **Controller** (HTML/CSS/JS) — responsive webpagina met touch controls
4. **Optioneel: State display** — controller toont HP/items van de game

## 3. Functioneel Ontwerp

### Controller (telefoon) — minimaal 4 interacties
| # | Interactie | Type | Functie |
|---|-----------|------|---------|
| 1 | D-pad | Touch buttons | Link bewegen (4 richtingen) |
| 2 | A-knop | Touch button | Zwaard aanval |
| 3 | B-knop | Touch button | Item gebruiken |
| 4 | Start | Touch button | Pause/menu |
| 5 | Optioneel: gyroscoop | DeviceOrientation | Alternatief sturen |

### Game (laptop)
- SNES-style top-down Zelda game
- Meerdere gebieden (overworld, dungeons)
- Vijanden met AI
- Items en combat
- HUD met health, items

## 4. Leerdoelen (SMART) — beoordelingscriterium D1-K1-W1.1

### Leerdoel 1: Pygame game development
- **Specifiek:** Ik kan een volledige 2D game bouwen in Pygame met sprites, collision detection, enemy AI en meerdere levels
- **Meetbaar:** De game heeft minimaal 2 gebieden, 3 soorten vijanden en een werkend combat systeem
- **Acceptabel:** Past bij mijn interesse in game development en software engineering
- **Realistisch:** Pygame documentatie en tutorials zijn beschikbaar, basis Python kennis is aanwezig
- **Tijdgebonden:** Game is werkend in week 2 (27 maart)

### Leerdoel 2: WebSocket real-time communicatie
- **Specifiek:** Ik kan een WebSocket verbinding opzetten tussen een browser en een Python applicatie via een Node.js relay server
- **Meetbaar:** Input van de telefoon is binnen <50ms zichtbaar in de game
- **Acceptabel:** WebSockets zijn behandeld in Opdracht 2 van deze module
- **Realistisch:** De ws/socket.io libraries zijn goed gedocumenteerd
- **Tijdgebonden:** WebSocket koppeling werkt in week 3 (3 april)

### Leerdoel 3: Responsive touch interface
- **Specifiek:** Ik kan een responsive controller UI bouwen die goed werkt op verschillende telefoons (iOS Safari + Android Chrome)
- **Meetbaar:** Controller werkt op minimaal 3 verschillende telefoons, geen mis-taps, duidelijke feedback
- **Acceptabel:** Sluit aan bij webdevelopment skills die relevant zijn voor mijn opleiding
- **Realistisch:** HTML/CSS/JS kennis is aanwezig, touch events zijn goed gedocumenteerd
- **Tijdgebonden:** Controller UI is af in week 3 (3 april)

### Leerdoel 4: Integratie en projectmanagement
- **Specifiek:** Ik kan meerdere technologieën (Python, Node.js, HTML) integreren tot één werkend systeem en dit documenteren
- **Meetbaar:** Alle componenten werken samen, code staat in Git, README beschrijft installatie
- **Acceptabel:** Full-stack integratie is een essentiële skill voor software developers
- **Realistisch:** Elk component is individueel al haalbaar, integratie is de uitdaging
- **Tijdgebonden:** Volledig werkend systeem in week 4 (10 april)

## 5. Planning / Milestones — beoordelingscriterium D1-K1-W1.2

### Milestone 1: Fundament (Week 1 — 16-20 maart)
- [x] Plan van aanpak
- [x] Technisch ontwerp
- [x] Functioneel ontwerp
- [ ] Planning (dit document)
- [ ] Git repo opzetten + docenten uitnodigen
- [ ] GO/NOGO vrijdag

### Milestone 2: Game werkend (Week 2 — 23-27 maart)
- [ ] Pygame game afronden (combat, enemies, dungeons)
- [ ] Game input abstraheren (keyboard → input handler)
- [ ] Node.js relay server opzetten (socket.io)
- [ ] Eerste WebSocket test (browser → server → console)

### Milestone 3: Controller + koppeling (Week 3 — 30 maart - 3 april)
- [ ] Controller UI bouwen (D-pad, A, B, Start)
- [ ] Touch events implementeren
- [ ] Pygame WebSocket client (python-socketio)
- [ ] Controller → Server → Game koppeling werkend
- [ ] Testen op verschillende telefoons

### Milestone 4: Polish + extras (Week 4 — 6-10 april)
- [ ] Bugs fixen, latency optimaliseren
- [ ] Game state terugsturen naar controller (HP display)
- [ ] Usability verbeteren (haptic feedback, visuele feedback)
- [ ] Code opschonen, README schrijven
- [ ] Final release in Git

### Milestone 5: Presentatie + inleveren (Week 5 — 13-17 april)
- [ ] Video presentatie maken (proces + product)
- [ ] Alle documenten in Git repo (zip)
- [ ] Retrospective
- [ ] Feedback geven en ontvangen

## 6. Deelproducten — beoordelingscriterium D1-K1-W1.3

1. **Plan van Aanpak** (dit document)
2. **Pygame Zelda Game** (Python broncode + sprites)
3. **Node.js Relay Server** (server.js + package.json)
4. **Controller Webpagina** (HTML/CSS/JS)
5. **Git Repository** (alle code + documentatie)
6. **Video Presentatie** (proces + product demo)
7. **Sprint verslagen** (planning, review, retrospective per week)

## 7. Feedback verwerking — beoordelingscriterium D1-K1-W1.4

- Na elke sprint review: feedback van docent documenteren
- Feedback verwerken in volgende sprint
- In presentatie laten zien: welke feedback, wat ermee gedaan, hoe het product verbeterd is

## 8. Reflectie — beoordelingscriterium D1-K1-W1.5

Wordt aan het einde van het project geschreven:
- Wat ging goed / wat kon beter?
- Zijn de leerdoelen behaald?
- Wat heb ik geleerd over het leerproces zelf?
- Hoe past dit in mijn verdere ontwikkeling als software developer?

## 9. Team

- 4 personen
- Taakverdeling: nog bespreken
- Communicatie: nog bespreken
- Git workflow: feature branches → main

## 10. Benodigdheden

- Python 3 + Pygame
- Node.js + npm
- Telefoons (3x iPhone, 1x Samsung) — controller is een webpagina, werkt overal
- Git repo (GitHub)
- Code editor (VS Code)
