# Functioneel Ontwerp — Zelda Remote Controller

## 1. Inleiding

Dit document beschrijft de functionaliteiten van het project vanuit gebruikersperspectief. De wireframes tonen hoe de controller (telefoon) en het spelscherm (laptop) eruitzien en welke interacties de gebruiker kan uitvoeren.

## 2. Overzicht

Het systeem bestaat uit twee schermen:

1. **Controller** — een webpagina op de telefoon waarmee de speler Link bestuurt
2. **Game** — een Pygame venster op de laptop dat de Zelda game toont

De telefoon stuurt input via WebSockets naar een relay server, die het doorstuurt naar de game. Optioneel stuurt de game state (HP, items) terug naar de controller.

## 3. Wireframe: Controller (telefoon)

```
┌──────────────────────────────┐
│      ZELDA CONTROLLER        │
│                              │
│   ♥ ♥ ♥ ♥ ♥ ♥    ⚔ 🏹 💣   │
│   HP: 6/6       Wapen: Sword │
│                              │
│        ┌───┐                 │
│        │ ▲ │          ┌───┐  │
│   ┌───┐├───┤┌───┐     │ A │  │
│   │ ◄ ││   ││ ► │     └───┘  │
│   └───┘├───┤└───┘     ┌───┐  │
│        │ ▼ │          │ B │  │
│        └───┘          └───┘  │
│                              │
│  ┌──────┐         ┌───────┐  │
│  │SELECT│         │ START │  │
│  └──────┘         └───────┘  │
└──────────────────────────────┘
```

### Beschrijving elementen

| Element | Type | Functie |
|---------|------|---------|
| D-pad (▲▼◄►) | Touch buttons | Link bewegen in 4 richtingen |
| A-knop | Touch button | Huidig wapen gebruiken (zwaard/boog/bom) |
| B-knop | Touch button | Secundaire actie / interactie |
| Start | Touch button | Pauze menu openen/sluiten |
| Select | Touch button | Wisselen tussen wapens (sword → bow → bomb) |
| HP display | Status indicator | Toont huidige health als hartjes |
| Wapen indicator | Status indicator | Toont actief wapen |

## 4. Wireframe: Game scherm (laptop)

```
┌──────────────────────────────────────────┐
│ HUD                                      │
│ ♥♥♥♥♥♥  RUPEES:12  ⚔SWORD  🏹15  💣5   │
├──────────────────────────────────────────┤
│                                          │
│   🌲  🌲          🌲  🌲                │
│                                          │
│        👾                    👾          │
│                                          │
│              🧝 (Link)                   │
│                                          │
│        👾              👾               │
│                                          │
│   🌲  🌲          🌲  🌲                │
│                                          │
│              [Stairs]                    │
├──────────────────────────────────────────┤
│ The Forest                               │
└──────────────────────────────────────────┘
```

### Beschrijving elementen

| Element | Beschrijving |
|---------|-------------|
| HUD (bovenbalk) | Health (hartjes), rupees, actief wapen, pijlen, bommen |
| Speelveld | 16×12 tile grid met gras, muren, bomen, water, lava, paden |
| Link (speler) | Geanimeerd karakter met loop- en aanvalanimaties |
| Vijanden | Slimes, vleermuizen, skeletten, ridders, magiërs, eindbaas |
| NPCs | Geven dialoog/hints wanneer de speler dichtbij komt |
| Kisten | Bevatten wapen-upgrades (boog, bommen, hart container) |
| Pickups | Hartjes, rupees, pijlen, bommen — spawnen ook uit gras |
| Trappen | Verschijnen als alle vijanden verslagen zijn → volgend level |

## 5. Functionaliteiten

### 5.1 Speler besturing (via controller)

| # | Functionaliteit | Input | Resultaat |
|---|----------------|-------|-----------|
| 1 | Bewegen | D-pad (4 richtingen) | Link loopt in aangegeven richting, diagonaal mogelijk |
| 2 | Zwaard aanval | A-knop | Link zwaait zwaard in kijkrichting (sweep animatie) |
| 3 | Boog schieten | A-knop (bij boog) | Pijl wordt afgeschoten in kijkrichting (kost 1 pijl) |
| 4 | Bom plaatsen | A-knop (bij bom) | Bom wordt geplaatst, ontploft na 2 seconden (kost 1 bom) |
| 5 | Wapen wisselen | Select-knop | Wisselt tussen zwaard, boog en bommen |
| 6 | Pauze | Start-knop | Pauzeer/hervat het spel |

### 5.2 Game systemen

| Systeem | Beschrijving |
|---------|-------------|
| Combat | Zwaard raakt vijanden in boog-sweep, boog schiet rechte pijlen, bommen doen area damage |
| Health | 6 HP (3 hartjes), uitbreidbaar met hart containers. Invincibility frames na schade |
| Vijand AI | Slimes bewegen willekeurig, vleermuizen vliegen zigzag, skeletten/ridders volgen speler, magiërs schieten projectielen |
| Boss (Shadow Lord) | 3 fases: (1) langzaam + enkele vuurbal, (2) sneller + dubbele vuurbal, (3) snel + driedubbele vuurbal |
| Levels | 5 gebieden: Forest → Cave → Castle → Lava Depths → Boss Arena |
| Progressie | Alle vijanden verslaan opent de trap naar het volgende level |
| Items | Boog (chest level 1), bommen (chest level 2), hart container (chest level 3) |
| Minimap | TAB toont overzichtskaart met posities van speler en vijanden |

### 5.3 Controller ↔ Game communicatie

| Richting | Data | Voorbeeld |
|----------|------|-----------|
| Controller → Game | Input state | `{ "type": "input", "dpad": "up", "a": true, "b": false, "start": false }` |
| Game → Controller | Game state | `{ "type": "state", "hp": 6, "maxHp": 6, "weapon": "sword", "area": "The Forest" }` |

## 6. Gebruikersscenario's

### Scenario 1: Spel starten
1. Speler start de Pygame game op de laptop
2. Speler opent de controller URL op de telefoon
3. WebSocket verbinding wordt automatisch gemaakt
4. Title screen verschijnt, speler drukt Start
5. Intro tekst scrollt, spel begint in The Forest

### Scenario 2: Level doorlopen
1. Speler beweegt Link met D-pad naar vijanden
2. Speler drukt A om met zwaard aan te vallen
3. Vijanden worden verslagen, drops verschijnen
4. Na alle vijanden verslagen: trap verschijnt
5. Speler loopt naar trap → transition naar volgend level

### Scenario 3: Boss verslaan
1. Level 4: Shadow Lord verschijnt in de arena
2. Speler ontwijkt vuurballen met D-pad
3. Speler valt aan met zwaard (A) en boog/bommen
4. Boss gaat door 3 fases (sneller, meer projectielen)
5. Boss verslagen → win scherm met statistieken
