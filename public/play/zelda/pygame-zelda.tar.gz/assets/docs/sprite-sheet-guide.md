# Link Sprite Sheet Guide
## `link_sprites.png` — 688×365 pixels

Based on SNES A Link to the Past sprite format. Teal background `(0, 128, 128)` = transparent.

### How the sheet works
- Each sprite is approximately **16×24** pixels (Link's body)
- Wider sprites (24-28px wide) are **attack frames** with sword extended
- Sprites are arranged in horizontal rows by **animation type + direction**
- Sprites within a row are animation frames, left to right
- Left-facing = horizontally flip Right-facing sprites

### Known animation states (from ALttP)
Stand, Walk, Attack (sword swing), Sword primed, Spin attack,
Dash, Push, Pull, Carry, Swim, Tread water, Fall, Bonk, Shield

---

## ROW-BY-ROW LAYOUT

### Row 0 — WALK/STAND DOWN (y ≈ 1-26)
31 sprites, mostly 16×24

| # | X | Y | Size | Notes |
|---|---|---|------|-------|
| 0 | 1 | 3 | 16×24 | Walk down frame 1 ← USED |
| 1 | 19 | 3 | 16×24 | Walk down frame 2 ← USED |
| 2 | 36 | 2 | 16×25 | Slightly taller — attack/action? |
| 3 | 53 | 1 | 16×26 | Tallest — sword down? |
| 4 | 70 | 3 | 16×24 | |
| 5 | 87 | 3 | 16×24 | |
| 6 | 104 | 2 | 16×25 | |
| 7 | 121 | 1 | 16×26 | |
| 8 | 138 | 3 | 16×24 | |
| 9 | 156 | 3 | 16×24 | |
| 10 | 173 | 4 | 16×23 | Shorter — shield? push? |
| 11 | 190 | 5 | 16×22 | |
| 12 | 207 | 3 | 16×24 | |
| 13 | 224 | 4 | 16×23 | |
| 14 | 241 | 5 | 16×22 | |
| 15 | 259 | 4 | 16×23 | |
| 16 | 276 | 5 | 16×22 | |
| 17 | 294 | 6 | 16×21 | |
| 18 | 311 | 5 | 16×22 | |
| 19 | 329 | 5 | 16×22 | |
| 20 | 346 | 6 | 16×21 | |
| 21 | 363 | 7 | 16×20 | Shortest |
| 22 | 381 | 6 | 16×21 | |
| 23 | 398 | 6 | 16×21 | |
| 24 | 416 | 3 | 16×24 | |
| 25 | 433 | 4 | 16×23 | |
| 26 | 450 | 5 | 16×22 | |
| 27 | 467 | 3 | 16×24 | |
| 28 | 484 | 4 | 16×23 | |
| 29 | 501 | 5 | 16×22 | |
| 30 | 519 | 3 | 16×24 | |

**Likely groups (verify visually):**
- 0-1: Walk cycle (2 frames)
- 2-3: Sword attack down (arm raised)
- 4-7: Another walk/action cycle
- 8-9: Stand/idle
- 10-23: Push, pull, carry, shield, swim (facing down)
- 24-30: More action states

---

### Row 1 — WALK/STAND UP (y ≈ 28-55)
35 sprites, mostly 16×22-24

| # | X | Y | Size | Notes |
|---|---|---|------|-------|
| 31 | 1 | 32 | 16×24 | Walk up frame 1 ← USED |
| 32 | 18 | 33 | 16×23 | Walk up frame 2 (old, jitters!) |
| 33 | 35 | 34 | 16×22 | |
| 34 | 52 | 37 | 16×19 | Very short — crouching? |
| 35 | 69 | 34 | 16×22 | |
| 36 | 86 | 33 | 16×23 | |
| 37 | 104 | 32 | 16×24 | Walk up frame 2 ALT ← NOW USED (matches #31 size!) |
| 38 | 121 | 33 | 16×23 | |
| 39 | 139 | 33 | 16×23 | |
| 40 | 156 | 34 | 16×22 | |
| 41 | 174 | 32 | 16×24 | |
| 42 | 191 | 33 | 16×23 | |
| 43 | 208 | 32 | 16×24 | |
| 44 | 226 | 33 | 16×23 | |
| 45 | 244 | 32 | 16×24 | |
| 46 | 261 | 33 | 17×23 | Slightly wider |
| 47 | 279 | 32 | 16×24 | |
| 48 | 297 | 32 | 16×24 | |
| 49 | 314 | 33 | 16×23 | |
| 50 | 331 | 34 | 16×22 | |
| 51 | 349 | 32 | 16×24 | |
| 52 | 366 | 32 | 16×24 | |
| 53 | 383 | 34 | 16×22 | |
| 54 | 401 | 32 | 16×24 | |
| 55 | 418 | 33 | 16×23 | |
| 56 | 435 | 33 | 16×23 | |
| 57 | 452 | 33 | 16×23 | |
| 58 | 470 | 29 | 16×23 | |
| 59 | 487 | 30 | 16×22 | |
| 60 | 505 | 28 | 16×24 | |
| 61 | 522 | 28 | 16×24 | |
| 62 | 539 | 28 | 16×24 | |
| 63 | 556 | 28 | 18×28 | **LARGE — sword attack up?** |
| 64 | 575 | 28 | 27×24 | **LARGE — sword swing up frame 1** |
| 65 | 603 | 28 | 28×24 | **LARGE — sword swing up frame 2** |

**Key sprites:**
- 31 + 37: Best walk up pair (both 16×24, no jitter)
- 63: 18×28 — attack preparation?
- 64-65: 27×24, 28×24 — **SWORD ATTACK UP** (Link with sword extending to the side)

---

### Row 2 — WALK/STAND RIGHT (y ≈ 57-82)
~25 sprites, mostly 17×24

| # | X | Y | Size | Notes |
|---|---|---|------|-------|
| 66 | 1 | 58 | 17×24 | Walk right frame 1 ← USED |
| 67 | 20 | 57 | 17×25 | Walk right frame 2 (old) |
| 68 | 38 | 57 | 16×25 | |
| 69 | 55 | 58 | 17×24 | Walk right frame 2 ALT ← NOW USED |
| 70 | 73 | 58 | 17×24 | |
| 71 | 91 | 57 | 17×25 | |
| 72 | 109 | 57 | 16×25 | |
| 73 | 126 | 58 | 16×24 | |
| ... | | | | More action frames facing right |

**Flip horizontally for LEFT-facing sprites.**

---

### Row 3 — ACTIONS RIGHT (y ≈ 84-107)
~40 sprites, mixed sizes. Contains some large sprites.

| # | X | Y | Size | Notes |
|---|---|---|------|-------|
| 91 | 1 | 85 | 17×23 | |
| 92 | 19 | 85 | 17×23 | |
| 93 | 37 | 86 | 19×22 | Wider — holding something? |
| **94** | **57** | **86** | **23×22** | **LARGE — sword attack right?** |
| 95 | 81 | 86 | 19×22 | |
| 96 | 101 | 85 | 16×23 | |
| 97 | 119 | 84 | 18×24 | |
| 98 | 138 | 84 | 17×24 | |
| ... | | | | |
| **121** | **574** | **88** | **21×20** | **Attack/action frame** |
| **122** | **596** | **88** | **24×20** | **LARGE — attack frame** |
| **123** | **641** | **88** | **21×20** | **Attack frame** |

---

### Row 4 — MORE ACTIONS DOWN (y ≈ 109-134)

| # | X | Y | Size | Notes |
|---|---|---|------|-------|
| 126-135 | various | ~109-111 | 16×24-26 | Facing down actions |
| **161** | **52** | **136** | **16×29** | **TALLEST sprite — sword overhead?** |

---

### Row 5 — MORE WALK/ACTION VARIANTS (y ≈ 139-165)

| # | X | Y | Size | Notes |
|---|---|---|------|-------|
| 161-195 | various | ~139-143 | 16×22-26 | Mixed |
| **191** | **576** | **141** | **28×24** | **LARGE — sword attack** |
| **192** | **605** | **141** | **26×24** | **LARGE — sword attack** |

---

### Row 6 — SMALL TILES + SPECIAL (y ≈ 166-190)

| # | X | Y | Size | Notes |
|---|---|---|------|-------|
| 212 | 1 | 168 | 16×16 | Small tile (hat? item?) |
| 213 | 18 | 168 | 16×23 | |
| 219 | 177 | 175 | 24×16 | **Wide — carrying item?** |
| **228** | **541** | **189** | **147×96** | **HUGE — composite/reference image** |

---

### Row 7+ — WALK VARIANTS & ITEMS (y ≈ 193+)

More walk animation variants, sword sprites, small item tiles.

| # | X | Y | Size | Notes |
|---|---|---|------|-------|
| 261-264 | 549-642 | 201 | 16×24 | Walk down variants |
| 265-268 | 1-44 | 218 | 7-29 wide | **Sword sprites (standalone)** |
| 277 | 105 | 218 | 36×12 | **Long sword/weapon sprite** |

---

### Row 10+ — EQUIPMENT & EFFECTS (y ≈ 286+)

16×16 tiles — likely **items, equipment, bunny Link, effects**

---

## RECOMMENDED SPRITE PAIRS FOR ANIMATION

### Walk cycles (2-frame each):
| Direction | Frame 1 | Frame 2 | Size |
|-----------|---------|---------|------|
| Down | #0 (1,3) | #1 (19,3) | 16×24 |
| Up | #31 (1,32) | #37 (104,32) | 16×24 |
| Right | #66 (1,58) | #69 (55,58) | 17×24 |
| Left | flip Right | flip Right | 17×24 |

### Attack frames (large sprites):
| Direction | Frame 1 | Frame 2 | Size |
|-----------|---------|---------|------|
| Up | #64 (575,28) | #65 (603,28) | 27-28×24 |
| Down | #2 (36,2) | #3 (53,1) | 16×25-26 |
| Right | #94 (57,86) | #95 (81,86) | 23×22 / 19×22 |
| Left | flip Right | flip Right | — |

---

## TODO: VISUAL VERIFICATION NEEDED

The Y ranges and sizes above are from automated extraction. To properly name sprites,
you need to **visually check** each sprite to confirm:

1. Which sprites are walk vs stand vs push vs pull vs carry
2. Which are sword swing frames (1-3 per direction)
3. Which are shield-holding poses
4. Which are swimming frames
5. Which are special (falling, bonking, bunny transformation)

**Tip:** Open `link_sprites.png` in an image editor with grid overlay at 16px intervals.
The teal color `#008080` is the transparent background.

---

## OTHER SPRITE SHEETS IN `sprites/`

| File | Contents |
|------|----------|
| `overworld.png` | Grass, trees, paths, water tiles |
| `dungeon.png` | Cave/castle floor, walls, doors |
| `items.png` | Weapons, pickups, keys, hearts |
| `enemies_light.png` | Light-world enemy sprites |
| `knights.png` | Armored knight enemy variants |
| `stalfos.png` | Skeleton enemy frames |
| `npcs.png` | NPC character sprites |
| `ganon.png` | Boss sprites |

These sheets also need coordinate mapping — same process: extract, identify, name.

## Sources
- [The Spriters Resource — Link](https://www.spriters-resource.com/snes/legendofzeldaalinktothepast/asset/7584/) (688×365 sheet, 37.76 KB)
- [SpriteSomething](https://github.com/Artheau/SpriteSomething) — 28×8 grid of 16×16 tiles, animation manifest
- [Zeldix — Sword Animation Data](https://www.zeldix.net/t1877-link-s-sword-animation-technical-data) — 3 sword states: swing, hold/stab, spin
- [ALttP Sprite Collections](https://snesrev.github.io/sprites-gfx/snes/zelda3/link/)
