# De Opdracht

# Inhoud Module

---

---

- Omschrijving
    
    Deel 1:
    De beginnend beroepsbeoefenaar doet een onderzoek naar de meeste relevante software voor de arbeidsmarkt waarin hij wil gaan werken. Hij onderzoekt de technologische veranderingen en de toepassingen van de software in dit werkveld waarin hij wil
    werken. Hij analyseert de verzamelde gegevens en maakt een keuze voor een software(pakket) waarin hij zich wil verdiepen op basis van marktrelevantie, loopbaankeuze en beschikbare tijd. In overleg met zijn leidinggevende bepaalt hij de software waarin
    hij zich gaat verdiepen. Hij beschrijft het keuzeproces en de onderbouwing van de keuze op basis van de verzamelde gegevens in een verslag.
    
    **Deel 2:
    *De beginnend beroepsbeoefenaar reflecteert op zijn kennis en vaardigheden en formuleert hierbij leerdoelen. Hij plant zijn stappen in deskundigheidsontwikkeling. Hij volgt de instructie en maakt de eventuele opdrachten voor de gekozen software. Hij selecteert en hanteert de juiste materialen (o.a. boeken, online cursus, video lessen). Hij bewaakt de voortgang en onderneemt actie wanneer dit nodig is.*
    
- Gedrag
    
    De beginnende beroepsbeoefenaar:
    
    - Maakt een zorgvuldige analyse van de voor hem relevante software.
    - Onderbouwt zijn keuze naar de leidinggevende met steekhoudende argumenten.
    - Verwoordt nauwkeurig en helder het onderzochte en de keuze.
    - Formuleert haalbare leerdoelen.
    - Maakt een realistisch tijdsplanning voor het leertraject.
    - Maakt een verantwoorde afweging voor het opdelen van de verschillende inhoudelijke onderdelen.
    - Zet zich proactief in bij het volgen van instructie.
    - Formuleert relevante vragen en weet die juist te adresseren
    
- Competenties
    - Overtuigen en beïnvloeden
    - Formuleren en rapporteren
    - Analyseren
    - Vakdeskundigheid toepassen
    - Leren
    - Plannen en organiseren
    
- Dit moet je weten
    
    *De beginnend beroepsbeoefenaar:*
    
    - heeft kennis van de relevantie van software voor de arbeidsmarkt waarin de beginnend beroepsbeoefenaar gaat werken
    - heeft actuele kennis van de gekozen software die relevant is voor de arbeidsmarkt waarin de beginnend beroepsbeoefenaar gaat werken
    - heeft specialistische kennis van de gekozen software die relevant is voor de arbeidsmarkt waarin de beginnend beroepsbeoefenaar gaat werken
    - heeft brede kennis van het leerproces om de software eigen te maken
    
- Dit moet je kunnen
    - kan overtuigings- en onderhandelingstechnieken toepassen in het gesprek met de leidinggevende over de gekozen software
    - kan het leerproces sturen
    - kan specialistische kennis van de software toepassen
    
- Complexiteit
    
    Het eigen maken van de software vindt plaats in een gestructureerde omgeving. De kennis die de beginnend beroepsbeoefenaar opdoet is specialistisch dan wel breed, omdat hij zich verdiept in de software die hij reeds in basis heeft aangeleerd of in nieuwe software die in het verlengde ligt van hetgeen reeds is aangeboden. Het zelfstandig vormgeven van het leertraject en het inschatten van de benodigde werkzaamheden in tijd maken het werk complex.
    
- Verantwoordelijkheid en zelfstandigheid
    
    De beginnend beroepsbeoefenaar heeft een uitvoerende rol. Hij komt met een eigen initiatief voor een keuze van een software(pakket). Hij stemt zijn keuze af met zijn leidinggevende. Hij is verantwoordelijk voor zijn eigen leertraject. Hij draagt verantwoordelijkheid voor de resultaten van zijn eigen handelingen en keuzes.
    

# Uitleg module

---

**Hoe gaat deze module in zijn werk?**

Deze module sluit je af met: 

- **1. Je proces**
    
    **Een presentatie** van het proces waarin **het keuzeproces en de onderbouwing van de keuze voor een software / programmeertaal / programmeertechniek beschreven staat** en waarin het leerproces gedocumenteerd word.
    

- **2. Je eindproduct**
    
    **Een eindproduct gemaakt met de gekozen software / programmeertaal / programmeertechniek.**
    

# Beoordelingscriteria in deze module

---

*Beoordelingscriteria zijn de eisen waar je aan moet voldoen om de module met een voldoende te kunnen halen. Je moet van sommige zaken aantonen dat je er kennis van hebt en van weer andere zaken moet je aantonen dat je het ook echt kunt.
Hieronder zie je de criteria uitgesplitst in de twee onderdelen: wat je moet kennen en kunnen voor deel 1 en deel 2 van deze module.*

---

[Beoordelingscriteria module](https://www.notion.so/1b569bb8092d81e181b4e455180ec374?pvs=21)

[Maakt een keuze voor software](https://www.notion.so/1b569bb8092d81c0a7ceef604031a0a8?pvs=21)

[Maakt zich de software eigen](https://www.notion.so/1b569bb8092d813fb05cffebdc9dd4b9?pvs=21)

---
# Achtergrondinformatie

Een goede beheersing van specifieke software en/of programmeertalen/technieken is voor een beginnend beroepsbeoefenaar essentieel. Met de continue ontwikkelingen van nieuwe software, technieken en programmeertalen zal een professional zich in zijn beroep zichzelf altijd moeten blijven ontwikkelen.

Met deze module wordt je voorbereid op je gekozen specialisatie en op een “leven lang leren” door niet voor te schrijven welke software/programmeertaal/techniek je moet gebruiken maar door je te laten richten op de manier waarop je deze kunt aanleren. En dat je kan aantonen dat je de software/programmeertaal/techniek daadwerkelijk beheerst.

Je maakt zelf een keuze voor een bepaalde software, programmeertaal of programmeertechniek; je stelt jouw eigen leerdoelen op; je bedenkt een project waarmee je jouw leerdoelen kunt bereiken; je maakt hier een plan voor; en werkt deze vervolgens uit.

# Planning

# Planning

|  | Acties - Activiteiten |  |
| --- | --- | --- |
| **Week 1:
16/3 - 20/3** |   **1) Plan van aanpak opstellen
  2) planning maken (Trello)
  3) Technisch ontwerp
  4) Functioneel ontwerp
  5) Goed laten keuren (GO/NOGO)** |  |
| Maandag |   • Start Module 7.2
  • Kick-off (door MKU)
  • Documenten uitwerken (1,2,3,4) | 2CSD-WDV1 |
| Dinsdag |   • Kick-off (door LST)
  • Documenten uitwerken (1,2,3,4) | 2CSD-WDV2 |
| Woensdag |   • Documenten uitwerken (1,2,3,4) | 2CSD-WDV1
2CSD-WDV2 |
| Donderdag | - | - |
| Vrijdag |   • Inleveren gitrepo URL
  • Inleveren documenten (gitrepo)
  • Goed laten keuren (5)

  • GO? Start met programmeren. | 2CSD-WDV1
2CSD-WDV2 |
|  |  |  |
| **Week 2:
23/3 - 27/3** |   1) Product uitwerken
  2) Planning monitoren
  3) Gitrepo bijhouden
 |  |
| Maandag | • Programmeren / uitwerken product. | 2CSD-WDV1 |
| Dinsdag | • Programmeren / uitwerken product. | 2CSD-WDV2 |
| Woensdag | • Programmeren / uitwerken product. | 2CSD-WDV1
2CSD-WDV2 |
| Donderdag | DOCENTEN STUDIEDAG | GEEN LES |
| Vrijdag | • Programmeren / uitwerken product. | 2CSD-WDV1
2CSD-WDV2 |
|  |  |  |
| **Week 3:
30/3 - 3/4** |   1) Product uitwerken
  2) Planning monitoren
  3) Gitrepo bijhouden
 |  |
| Maandag | • Programmeren / uitwerken product. | 2CSD-WDV1 |
| Dinsdag | • Programmeren / uitwerken product. | 2CSD-WDV2 |
| Woensdag | • Programmeren / uitwerken product. | 2CSD-WDV1
2CSD-WDV2 |
| Donderdag | - | - |
| Vrijdag | GOEDE VRIJDAG | GEEN LES |
|  |  |  |
| **Week 4:
6/4 - 10/4** |   1) Product uitwerken / afronden
  2) Planning monitoren
  3) Gitrepo bijhouden
 |  |
| Maandag | TWEEDE PAASDAG | GEEN LES |
| Dinsdag | • Programmeren / uitwerken product. | 2CSD-WDV2 |
| Woensdag | • Programmeren / uitwerken product. | 2CSD-WDV1
2CSD-WDV2 |
| Donderdag | - | - |
| Vrijdag | • Programmeren / uitwerken product. | 2CSD-WDV1
2CSD-WDV2 |
|  |  |  |
| **Week 5:
13/4 - 17/4** |   **1) Ontwikkelweek
  2) Inleveren
  3) Video presentatie maken
  4) Retrospective**
 |  |
| Maandag |   • Video presentatie maken | 2CSD-WDV1 |
| Dinsdag |   • Video presentatie maken | 2CSD-WDV2 |
| Woensdag |   • Inleveren product (gitrepo)
  • Inleveren video presentatie (gitrepo) | 2CSD-WDV1
2CSD-WDV2 |
| Donderdag | - | - |
| Vrijdag |   • Retrospective
  • Video presentaties bekijken
  • Feedback geven en ontvangen | 2CSD-WDV1
2CSD-WDV2 |

# 7.2 - Module - Remote controller

👋  en welkom bij de Module **Remote Controller**. 

In de snel veranderende wereld van technologie is het voor elke professional van groot belang om continu op de hoogte te blijven van de nieuwste software, programmeertalen en technieken. Deze module biedt jou de kans om je verder te specialiseren, maar vooral om te leren hoe je jezelf nieuwe tools en vaardigheden eigen kunt maken – een onmisbare skill in jouw toekomstige carrière.

In plaats van een vaste set software of programmeertalen voor te schrijven, krijg je in deze module de vrijheid om je eigen keuzes te maken. Jij bepaalt welke software, programmeertaal of techniek je wilt leren, stelt je eigen leerdoelen op, en werkt aan een project waarmee je die doelen kunt bereiken. 

*Wil je leren hoe je een eigen remote controller bouwt met behulp van Websockets? Dit deze module geeft je de kans om je eigen project te realiseren: een systeem waarmee je jouw computer (browser) kunt besturen via je telefoon. Leer hoe je communicatie opzet tussen apparaten, data overdraagt via Websockets en een intuïtieve interface creëert. Zo ontwikkel je praktische vaardigheden die direct toepasbaar zijn in de wereld van webontwikkeling en IoT. Ben jij klaar om de controle over je computer in handen te nemen met je eigen smartphone?*

We wensen je veel succes en vooral veel plezier met het ontdekken en ontwikkelen van jouw talenten!

## ⬇️ Snel naar een pagina:

---

[De Opdracht](https://www.notion.so/De-Opdracht-1b569bb8092d817ba159fb69b2fb93d3?pvs=21)

[Maakt een keuze voor software](https://www.notion.so/1b569bb8092d81c0a7ceef604031a0a8?pvs=21)

[Maakt zich de software eigen](https://www.notion.so/1b569bb8092d813fb05cffebdc9dd4b9?pvs=21)

[Achtergrondinformatie](https://www.notion.so/Achtergrondinformatie-1b569bb8092d81a8b035d1ad840b848d?pvs=21)

[Inspiratie](https://www.notion.so/Inspiratie-1b569bb8092d8189992edf1288ae86fd?pvs=21)

---

[Kennisbank](https://www.notion.so/1b569bb8092d81888275ce380132e245?pvs=21)

---

[Planning](https://www.notion.so/Planning-1b569bb8092d8166869ff9803fd1ce5a?pvs=21)

---

<aside>
⏰

## Inleveren

Zorg ervoor dat er in alles in een zip doet en in je eigen GIT-repo gaat opleveren:

1. Je voorbereidende documenten in een map
2. Je eindproduct (code) in een map
3. Je video presentaties
    1. Leg je proces uit in je video presentatie
    2. Leg je product uit in je video presentatie
    3. Kijk goed naar de beoordelingscriteria
    

Tip: **Past de video niet in jouw gitrepo? Verzin dan een alternatief voor de video:** 
- Plaats een Youtube-video en voeg de URL in een txt-bestand toe aan jouw gitrepo.
- Zorg voor extreem goede compressie in de video.
- Misschien heb je zelf nog creatieve oplossingen? Jouw Gitrepo moet ons leiden naar jouw gekozen oplossing.

</aside>

# Opdrachten

[Opdracht 1: Kennismaken met interfaces](https://www.notion.so/Opdracht-1-Kennismaken-met-interfaces-1b669bb8092d80a8968ef598e5b8b0c1?pvs=21)

[Opdracht 2: Websockets NPM](https://www.notion.so/Opdracht-2-Websockets-NPM-1b669bb8092d80d99bf3f792cf833601?pvs=21)

[Opdracht 3: **Usability**](https://www.notion.so/Opdracht-3-Usability-1b669bb8092d804eadfcee1edc21f528?pvs=21)

[Backup Challenge: Remote Controller bouwen](https://www.notion.so/Backup-Challenge-Remote-Controller-bouwen-1b669bb8092d80fdb95bfde3b4855a8f?pvs=21)

![inspiration.png](https://s3-us-west-2.amazonaws.com/secure.notion-static.com/0375a75a-2abb-42a7-b9ee-1de382b1f289/inspiration.png)

# Opdracht 1: Kennismaken met interfaces

## Binnen deze opdracht maak je kennis met verschillende soorten interfaces.

Dat doe je door samen op zoek te gaan naar voorbeelden en die te analyseren.

<aside>
👉 Presentatie bij de deze opdracht:

[Opdracht-1.pptx](https://s3-us-west-2.amazonaws.com/secure.notion-static.com/bb5c9adc-0e28-4306-b412-63665ca87738/Opdracht-1.pptx)

</aside>

## Stap 1

### Groepjes maken en onderwerpen vaststellen.

Maak groepjes van minimaal 3 en maximaal 5 studenten.
Geef aan de docent door met wie je een groepje wilt vormen.

De docent noteert de namen van de studenten in je groepje 
en geeft jullie twee onderwerpen voor interfaces (1 fysieke en 1 digitale).
Met die onderwerpen gaan jullie de opdracht uitvoeren. 

De docent hanteert hierbij de volgende lijst:

**Digitaal**

- webshop (bol.com/amazon.nl)
- email client/site/app (gmail/outlook)
- streaming service (YouTube, Netflix, Twitch, Spotify) (mobile/desktop)

**Fysiek**

- dashboard van een auto (elektrisch/traditioneel)
- camera (spiegelreflex/systeem camera/compact)
- printer (Xerox, HP, Epson)

## Stap 2

### Voorbeelden zoeken en uitprinten

**Zoek** bij de twee onderwerpen die jullie hebben gekregen samen met jullie groepje voorbeelden van interfaces die horen bij de twee onderwerpen die jullie hebben gekregen van de docent.

**Verzamel** 3 *verschillende* ****afbeeldingen per onderwerp.
Voor de voorbeelden van de fysieke interfaces kunt je gebruik maken van [Google Image search](https://images.google.com/).
Voor de voorbeelden van de digitale interfaces kun je een screenshot maken van de (startpagina) van de websites die horen bij het onderwerp dat je hebt gekregen.

**Print** deze afbeeldingen zo groot mogelijk uit op A3 papier.
Aan het einde van stap 2 heb je 6 prints.

## Stap 3

### Analyseren

Vanaf nu heb je jullie computers niet meer nodig, deze kunnen dus dicht.
Leg alle prints overzichtelijk naast elkaar op een grote tafel zodat je 
er makkelijk met alle studenten uit je groepje naar kunt kijken.

Analyseer nu met elkaar de 3 prints die horen bij het eerste onderwerp.
Daarbij ga je op zoek naar overeenkomsten en verschillen:

**Omcirkel op de prints opvallende overeenkomsten met GROEN 
en zet daar een uniek nummer bij.

Omcirkel op de prints opvallende verschillen met ROOD 
en zet daar een uniek nummer bij.**

Noteer op een leeg A3 papier de nummers en schrijf daarna een zinnige 
opmerking bij het nummer waarmee je omschrijft wat er te zien is op de 
print en wat er daarbij opvalt.

Als je hier mee klaar bent doe je hetzelfde voor de 3 prints bij het tweede onderwerp,

Aan het einde van stap 3 heb je 6 prints met daarop rode en groene cirkels voorzien van unieke nummers.
Daarnaast heb je ook twee A3 vellen waarop een toelichting is gegeven bij de nummers op de prints.

<aside>
👉 TIP: bij de analyse kun je bijvoorbeeld kijken naar kermerken als: 
de plaats, de vorm of het kleurgebruik van onderdelen van de interface.

</aside>

![voorbeeld_5.jpg](https://s3-us-west-2.amazonaws.com/secure.notion-static.com/2a7fac49-6f22-4ca4-ac19-59f7f5cdab3e/voorbeeld_5.jpg)

## Stap 4

### Conclusies trekken uit de analyse

Bespreek met elkaar wat er volgens jullie van belang is voor een goede/optimale gebruikerservaring van een interface.
Maak daarbij gebruik van de analyse die je daarvoor met elkaar hebt gemaakt.

Noteer op een leeg A3 papier **5 regels** die volgens jullie het meest van belang zijn voor een goede/gebruikerservaring van een interface.

<aside>
👉 NOTE: in vakjargon worden de afkortingen UX en UI gebruikt. UX staat 
daarbij voor User Experience (=gebruikerservaring) en UI staat voor User Interface.

</aside>

## Stap 5

### **Presenteren en elkaars werk bekijken**

In het laatste half uur van de les presenteren een aantal groepen (die 
door de docent worden uitgekozen) hun uitwerking van de opdracht voor de klas.
Daarbij komen alle onderwerpen 1 keer aan bod. (in totaal worden er dus 6 presentaties gegeven)
Tijdens de presentaties worden opvallende verschillen en overeenkomsten gepresenteerd en de conclusie die daaruit kan worden getrokken.

# Globale tijdsplanning

09:00 – 09:10	inloop 
09:10 – 09:35	kick off module en toelichting opdracht 1
09:35 – 09:45 	stap 1 opdracht
09:45 – 10:00 	stap 2 opdracht
10:00 – 10:15 	pauze 
10:15 – 10:45 	stap 3 opdracht
10:45 – 11:15 	stap 4 opdracht
11:15 – 11:45 	stap 5 opdracht

# Benodigdheden voor de opdracht

- groene markers
- rode markers
- zwarte markers
- A3 papier

[Groepen van opdracht 1](https://www.notion.so/Groepen-van-opdracht-1-1b669bb8092d817dabf7c76bfad43042?pvs=21)
# Opdracht 2: Websockets NPM

# **Workshop: Real-time communicatie met WebSockets en NPM**

**Doel:** Studenten leren WebSockets te installeren en gebruiken met behulp van NPM om real-time communicatie in webapplicaties te implementeren.

<aside>
⚠️

**Benodigdheden:**

- Node.js en NPM geïnstalleerd
- Code-editor (bijv. VS Code)
- Basis kennis van JavaScript en Node.js
</aside>

### **Stap 1: Project setup**

1. **Maak een nieuwe projectmap aan:**
    - Open je terminal en navigeer naar de map waar je je project wilt maken.
    - Voer het commando `mkdir websocket-workshop` uit om een nieuwe map te maken.
    - Navigeer naar de nieuwe map met `cd websocket-workshop`.
2. **Initialiseer een nieuw Node.js project:**
    - Voer het commando `npm init -y` uit om een `package.json`bestand te maken met standaardinstellingen.

### **Stap 2: WebSocket library installeren**

1. **Installeer de `ws` library:**
    - Voer het commando `npm install ws` uit om de `ws` library te installeren, die we zullen gebruiken voor WebSocket-functionaliteit.

### **Stap 3: Server-side code (Node.js)**

1. **Maak een `server.js` bestand:**
    - Open je code-editor en maak een nieuw bestand genaamd `server.js` in de projectmap.
2. **Voeg de volgende code toe aan `server.js`:**

JavaScript

```jsx
    const WebSocket = require('ws');
    const wss = new WebSocket.Server({ port: 8080 });

    wss.on('connection', ws => {
      console.log('Client connected');

      ws.on('message', message => {
        console.log(`Received: ${message}`);
        wss.clients.forEach(client => {
          if (client !== ws && client.readyState === WebSocket.OPEN) {
            client.send(`Server: ${message}`);
          }
        });
      });

      ws.on('close', () => {
        console.log('Client disconnected');
      });
    });

    console.log('WebSocket server started on port 8080');
```

### **Stap 4: Client-side code (HTML/JavaScript)**

1. **Maak een `index.html` bestand:**
    - Maak een nieuw bestand genaamd `index.html` in de projectmap.
2. **Voeg de volgende code toe aan `index.html`:**

HTML

```jsx
    <!DOCTYPE html>
    <html>
    <head>
      <title>WebSocket Client</title>
    </head>
    <body>
      <input type="text" id="messageInput">
      <button id="sendButton">Send</button>
      <ul id="messages"></ul>

      <script>
        const socket = new WebSocket('ws://localhost:8080');
        const messageInput = document.getElementById('messageInput');
        const sendButton = document.getElementById('sendButton');
        const messages = document.getElementById('messages');

        socket.addEventListener('open', () => {
          console.log('Connected to server');
        });

        socket.addEventListener('message', event => {
          const message = document.createElement('li');
          message.textContent = event.data;
          messages.appendChild(message);
        });

        socket.addEventListener('close', () => {
          console.log('Disconnected from server');
        });

        sendButton.addEventListener('click', () => {
          const message = messageInput.value;
          socket.send(message);
          messageInput.value = '';
        });
      </script>
    </body>
    </html>
```

### **Stap 5: De applicatie uitvoeren**

1. **Start de server:**
    - Open je terminal en navigeer naar de projectmap.
    - Voer het commando `node server.js` uit om de server te starten.
2. **Open de client:**
    - Open `index.html` in je webbrowser.
3. **Test de applicatie:**
    - Open meerdere browser vensters met de `index.html` pagina.
    - Typ een bericht in het invoerveld en klik op "Send".
    - Het bericht zou in alle browser vensters moeten verschijnen.

<aside>
⚠️

### Stap 6:

Maak het script nu zo dat ik ook mijn eigen berichten terug kan vinden.

Voeg ook toe dat je elkaar kan “Ping”-en! Speel dan een geluidje af bij de ander.

</aside>

# Opdracht 3: **Usability**

### Binnen deze opdracht maak je 5 voorbeelden die horen bij de 
10 principes over Usability, 
opgesteld door Jakob Nielsen.
Je voert deze opdracht uit met een groepje (minimaal 3 - maximaal 5 studenten)

<aside>
👉 Presentatie bij deze opdracht

[Opdracht-3.pptx](attachment:ba46f04d-3005-4105-a2a9-2a658c904945:Opdracht-3.pptx)

</aside>

# Wat zijn de *10 Usability heuristics* oftewel 
de 10 vuistregels voor gebruiksvriendelijkheid?

> "In 1994, Jakob Nielsen created a framework to help people 
design interactions in ways that are most efficient to the user. He 
identified ten general principles for interaction design. These 
principles can be used as broad guidelines to help platforms deliver 
seamless and consistent user experiences. They are not concrete rules 
that must be abided by, but they are incredibly useful when evaluating 
systems for usability, and initially creating digital interactions."
> 

## Stap 1

### Groepjes vormen

Maak groepjes van 3 tot 5 personen en geef deze groep door aan je docent.

## Stap 2

### **Onderzoek en schetsen**

Bestudeer en bespreek samen met de studenten in je groepje de 10 principes van Jakob Nielsen.

Gebruik daarbij eventueel de links die onder aan deze pagina zijn opgenomen.

Maak bij elk principe een klein schetsje van hoe dit principe voor jou als webdeveloper van belang zou kunnen zijn bij het maken van websites/applicaties.

## Stap 3

### **Uitwerken**

Kies 5 principes uit en maak daarbij nu een werkend voorbeeld waarin dit principe wordt toegepast.
Maak onderling ook afspraken over hoe jullie daarbij aan het werk gaan.

- Gebruiken jullie de schetsen die je hebt gemaakt bij stap 2?
- Verdelen jullie de voorbeelden onderling?
- Werken jullie samen aan een voorbeeld?

## Stap 4

### **Presentatie/inleveren**

Aan het eind van de les lever je met je groepje je 5 uitgewerkte voorbeelden in.
Als er daarvoor tijd is, kunnen een aantal uitwerkingen gepresenteerd worden in de les.

# Informatie over het onderwerp:

[**10 Usability Heuristics Every Designer Should Know**](https://uxdesign.cc/10-usability-heuristics-every-designer-should-know-129b9779ac53)

[**10 Usability Heuristics with Examples**](https://blog.prototypr.io/10-usability-heuristics-with-examples-4a81ada920c)
# Backup Challenge: Remote Controller bouwen

<aside>
💡

Kom je er niet uit met node.js en socket.io, dan biedt deze challenge wellicht uitkomst.

Hier staan een aantal voorbeelden van een Remote Controller met Javascript, Ajax en PHP

</aside>

> "Afstandsbediening is een techniek waarbij iets (een 
toestel of een verschijnsel) niet ter plaatse, maar vanaf een zekere 
afstand wordt bestuurd, geregeld of bediend."

https://nl.wikipedia.org/wiki/Afstandsbediening
> 

## Het project

### Tijdens de 2e en 3e week van Module 7.2 - Interface, werk je aan een challenge: het bouwen van een remote controller.

<aside>
👉 presentatie bij Challenge

[Challenge-V2.pptx](https://s3-us-west-2.amazonaws.com/secure.notion-static.com/68e19cf9-d04b-41f7-9616-2ef89ffcc4ec/Challenge-V2.pptx)

</aside>

Binnen het project maak je twee webpagina's.
De eerste pagina is een 'controller' (afstandsbediening) die je kunt gebruiken op een mobile device.
De tweede pagina maakt het 'onderwerp' dat je met de 'controller' bedient zichtbaar.

## Voorbeelden

### Voorbeeld 1

Op je telefoon open je een pagina met daarop een lichtknopje. https://www.kunstman.nl/lightSwitchExample/lightSwitch.html

Op je laptop open je een pagina die het resultaat van het bedienen van het lichtknopje weergeeft. https://www.kunstman.nl/lightSwitchExample/light.html

### Voorbeeld 2

Op je telefoon open je een pagina met daarop een 'controller'. https://ttijs.gluwebsite.nl/interface/examples/json/controller.html

Op je laptop open je eenpagina met het onderwerp dat je bedient met deze 'controller'. https://ttijs.gluwebsite.nl/interface/examples/json/car.html

### Voorbeeld 3

Besteed aandacht aan de vormgeving. https://www.kunstman.nl/light/

<aside>
👉 De source-code van deze voorbeelden kun je vinden op:

https://github.com/martijnkunstman/GLU-projectInterface

Daar staat ook een voorbeeld met Websocket, die je moet draaien met node

</aside>

### Voorbeeld 4

Ramped: https://player.vimeo.com/video/74110866?#t=8m45s

# Samenwerking

BIj deze opdracht werk je in duo’s. Daarbij gebruik je samen een 1 gitrepo.

Ook gebruik je de principes van (small scale) Scrum, zoals een 

project-backlog, sprint-planning, sprint reviews en retrospectives, etc

- [ ]  **Plan van Aanpak**
Wat jullie gaan doen en hoe dat gaan aanpakken?
- [ ]  **Project Backlog**: 
Een opsomming van wat je allemaal moet maken. Daarbij laat je je inspirren door de *User Stories* die er zijn: wat moet er allemaal kunnen. Bedenkt hierbij niet alleen waarom, maar ook hoe! Daaruit haal je de dingen die jullie gaan maken.
En hak deze to-do’s in **hapklare** brokken!

Maak je hiervoor een online Kanban-bord? Lever dan de link daarnaartoe in. 
Tip: Gebruik daarvoor Trello, Notion, Git-projects, etc.
- [ ]  **Sprint planning**
Maak een planning met een taakverdeling: wie gaat wat wanneer doen.
Maak een sprint-planning elke week.

![big-buger-eat-buger.gif](https://s3-us-west-2.amazonaws.com/secure.notion-static.com/4a189a45-0155-4ad2-9766-a087ac59beb0/big-buger-eat-buger.gif)

- [ ]  **Sprint review**
Aan het eind van elke week laat je aan de docent zien hoever jullie zijn. Als je overleg hebt gehad, maak daarvan dan aantekeningen en lever deze ook in.
- [ ]  **Sprint retrospective**
Direct na de sprint review gaan jullie na wat er anders moet, beter kan. Maak daarvan dan aantekeningen en lever deze ook in.
- [ ]  Hierna maak je weer een nieuwe **Sprint planning voor de volgende week**

Zie voor meer uitleg over Small Scale Scrum de [website van Agile Alliance](https://www.agilealliance.org/resources/experience-reports/small-scale-scrum/)

![fig1-small-scale-scrum-framework-1024x828.png](https://s3-us-west-2.amazonaws.com/secure.notion-static.com/0c02ebfd-1fe7-4c34-9925-1d0b09d1a51c/fig1-small-scale-scrum-framework-1024x828.png)

# Planning

### Maandag week 1

- Kick-off van het project
- Duo's vormen en afspraken maken over taakverdeling en samenwerking.
- Concept bedenken en uitschetsen op papier (eenvoudig/uitdagend/passend bij je eigen skills en de tijd die er is)
- Concept laten goedkeuren door docent
- Opleveren documenten
via het inleverloket tekstbestand inleveren met het adres van een GIT-repo.
In de Gitrepo vandaag inleveren: Plan van Aanpak, Project Backlog, Sprint Planning.

<aside>
👉 Repo op private? Nodig docenten uit:

- Stroomer
- janvanos
- martijnkunstman
- keun
- ttijs

</aside>

### Dinsdag week 1

- Ontwerp maken (Low-fidelity prototype) in HTML en CSS voor de layout en vormgeving van de controller en het onderwerp.
- Opleveren documenten via een GIT-commit (concept/ontwerpschetsen, lofi prototype/Proof of Concept (PoC))

### Vrijdag week 1

- Data structure vaststellen (welke data heb ik nodig voor het besturen en hoe leg ik die vast?)
- Data type vaststellen (csv, json, database fields)
- Datasource vaststellen (file op de server, database, server variabele)
- Datasource en dataconnectie programmeren (PHP, nodeJS)
- Code documenteren (handleiding voor installatie en gebruik, README.md)
- Eerst sprint af:
Sprint review en retrospective met docent. Demo van de first release
- Nieuwe sprint planning maken
- Opleveren via een GIT-commit (code, verslag van review en retrospective, sprint planning)

### Maandag week 2

- Nieuwe sprint-planning maken indien nog niet gedaan
- bouwen aan product
- Pushen naar Git!

### Dinsdag week 2

- Ochtend: Bouwen
- Middag: testen + debuggen + bugfixing
- Einde: Final release opleveren (via GIT)

### Vrijdag week 2

- Sprint review, retrospective
- Gebruikerstest en beoordeling (=beoordelingsformulier/review (sterren))
- Presentaties van Final Release!

# De controller

De lay-out van deze pagina is responsive zodat de controller goed zichtbaar is op mobile devices van verschillende formaten.

De controller kun je bouwen met componenten van een JavaScript en/of CSS library of framework, maar dat is niet verplicht.

In feite is de controller een eenvoudige user interface, waarbij usability van belang is.
De controller moet op zijn minst 4 verschillende interacties kunnen uitvoeren. 
Voorbeelden: knop, joystick, tekst invoer, slider, draaiknop, gyroscoop, swipe/gesture, drag/drop.

# Het onderwerp

Je bent volledig vrij in de keuze voor het onderwerp dat je bedient. 
Voorbeelden:

Een machine. Bijvoorbeeld een graafmachine of een grijparm.  
Een voertuig. Bijvoorbeeld een drone of een tank. 
Een personage. Bijvoorbeeld een robot of pacman. 
Een apparaat. Bijvoorbeeld een televisie of een magnetron.

Ga na welke data er nodig is om het onderwerp te bedienen. 
Denk daarbij bijvoorbeeld aan: 
Positie, snelheid, schieten, hoogte, open/dicht, grootte, aan/uit, etc.

<aside>
👉 Als je er aan toe bent, mag je hierbij ook gebruik maken van VR of AR, met [A-Frame](https://aframe.io/) of [Three-js](https://threejs.org/) bijvoorbeeld. We hebben een aantal [Oculus Quest](https://www.theverge.com/21437674/oculus-quest-2-review-features-photos)’s ter beschikking!

</aside>

# Beoordeling

peer-review en ingeleverde producten

[review-pdf.pdf](https://s3-us-west-2.amazonaws.com/secure.notion-static.com/96215b16-e757-4e9e-96f9-8471acb5cea7/review-pdf.pdf)

---

## Inspiratie

![inspiration.png](https://s3-us-west-2.amazonaws.com/secure.notion-static.com/0f199d04-6a2d-4d2e-8113-c98b7dc2fb14/inspiration.png)

![keychatter.webp](https://s3-us-west-2.amazonaws.com/secure.notion-static.com/f0323b19-516c-4a09-b8fe-411c286738c7/keychatter.webp)

![theramin.jpg](https://s3-us-west-2.amazonaws.com/secure.notion-static.com/8ceba46e-e7e3-4d54-a87c-9e95611a542e/theramin.jpg)

![quest-oculus.jpg](https://s3-us-west-2.amazonaws.com/secure.notion-static.com/fe57da88-f154-4979-978d-cbfcd3f316fe/quest-oculus.jpg)

![ironman.jpg](https://s3-us-west-2.amazonaws.com/secure.notion-static.com/5e9dbe11-f7a0-42cc-942f-0bf359ba200a/ironman.jpg)

[Projecttroepen](https://www.notion.so/Projecttroepen-1b669bb8092d81f19db1dd77924fe2db?pvs=21)