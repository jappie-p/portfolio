# Concept: Zelda Remote Controller

Bestuur Link in een SNES-style Zelda game (Pygame) vanaf je telefoon via WebSockets.

## Wat we al hebben
- Werkende Pygame Zelda game (1550 regels) met sprites, enemies, dungeons, combat
- Keyboard controls die we vervangen met WebSocket input

## Architectuur
```
Telefoon (browser)       Node.js server        Pygame game (laptop)
┌──────────────┐        ┌──────────────┐       ┌──────────────┐
│ D-pad/Joystick│──ws──>│  Relay server │──ws──>│ Leest input  │
│ A = zwaard    │       │              │       │ Beweegt Link │
│ B = item      │       │              │<──ws──│ Stuurt state │
│ Start = pause │       └──────────────┘       └──────────────┘
└──────────────┘
```

## Controller (telefoon) — 4+ interacties
1. D-pad of joystick (touch) — bewegen (omhoog/omlaag/links/rechts)
2. A-knop — zwaard aanval
3. B-knop — item gebruiken
4. Start — pause/menu
5. Optioneel: gyroscoop sturen, shake = special attack

## Scherm (laptop)
- Pygame venster met de Zelda game (al werkend)
- Link beweegt op basis van WebSocket data ipv keyboard

## Tech
- Python + Pygame (game, al klaar)
- Python websockets library (game ontvangt input)
- Node.js + socket.io (relay server)
- HTML/CSS/JS (controller op telefoon, touch events)
- Git repo

## Wat moet er gebouwd worden
1. Node.js relay server (klein, stuurt JSON door)
2. Pygame WebSocket client (vervangt keyboard input)
3. Telefoon controller UI (responsive, touch-friendly)
4. Optioneel: game state terugsturen naar telefoon (HP, items, map)

## Nog bespreken met team
- Taakverdeling (wie doet controller UI, wie doet WebSocket koppeling?)
- Planning (Trello/Notion)
- Multiplayer? (2 telefoons = co-op?)
