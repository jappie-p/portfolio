const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*' }
});

const PORT = process.env.PORT || 3000;

// Serve the controller UI
app.use(express.static(path.join(__dirname, '..', 'controller')));

// Track connections
let gameClient = null;
const controllers = {}; // player number → socket

io.on('connection', (socket) => {
  socket.on('register', (role, playerNum) => {
    socket.role = role;

    if (role === 'game') {
      gameClient = socket;
      console.log('[+] Game (bridge) connected');
    } else if (role === 'controller') {
      socket.playerNum = playerNum || 1;
      controllers[socket.playerNum] = socket;
      console.log('[+] Player ' + socket.playerNum + ' controller connected');
    }
  });

  // Controller sends input → tag with player number → relay to game
  socket.on('input', (data) => {
    if (gameClient && gameClient.connected) {
      data.player = socket.playerNum || 1;
      gameClient.emit('input', data);
    }
  });

  // Game sends state → relay to all controllers
  socket.on('game_state', (data) => {
    socket.broadcast.emit('game_state', data);
  });

  socket.on('disconnect', () => {
    if (socket.role === 'game') {
      gameClient = null;
      console.log('[-] Game (bridge) disconnected');
    } else if (socket.role === 'controller') {
      delete controllers[socket.playerNum];
      console.log('[-] Player ' + socket.playerNum + ' disconnected');
    }
  });
});

server.listen(PORT, '0.0.0.0', () => {
  // Get local IP for phone access
  const nets = require('os').networkInterfaces();
  let localIP = 'localhost';
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      if (net.family === 'IPv4' && !net.internal) {
        localIP = net.address;
        break;
      }
    }
  }

  console.log('');
  console.log('  Zelda Relay Server running');
  console.log('  ─────────────────────────');
  console.log('  Controller:  http://' + localIP + ':' + PORT);
  console.log('  Local:       http://localhost:' + PORT);
  console.log('');
});
